import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/app_models.dart';
import '../../core/network/app_api.dart';

final gimbalControllerProvider =
    AutoDisposeAsyncNotifierProvider<GimbalController, GimbalState>(
  GimbalController.new,
);

class GimbalController extends AutoDisposeAsyncNotifier<GimbalState> {
  Timer? _timer;

  @override
  Future<GimbalState> build() async {
    ref.onDispose(() {
      _timer?.cancel();
    });
    _timer = Timer.periodic(const Duration(seconds: 2), (_) {
      refresh();
    });
    return _load();
  }

  Future<void> refresh() async {
    state = await AsyncValue.guard(_load);
  }

  Future<void> move({
    double yaw = 0,
    double pitch = 0,
    int autoStopMs = 350,
    String reason = 'flutter-manual',
  }) async {
    final api = ref.read(appApiProvider);
    await api.getJson(
      '/api/vision/gimbal/command',
      queryParameters: {
        'yaw_rpm': '$yaw',
        'pitch_rpm': '$pitch',
        'auto_stop_ms': '$autoStopMs',
        'reason': reason,
      },
    );
    await refresh();
  }

  Future<void> stop() async {
    final api = ref.read(appApiProvider);
    await api.getJson(
      '/api/vision/gimbal/command',
      queryParameters: {'mode': 'stop', 'reason': 'flutter-stop'},
    );
    await refresh();
  }

  Future<void> setLaser(bool on) async {
    final api = ref.read(appApiProvider);
    await api.getJson(
      '/api/vision/gimbal/command',
      queryParameters: {
        'laser_enabled': on ? '1' : '0',
        'reason': 'flutter-laser',
      },
    );
    await refresh();
  }

  Future<void> setEnabled(bool on) async {
    final api = ref.read(appApiProvider);
    await api.getJson(
      '/api/vision/gimbal/command',
      queryParameters: {
        'enabled': on ? '1' : '0',
        'reason': 'flutter-enable',
      },
    );
    await refresh();
  }

  Future<void> setLock(bool on) async {
    final api = ref.read(appApiProvider);
    if (on) {
      await api.getJson(
        '/api/vision/gimbal/lock/start',
        queryParameters: {
          'target': 'person',
          'detector': 'face',
          'reason': 'flutter-lock',
        },
      );
    } else {
      await api.getJson(
        '/api/vision/gimbal/lock/stop',
        queryParameters: {'reason': 'flutter-unlock'},
      );
    }
    await refresh();
  }

  Future<GimbalState> _load() async {
    final api = ref.read(appApiProvider);
    final results = await Future.wait([
      api.getJson('/api/vision/gimbal/status'),
      api.getJson('/api/vision/gimbal/lock/status'),
    ]);
    final status = results[0];
    final lock = results[1];

    final connected = status['ok'] == true;
    final active = _truthy(
      status['active'] ??
          status['enabled'] ??
          status['gimbal_enabled'] ??
          status['online'],
    );
    final locked = _truthy(lock['active'] ?? lock['locked'] ?? lock['ok']);
    final rows = <StatusRow>[
      StatusRow(
        label: '设备状态',
        value: connected ? '在线' : '离线',
        level: connected ? StatusLevel.good : StatusLevel.bad,
      ),
      StatusRow(
        label: '云台使能',
        value: active ? 'ON' : 'OFF',
        level: active ? StatusLevel.good : StatusLevel.warn,
      ),
      StatusRow(
        label: '锁定跟踪',
        value: locked ? 'ACTIVE' : 'IDLE',
        level: locked ? StatusLevel.good : StatusLevel.normal,
      ),
      StatusRow(label: '状态信息', value: status['message']?.toString() ?? '-'),
      StatusRow(label: '锁定信息', value: lock['message']?.toString() ?? '-'),
    ];

    return GimbalState(
      connected: connected,
      active: active,
      locked: locked,
      message:
          status['message']?.toString() ?? lock['message']?.toString() ?? '',
      statusRows: rows,
    );
  }

  bool _truthy(Object? value) {
    if (value is bool) {
      return value;
    }
    final raw = value?.toString().toLowerCase() ?? '';
    return raw == '1' || raw == 'true' || raw == 'on' || raw == 'active';
  }
}
