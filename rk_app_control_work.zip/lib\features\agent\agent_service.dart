import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

final imagePickerProvider = Provider<ImagePicker>((ref) => ImagePicker());

class PickedMedia {
  const PickedMedia({
    required this.file,
    required this.name,
    required this.extension,
  });

  final File file;
  final String name;
  final String extension;
}

class AgentService {
  AgentService(this._picker);

  final ImagePicker _picker;

  Future<PickedMedia?> pickVideo() async {
    final file = await _picker.pickVideo(source: ImageSource.gallery);
    if (file == null) {
      return null;
    }
    return _toMedia(file);
  }

  Future<PickedMedia?> pickImage() async {
    final file = await _picker.pickImage(source: ImageSource.gallery);
    if (file == null) {
      return null;
    }
    return _toMedia(file);
  }

  PickedMedia _toMedia(XFile file) {
    final normalized = file.name.trim();
    final dot = normalized.lastIndexOf('.');
    final extension = dot >= 0 ? normalized.substring(dot + 1).toLowerCase() : '';
    return PickedMedia(
      file: File(file.path),
      name: normalized,
      extension: extension,
    );
  }
}

final agentServiceProvider = Provider<AgentService>((ref) {
  return AgentService(ref.watch(imagePickerProvider));
});
