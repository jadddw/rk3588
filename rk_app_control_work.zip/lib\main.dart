import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/models/app_models.dart';
import 'core/network/app_api.dart';
import 'core/theme/app_theme.dart';
import 'features/agent/agent_page.dart';
import 'features/gimbal/gimbal_page.dart';
import 'features/settings/settings_controller.dart';
import 'features/video/video_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: RkControlApp()));
}

class RkControlApp extends ConsumerWidget {
  const RkControlApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsControllerProvider);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ELF2 Control',
      theme: buildAppTheme(),
      home: settings.when(
        data: (_) => const AccountGatePage(),
        loading: () => const _BootScreen(),
        error: (error, _) => _BootError(error: error),
      ),
    );
  }
}

class AccountGatePage extends ConsumerStatefulWidget {
  const AccountGatePage({super.key});

  @override
  ConsumerState<AccountGatePage> createState() => _AccountGatePageState();
}

class _AccountGatePageState extends ConsumerState<AccountGatePage> {
  late final TextEditingController _usernameController;
  late final TextEditingController _passwordController;
  bool _busy = false;
  bool _authenticated = false;
  String _statusText = '请输入账号密码';

  @override
  void initState() {
    super.initState();
    _usernameController = TextEditingController();
    _passwordController = TextEditingController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadSavedSession();
    });
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _loadSavedSession() async {
    final saved = await ref.read(localStoreProvider).loadAccountSession();
    if (!mounted) {
      return;
    }
    setState(() {
      _usernameController.text = saved?.username ?? '123';
      _passwordController.text = saved?.password ?? '123';
      _statusText = '请输入账号密码';
    });
  }

  Future<void> _login() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();
    if (username.isEmpty || password.isEmpty) {
      setState(() {
        _statusText = '账号和密码不能为空';
      });
      return;
    }

    setState(() {
      _busy = true;
      _statusText = '正在连接账号...';
    });
    try {
      final payload = await ref.read(appApiProvider).postJson(
        '/api/vision/accounts/session',
        {
          'username': username,
          'password': password,
        },
      );
      if (payload['ok'] != true) {
        throw Exception(payload['error']?.toString() ?? '账号登录失败');
      }
      await ref.read(localStoreProvider).saveAccountSession(
            AppAccountSession(
              username: username,
              password: password,
            ),
          );
      if (!mounted) {
        return;
      }
      setState(() {
        _authenticated = true;
        _busy = false;
        _statusText = '登录成功';
      });
    } catch (error) {
      if (!mounted) {
        return;
      }
      setState(() {
        _busy = false;
        _statusText = '登录失败: $error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_authenticated) {
      return const ShellPage();
    }
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppPalette.backgroundTop, AppPalette.background],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppPalette.panel,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: AppPalette.stroke),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x55000000),
                        blurRadius: 26,
                        offset: Offset(0, 16),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '账号登录',
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '账号和唯一人脸照片来自 HTML 端。APP 只负责识别打卡并把结果写回同一套账号库。',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      const SizedBox(height: 18),
                      TextField(
                        controller: _usernameController,
                        enabled: !_busy,
                        decoration: const InputDecoration(
                          labelText: '账号',
                          hintText: '例如 123',
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _passwordController,
                        enabled: !_busy,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: '密码',
                        ),
                        onSubmitted: (_) => _busy ? null : _login(),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: FilledButton(
                          onPressed: _busy ? null : _login,
                          child: Text(_busy ? '登录中...' : '进入系统'),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        _statusText,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: _statusText.startsWith('登录失败')
                                  ? AppPalette.danger
                                  : AppPalette.muted,
                            ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ShellPage extends StatefulWidget {
  const ShellPage({super.key});

  @override
  State<ShellPage> createState() => _ShellPageState();
}

class _ShellPageState extends State<ShellPage> {
  int _index = 0;

  static const _pages = [
    VideoPage(),
    AgentPage(),
    GimbalPage(),
  ];

  static const _items = [
    _DockItem(icon: Icons.badge_rounded, label: '门禁'),
    _DockItem(icon: Icons.chat_bubble_rounded, label: '智能'),
    _DockItem(icon: Icons.control_camera_rounded, label: '云台'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppPalette.backgroundTop, AppPalette.background],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: KeyedSubtree(
              key: ValueKey(_index),
              child: _pages[_index],
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: const Color(0xCC171C25),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: AppPalette.stroke),
            boxShadow: const [
              BoxShadow(
                color: Color(0x55000000),
                blurRadius: 22,
                offset: Offset(0, 12),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            child: Row(
              children: List.generate(_items.length, (i) {
                final item = _items[i];
                final selected = i == _index;
                return Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => setState(() => _index = i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 8),
                      decoration: BoxDecoration(
                        color: selected
                            ? const Color(0xFF273548)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            item.icon,
                            size: 22,
                            color:
                                selected ? AppPalette.text : AppPalette.muted,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            item.label,
                            style: TextStyle(
                              color:
                                  selected ? AppPalette.text : AppPalette.muted,
                              fontSize: 12,
                              fontWeight:
                                  selected ? FontWeight.w700 : FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _DockItem {
  const _DockItem({
    required this.icon,
    required this.label,
  });

  final IconData icon;
  final String label;
}

class _BootScreen extends StatelessWidget {
  const _BootScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class _BootError extends StatelessWidget {
  const _BootError({required this.error});

  final Object error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            '初始化失败: $error',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
