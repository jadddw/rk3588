import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/app_models.dart';
import '../../core/network/app_api.dart';
import '../../core/storage/local_store.dart';
import '../settings/settings_controller.dart';
import 'agent_service.dart';

final agentControllerProvider =
    AsyncNotifierProvider<AgentController, AgentState>(AgentController.new);

class AgentState {
  const AgentState({
    required this.history,
    required this.pendingConfirmToken,
    required this.traceId,
    required this.isSending,
    required this.streamText,
    required this.errorText,
    required this.chatMode,
    required this.thinkingEnabled,
    this.attachment,
    this.attachmentType = '',
    this.attachmentSummary = '',
  });

  final List<CommandHistoryEntry> history;
  final String pendingConfirmToken;
  final String traceId;
  final bool isSending;
  final String streamText;
  final String errorText;
  final bool chatMode;
  final bool thinkingEnabled;
  final PickedMedia? attachment;
  final String attachmentType;
  final String attachmentSummary;

  AgentState copyWith({
    List<CommandHistoryEntry>? history,
    String? pendingConfirmToken,
    String? traceId,
    bool? isSending,
    String? streamText,
    String? errorText,
    bool? chatMode,
    bool? thinkingEnabled,
    PickedMedia? attachment,
    bool clearAttachment = false,
    String? attachmentType,
    String? attachmentSummary,
  }) {
    return AgentState(
      history: history ?? this.history,
      pendingConfirmToken: pendingConfirmToken ?? this.pendingConfirmToken,
      traceId: traceId ?? this.traceId,
      isSending: isSending ?? this.isSending,
      streamText: streamText ?? this.streamText,
      errorText: errorText ?? this.errorText,
      chatMode: chatMode ?? this.chatMode,
      thinkingEnabled: thinkingEnabled ?? this.thinkingEnabled,
      attachment: clearAttachment ? null : (attachment ?? this.attachment),
      attachmentType:
          clearAttachment ? '' : (attachmentType ?? this.attachmentType),
      attachmentSummary:
          clearAttachment ? '' : (attachmentSummary ?? this.attachmentSummary),
    );
  }
}

class AgentController extends AsyncNotifier<AgentState> {
  LocalStore get _store => ref.read(localStoreProvider);
  AppApi get _api => ref.read(appApiProvider);
  AgentService get _service => ref.read(agentServiceProvider);

  @override
  Future<AgentState> build() async {
    final history = await _store.loadHistory();
    return AgentState(
      history: history,
      pendingConfirmToken: '',
      traceId: '',
      isSending: false,
      streamText: '',
      errorText: '',
      chatMode: true,
      thinkingEnabled: false,
    );
  }

  Future<void> setChatMode(bool value) async {
    state =
        AsyncData(state.requireValue.copyWith(chatMode: value, errorText: ''));
  }

  Future<void> setThinkingEnabled(bool value) async {
    state = AsyncData(
      state.requireValue.copyWith(thinkingEnabled: value, errorText: ''),
    );
  }

  Future<void> clearHistory() async {
    final next = state.requireValue.copyWith(history: []);
    state = AsyncData(next);
    await _store.saveHistory(next.history);
  }

  Future<void> attachImage() async {
    final media = await _service.pickImage();
    if (media == null) {
      return;
    }
    state = AsyncData(
      state.requireValue.copyWith(
        attachment: media,
        attachmentType: 'image',
        attachmentSummary: media.name,
        errorText: '',
      ),
    );
  }

  Future<void> attachVideo() async {
    final media = await _service.pickVideo();
    if (media == null) {
      return;
    }
    state = AsyncData(
      state.requireValue.copyWith(
        attachment: media,
        attachmentType: 'video',
        attachmentSummary: media.name,
        errorText: '',
      ),
    );
  }

  Future<void> clearAttachment() async {
    state = AsyncData(state.requireValue.copyWith(clearAttachment: true));
  }

  Future<void> send(String input) async {
    final text = input.trim();
    final current = state.requireValue;
    if (text.isEmpty && current.attachment == null) {
      return;
    }
    final displayText = text.isEmpty
        ? '[${current.attachmentType}] ${current.attachmentSummary}'
        : text;
    final userEntry = _entry(
      role: 'user',
      text: displayText,
      mode: current.chatMode ? 'chat_manual' : 'command_manual',
    );
    final history = [...current.history, userEntry];
    state = AsyncData(
      current.copyWith(
        history: history,
        isSending: true,
        streamText: '',
        errorText: '',
      ),
    );
    await _store.saveHistory(history);

    if (current.attachment != null) {
      await _sendMedia(text, current);
      return;
    }

    if (current.chatMode) {
      await _sendChat(text);
    } else {
      await _sendCommand(text);
    }
  }

  Future<void> confirmPending() async {
    final current = state.requireValue;
    if (current.pendingConfirmToken.isEmpty) {
      return;
    }
    state = AsyncData(
        current.copyWith(isSending: true, errorText: '', streamText: ''));
    try {
      final payload = await _api.postJson('/api/agent/command_manual', {
        'confirm_token': current.pendingConfirmToken,
      });
      await _applyCommandReply(_fromCommandPayload(payload));
    } catch (error) {
      state = AsyncData(
        state.requireValue.copyWith(
          isSending: false,
          errorText: error.toString(),
        ),
      );
    }
  }

  Future<void> _sendMedia(String text, AgentState current) async {
    try {
      final payload = await _api.postMultipart(
        '/api/upload/media',
        fields: {
          'query': text,
          'mode': current.chatMode ? 'chat_manual' : 'command_manual',
        },
        file: current.attachment?.file,
        filename: current.attachment?.name,
      );
      final reply = AgentReply(
        ok: payload['ok'] == true,
        text: payload['summary']?.toString() ??
            payload['assistant_feedback']?.toString() ??
            '文件已上传',
        traceId: payload['trace_id']?.toString() ?? '',
        executed: false,
        awaitingConfirmation: false,
        confirmToken: '',
        mode: 'media_upload',
        detail: payload['error']?.toString() ?? '',
      );
      await _applyCommandReply(reply, clearAttachment: true);
    } catch (error) {
      state = AsyncData(
        state.requireValue.copyWith(
          isSending: false,
          errorText: error.toString(),
        ),
      );
    }
  }

  Future<void> _sendChat(String text) async {
    final current = state.requireValue;
    final dialog = _dialogueHistory();
    final buffer = StringBuffer();
    String traceId = '';

    try {
      await for (final event in _api.streamChat('/api/agent/chat_manual', {
        'query': text,
        'stream': true,
        'dialogue_history': dialog,
        'enable_thinking': current.thinkingEnabled,
      })) {
        if (event.type == 'meta' || event.type == 'agent_meta') {
          final nextTrace = event.payload['trace_id']?.toString() ?? '';
          if (nextTrace.isNotEmpty) {
            traceId = nextTrace;
            state = AsyncData(state.requireValue.copyWith(traceId: traceId));
          }
          continue;
        }
        if (event.type == 'token') {
          final delta = event.payload['delta']?.toString() ?? '';
          buffer.write(delta);
          state = AsyncData(
              state.requireValue.copyWith(streamText: buffer.toString()));
          continue;
        }
        if (event.type == 'error') {
          final detail = event.payload['detail']?.toString() ??
              event.payload['error']?.toString() ??
              'stream error';
          state = AsyncData(
            state.requireValue.copyWith(
              isSending: false,
              errorText: detail,
              streamText: buffer.toString(),
            ),
          );
        }
        if (event.type == 'done') {
          final doneText = event.payload['text']?.toString();
          final textResult = (doneText != null && doneText.isNotEmpty)
              ? doneText
              : buffer.toString();
          final reply = AgentReply(
            ok: event.payload['ok'] == true,
            text: textResult,
            traceId: traceId,
            executed: false,
            awaitingConfirmation: false,
            confirmToken: '',
            mode: 'chat_manual',
            detail: event.payload['detail']?.toString() ?? '',
          );
          await _applyCommandReply(reply);
        }
      }
    } catch (error) {
      state = AsyncData(
        state.requireValue.copyWith(
          isSending: false,
          errorText: error.toString(),
          streamText: buffer.toString(),
        ),
      );
    }
  }

  Future<void> _sendCommand(String text) async {
    try {
      final payload = await _api.postJson('/api/agent/command_manual', {
        'query': text,
        'dialogue_history': _dialogueHistory(),
      });
      await _applyCommandReply(_fromCommandPayload(payload));
    } catch (error) {
      state = AsyncData(
        state.requireValue.copyWith(
          isSending: false,
          errorText: error.toString(),
        ),
      );
    }
  }

  Future<void> _applyCommandReply(
    AgentReply reply, {
    bool clearAttachment = false,
  }) async {
    final current = state.requireValue;
    final entry = _entry(
      role: 'assistant',
      text: reply.text.isNotEmpty ? reply.text : reply.detail,
      mode: reply.mode,
      traceId: reply.traceId,
      executed: reply.executed,
      awaitingConfirmation: reply.awaitingConfirmation,
      error: reply.ok ? null : reply.detail,
    );
    final nextHistory = [...current.history, entry];
    final next = current.copyWith(
      history: nextHistory,
      pendingConfirmToken: reply.confirmToken,
      traceId: reply.traceId,
      isSending: false,
      streamText: '',
      errorText: reply.ok ? '' : reply.detail,
      clearAttachment: clearAttachment,
    );
    state = AsyncData(next);
    await _store.saveHistory(nextHistory);
  }

  AgentReply _fromCommandPayload(Map<String, dynamic> payload) {
    return AgentReply(
      ok: payload['ok'] == true,
      text: payload['assistant_feedback']?.toString() ?? '',
      traceId: payload['execution_trace'] is Map
          ? ((payload['execution_trace'] as Map)['trace_id']?.toString() ?? '')
          : '',
      executed: payload['executed'] == true,
      awaitingConfirmation: payload['awaiting_confirmation'] == true,
      confirmToken: payload['confirm_token']?.toString() ?? '',
      mode: payload['response_mode']?.toString() ?? 'command_manual',
      detail: payload['error_detail']?.toString() ??
          payload['error']?.toString() ??
          payload['assistant_feedback']?.toString() ??
          '',
    );
  }

  List<Map<String, dynamic>> _dialogueHistory() {
    final rows = state.requireValue.history;
    return rows
        .take(rows.length > 12 ? 12 : rows.length)
        .map(
          (row) => {
            'role': row.role,
            'text': row.text,
          },
        )
        .toList();
  }

  CommandHistoryEntry _entry({
    required String role,
    required String text,
    required String mode,
    String? traceId,
    bool? executed,
    bool? awaitingConfirmation,
    String? error,
  }) {
    return CommandHistoryEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      role: role,
      text: text,
      timestamp: DateTime.now(),
      mode: mode,
      traceId: traceId,
      executed: executed,
      awaitingConfirmation: awaitingConfirmation,
      error: error,
    );
  }
}
