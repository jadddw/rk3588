import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/app_models.dart';
import '../../core/network/app_api.dart';
import '../../core/utils/formatters.dart';

final dashboardControllerProvider =
    AutoDisposeAsyncNotifierProvider<DashboardController, DashboardSnapshot>(
  DashboardController.new,
);

class DashboardController extends AutoDisposeAsyncNotifier<DashboardSnapshot> {
  Timer? _timer;

  @override
  Future<DashboardSnapshot> build() async {
    ref.onDispose(() {
      _timer?.cancel();
    });
    _timer = Timer.periodic(const Duration(seconds: 2), (_) {
      refresh();
    });
    return _load();
  }

  Future<void> refresh() async {
    state = await AsyncValue.guard(_load);
  }

  Future<DashboardSnapshot> _load() async {
    final api = ref.read(appApiProvider);
    final results = await Future.wait([
      api.getJson('/api/metrics'),
      api.getJson('/api/camera/diag'),
      api.getJson('/api/vision/profile'),
    ]);

    Map<String, dynamic> observe = const {};
    String? observeError;
    try {
      observe = await api.getJson(
        '/api/vision/observe',
        queryParameters: {'detector': 'face'},
      );
    } catch (error) {
      observeError = error.toString();
    }

    final metrics = results[0];
    final cameraDiag = results[1];
    final profile = results[2];

    final cpu = metrics['cpu'] as Map? ?? const {};
    final memory = metrics['memory'] as Map? ?? const {};
    final npu = metrics['npu'] as Map? ?? const {};
    final network =
        (metrics['network'] as List? ?? const []).whereType<Map>().toList();
    final processCpu = (metrics['processes_cpu'] as List? ??
            metrics['processes'] as List? ??
            const [])
        .whereType<Map>()
        .toList();
    final processMem = (metrics['processes_mem'] as List? ?? const [])
        .whereType<Map>()
        .toList();

    final capture = cameraDiag['capture'] as Map? ?? const {};
    final usb = cameraDiag['usb'] as Map? ?? const {};
    final device = cameraDiag['device'] as Map? ?? const {};
    final diagProfile = cameraDiag['profile'] as Map? ?? const {};
    final dmesg = cameraDiag['dmesg'] as Map? ?? const {};
    final stability = (cameraDiag['stability'] as Map?) ??
        (dmesg['stability'] as Map?) ??
        const {};
    final cameraLogs = (dmesg['latest_lines'] as List? ?? const [])
        .map((line) => line.toString())
        .toList();

    final cam = observe['camera'] as Map? ??
        <String, dynamic>{
          'enabled': profile['enabled'],
          'stream_enabled': profile['stream_enabled'],
          'capture_fps': 0,
          'stream_fps': 0,
          'frame_age_ms': null,
        };
    final objects = (observe['objects'] as List? ?? const []).length;
    final wearGlasses = observe['wear_glasses'] as Map? ?? const {};
    final emotion = observe['emotion'] as Map? ?? const {};

    final npuCores = (npu['cores'] as List? ?? const [])
        .asMap()
        .entries
        .map((entry) =>
            'C${entry.key}:${fmtPercent(_toDouble(entry.value), digits: 0)}')
        .join(' ');

    final visionRows = <StatusRow>[
      StatusRow(label: '视觉开关', value: _boolText(cam['enabled'])),
      StatusRow(
          label: '预览流', value: cam['stream_enabled'] == false ? 'OFF' : 'ON'),
      StatusRow(label: '检测器', value: observe['detector']?.toString() ?? 'face'),
      StatusRow(label: '目标数量', value: '$objects'),
      StatusRow(
          label: '采集 FPS', value: fmtNumber(_toDouble(cam['capture_fps']))),
      StatusRow(
          label: '输出 FPS', value: fmtNumber(_toDouble(cam['stream_fps']))),
      StatusRow(label: '帧龄', value: fmtMs(_toDouble(cam['frame_age_ms']))),
    ];
    if (observeError != null) {
      visionRows.add(
        const StatusRow(
          label: '视觉状态',
          value: '当前无帧或视觉服务暂不可用',
          level: StatusLevel.warn,
        ),
      );
    }
    if (wearGlasses['ok'] == true) {
      visionRows.add(
        StatusRow(
          label: '眼镜识别',
          value: '${wearGlasses['wear_glasses_count'] ?? 0}',
        ),
      );
    }
    if (emotion['ok'] == true) {
      visionRows.add(
        StatusRow(
          label: '情绪识别',
          value: '${emotion['emotion_count'] ?? 0}',
        ),
      );
    }

    final level = _mapLevel(stability['level']?.toString());

    return DashboardSnapshot(
      cpu: MetricBlock(
        label: 'CPU',
        percent: _toDouble(cpu['usage_percent']),
        detail: 'Load ${fmtNumber(_first(cpu['load']), digits: 2)}',
      ),
      memory: MetricBlock(
        label: '内存',
        percent: _toDouble(memory['used_percent']),
        detail:
            '${fmtBytes(_toDouble(memory['used']))} / ${fmtBytes(_toDouble(memory['total']))}',
      ),
      npu: MetricBlock(
        label: 'NPU',
        percent: _toDouble(npu['usage_percent']),
        detail: npuCores.isNotEmpty ? npuCores : 'NPU 指标不可用',
      ),
      uptime: fmtUptime(_toDouble(metrics['uptime_seconds'])),
      networkRows: network
          .map(
            (row) => StatusRow(
              label: row['name']?.toString() ?? '-',
              value:
                  '${row['state']?.toString().toUpperCase() ?? '-'} | RX ${fmtRate(_toDouble(row['rx_rate']))} | TX ${fmtRate(_toDouble(row['tx_rate']))}',
              level: row['state']?.toString() == 'up'
                  ? StatusLevel.good
                  : StatusLevel.warn,
            ),
          )
          .toList(),
      processCpuRows: processCpu
          .take(5)
          .map(
            (row) => StatusRow(
              label: row['name']?.toString() ?? '-',
              value:
                  'PID ${row['pid'] ?? '-'} | CPU ${fmtPercent(_toDouble(row['cpu_percent']))} | MEM ${fmtPercent(_toDouble(row['mem_percent']))}',
            ),
          )
          .toList(),
      processMemRows: (processMem.isNotEmpty ? processMem : processCpu)
          .take(5)
          .map(
            (row) => StatusRow(
              label: row['name']?.toString() ?? '-',
              value:
                  'PID ${row['pid'] ?? '-'} | MEM ${fmtPercent(_toDouble(row['mem_percent']))} | CPU ${fmtPercent(_toDouble(row['cpu_percent']))}',
            ),
          )
          .toList(),
      cameraRows: [
        StatusRow(
            label: '设备',
            value: device['resolved_path']?.toString() ??
                device['path']?.toString() ??
                '-'),
        StatusRow(label: '总线', value: usb['port_id']?.toString() ?? '-'),
        StatusRow(label: '控制器', value: usb['controller']?.toString() ?? '-'),
        StatusRow(
          label: '链路',
          value:
              '${usb['speed_mbps'] != null ? '${(usb['speed_mbps'] as num).toStringAsFixed(0)} Mbps' : '-'}${usb['transport'] != null ? ' (${usb['transport']})' : ''}',
        ),
        StatusRow(
            label: '档位',
            value: diagProfile['current']?.toString() ??
                profile['current']?.toString() ??
                '-'),
        StatusRow(
          label: '格式',
          value:
              '${capture['pixel_format'] ?? '-'} ${(capture['width'] != null && capture['height'] != null) ? '${capture['width']}x${capture['height']}' : ''}'
                  .trim(),
        ),
        StatusRow(
          label: '相机 FPS',
          value: capture['fps'] != null
              ? '${fmtNumber(_toDouble(capture['fps']))} fps'
              : '-',
        ),
      ],
      visionRows: visionRows,
      cameraLogs: cameraLogs,
      updatedAt: DateTime.now(),
      cameraDiagLevel: level,
      cameraDiagLabel: stability['label']?.toString() ?? '未知',
    );
  }

  double? _toDouble(Object? value) {
    if (value is num) {
      return value.toDouble();
    }
    return double.tryParse(value?.toString() ?? '');
  }

  double? _first(Object? value) {
    if (value is List && value.isNotEmpty) {
      return _toDouble(value.first);
    }
    return null;
  }

  String _boolText(Object? value) {
    return value == true ? 'ON' : 'OFF';
  }

  StatusLevel _mapLevel(String? value) {
    switch (value) {
      case 'good':
        return StatusLevel.good;
      case 'bad':
        return StatusLevel.bad;
      case 'warn':
        return StatusLevel.warn;
      default:
        return StatusLevel.normal;
    }
  }
}
