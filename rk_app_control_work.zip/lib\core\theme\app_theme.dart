import 'package:flutter/material.dart';

ThemeData buildAppTheme() {
  const background = Color(0xFF0B0E13);
  const surface = Color(0xFF141922);
  const surfaceSoft = Color(0xFF1A2230);
  const stroke = Color(0x1FFFFFFF);
  const accent = Color(0xFF64D2FF);
  const accentWarm = Color(0xFFFF9F0A);
  const text = Color(0xFFF5F7FA);
  const muted = Color(0xFF98A2B3);

  final scheme = ColorScheme.fromSeed(
    seedColor: accent,
    brightness: Brightness.dark,
    primary: accent,
    secondary: accentWarm,
    surface: surface,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    cardColor: surface,
    dividerColor: stroke,
    splashFactory: NoSplash.splashFactory,
    textTheme: const TextTheme(
      headlineMedium: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        color: text,
        letterSpacing: -1.0,
        height: 1.0,
      ),
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: text,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: text,
      ),
      bodyLarge: TextStyle(
        fontSize: 15,
        color: text,
        height: 1.35,
      ),
      bodyMedium: TextStyle(
        fontSize: 13,
        color: muted,
        height: 1.4,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surfaceSoft,
      hintStyle: const TextStyle(color: muted),
      labelStyle: const TextStyle(color: muted),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(24),
        borderSide: const BorderSide(color: stroke),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(24),
        borderSide: const BorderSide(color: stroke),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(24),
        borderSide: const BorderSide(color: accent, width: 1.4),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: surfaceSoft,
      selectedColor: const Color(0xFF263346),
      side: const BorderSide(color: stroke),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      labelStyle: const TextStyle(color: text, fontWeight: FontWeight.w600),
      secondaryLabelStyle: const TextStyle(color: text, fontWeight: FontWeight.w600),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    ),
  );
}

class AppPalette {
  static const background = Color(0xFF0B0E13);
  static const backgroundTop = Color(0xFF111723);
  static const panel = Color(0xCC141922);
  static const panelSoft = Color(0xFF1A2230);
  static const panelStrong = Color(0xFF202A39);
  static const accent = Color(0xFF64D2FF);
  static const accentWarm = Color(0xFFFF9F0A);
  static const success = Color(0xFF30D158);
  static const warning = Color(0xFFFF9F0A);
  static const danger = Color(0xFFFF453A);
  static const text = Color(0xFFF5F7FA);
  static const muted = Color(0xFF98A2B3);
  static const stroke = Color(0x1FFFFFFF);
}
