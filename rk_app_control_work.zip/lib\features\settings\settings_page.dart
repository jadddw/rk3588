import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/theme/app_theme.dart';
import '../../shared/widgets/panel_card.dart';
import 'settings_controller.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsControllerProvider);
    return settings.when(
      data: (state) {
        final color = state.isConnected ? AppPalette.success : AppPalette.warning;
        final timeText = state.lastProbeAt == null
            ? '尚未探测'
            : DateFormat('HH:mm:ss').format(state.lastProbeAt!);

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
          children: [
            Text('双模式连接', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text(
              '同时兼容板子热点和手机热点两种连接方式，优先发现正式服务。',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 18),
            PanelCard(
              title: '连接状态',
              trailing: FilledButton.tonal(
                onPressed: state.isScanning
                    ? null
                    : () => ref.read(settingsControllerProvider.notifier).refreshConnection(),
                child: Text(state.isScanning ? '扫描中' : '重新扫描'),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          state.statusText,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const _InfoRow(label: '支持模式', value: '板子热点 / 手机热点'),
                  _InfoRow(label: '最近探测', value: timeText),
                  const _InfoRow(label: '内部策略', value: '优先正式网关 8090，兼容回落 18090'),
                ],
              ),
            ),
            const PanelCard(
              title: '使用方式',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('1. 板子和手机进入同一局域网'),
                  SizedBox(height: 8),
                  Text('2. 可以是板子开热点，也可以是手机开热点'),
                  SizedBox(height: 8),
                  Text('3. 打开 App，等待自动发现正式服务'),
                  SizedBox(height: 8),
                  Text('4. 如果没有连上，点“重新扫描”'),
                ],
              ),
            ),
            PanelCard(
              title: '系统说明',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('外部体验上不暴露 IP、端口或 HTTP。'),
                  const SizedBox(height: 8),
                  const Text('当前版本内部会优先搜索 8090 正式网关，不可用时再尝试 18090 兼容层。'),
                  if (state.triedEndpoints.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(
                      '本轮探测节点: ${state.triedEndpoints.join('  |  ')}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ],
              ),
            ),
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('连接状态加载失败: $error', textAlign: TextAlign.center),
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 72,
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ],
      ),
    );
  }
}
