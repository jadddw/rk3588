import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/app_models.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/panel_card.dart';
import 'gimbal_controller.dart';

class GimbalPage extends ConsumerWidget {
  const GimbalPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(gimbalControllerProvider);
    return state.when(
      data: (data) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('手动云台',
                        style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 6),
                    Text(
                      '直控优先，LLM 控制只是补充。方向键会发送短脉冲转速命令。',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () =>
                    ref.read(gimbalControllerProvider.notifier).refresh(),
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          const SizedBox(height: 16),
          PanelCard(
            title: '方向控制',
            child: _GimbalPad(
              onUp: () =>
                  ref.read(gimbalControllerProvider.notifier).move(pitch: -1.2),
              onDown: () =>
                  ref.read(gimbalControllerProvider.notifier).move(pitch: 1.2),
              onLeft: () =>
                  ref.read(gimbalControllerProvider.notifier).move(yaw: -1.2),
              onRight: () =>
                  ref.read(gimbalControllerProvider.notifier).move(yaw: 1.2),
              onStop: () => ref.read(gimbalControllerProvider.notifier).stop(),
            ),
          ),
          PanelCard(
            title: '快捷动作',
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FilledButton.tonal(
                  onPressed: () =>
                      ref.read(gimbalControllerProvider.notifier).stop(),
                  child: const Text('停止'),
                ),
                FilledButton.tonal(
                  onPressed: () =>
                      ref.read(gimbalControllerProvider.notifier).move(
                            yaw: 0,
                            pitch: 0,
                            autoStopMs: 1,
                            reason: 'flutter-center',
                          ),
                  child: const Text('回中占位'),
                ),
                FilledButton.tonal(
                  onPressed: () =>
                      ref.read(gimbalControllerProvider.notifier).setLock(true),
                  child: const Text('开始锁定'),
                ),
                FilledButton.tonal(
                  onPressed: () => ref
                      .read(gimbalControllerProvider.notifier)
                      .setLock(false),
                  child: const Text('解除锁定'),
                ),
                FilledButton.tonal(
                  onPressed: () => ref
                      .read(gimbalControllerProvider.notifier)
                      .setLaser(true),
                  child: const Text('开激光'),
                ),
                FilledButton.tonal(
                  onPressed: () => ref
                      .read(gimbalControllerProvider.notifier)
                      .setLaser(false),
                  child: const Text('关激光'),
                ),
                FilledButton.tonal(
                  onPressed: () => ref
                      .read(gimbalControllerProvider.notifier)
                      .setEnabled(true),
                  child: const Text('云台上电'),
                ),
                FilledButton.tonal(
                  onPressed: () => ref
                      .read(gimbalControllerProvider.notifier)
                      .setEnabled(false),
                  child: const Text('云台断使能'),
                ),
              ],
            ),
          ),
          PanelCard(
            title: '状态',
            child: Column(
              children: data.statusRows
                  .map((row) => _StatusRowWidget(row: row))
                  .toList(),
            ),
          ),
        ],
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('云台页加载失败\n$error', textAlign: TextAlign.center),
        ),
      ),
    );
  }
}

class _GimbalPad extends StatelessWidget {
  const _GimbalPad({
    required this.onUp,
    required this.onDown,
    required this.onLeft,
    required this.onRight,
    required this.onStop,
  });

  final VoidCallback onUp;
  final VoidCallback onDown;
  final VoidCallback onLeft;
  final VoidCallback onRight;
  final VoidCallback onStop;

  @override
  Widget build(BuildContext context) {
    Widget button(IconData icon, VoidCallback onPressed, {Color? bg}) {
      return FilledButton.tonal(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: bg,
          minimumSize: const Size(78, 78),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
        ),
        child: Icon(icon),
      );
    }

    return Center(
      child: Column(
        children: [
          button(Icons.keyboard_arrow_up_rounded, onUp),
          const SizedBox(height: 12),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              button(Icons.keyboard_arrow_left_rounded, onLeft),
              const SizedBox(width: 12),
              button(Icons.stop_rounded, onStop,
                  bg: AppPalette.danger.withOpacity(0.18)),
              const SizedBox(width: 12),
              button(Icons.keyboard_arrow_right_rounded, onRight),
            ],
          ),
          const SizedBox(height: 12),
          button(Icons.keyboard_arrow_down_rounded, onDown),
        ],
      ),
    );
  }
}

class _StatusRowWidget extends StatelessWidget {
  const _StatusRowWidget({required this.row});

  final StatusRow row;

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (row.level) {
      case StatusLevel.good:
        color = AppPalette.success;
        break;
      case StatusLevel.warn:
        color = AppPalette.warning;
        break;
      case StatusLevel.bad:
        color = AppPalette.danger;
        break;
      case StatusLevel.normal:
        color = AppPalette.text;
        break;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(row.label)),
          Flexible(
            child: Text(
              row.value,
              textAlign: TextAlign.right,
              style: TextStyle(color: color, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}
