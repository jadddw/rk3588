import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/models/app_models.dart';
import '../../core/theme/app_theme.dart';
import 'agent_controller.dart';

class AgentPage extends ConsumerStatefulWidget {
  const AgentPage({super.key});

  @override
  ConsumerState<AgentPage> createState() => _AgentPageState();
}

class _AgentPageState extends ConsumerState<AgentPage> {
  late final TextEditingController _input;

  @override
  void initState() {
    super.initState();
    _input = TextEditingController();
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(agentControllerProvider);
    return state.when(
      data: (data) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: _AgentHeader(
              state: data,
              onSetMode: (value) =>
                  ref.read(agentControllerProvider.notifier).setChatMode(value),
              onSetThinking: (value) => ref
                  .read(agentControllerProvider.notifier)
                  .setThinkingEnabled(value),
              onConfirm: () =>
                  ref.read(agentControllerProvider.notifier).confirmPending(),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              reverse: true,
              itemCount: data.history.length +
                  (data.isSending && data.streamText.isNotEmpty ? 1 : 0),
              itemBuilder: (context, index) {
                if (data.isSending &&
                    data.streamText.isNotEmpty &&
                    index == 0) {
                  return _LiveBubble(text: data.streamText);
                }
                final offset =
                    data.isSending && data.streamText.isNotEmpty ? 1 : 0;
                final row =
                    data.history[data.history.length - 1 - (index - offset)];
                return _MessageBubble(entry: row);
              },
            ),
          ),
          if (data.errorText.isNotEmpty)
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppPalette.danger.withOpacity(0.14),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppPalette.danger.withOpacity(0.35)),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.error_outline_rounded,
                    color: AppPalette.danger,
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: Text(data.errorText)),
                ],
              ),
            ),
          _Composer(
            controller: _input,
            state: data,
            onSend: () async {
              final text = _input.text;
              _input.clear();
              await ref.read(agentControllerProvider.notifier).send(text);
            },
          ),
        ],
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('智能页加载失败\n$error', textAlign: TextAlign.center),
        ),
      ),
    );
  }
}

class _AgentHeader extends StatelessWidget {
  const _AgentHeader({
    required this.state,
    required this.onSetMode,
    required this.onSetThinking,
    required this.onConfirm,
  });

  final AgentState state;
  final ValueChanged<bool> onSetMode;
  final ValueChanged<bool> onSetThinking;
  final VoidCallback onConfirm;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppPalette.panel,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppPalette.stroke),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '智能控制',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: SegmentedButton<bool>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment<bool>(value: true, label: Text('聊天')),
                    ButtonSegment<bool>(value: false, label: Text('执行')),
                  ],
                  selected: {state.chatMode},
                  onSelectionChanged: (selection) => onSetMode(selection.first),
                ),
              ),
              const SizedBox(width: 12),
              _ThinkingToggle(
                enabled: state.chatMode,
                active: state.thinkingEnabled,
                busy: state.isSending,
                onChanged: onSetThinking,
              ),
              if (state.pendingConfirmToken.isNotEmpty) ...[
                const SizedBox(width: 12),
                FilledButton.tonal(
                  onPressed: state.isSending ? null : onConfirm,
                  child: const Text('确认执行'),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.entry});

  final CommandHistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    final isUser = entry.role == 'user';
    final meta = <String>[
      entry.mode ?? '',
      if (entry.executed == true) '已执行',
      if (entry.awaitingConfirmation == true) '待确认',
      if (entry.error != null && entry.error!.isNotEmpty) '错误',
    ].where((item) => item.isNotEmpty).join(' · ');

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isUser ? const Color(0xFF233448) : AppPalette.panelSoft,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppPalette.stroke),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    radius: 14,
                    backgroundColor:
                        isUser ? AppPalette.accent : AppPalette.panelStrong,
                    child: Icon(
                      isUser
                          ? Icons.person_rounded
                          : Icons.auto_awesome_rounded,
                      size: 16,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    isUser ? '你' : 'ELF2',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(entry.text, style: Theme.of(context).textTheme.bodyLarge),
              const SizedBox(height: 10),
              Text(
                '${DateFormat('HH:mm:ss').format(entry.timestamp)}${meta.isNotEmpty ? ' · $meta' : ''}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LiveBubble extends StatelessWidget {
  const _LiveBubble({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppPalette.panelSoft,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppPalette.stroke),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  CircleAvatar(
                    radius: 14,
                    backgroundColor: AppPalette.panelStrong,
                    child: Icon(
                      Icons.auto_awesome_rounded,
                      size: 16,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'ELF2 正在思考',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: AppPalette.text,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(text, style: Theme.of(context).textTheme.bodyLarge),
            ],
          ),
        ),
      ),
    );
  }
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.state,
    required this.onSend,
  });

  final TextEditingController controller;
  final AgentState state;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        decoration: BoxDecoration(
          color: const Color(0xE6161B24),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppPalette.stroke),
          boxShadow: const [
            BoxShadow(
              color: Color(0x40000000),
              blurRadius: 24,
              offset: Offset(0, 14),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 5,
                decoration: InputDecoration(
                  hintText:
                      state.chatMode ? '给板子发一条自然语言消息' : '输入执行命令，例如：锁定目标并开始跟踪',
                ),
              ),
            ),
            const SizedBox(width: 10),
            _SendButton(
              icon: state.isSending
                  ? Icons.more_horiz_rounded
                  : Icons.arrow_upward_rounded,
              onTap: state.isSending ? null : onSend,
            ),
          ],
        ),
      ),
    );
  }
}

class _ThinkingToggle extends StatelessWidget {
  const _ThinkingToggle({
    required this.enabled,
    required this.active,
    required this.busy,
    required this.onChanged,
  });

  final bool enabled;
  final bool active;
  final bool busy;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final usable = enabled && !busy;
    return GestureDetector(
      onTap: usable ? () => onChanged(!active) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: active
              ? AppPalette.accent.withOpacity(0.20)
              : AppPalette.panelSoft,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: active
                ? AppPalette.accent.withOpacity(0.65)
                : AppPalette.stroke,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              active ? 'Thinking On' : 'Thinking Off',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    color: usable
                        ? AppPalette.text
                        : AppPalette.muted.withOpacity(0.8),
                  ),
            ),
            const SizedBox(height: 2),
            Text(
              enabled ? '聊天模式' : '仅聊天可用',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppPalette.muted,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SendButton extends StatelessWidget {
  const _SendButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppPalette.accent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: SizedBox(
          width: 46,
          height: 46,
          child: Icon(
            icon,
            color: AppPalette.background,
          ),
        ),
      ),
    );
  }
}
