import 'dart:convert';
import 'dart:typed_data';

class CommandHistoryEntry {
  const CommandHistoryEntry({
    required this.id,
    required this.role,
    required this.text,
    required this.timestamp,
    this.mode,
    this.traceId,
    this.executed,
    this.awaitingConfirmation,
    this.error,
  });

  final String id;
  final String role;
  final String text;
  final DateTime timestamp;
  final String? mode;
  final String? traceId;
  final bool? executed;
  final bool? awaitingConfirmation;
  final String? error;

  factory CommandHistoryEntry.fromJson(Map<String, dynamic> json) {
    return CommandHistoryEntry(
      id: json['id']?.toString() ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      role: json['role']?.toString() ?? 'assistant',
      text: json['text']?.toString() ?? '',
      timestamp: DateTime.tryParse(json['timestamp']?.toString() ?? '') ??
          DateTime.now(),
      mode: json['mode']?.toString(),
      traceId: json['traceId']?.toString(),
      executed: json['executed'] is bool ? json['executed'] as bool : null,
      awaitingConfirmation: json['awaitingConfirmation'] is bool
          ? json['awaitingConfirmation'] as bool
          : null,
      error: json['error']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'role': role,
      'text': text,
      'timestamp': timestamp.toIso8601String(),
      'mode': mode,
      'traceId': traceId,
      'executed': executed,
      'awaitingConfirmation': awaitingConfirmation,
      'error': error,
    };
  }
}

class MetricBlock {
  const MetricBlock({
    required this.label,
    required this.percent,
    required this.detail,
  });

  final String label;
  final double? percent;
  final String detail;
}

class StatusRow {
  const StatusRow({
    required this.label,
    required this.value,
    this.level = StatusLevel.normal,
  });

  final String label;
  final String value;
  final StatusLevel level;
}

enum StatusLevel { normal, good, warn, bad }

class DashboardSnapshot {
  const DashboardSnapshot({
    required this.cpu,
    required this.memory,
    required this.npu,
    required this.uptime,
    required this.networkRows,
    required this.processCpuRows,
    required this.processMemRows,
    required this.cameraRows,
    required this.visionRows,
    required this.cameraLogs,
    required this.updatedAt,
    required this.cameraDiagLevel,
    required this.cameraDiagLabel,
  });

  final MetricBlock cpu;
  final MetricBlock memory;
  final MetricBlock npu;
  final String uptime;
  final List<StatusRow> networkRows;
  final List<StatusRow> processCpuRows;
  final List<StatusRow> processMemRows;
  final List<StatusRow> cameraRows;
  final List<StatusRow> visionRows;
  final List<String> cameraLogs;
  final DateTime updatedAt;
  final StatusLevel cameraDiagLevel;
  final String cameraDiagLabel;
}

class AppAccountSession {
  const AppAccountSession({
    required this.username,
    required this.password,
  });

  final String username;
  final String password;

  bool get isValid => username.trim().isNotEmpty && password.trim().isNotEmpty;

  factory AppAccountSession.fromJson(Map<String, dynamic> json) {
    return AppAccountSession(
      username: json['username']?.toString() ?? '',
      password: json['password']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'password': password,
    };
  }
}

class FaceProfile {
  const FaceProfile({
    required this.identityKey,
    required this.displayName,
    required this.enrolledAt,
    this.portraitBytes,
  });

  final String identityKey;
  final String displayName;
  final DateTime enrolledAt;
  final Uint8List? portraitBytes;

  factory FaceProfile.fromJson(Map<String, dynamic> json) {
    Uint8List? portraitBytes;
    final portraitRaw = json['portraitBase64']?.toString() ?? '';
    if (portraitRaw.isNotEmpty) {
      try {
        portraitBytes = base64Decode(portraitRaw);
      } catch (_) {
        portraitBytes = null;
      }
    }
    return FaceProfile(
      identityKey: json['identityKey']?.toString() ?? 'test_user',
      displayName: json['displayName']?.toString() ?? '小明',
      enrolledAt: DateTime.tryParse(json['enrolledAt']?.toString() ?? '') ??
          DateTime.now(),
      portraitBytes: portraitBytes,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'identityKey': identityKey,
      'displayName': displayName,
      'enrolledAt': enrolledAt.toIso8601String(),
      'portraitBase64':
          portraitBytes == null ? '' : base64Encode(portraitBytes!),
    };
  }

  FaceProfile copyWith({
    String? identityKey,
    String? displayName,
    DateTime? enrolledAt,
    Uint8List? portraitBytes,
    bool clearPortrait = false,
  }) {
    return FaceProfile(
      identityKey: identityKey ?? this.identityKey,
      displayName: displayName ?? this.displayName,
      enrolledAt: enrolledAt ?? this.enrolledAt,
      portraitBytes:
          clearPortrait ? null : (portraitBytes ?? this.portraitBytes),
    );
  }
}

class FaceAttendanceRecord {
  const FaceAttendanceRecord({
    this.checkedInAt,
  });

  final DateTime? checkedInAt;

  factory FaceAttendanceRecord.fromJson(Map<String, dynamic> json) {
    return FaceAttendanceRecord(
      checkedInAt: DateTime.tryParse(json['checkedInAt']?.toString() ?? ''),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'checkedInAt': checkedInAt?.toIso8601String(),
    };
  }

  bool isCheckedInToday([DateTime? now]) {
    final value = checkedInAt;
    if (value == null) {
      return false;
    }
    final current = now ?? DateTime.now();
    return value.year == current.year &&
        value.month == current.month &&
        value.day == current.day;
  }
}

class VideoSnapshot {
  const VideoSnapshot({
    required this.profile,
    required this.portraitBytes,
    required this.attendanceStatusText,
    required this.recognitionText,
    required this.cameraName,
    required this.backendStatus,
    required this.checkedIn,
    required this.isCheckingIn,
    required this.countdownSeconds,
    required this.consecutiveMatches,
    required this.lastCheckSucceeded,
    required this.attendanceIntervalMinutes,
    required this.attendanceRemainingSeconds,
    this.lastCheckInAt,
    this.nextCheckInDueAt,
  });

  final FaceProfile profile;
  final Uint8List? portraitBytes;
  final String attendanceStatusText;
  final String recognitionText;
  final String cameraName;
  final String backendStatus;
  final bool checkedIn;
  final bool isCheckingIn;
  final int countdownSeconds;
  final int consecutiveMatches;
  final bool lastCheckSucceeded;
  final int attendanceIntervalMinutes;
  final int attendanceRemainingSeconds;
  final DateTime? lastCheckInAt;
  final DateTime? nextCheckInDueAt;

  bool get hasPortrait => portraitBytes != null && portraitBytes!.isNotEmpty;

  VideoSnapshot copyWith({
    FaceProfile? profile,
    Uint8List? portraitBytes,
    bool clearPortrait = false,
    String? attendanceStatusText,
    String? recognitionText,
    String? cameraName,
    String? backendStatus,
    bool? checkedIn,
    bool? isCheckingIn,
    int? countdownSeconds,
    int? consecutiveMatches,
    bool? lastCheckSucceeded,
    int? attendanceIntervalMinutes,
    int? attendanceRemainingSeconds,
    DateTime? lastCheckInAt,
    DateTime? nextCheckInDueAt,
    bool clearLastCheckInAt = false,
    bool clearNextCheckInDueAt = false,
  }) {
    return VideoSnapshot(
      profile: profile ?? this.profile,
      portraitBytes:
          clearPortrait ? null : (portraitBytes ?? this.portraitBytes),
      attendanceStatusText: attendanceStatusText ?? this.attendanceStatusText,
      recognitionText: recognitionText ?? this.recognitionText,
      cameraName: cameraName ?? this.cameraName,
      backendStatus: backendStatus ?? this.backendStatus,
      checkedIn: checkedIn ?? this.checkedIn,
      isCheckingIn: isCheckingIn ?? this.isCheckingIn,
      countdownSeconds: countdownSeconds ?? this.countdownSeconds,
      consecutiveMatches: consecutiveMatches ?? this.consecutiveMatches,
      lastCheckSucceeded: lastCheckSucceeded ?? this.lastCheckSucceeded,
      attendanceIntervalMinutes:
          attendanceIntervalMinutes ?? this.attendanceIntervalMinutes,
      attendanceRemainingSeconds:
          attendanceRemainingSeconds ?? this.attendanceRemainingSeconds,
      lastCheckInAt:
          clearLastCheckInAt ? null : (lastCheckInAt ?? this.lastCheckInAt),
      nextCheckInDueAt: clearNextCheckInDueAt
          ? null
          : (nextCheckInDueAt ?? this.nextCheckInDueAt),
    );
  }
}

class GimbalState {
  const GimbalState({
    required this.connected,
    required this.active,
    required this.locked,
    required this.message,
    required this.statusRows,
  });

  final bool connected;
  final bool active;
  final bool locked;
  final String message;
  final List<StatusRow> statusRows;
}

class AgentEvent {
  const AgentEvent({
    required this.type,
    required this.payload,
  });

  final String type;
  final Map<String, dynamic> payload;
}

class AgentReply {
  const AgentReply({
    required this.ok,
    required this.text,
    required this.traceId,
    required this.executed,
    required this.awaitingConfirmation,
    required this.confirmToken,
    required this.mode,
    required this.detail,
  });

  final bool ok;
  final String text;
  final String traceId;
  final bool executed;
  final bool awaitingConfirmation;
  final String confirmToken;
  final String mode;
  final String detail;
}
