import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../shared/widgets/panel_card.dart';
import 'video_controller.dart';

class VideoPage extends ConsumerWidget {
  const VideoPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final snapshot = ref.watch(videoControllerProvider);

    return snapshot.when(
      data: (data) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
        children: [
          Text(
            '门禁打卡',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontSize: 28,
                  height: 1.02,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'HTML 端负责账号和唯一人脸照片，APP 端负责识别打卡并把结果回写到同一套账号库。',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          PanelCard(
            title: '当前账号',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SimpleRow(label: '账号', value: data.profile.identityKey),
                const SizedBox(height: 10),
                _SimpleRow(label: '状态', value: data.backendStatus),
                const SizedBox(height: 10),
                _SimpleRow(
                  label: '有效期',
                  value: _formatInterval(data.attendanceIntervalMinutes),
                ),
                const SizedBox(height: 10),
                _SimpleRow(
                  label: '照片',
                  value: data.hasPortrait ? '已从板端同步' : '请先去 HTML 上传',
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.tonal(
                        onPressed: () => _showAccountDialog(context, ref),
                        child: const Text('切换账号'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.tonal(
                        onPressed: () => ref
                            .read(videoControllerProvider.notifier)
                            .refresh(),
                        child: const Text('刷新同步'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          PanelCard(
            title: '人脸模板',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AspectRatio(
                  aspectRatio: 16 / 10,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF121927), Color(0xFF273447)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: data.profile.portraitBytes != null &&
                              data.profile.portraitBytes!.isNotEmpty
                          ? Image.memory(
                              data.profile.portraitBytes!,
                              fit: BoxFit.contain,
                              gaplessPlayback: true,
                              filterQuality: FilterQuality.high,
                            )
                          : _PortraitPlaceholder(
                              name: data.profile.displayName),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _InfoCard(
                        title: '姓名',
                        value: data.profile.displayName,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _InfoCard(
                        title: '同步时间',
                        value: fmtDateTime(data.profile.enrolledAt),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _StatusCard(
                  status: data.attendanceStatusText,
                  detail: data.recognitionText,
                  checkedIn: data.checkedIn,
                  isCheckingIn: data.isCheckingIn,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: FilledButton(
                    onPressed: data.isCheckingIn
                        ? null
                        : () => _startCheckIn(context, ref),
                    style: FilledButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: Text(
                      data.isCheckingIn ? '识别中...' : '打卡',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          PanelCard(
            title: '识别信息',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SimpleRow(label: '服务', value: data.backendStatus),
                const SizedBox(height: 10),
                _SimpleRow(label: '摄像头', value: data.cameraName),
                const SizedBox(height: 10),
                _SimpleRow(label: '打卡账号', value: data.profile.identityKey),
                const SizedBox(height: 10),
                _SimpleRow(
                  label: '最近打卡',
                  value: data.lastCheckInAt == null
                      ? '未打卡'
                      : fmtDateTime(data.lastCheckInAt!),
                ),
                const SizedBox(height: 10),
                _SimpleRow(
                  label: '下次重打卡',
                  value: data.nextCheckInDueAt == null
                      ? '待打卡后生成'
                      : fmtDateTime(data.nextCheckInDueAt!),
                ),
              ],
            ),
          ),
        ],
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('门禁页面加载失败\n$error', textAlign: TextAlign.center),
        ),
      ),
    );
  }

  Future<void> _showAccountDialog(BuildContext context, WidgetRef ref) async {
    final current = ref.read(videoControllerProvider).valueOrNull;
    final usernameController = TextEditingController(
      text: current?.profile.identityKey == '未登录'
          ? ''
          : current?.profile.identityKey,
    );
    final passwordController = TextEditingController();
    final messenger = ScaffoldMessenger.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        var busy = false;
        return StatefulBuilder(
          builder: (context, setState) => AlertDialog(
            backgroundColor: AppPalette.panelStrong,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Text('切换账号'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: usernameController,
                  decoration: const InputDecoration(
                    labelText: '账号',
                    hintText: '例如 123',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: '密码',
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed:
                    busy ? null : () => Navigator.of(dialogContext).pop(false),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: busy
                    ? null
                    : () async {
                        setState(() => busy = true);
                        final success = await ref
                            .read(videoControllerProvider.notifier)
                            .login(
                              username: usernameController.text,
                              password: passwordController.text,
                            );
                        if (dialogContext.mounted) {
                          Navigator.of(dialogContext).pop(success);
                        }
                      },
                child: Text(busy ? '同步中...' : '确认'),
              ),
            ],
          ),
        );
      },
    );
    usernameController.dispose();
    passwordController.dispose();
    if (ok == null) {
      return;
    }
    messenger.showSnackBar(
      SnackBar(
        content: Text(ok ? '账号同步成功' : '账号同步失败，请检查账号密码'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _startCheckIn(BuildContext context, WidgetRef ref) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _CheckInDialog(),
    );
    final ok = await ref.read(videoControllerProvider.notifier).startCheckIn();
    if (context.mounted) {
      Navigator.of(context, rootNavigator: true).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(ok ? '打卡成功' : '打卡失败，请重试'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }
}

class _CheckInDialog extends ConsumerWidget {
  const _CheckInDialog();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(videoControllerProvider).valueOrNull;
    final remaining = data?.countdownSeconds ?? 10;
    final progress =
        (((10 - remaining) / 10).clamp(0.0, 1.0) as num).toDouble();
    final matches = data?.consecutiveMatches ?? 0;
    return AlertDialog(
      backgroundColor: AppPalette.panelStrong,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: const Text('正在进行打卡'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('只在打卡时请求识别，命中 2 次就会把结果写回板端账号库。'),
          const SizedBox(height: 10),
          Text(
            '当前重打卡有效期：${_formatInterval(data?.attendanceIntervalMinutes ?? 1440)}',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: 72,
            height: 72,
            child: CircularProgressIndicator(
              value: progress,
              strokeWidth: 6,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '${remaining}s',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text('识别命中 $matches/2'),
          const SizedBox(height: 8),
          Text(
            data?.recognitionText ?? '',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}

String _formatInterval(int minutes) {
  if (minutes <= 0) {
    return '-';
  }
  if (minutes % 60 == 0) {
    final hours = minutes ~/ 60;
    if (hours % 24 == 0) {
      return '${hours ~/ 24} 天';
    }
    return '$hours 小时';
  }
  return '$minutes 分钟';
}

class _PortraitPlaceholder extends StatelessWidget {
  const _PortraitPlaceholder({
    required this.name,
  });

  final String name;

  @override
  Widget build(BuildContext context) {
    final initial = name.isNotEmpty ? name.substring(0, 1) : '人';
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 112,
            height: 112,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.08),
              border: Border.all(color: Colors.white.withOpacity(0.18)),
            ),
            alignment: Alignment.center,
            child: Text(
              initial,
              style: const TextStyle(
                color: AppPalette.text,
                fontSize: 48,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            '等待 HTML 端同步照片',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({
    required this.title,
    required this.value,
  });

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppPalette.panelSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppPalette.stroke),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 6),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({
    required this.status,
    required this.detail,
    required this.checkedIn,
    required this.isCheckingIn,
  });

  final String status;
  final String detail;
  final bool checkedIn;
  final bool isCheckingIn;

  @override
  Widget build(BuildContext context) {
    final color = isCheckingIn
        ? AppPalette.warning
        : (checkedIn ? AppPalette.success : AppPalette.danger);
    final icon = isCheckingIn
        ? Icons.radar_rounded
        : (checkedIn
            ? Icons.verified_user_rounded
            : Icons.pending_actions_rounded);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '打卡状态: $status',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SimpleRow extends StatelessWidget {
  const _SimpleRow({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 74,
          child: Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ),
      ],
    );
  }
}
