String fmtPercent(num? value, {int digits = 1}) {
  if (value == null) {
    return '-';
  }
  return '${value.toStringAsFixed(digits)}%';
}

String fmtNumber(num? value, {int digits = 1}) {
  if (value == null) {
    return '-';
  }
  return value.toStringAsFixed(digits);
}

String fmtMs(num? value) {
  if (value == null) {
    return '-';
  }
  return '${value.round()} ms';
}

String fmtUptime(num? value) {
  if (value == null) {
    return '-';
  }
  final total = value.round();
  final hours = total ~/ 3600;
  final minutes = (total % 3600) ~/ 60;
  final seconds = total % 60;
  if (hours > 0) {
    return '${hours}h ${minutes}m ${seconds}s';
  }
  if (minutes > 0) {
    return '${minutes}m ${seconds}s';
  }
  return '${seconds}s';
}

String fmtBytes(num? value) {
  if (value == null) {
    return '-';
  }
  final units = ['B', 'KB', 'MB', 'GB', 'TB'];
  var size = value.toDouble();
  var index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index++;
  }
  return '${size.toStringAsFixed(index == 0 ? 0 : 1)} ${units[index]}';
}

String fmtRate(num? value) {
  if (value == null) {
    return '-';
  }
  return '${fmtBytes(value)}/s';
}

String fmtDateTime(DateTime? value) {
  if (value == null) {
    return '-';
  }
  final y = value.year.toString().padLeft(4, '0');
  final m = value.month.toString().padLeft(2, '0');
  final d = value.day.toString().padLeft(2, '0');
  final hh = value.hour.toString().padLeft(2, '0');
  final mm = value.minute.toString().padLeft(2, '0');
  return '$y-$m-$d $hh:$mm';
}

String shortCameraLabel(String? device, [Object? index]) {
  if (device != null && device.isNotEmpty) {
    if (device.length <= 28) {
      return device;
    }
    return '...${device.substring(device.length - 25)}';
  }
  if (index != null && index.toString().isNotEmpty) {
    return 'index=$index';
  }
  return '-';
}
