package com.example.rk_app_control

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
