import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/models/app_models.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/panel_card.dart';
import 'dashboard_controller.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final snapshot = ref.watch(dashboardControllerProvider);
    return snapshot.when(
      data: (data) => RefreshIndicator(
        onRefresh: () =>
            ref.read(dashboardControllerProvider.notifier).refresh(),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
          children: [
            _TopBanner(
              uptime: data.uptime,
              updatedAt: data.updatedAt,
              cameraDiagLabel: data.cameraDiagLabel,
              cameraDiagLevel: data.cameraDiagLevel,
              onRefresh: () =>
                  ref.read(dashboardControllerProvider.notifier).refresh(),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 6,
                  child: _HeroMetricCard(
                    metric: data.cpu,
                    color: AppPalette.accent,
                    subtitle: '系统算力',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 4,
                  child: Column(
                    children: [
                      _CompactMetricCard(
                        metric: data.memory,
                        color: AppPalette.success,
                        subtitle: '驻留占用',
                      ),
                      _CompactMetricCard(
                        metric: data.npu,
                        color: AppPalette.accentWarm,
                        subtitle: '推理单元',
                      ),
                    ],
                  ),
                ),
              ],
            ),
            PanelCard(
              title: '快速状态',
              child: Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  _StatusPill(
                    label: '相机诊断',
                    value: data.cameraDiagLabel,
                    color: _levelColor(data.cameraDiagLevel),
                  ),
                  _StatusPill(
                    label: '网络接口',
                    value: data.networkRows.isEmpty
                        ? '无数据'
                        : data.networkRows.first.value,
                    color: AppPalette.accent,
                  ),
                  if (data.visionRows.isNotEmpty)
                    _StatusPill(
                      label: data.visionRows.first.label,
                      value: data.visionRows.first.value,
                      color: AppPalette.accentWarm,
                    ),
                ],
              ),
            ),
            const _SectionTitle(
              title: '视觉与相机',
              subtitle: '像下拉小组件那样，把关键信息先收在一屏里。',
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: PanelCard(
                    title: '视觉指标',
                    child: Column(
                      children: data.visionRows
                          .map((row) => _StatusRowWidget(row: row))
                          .toList(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: PanelCard(
                    title: '相机诊断',
                    child: Column(
                      children: data.cameraRows
                          .map((row) => _StatusRowWidget(row: row))
                          .toList(),
                    ),
                  ),
                ),
              ],
            ),
            const _SectionTitle(
              title: '运行面板',
              subtitle: '进程、网络、最近日志集中排布，现场联调会更直观。',
            ),
            PanelCard(
              title: '关键进程',
              child: Column(
                children: [
                  ...data.processCpuRows
                      .map((row) => _StatusRowWidget(row: row)),
                  if (data.processMemRows.isNotEmpty) const Divider(height: 24),
                  ...data.processMemRows
                      .map((row) => _StatusRowWidget(row: row)),
                ],
              ),
            ),
            PanelCard(
              title: '网络',
              child: Column(
                children: data.networkRows
                    .map((row) => _StatusRowWidget(row: row))
                    .toList(),
              ),
            ),
            PanelCard(
              title: '最近日志',
              child: data.cameraLogs.isEmpty
                  ? const Text('暂无相机相关日志')
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: data.cameraLogs
                          .take(6)
                          .map(
                            (line) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(line,
                                  style:
                                      Theme.of(context).textTheme.bodyMedium),
                            ),
                          )
                          .toList(),
                    ),
            ),
          ],
        ),
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => _ErrorState(
        error: error,
        onRetry: () => ref.read(dashboardControllerProvider.notifier).refresh(),
      ),
    );
  }

  Color _levelColor(StatusLevel level) {
    switch (level) {
      case StatusLevel.good:
        return AppPalette.success;
      case StatusLevel.warn:
        return AppPalette.warning;
      case StatusLevel.bad:
        return AppPalette.danger;
      case StatusLevel.normal:
        return AppPalette.accent;
    }
  }
}

class _TopBanner extends StatelessWidget {
  const _TopBanner({
    required this.uptime,
    required this.updatedAt,
    required this.cameraDiagLabel,
    required this.cameraDiagLevel,
    required this.onRefresh,
  });

  final String uptime;
  final DateTime updatedAt;
  final String cameraDiagLabel;
  final StatusLevel cameraDiagLevel;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    return PanelCard(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('系统总览',
                        style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 8),
                    Text(
                      '像 iPhone 小组件那样先看重点，再决定是否进入视频、智能或云台。',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: onRefresh,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              _MiniHeadline(label: '在线时长', value: uptime),
              const SizedBox(width: 14),
              _MiniHeadline(
                  label: '最近更新',
                  value: DateFormat('HH:mm:ss').format(updatedAt)),
            ],
          ),
          const SizedBox(height: 14),
          _StatusPill(
            label: '相机诊断',
            value: cameraDiagLabel,
            color: switch (cameraDiagLevel) {
              StatusLevel.good => AppPalette.success,
              StatusLevel.warn => AppPalette.warning,
              StatusLevel.bad => AppPalette.danger,
              StatusLevel.normal => AppPalette.accent,
            },
          ),
        ],
      ),
    );
  }
}

class _HeroMetricCard extends StatelessWidget {
  const _HeroMetricCard({
    required this.metric,
    required this.color,
    required this.subtitle,
  });

  final MetricBlock metric;
  final Color color;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return PanelCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(metric.label, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 22),
          Text(
            metric.percent == null
                ? '--'
                : '${metric.percent!.toStringAsFixed(1)}%',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: color,
                  fontSize: 42,
                ),
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: (metric.percent ?? 0) / 100,
              minHeight: 10,
              backgroundColor: Colors.white10,
              color: color,
            ),
          ),
          const SizedBox(height: 14),
          Text(metric.detail, style: Theme.of(context).textTheme.bodyLarge),
        ],
      ),
    );
  }
}

class _CompactMetricCard extends StatelessWidget {
  const _CompactMetricCard({
    required this.metric,
    required this.color,
    required this.subtitle,
  });

  final MetricBlock metric;
  final Color color;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return PanelCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(metric.label, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 16),
          Text(
            metric.percent == null
                ? '--'
                : '${metric.percent!.toStringAsFixed(0)}%',
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(color: color, fontSize: 30),
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: (metric.percent ?? 0) / 100,
              minHeight: 8,
              backgroundColor: Colors.white10,
              color: color,
            ),
          ),
          const SizedBox(height: 12),
          Text(metric.detail, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

class _MiniHeadline extends StatelessWidget {
  const _MiniHeadline({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: AppPalette.panelSoft,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 4),
            Text(value, style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({
    required this.title,
    required this.subtitle,
  });

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 4),
          Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusRowWidget extends StatelessWidget {
  const _StatusRowWidget({required this.row});

  final StatusRow row;

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (row.level) {
      case StatusLevel.good:
        color = AppPalette.success;
        break;
      case StatusLevel.warn:
        color = AppPalette.warning;
        break;
      case StatusLevel.bad:
        color = AppPalette.danger;
        break;
      case StatusLevel.normal:
        color = AppPalette.text;
        break;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Text(row.label)),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              row.value,
              textAlign: TextAlign.right,
              style: TextStyle(color: color, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({
    required this.error,
    required this.onRetry,
  });

  final Object error;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('总览加载失败', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Text(error.toString(), textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: onRetry,
              child: const Text('重试'),
            ),
          ],
        ),
      ),
    );
  }
}
