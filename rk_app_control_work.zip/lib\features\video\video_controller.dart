import 'dart:async';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/app_models.dart';
import '../../core/network/app_api.dart';
import '../../core/storage/local_store.dart';
import '../../core/utils/formatters.dart';
import '../settings/settings_controller.dart';

final videoControllerProvider =
    AutoDisposeAsyncNotifierProvider<VideoController, VideoSnapshot>(
  VideoController.new,
);

class VideoController extends AutoDisposeAsyncNotifier<VideoSnapshot> {
  static const _checkInWindowSeconds = 10;
  static const _requiredMatches = 2;
  static const _defaultSession =
      AppAccountSession(username: '123', password: '123');
  static const _probeInterval = Duration(milliseconds: 350);
  static const _gimbalStepPause = Duration(milliseconds: 180);
  static const _successNodPulseMs = 660;
  static const _successPassPulseMs = 4200;
  static const _successNodPitchRpm = 2.2;
  static const _successPassYawRpm = 6.0;
  static const _failureDropPulseMs = 1100;
  static const _failureRestorePulseMs = 1100;
  static const _failureBlinkCount = 5;
  static const _failureBlinkOnMs = 300;
  static const _failureBlinkOffMs = 300;
  static const _failurePitchRpm = 4.2;

  LocalStore get _store => ref.read(localStoreProvider);

  AppAccountSession _session = _defaultSession;

  @override
  Future<VideoSnapshot> build() async {
    _session = await _loadOrCreateSession();
    return _loadRemoteState(session: _session);
  }

  Future<void> refresh() async {
    final session = await _loadOrCreateSession();
    _session = session;
    state = AsyncData(await _loadRemoteState(session: session));
  }

  Future<bool> login({
    required String username,
    required String password,
  }) async {
    final next = AppAccountSession(
      username: username.trim(),
      password: password.trim(),
    );
    final snapshot = await _loadRemoteState(
      session: next,
      saveOnSuccess: true,
    );
    state = AsyncData(snapshot);
    final ok = snapshot.backendStatus == '账号已连接';
    if (ok) {
      _session = next;
    }
    return ok;
  }

  Future<bool> startCheckIn() async {
    final current = state.valueOrNull;
    if (current == null || current.isCheckingIn) {
      return false;
    }

    state = AsyncData(
      current.copyWith(
        attendanceStatusText: '打卡中',
        recognitionText: '正在请求识别，将自动跟随人脸，请正对摄像头',
        backendStatus: '识别请求中',
        isCheckingIn: true,
        countdownSeconds: _checkInWindowSeconds,
        consecutiveMatches: 0,
        lastCheckSucceeded: false,
      ),
    );

    final trackingReady = await _startCheckInTracking();
    final statusNotes = <String>[
      if (!trackingReady) '云台跟随未启动',
    ];

    var matchCount = 0;
    var lastCameraName = current.cameraName;
    var lastBackendStatus = _composeBackendStatus('识别请求中', statusNotes);
    final deadline = DateTime.now().add(
      const Duration(seconds: _checkInWindowSeconds),
    );
    final profile = current.profile;
    var trackingStopped = false;

    try {
      while (true) {
        final probe = await _probeRecognition(profile);
        if (probe.matched) {
          matchCount += 1;
        }
        if (probe.cameraName.isNotEmpty) {
          lastCameraName = probe.cameraName;
        }
        if (probe.backendStatus.isNotEmpty) {
          lastBackendStatus =
              _composeBackendStatus(probe.backendStatus, statusNotes);
        }

        final success = matchCount >= _requiredMatches;
        final remaining = deadline
            .difference(DateTime.now())
            .inSeconds
            .clamp(0, _checkInWindowSeconds);

        state = AsyncData(
          state.requireValue.copyWith(
            attendanceStatusText:
                success ? '已打卡' : (current.checkedIn ? '已打卡' : '打卡中'),
            recognitionText: probe.message,
            backendStatus: lastBackendStatus,
            cameraName: lastCameraName,
            checkedIn: success || current.checkedIn,
            isCheckingIn: !success,
            countdownSeconds: success ? 0 : remaining,
            consecutiveMatches: matchCount,
            lastCheckSucceeded: success,
          ),
        );

        if (success) {
          await _markAttendance(profile.identityKey);
          await _stopCheckInTracking(reason: 'flutter-checkin-success');
          trackingStopped = true;
          final gestureOk = await _runCheckInSuccessGesture();
          if (!gestureOk) {
            statusNotes.add('云台放行动作异常');
          }
          final refreshed = await _loadRemoteState(session: _session);
          state = AsyncData(
            refreshed.copyWith(
              attendanceStatusText: '已打卡',
              recognitionText: '${profile.displayName} 打卡成功，已示意放行',
              backendStatus: _composeBackendStatus(
                lastBackendStatus,
                statusNotes,
              ),
              cameraName: lastCameraName,
              checkedIn: true,
              isCheckingIn: false,
              countdownSeconds: 0,
              consecutiveMatches: matchCount,
              lastCheckSucceeded: true,
            ),
          );
          return true;
        }

        if (DateTime.now().isAfter(deadline)) {
          break;
        }
        await Future.delayed(_probeInterval);
      }
    } finally {
      if (!trackingStopped) {
        await _stopCheckInTracking(reason: 'flutter-checkin-end');
        trackingStopped = true;
      }
    }

    final failureGestureOk = await _runCheckInFailureGesture();
    if (!failureGestureOk) {
      statusNotes.add('浜戝彴澶辫触鎻愮ず鍔ㄤ綔寮傚父');
    }

    state = AsyncData(
      state.requireValue.copyWith(
        attendanceStatusText: current.checkedIn ? '已打卡' : '未打卡',
        recognitionText: '10 秒内命中不足 2 次，请重试',
        backendStatus: _composeBackendStatus(lastBackendStatus, statusNotes),
        cameraName: lastCameraName,
        checkedIn: current.checkedIn,
        isCheckingIn: false,
        countdownSeconds: 0,
        consecutiveMatches: matchCount,
        lastCheckSucceeded: false,
      ),
    );
    return false;
  }

  Future<AppAccountSession> _loadOrCreateSession() async {
    final saved = await _store.loadAccountSession();
    if (saved != null && saved.isValid) {
      return saved;
    }
    await _store.saveAccountSession(_defaultSession);
    return _defaultSession;
  }

  Future<VideoSnapshot> _loadRemoteState({
    required AppAccountSession session,
    bool saveOnSuccess = false,
  }) async {
    if (!session.isValid) {
      return _fallbackSnapshot(
        session,
        backendStatus: '账号未配置',
        recognitionText: '请输入账号和密码后再同步',
      );
    }

    final api = ref.read(appApiProvider);
    try {
      final auth = await api.postJson(
        '/api/vision/accounts/session',
        {
          'username': session.username,
          'password': session.password,
        },
      );
      final account = Map<String, dynamic>.from(
        auth['account'] as Map? ?? const <String, dynamic>{},
      );
      final settings = Map<String, dynamic>.from(
        auth['settings'] as Map? ?? const <String, dynamic>{},
      );
      Uint8List? portraitBytes;
      final portraitUrl = account['portrait_url']?.toString() ?? '';
      if (portraitUrl.isNotEmpty) {
        portraitBytes = await api.getBytes(portraitUrl);
      }
      final snapshot = _snapshotFromAccount(
        session: session,
        account: account,
        settings: settings,
        portraitBytes: portraitBytes,
      );
      if (saveOnSuccess) {
        await _store.saveAccountSession(session);
      }
      return snapshot;
    } catch (_) {
      return _fallbackSnapshot(
        session,
        backendStatus: '账号同步失败',
        recognitionText: '账号或密码错误，或板端账号服务不可用',
      );
    }
  }

  VideoSnapshot _snapshotFromAccount({
    required AppAccountSession session,
    required Map<String, dynamic> account,
    required Map<String, dynamic> settings,
    required Uint8List? portraitBytes,
  }) {
    final username = account['username']?.toString() ?? session.username;
    final displayName = account['display_name']?.toString() ?? username;
    final checkedIn = account['checked_in_valid'] == true ||
        account['checked_in_today'] == true;
    final createdAt =
        DateTime.tryParse(account['created_at']?.toString() ?? '') ??
            DateTime.now();
    final lastCheckInAt = DateTime.tryParse(
      account['last_check_in_at']?.toString() ?? '',
    );
    final nextCheckInDueAt = DateTime.tryParse(
      account['attendance_next_due_at']?.toString() ?? '',
    );
    final attendanceIntervalMinutes = _readPositiveInt(
      account['attendance_recheck_interval_minutes'] ??
          settings['attendance_recheck_interval_minutes'],
      fallback: 1440,
    );
    final attendanceRemainingSeconds = _readPositiveInt(
      account['attendance_remaining_seconds'],
      fallback: 0,
    );
    final profile = FaceProfile(
      identityKey: username,
      displayName: displayName,
      enrolledAt: createdAt,
      portraitBytes: portraitBytes,
    );

    return VideoSnapshot(
      profile: profile,
      portraitBytes: portraitBytes,
      attendanceStatusText: checkedIn ? '已打卡' : '未打卡',
      recognitionText: portraitBytes == null || portraitBytes.isEmpty
          ? '请先在 HTML 端给这个账号上传唯一人脸照片'
          : '账号和照片已从板端同步',
      cameraName: '-',
      backendStatus: '账号已连接',
      checkedIn: checkedIn,
      isCheckingIn: false,
      countdownSeconds: 0,
      consecutiveMatches: 0,
      lastCheckSucceeded: checkedIn,
      attendanceIntervalMinutes: attendanceIntervalMinutes,
      attendanceRemainingSeconds: attendanceRemainingSeconds,
      lastCheckInAt: lastCheckInAt,
      nextCheckInDueAt: nextCheckInDueAt,
    );
  }

  VideoSnapshot _fallbackSnapshot(
    AppAccountSession session, {
    required String backendStatus,
    required String recognitionText,
  }) {
    final profile = FaceProfile(
      identityKey: session.username.isEmpty ? '未登录' : session.username,
      displayName: session.username.isEmpty ? '未登录' : session.username,
      enrolledAt: DateTime.now(),
    );
    return VideoSnapshot(
      profile: profile,
      portraitBytes: null,
      attendanceStatusText: '未打卡',
      recognitionText: recognitionText,
      cameraName: '-',
      backendStatus: backendStatus,
      checkedIn: false,
      isCheckingIn: false,
      countdownSeconds: 0,
      consecutiveMatches: 0,
      lastCheckSucceeded: false,
      attendanceIntervalMinutes: 1440,
      attendanceRemainingSeconds: 0,
      lastCheckInAt: null,
      nextCheckInDueAt: null,
    );
  }

  Future<void> _markAttendance(String username) async {
    final api = ref.read(appApiProvider);
    await api.postJson(
      '/api/vision/accounts/checkin',
      {
        'username': username,
        'action': 'checkin',
      },
    );
  }

  Future<bool> _startCheckInTracking() async {
    final api = ref.read(appApiProvider);
    try {
      await api.getJson(
        '/api/vision/gimbal/lock/start',
        queryParameters: {
          'target': 'person',
          'detector': 'face',
          'continuous': '1',
          'timeout_sec': '${_checkInWindowSeconds + 2}',
          'reason': 'flutter-checkin-follow',
        },
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _stopCheckInTracking({required String reason}) async {
    final api = ref.read(appApiProvider);
    try {
      await api.getJson(
        '/api/vision/gimbal/lock/stop',
        queryParameters: {'reason': reason},
      );
    } catch (_) {
      // Best-effort stop.
    }
  }

  Future<bool> _runCheckInSuccessGesture() async {
    try {
      await _pulseGimbal(
        pitch: _successNodPitchRpm,
        autoStopMs: _successNodPulseMs,
        reason: 'flutter-checkin-nod-down-1',
      );
      await _pulseGimbal(
        pitch: -_successNodPitchRpm,
        autoStopMs: _successNodPulseMs,
        reason: 'flutter-checkin-nod-up-1',
      );
      await _pulseGimbal(
        pitch: _successNodPitchRpm,
        autoStopMs: _successNodPulseMs,
        reason: 'flutter-checkin-nod-down-2',
      );
      await _pulseGimbal(
        pitch: -_successNodPitchRpm,
        autoStopMs: _successNodPulseMs,
        reason: 'flutter-checkin-nod-up-2',
      );
      await _pulseGimbal(
        yaw: _successPassYawRpm,
        autoStopMs: _successPassPulseMs,
        reason: 'flutter-checkin-pass-right',
      );
      await _pulseGimbal(
        yaw: -_successPassYawRpm,
        autoStopMs: _successPassPulseMs,
        reason: 'flutter-checkin-pass-return',
      );
      await _stopGimbalMotion(reason: 'flutter-checkin-gesture-stop');
      return true;
    } catch (_) {
      await _stopGimbalMotion(reason: 'flutter-checkin-gesture-error');
      return false;
    }
  }

  Future<bool> _runCheckInFailureGesture() async {
    try {
      await _pulseGimbal(
        pitch: _failurePitchRpm,
        autoStopMs: _failureDropPulseMs,
        reason: 'flutter-checkin-fail-down',
      );
      await _blinkLaser(
        blinks: _failureBlinkCount,
        laserOnMs: _failureBlinkOnMs,
        laserOffMs: _failureBlinkOffMs,
        reason: 'flutter-checkin-fail-blink',
      );
      await _pulseGimbal(
        pitch: -_failurePitchRpm,
        autoStopMs: _failureRestorePulseMs,
        reason: 'flutter-checkin-fail-restore',
      );
      await _stopGimbalMotion(reason: 'flutter-checkin-fail-stop');
      return true;
    } catch (_) {
      await _stopGimbalMotion(reason: 'flutter-checkin-fail-error');
      return false;
    }
  }

  Future<void> _pulseGimbal({
    double yaw = 0,
    double pitch = 0,
    required int autoStopMs,
    required String reason,
  }) async {
    final api = ref.read(appApiProvider);
    await api.getJson(
      '/api/vision/gimbal/command',
      queryParameters: {
        'yaw_rpm': '$yaw',
        'pitch_rpm': '$pitch',
        'auto_stop_ms': '$autoStopMs',
        'reason': reason,
      },
    );
    await Future.delayed(
      Duration(milliseconds: autoStopMs) + _gimbalStepPause,
    );
  }

  Future<void> _stopGimbalMotion({required String reason}) async {
    final api = ref.read(appApiProvider);
    try {
      await api.getJson(
        '/api/vision/gimbal/command',
        queryParameters: {
          'mode': 'stop',
          'reason': reason,
        },
      );
    } catch (_) {
      // Best-effort stop.
    }
  }

  Future<void> _blinkLaser({
    required int blinks,
    required int laserOnMs,
    required int laserOffMs,
    required String reason,
  }) async {
    final api = ref.read(appApiProvider);
    await api.getJson(
      '/api/vision/gimbal/laser/blink',
      queryParameters: {
        'blinks': '$blinks',
        'laser_on_ms': '$laserOnMs',
        'laser_off_ms': '$laserOffMs',
        'reason': reason,
      },
    );
    await Future.delayed(
      Duration(milliseconds: blinks * (laserOnMs + laserOffMs)) +
          _gimbalStepPause,
    );
  }

  Future<_RecognitionProbe> _probeRecognition(FaceProfile profile) async {
    final api = ref.read(appApiProvider);
    try {
      final observe = await api.getJson(
        '/api/vision/observe',
        queryParameters: const {
          'detector': 'face',
          'recognize': '1',
        },
      );
      final camera = observe['camera'] as Map? ?? const {};
      final cameraName = shortCameraLabel(
        camera['device']?.toString(),
        camera['index'],
      );
      return _parseRecognition(profile, observe).copyWith(
        cameraName: cameraName,
        backendStatus: _buildBackendStatus(observe),
      );
    } catch (_) {
      return const _RecognitionProbe(
        matched: false,
        message: '识别服务不可用，请检查板端服务',
        backendStatus: '识别服务离线',
      );
    }
  }

  _RecognitionProbe _parseRecognition(
    FaceProfile profile,
    Map<String, dynamic> observe,
  ) {
    final objects =
        (observe['objects'] as List? ?? const []).whereType<Map>().toList();
    if (objects.isEmpty) {
      return const _RecognitionProbe(
        matched: false,
        message: '未检测到人脸',
      );
    }

    final attrs = objects.first['attributes'];
    final map = attrs is Map
        ? Map<String, dynamic>.from(attrs)
        : const <String, dynamic>{};
    final identityLabel = map['identity_label']?.toString() ?? '';
    final identityMatch = map['identity_match'] == true;
    final matched = identityMatch && identityLabel == profile.identityKey;

    if (matched) {
      return _RecognitionProbe(
        matched: true,
        message: '${profile.displayName} 识别命中',
        identityLabel: identityLabel,
      );
    }

    if (identityLabel.isNotEmpty && identityLabel != 'unknown') {
      return _RecognitionProbe(
        matched: false,
        message: '当前识别结果属于其他账号：$identityLabel',
        identityLabel: identityLabel,
      );
    }

    final bestCandidate = map['identity_best_candidate']?.toString() ?? '';
    final score = map['identity_score'];
    final scoreText = score is num ? score.toStringAsFixed(2) : '';
    if (bestCandidate.isNotEmpty) {
      return _RecognitionProbe(
        matched: false,
        message:
            scoreText.isEmpty ? '检测到人脸，但未达到模板阈值' : '检测到人脸，但匹配分数仅 $scoreText',
        identityLabel: bestCandidate,
      );
    }

    return const _RecognitionProbe(
      matched: false,
      message: '检测到人脸，但未匹配到当前账号',
    );
  }

  String _buildBackendStatus(Map<String, dynamic> observe) {
    final error = observe['error']?.toString() ?? '';
    if (error.contains('camera read failed')) {
      return '摄像头异常';
    }
    if (error.contains('frame unavailable')) {
      return '画面不可用';
    }
    if (observe['ok'] != true) {
      return '识别请求失败';
    }
    return '识别服务在线';
  }

  int _readPositiveInt(dynamic value, {required int fallback}) {
    if (value is num) {
      final intValue = value.toInt();
      return intValue >= 0 ? intValue : fallback;
    }
    final parsed = int.tryParse(value?.toString() ?? '');
    if (parsed == null || parsed < 0) {
      return fallback;
    }
    return parsed;
  }

  String _composeBackendStatus(String primary, Iterable<String> notes) {
    final parts = <String>[];
    final head = primary.trim();
    if (head.isNotEmpty) {
      parts.add(head);
    }
    for (final note in notes) {
      final text = note.trim();
      if (text.isEmpty || parts.contains(text)) {
        continue;
      }
      parts.add(text);
    }
    return parts.isEmpty ? '-' : parts.join(' / ');
  }
}

class _RecognitionProbe {
  const _RecognitionProbe({
    required this.matched,
    required this.message,
    this.identityLabel = '',
    this.cameraName = '',
    this.backendStatus = '',
  });

  final bool matched;
  final String message;
  final String identityLabel;
  final String cameraName;
  final String backendStatus;

  _RecognitionProbe copyWith({
    bool? matched,
    String? message,
    String? identityLabel,
    String? cameraName,
    String? backendStatus,
  }) {
    return _RecognitionProbe(
      matched: matched ?? this.matched,
      message: message ?? this.message,
      identityLabel: identityLabel ?? this.identityLabel,
      cameraName: cameraName ?? this.cameraName,
      backendStatus: backendStatus ?? this.backendStatus,
    );
  }
}
