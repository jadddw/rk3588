import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_models.dart';

class LocalStore {
  static const _baseUrlKey = 'app.base_url';
  static const _historyKey = 'app.command_history';
  static const _faceProfileKey = 'app.face_profile';
  static const _attendanceKey = 'app.face_attendance';
  static const _accountSessionKey = 'app.account_session';

  Future<String> loadBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_baseUrlKey) ?? 'http://192.168.197.169:8090';
  }

  Future<void> saveBaseUrl(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_baseUrlKey, value);
  }

  Future<List<CommandHistoryEntry>> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey);
    if (raw == null || raw.isEmpty) {
      return const [];
    }
    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      return const [];
    }
    return decoded
        .whereType<Map>()
        .map((row) =>
            CommandHistoryEntry.fromJson(Map<String, dynamic>.from(row)))
        .toList();
  }

  Future<void> saveHistory(List<CommandHistoryEntry> rows) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _historyKey,
      jsonEncode(rows.map((row) => row.toJson()).toList()),
    );
  }

  Future<FaceProfile?> loadFaceProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_faceProfileKey);
    if (raw == null || raw.isEmpty) {
      return null;
    }
    final decoded = jsonDecode(raw);
    if (decoded is! Map) {
      return null;
    }
    return FaceProfile.fromJson(Map<String, dynamic>.from(decoded));
  }

  Future<void> saveFaceProfile(FaceProfile profile) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_faceProfileKey, jsonEncode(profile.toJson()));
  }

  Future<FaceAttendanceRecord> loadAttendance() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_attendanceKey);
    if (raw == null || raw.isEmpty) {
      return const FaceAttendanceRecord();
    }
    final decoded = jsonDecode(raw);
    if (decoded is! Map) {
      return const FaceAttendanceRecord();
    }
    return FaceAttendanceRecord.fromJson(Map<String, dynamic>.from(decoded));
  }

  Future<void> saveAttendance(FaceAttendanceRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_attendanceKey, jsonEncode(record.toJson()));
  }

  Future<AppAccountSession?> loadAccountSession() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_accountSessionKey);
    if (raw == null || raw.isEmpty) {
      return null;
    }
    final decoded = jsonDecode(raw);
    if (decoded is! Map) {
      return null;
    }
    return AppAccountSession.fromJson(Map<String, dynamic>.from(decoded));
  }

  Future<void> saveAccountSession(AppAccountSession session) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accountSessionKey, jsonEncode(session.toJson()));
  }
}
