import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/storage/local_store.dart';

final localStoreProvider = Provider<LocalStore>((ref) => LocalStore());

class SettingsState {
  const SettingsState({
    required this.resolvedBaseUrl,
    required this.isConnected,
    required this.isScanning,
    required this.statusText,
    required this.lastProbeAt,
    required this.triedEndpoints,
  });

  final String resolvedBaseUrl;
  final bool isConnected;
  final bool isScanning;
  final String statusText;
  final DateTime? lastProbeAt;
  final List<String> triedEndpoints;

  SettingsState copyWith({
    String? resolvedBaseUrl,
    bool? isConnected,
    bool? isScanning,
    String? statusText,
    DateTime? lastProbeAt,
    bool clearLastProbeAt = false,
    List<String>? triedEndpoints,
  }) {
    return SettingsState(
      resolvedBaseUrl: resolvedBaseUrl ?? this.resolvedBaseUrl,
      isConnected: isConnected ?? this.isConnected,
      isScanning: isScanning ?? this.isScanning,
      statusText: statusText ?? this.statusText,
      lastProbeAt: clearLastProbeAt ? null : (lastProbeAt ?? this.lastProbeAt),
      triedEndpoints: triedEndpoints ?? this.triedEndpoints,
    );
  }
}

class _ProbeHit {
  const _ProbeHit({
    required this.baseUrl,
  });

  final String baseUrl;
}

class SettingsController extends AsyncNotifier<SettingsState> {
  static const _defaultBoardUrl = 'http://192.168.197.169:8090';
  static const _ports = [8090, 18090];
  static const _chunkSize = 24;
  static const _probeTimeout = Duration(milliseconds: 650);

  @override
  Future<SettingsState> build() async {
    final saved = await ref.read(localStoreProvider).loadBaseUrl();
    return _discover(preferred: saved);
  }

  Future<void> refreshConnection() async {
    final current = state.valueOrNull ??
        const SettingsState(
          resolvedBaseUrl: _defaultBoardUrl,
          isConnected: false,
          isScanning: false,
          statusText: '等待扫描连接',
          lastProbeAt: null,
          triedEndpoints: [],
        );
    state = AsyncData(
      current.copyWith(
        isScanning: true,
        isConnected: false,
        statusText: '正在搜索板端服务...',
      ),
    );
    final saved = await ref.read(localStoreProvider).loadBaseUrl();
    state = AsyncData(await _discover(preferred: saved));
  }

  Future<SettingsState> _discover({required String preferred}) async {
    final tried = <String>[];
    final client = HttpClient()..connectionTimeout = _probeTimeout;

    try {
      final quickCandidates = await _quickCandidates(preferred);
      final quickHit =
          await _findFirstReachable(client, quickCandidates, tried);
      if (quickHit != null) {
        await ref.read(localStoreProvider).saveBaseUrl(quickHit.baseUrl);
        return _connectedState(quickHit.baseUrl, tried);
      }

      final subnetCandidates = await _subnetCandidates(preferred);
      final subnetHit =
          await _findFirstReachable(client, subnetCandidates, tried);
      if (subnetHit != null) {
        await ref.read(localStoreProvider).saveBaseUrl(subnetHit.baseUrl);
        return _connectedState(subnetHit.baseUrl, tried);
      }

      return SettingsState(
        resolvedBaseUrl: _normalizeUrl(preferred).isEmpty
            ? _defaultBoardUrl
            : _normalizeUrl(preferred),
        isConnected: false,
        isScanning: false,
        statusText: '未找到板端服务，请确认手机和板子已在同一热点内',
        lastProbeAt: DateTime.now(),
        triedEndpoints: tried,
      );
    } finally {
      client.close(force: true);
    }
  }

  SettingsState _connectedState(String baseUrl, List<String> tried) {
    final uri = Uri.parse(baseUrl);
    final port = uri.hasPort ? uri.port : 80;
    final mode = port == 8090 ? '已连接正式统一网关' : '已连接兼容网关';
    return SettingsState(
      resolvedBaseUrl: baseUrl,
      isConnected: true,
      isScanning: false,
      statusText: mode,
      lastProbeAt: DateTime.now(),
      triedEndpoints: tried,
    );
  }

  Future<List<String>> _quickCandidates(String preferred) async {
    final saved = _normalizeUrl(preferred);
    final hosts = <String>{
      if (saved.isNotEmpty) _hostOf(saved),
      '192.168.197.169',
      '192.168.4.1',
      '192.168.43.1',
      '192.168.137.1',
      '172.20.10.1',
      '192.168.61.1',
      'rk3588.local',
      'orangepi.local',
      'rk-control.local',
    }..removeWhere((item) => item.isEmpty);

    final interfaces = await _privateIpv4Addresses();
    for (final ip in interfaces) {
      final parts = ip.split('.');
      if (parts.length != 4) {
        continue;
      }
      final prefix = '${parts[0]}.${parts[1]}.${parts[2]}.';
      final ownLast = int.tryParse(parts[3]) ?? 0;
      if (ownLast == 1) {
        hosts.add('${prefix}169');
        hosts.add('${prefix}197');
        hosts.add('${prefix}100');
        hosts.add('${prefix}2');
      } else {
        hosts.add('${prefix}1');
        hosts.add('${prefix}169');
        hosts.add('${prefix}197');
      }
    }

    return _expandHostsToUrls(hosts.toList(), includeCompat: true);
  }

  Future<List<String>> _subnetCandidates(String preferred) async {
    final urls = <String>[];
    final interfaces = await _privateIpv4Addresses();
    final savedHost = _hostOf(_normalizeUrl(preferred));
    final seenHosts = <String>{};

    for (final ip in interfaces) {
      final parts = ip.split('.');
      if (parts.length != 4) {
        continue;
      }
      final prefix = '${parts[0]}.${parts[1]}.${parts[2]}.';
      final ownLast = int.tryParse(parts[3]) ?? 0;
      final hostOrder = <int>[
        if (savedHost.startsWith(prefix))
          int.tryParse(savedHost.split('.').last) ?? -1,
        if (ownLast == 1) 169,
        if (ownLast == 1) ...List<int>.generate(31, (i) => i + 2),
        if (ownLast == 1) ...List<int>.generate(101, (i) => i + 100),
        if (ownLast == 1) ...List<int>.generate(67, (i) => i + 33),
        if (ownLast == 1) ...List<int>.generate(54, (i) => i + 201),
        if (ownLast != 1) 1,
      ].where((item) => item >= 1 && item <= 254 && item != ownLast).toList();

      for (final host in hostOrder) {
        final value = '$prefix$host';
        if (seenHosts.add(value)) {
          urls.addAll(_expandHostsToUrls([value], includeCompat: true));
        }
      }
    }
    return urls;
  }

  List<String> _expandHostsToUrls(List<String> hosts,
      {required bool includeCompat}) {
    final urls = <String>[];
    final seen = <String>{};
    for (final host in hosts) {
      if (host.isEmpty) {
        continue;
      }
      for (final port in _ports) {
        if (port == 18090 && !includeCompat) {
          continue;
        }
        final url = 'http://$host:$port';
        if (seen.add(url)) {
          urls.add(url);
        }
      }
    }
    return urls;
  }

  Future<List<String>> _privateIpv4Addresses() async {
    final results = <String>{};
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      for (final interface in interfaces) {
        for (final address in interface.addresses) {
          final ip = address.address;
          if (_isPrivateIpv4(ip)) {
            results.add(ip);
          }
        }
      }
    } catch (_) {
      return const [];
    }
    return results.toList();
  }

  bool _isPrivateIpv4(String ip) {
    final parts = ip.split('.');
    if (parts.length != 4) {
      return false;
    }
    final a = int.tryParse(parts[0]) ?? -1;
    final b = int.tryParse(parts[1]) ?? -1;
    if (a == 10) {
      return true;
    }
    if (a == 172 && b >= 16 && b <= 31) {
      return true;
    }
    if (a == 192 && b == 168) {
      return true;
    }
    return false;
  }

  Future<_ProbeHit?> _findFirstReachable(
    HttpClient client,
    List<String> urls,
    List<String> tried,
  ) async {
    for (var i = 0; i < urls.length; i += _chunkSize) {
      final chunk = urls.sublist(
          i, i + _chunkSize > urls.length ? urls.length : i + _chunkSize);
      for (final item in chunk) {
        if (!tried.contains(item)) {
          tried.add(item);
        }
      }
      final results = await Future.wait(
        chunk.map((baseUrl) => _probe(client, baseUrl)),
      );
      for (final result in results) {
        if (result != null) {
          return result;
        }
      }
    }
    return null;
  }

  Future<_ProbeHit?> _probe(HttpClient client, String baseUrl) async {
    try {
      final request = await client.getUrl(Uri.parse('$baseUrl/health'));
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      final response = await request.close().timeout(_probeTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return null;
      }
      final body =
          await utf8.decoder.bind(response).join().timeout(_probeTimeout);
      final decoded = jsonDecode(body);
      if (decoded is! Map) {
        return null;
      }
      final json = Map<String, dynamic>.from(decoded);
      if (json['ok'] == true) {
        return _ProbeHit(baseUrl: baseUrl);
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  String _normalizeUrl(String value) {
    var text = value.trim();
    if (text.isEmpty) {
      return '';
    }
    if (!text.startsWith('http://') && !text.startsWith('https://')) {
      text = 'http://$text';
    }
    if (text.endsWith('/')) {
      text = text.substring(0, text.length - 1);
    }
    return text;
  }

  String _hostOf(String value) {
    if (value.isEmpty) {
      return '';
    }
    final uri = Uri.tryParse(value);
    return uri?.host ?? '';
  }
}

final settingsControllerProvider =
    AsyncNotifierProvider<SettingsController, SettingsState>(
        SettingsController.new);
