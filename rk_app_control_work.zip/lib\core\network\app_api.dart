import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_models.dart';
import '../../features/settings/settings_controller.dart';

final appApiProvider = Provider<AppApi>((ref) {
  final settings = ref.watch(settingsControllerProvider).value;
  final baseUrl = settings?.resolvedBaseUrl ?? 'http://192.168.197.169:8090';
  return AppApi(baseUrl);
});

class AppApi {
  AppApi(this.baseUrl)
      : _dio = Dio(
          BaseOptions(
            baseUrl: baseUrl,
            connectTimeout: const Duration(seconds: 6),
            receiveTimeout: const Duration(seconds: 20),
            sendTimeout: const Duration(seconds: 12),
          ),
        );

  final String baseUrl;
  final Dio _dio;

  Future<Map<String, dynamic>> getJson(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    final response = await _dio.get<dynamic>(
      path,
      queryParameters: queryParameters,
    );
    if (response.data is Map) {
      return Map<String, dynamic>.from(response.data as Map);
    }
    throw StateError('Expected JSON object from $path');
  }

  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body, {
    Map<String, String>? headers,
  }) async {
    final response = await _dio.post<dynamic>(
      path,
      data: body,
      options: Options(headers: headers),
    );
    if (response.data is Map) {
      return Map<String, dynamic>.from(response.data as Map);
    }
    throw StateError('Expected JSON object from $path');
  }

  Future<Map<String, dynamic>> postMultipart(
    String path, {
    Map<String, dynamic>? fields,
    File? file,
    String fileField = 'file',
    String? filename,
  }) async {
    final data = FormData();
    for (final entry in (fields ?? const <String, dynamic>{}).entries) {
      data.fields.add(MapEntry(entry.key, entry.value?.toString() ?? ''));
    }
    if (file != null) {
      data.files.add(
        MapEntry(
          fileField,
          await MultipartFile.fromFile(
            file.path,
            filename: filename,
          ),
        ),
      );
    }
    final response = await _dio.post<dynamic>(
      path,
      data: data,
      options: Options(
        headers: const {'Accept': 'application/json'},
      ),
    );
    if (response.data is Map) {
      return Map<String, dynamic>.from(response.data as Map);
    }
    throw StateError('Expected JSON object from $path');
  }

  Future<Uint8List> getBytes(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    final response = await _dio.get<List<int>>(
      path,
      queryParameters: queryParameters,
      options: Options(responseType: ResponseType.bytes),
    );
    final data = response.data;
    if (data == null || data.isEmpty) {
      throw StateError('Expected binary body from $path');
    }
    return Uint8List.fromList(data);
  }

  Stream<AgentEvent> streamChat(
    String path,
    Map<String, dynamic> body,
  ) async* {
    final response = await _dio.post<ResponseBody>(
      path,
      data: body,
      options: Options(
        responseType: ResponseType.stream,
        headers: const {
          'Accept': 'text/event-stream',
          'Content-Type': 'application/json',
        },
      ),
    );
    final stream = response.data?.stream;
    if (stream == null) {
      throw StateError('Stream body unavailable');
    }

    var buffer = '';
    await for (final chunk in stream) {
      buffer +=
          utf8.decode(chunk, allowMalformed: true).replaceAll('\r\n', '\n');
      while (true) {
        final split = buffer.indexOf('\n\n');
        if (split < 0) {
          break;
        }
        final block = buffer.substring(0, split).trim();
        buffer = buffer.substring(split + 2);
        final event = _parseSseBlock(block);
        if (event != null) {
          yield event;
        }
      }
    }
    final tail = _parseSseBlock(buffer.trim());
    if (tail != null) {
      yield tail;
    }
  }

  Stream<Uint8List> streamMjpeg(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async* {
    final response = await _dio.get<ResponseBody>(
      path,
      queryParameters: queryParameters,
      options: Options(responseType: ResponseType.stream),
    );
    final stream = response.data?.stream;
    if (stream == null) {
      throw StateError('MJPEG stream unavailable');
    }

    final bytes = <int>[];
    var start = -1;
    await for (final chunk in stream) {
      bytes.addAll(chunk);
      while (true) {
        if (start < 0) {
          start = _indexOfMarker(bytes, const [0xFF, 0xD8], 0);
          if (start < 0) {
            if (bytes.length > 1024 * 1024) {
              bytes.clear();
            }
            break;
          }
        }
        final end = _indexOfMarker(bytes, const [0xFF, 0xD9], start + 2);
        if (end < 0) {
          if (start > 0) {
            bytes.removeRange(0, start);
            start = 0;
          }
          break;
        }
        final frame = Uint8List.fromList(bytes.sublist(start, end + 2));
        bytes.removeRange(0, end + 2);
        start = -1;
        yield frame;
      }
    }
  }

  Future<void> close() async {
    _dio.close(force: true);
  }

  int _indexOfMarker(List<int> source, List<int> marker, int from) {
    for (var i = from; i <= source.length - marker.length; i++) {
      var found = true;
      for (var j = 0; j < marker.length; j++) {
        if (source[i + j] != marker[j]) {
          found = false;
          break;
        }
      }
      if (found) {
        return i;
      }
    }
    return -1;
  }

  AgentEvent? _parseSseBlock(String block) {
    if (block.isEmpty) {
      return null;
    }
    var type = 'message';
    final dataLines = <String>[];
    for (final line in block.split('\n')) {
      if (line.startsWith('event:')) {
        type = line.substring(6).trim();
      } else if (line.startsWith('data:')) {
        dataLines.add(line.substring(5).trim());
      }
    }
    final joined = dataLines.join('\n');
    if (joined.isEmpty) {
      return AgentEvent(type: type, payload: const {});
    }
    final decoded = jsonDecode(joined);
    return AgentEvent(
      type: type,
      payload: decoded is Map<String, dynamic>
          ? decoded
          : <String, dynamic>{'value': decoded},
    );
  }
}
