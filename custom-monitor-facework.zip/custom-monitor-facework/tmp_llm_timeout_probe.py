
import json, urllib.request, urllib.error
payload={"message":"Explain in detail the architecture, modules, data flow, deployment path, and current limitations of this project in Chinese, and expand as much as possible.","tools":[],"attach_vision":False,"max_retries":0,"timeout_sec":20,"max_tokens":64}
req=urllib.request.Request("http://127.0.0.1:8091/api/llm/chat", data=json.dumps(payload).encode("utf-8"), headers={"Content-Type":"application/json"})
try:
    with urllib.request.urlopen(req, timeout=50) as r:
        print(r.read().decode('utf-8','replace')[:2000])
except urllib.error.HTTPError as e:
    print('HTTP_ERROR', e.code)
    try:
        print(e.read().decode('utf-8','replace')[:2000])
    except Exception as inner:
        print('READ_ERR', repr(inner))
except Exception as e:
    print('ERR', repr(e))
