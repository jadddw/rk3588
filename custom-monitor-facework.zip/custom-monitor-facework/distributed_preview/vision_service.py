#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit

from ipc_http import bind_server

HOST = os.environ.get("VISION_PREVIEW_HOST", "0.0.0.0")
PORT = int(os.environ.get("VISION_PREVIEW_PORT", "8092"))
UNIX_SOCKET_PATH = str(os.environ.get("VISION_UNIX_SOCKET", "")).strip()

VISION_EXECUTION_MODE = "embedded"
VISION_STREAM_MAX_FPS = float(os.environ.get("VISION_STREAM_MAX_FPS", "120"))
VISION_STREAM_MAX_CLIENTS = int(os.environ.get("VISION_STREAM_MAX_CLIENTS", "0"))
VISION_STREAM_FACE_MAX_FPS = float(os.environ.get("VISION_STREAM_FACE_MAX_FPS", "30"))
VISION_STREAM_YOLO_WORLD_MAX_FPS = float(os.environ.get("VISION_STREAM_YOLO_WORLD_MAX_FPS", "24"))
VISION_STREAM_YOLO_MAX_FPS = float(os.environ.get("VISION_STREAM_YOLO_MAX_FPS", "20"))
VISION_STREAM_ATTR_MAX_FPS = float(os.environ.get("VISION_STREAM_ATTR_MAX_FPS", "18"))

VISION_API_ROUTES = {
    "/api/vision/observe",
    "/api/vision/profile",
    "/api/vision/profile/set",
    "/api/vision/enabled/set",
    "/api/vision/stream/set",
    "/api/vision/emotion/set",
    "/api/vision/recover",
    "/api/vision/face_recognition",
    "/api/vision/face_recognition/reload",
    "/api/vision/accounts",
    "/api/vision/accounts/settings",
    "/api/vision/accounts/create",
    "/api/vision/accounts/session",
    "/api/vision/accounts/checkin",
    "/api/vision/accounts/portrait",
    "/api/vision/gimbal/status",
    "/api/vision/gimbal/command",
    "/api/vision/gimbal/laser/blink",
    "/api/vision/gimbal/lock/status",
    "/api/vision/gimbal/lock/start",
    "/api/vision/gimbal/lock/stop",
    "/api/vision/frame.jpg",
    "/api/vision/stream.mjpg",
    "/api/vision/yolo_world/filter",
    "/api/vision/yolo_world/filter/set",
    "/api/vision/yolo_world/prompt",
    "/api/vision/yolo_world/prompt/set",
    "/api/vision/yolo_world/vocab",
    "/api/vision/yolo_world/vocab/list",
    "/api/vision/yolo_world/vocab/apply",
    "/api/vision/yolo_world/vocab/reload",
    "/api/vision/sensors",
    "/api/vision/sensors/status",
    "/api/vision/sensors/thresholds",
    "/api/vision/sensors/sample",
}

_EMBEDDED_LOCK = threading.Lock()
_EMBEDDED_VISION: Any | None = None
_EMBEDDED_ERROR = ""


class SensorStateStore:
    _METRICS: dict[str, dict[str, Any]] = {
        "temperature_c": {
            "label": "温度",
            "unit": "°C",
            "aliases": ("temperature", "temp", "temperature_c"),
            "advice": {
                "high": "温度偏高，建议检查增氧、遮阳、换水或冷却环节。",
                "low": "温度偏低，建议检查加热、保温和循环水状态。",
            },
        },
        "ph": {
            "label": "pH",
            "unit": "",
            "aliases": ("ph", "ph_value"),
            "advice": {
                "high": "pH 偏高，建议检查换水、加药和探头校准情况。",
                "low": "pH 偏低，建议检查酸化来源、换水和探头校准情况。",
            },
        },
        "turbidity_ntu": {
            "label": "浊度",
            "unit": "NTU",
            "aliases": ("turbidity", "ntu", "turbidity_ntu"),
            "advice": {
                "high": "浊度偏高，建议检查残饵、排泄物、过滤和换水情况。",
                "low": "浊度偏低，建议结合现场确认是否为清水状态或探头过度漂移。",
            },
        },
    }

    def __init__(self) -> None:
        runtime_dir = Path(__file__).resolve().parent / "runtime"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        state_path_text = str(os.environ.get("VISION_SENSOR_STATE_PATH", "")).strip()
        self._state_path = Path(state_path_text) if state_path_text else (runtime_dir / "sensor_state.json")
        self._lock = threading.Lock()
        self._state = self._default_state()
        self._load()

    def _default_state(self) -> dict[str, Any]:
        return {
            "source": {
                "mode": "usb_serial",
                "port": str(os.environ.get("VISION_SENSOR_SERIAL_PORT", "/dev/ttyUSB0")).strip() or "/dev/ttyUSB0",
                "baudrate": int(str(os.environ.get("VISION_SENSOR_SERIAL_BAUD", "115200")).strip() or "115200"),
                "protocol": str(os.environ.get("VISION_SENSOR_PROTOCOL", "custom_ascii")).strip() or "custom_ascii",
                "status": "awaiting_data",
            },
            "latest": {
                "temperature_c": None,
                "ph": None,
                "turbidity_ntu": None,
                "updated_at": "",
                "sample_source": "",
            },
            "thresholds": {
                "temperature_c": {"min": 20.0, "max": 32.0},
                "ph": {"min": 6.5, "max": 8.5},
                "turbidity_ntu": {"min": 0.0, "max": 15.0},
            },
        }

    def _load(self) -> None:
        if not self._state_path.is_file():
            self._persist()
            return
        try:
            loaded = json.loads(self._state_path.read_text(encoding="utf-8"))
        except Exception:
            self._persist()
            return
        if not isinstance(loaded, dict):
            self._persist()
            return
        self._merge_loaded_state(loaded)
        self._persist()

    def _merge_loaded_state(self, loaded: dict[str, Any]) -> None:
        source = loaded.get("source") if isinstance(loaded.get("source"), dict) else {}
        latest = loaded.get("latest") if isinstance(loaded.get("latest"), dict) else {}
        thresholds = loaded.get("thresholds") if isinstance(loaded.get("thresholds"), dict) else {}

        self._state["source"].update(
            {
                "mode": str(source.get("mode") or self._state["source"]["mode"]).strip() or "usb_serial",
                "port": str(source.get("port") or self._state["source"]["port"]).strip() or "/dev/ttyUSB0",
                "baudrate": self._safe_int(source.get("baudrate"), fallback=self._state["source"]["baudrate"]),
                "protocol": str(source.get("protocol") or self._state["source"]["protocol"]).strip()
                or "custom_ascii",
                "status": str(source.get("status") or self._state["source"]["status"]).strip() or "awaiting_data",
            }
        )
        self._state["latest"]["updated_at"] = str(latest.get("updated_at") or "").strip()
        self._state["latest"]["sample_source"] = str(latest.get("sample_source") or "").strip()
        for metric in self._METRICS.keys():
            self._state["latest"][metric] = self._safe_float(latest.get(metric), fallback=None)
            metric_thr = thresholds.get(metric) if isinstance(thresholds.get(metric), dict) else {}
            self._state["thresholds"][metric] = {
                "min": self._safe_float(metric_thr.get("min"), fallback=self._state["thresholds"][metric]["min"]),
                "max": self._safe_float(metric_thr.get("max"), fallback=self._state["thresholds"][metric]["max"]),
            }

    def _persist(self) -> None:
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        self._state_path.write_text(
            json.dumps(self._state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @staticmethod
    def _safe_float(value: Any, fallback: float | None) -> float | None:
        if value is None or value == "":
            return fallback
        try:
            return float(value)
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def _safe_int(value: Any, fallback: int) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return fallback

    @classmethod
    def _resolve_metric(cls, name: str) -> str:
        raw = str(name or "").strip().lower()
        if not raw:
            return ""
        for metric, meta in cls._METRICS.items():
            aliases = meta.get("aliases") if isinstance(meta.get("aliases"), tuple) else ()
            if raw == metric or raw in aliases:
                return metric
        return ""

    @staticmethod
    def _fmt_value(value: float | None, unit: str) -> str:
        if value is None:
            return "--"
        if abs(value) >= 100 or abs(value - round(value)) < 1e-6:
            text = f"{value:.0f}"
        else:
            text = f"{value:.2f}".rstrip("0").rstrip(".")
        return f"{text}{unit}"

    def _metric_status(
        self,
        metric: str,
        value: float | None,
        threshold_min: float,
        threshold_max: float,
    ) -> tuple[str, str]:
        if value is None:
            return "waiting", "等待数据"
        if value < threshold_min:
            return "low", "低于下限"
        if value > threshold_max:
            return "high", "高于上限"
        return "normal", "范围正常"

    def _build_status_payload(self) -> dict[str, Any]:
        latest = self._state["latest"]
        thresholds = self._state["thresholds"]
        source = dict(self._state["source"])
        updated_at = str(latest.get("updated_at") or "").strip()
        age_sec: float | None = None
        if updated_at:
            try:
                age_sec = max(
                    0.0,
                    time.time() - datetime.fromisoformat(updated_at).timestamp(),
                )
            except Exception:
                age_sec = None

        metrics_payload: dict[str, Any] = {}
        alerts: list[str] = []
        advice: list[str] = []
        normal_count = 0
        present_count = 0
        for metric, meta in self._METRICS.items():
            value = self._safe_float(latest.get(metric), fallback=None)
            threshold_min = float(thresholds[metric]["min"])
            threshold_max = float(thresholds[metric]["max"])
            status, status_label = self._metric_status(metric, value, threshold_min, threshold_max)
            if value is not None:
                present_count += 1
            if status == "normal":
                normal_count += 1
            elif status in ("low", "high"):
                alerts.append(f"{meta['label']}{status_label}")
                advice_map = meta.get("advice") if isinstance(meta.get("advice"), dict) else {}
                advice_text = str(advice_map.get(status) or "").strip()
                if advice_text:
                    advice.append(advice_text)
            metrics_payload[metric] = {
                "key": metric,
                "label": meta["label"],
                "unit": meta["unit"],
                "value": value,
                "value_text": self._fmt_value(value, str(meta["unit"])),
                "status": status,
                "status_label": status_label,
                "threshold_min": threshold_min,
                "threshold_max": threshold_max,
                "threshold_text": f"{self._fmt_value(threshold_min, str(meta['unit']))} ~ {self._fmt_value(threshold_max, str(meta['unit']))}",
            }

        if present_count == 0:
            overall_status = "waiting"
            summary = "传感器页面已就绪，正在等待 USB 串口样本。"
            source["status"] = "awaiting_data"
            if not advice:
                advice.append("先接入 USB 转串口，再把下位机数据桥接到 /api/vision/sensors/sample。")
        elif alerts:
            overall_status = "alert"
            summary = "当前存在传感器告警：" + "、".join(alerts[:3]) + "。"
            source["status"] = "live"
        else:
            overall_status = "ok"
            summary = "当前温度、pH、浊度都在设定阈值范围内。"
            source["status"] = "live"
            if not advice:
                advice.append("当前参数正常，建议继续观察趋势变化与探头稳定性。")

        if age_sec is not None and present_count > 0 and age_sec > 180.0:
            source["status"] = "stale"
            summary += " 但样本更新时间较久，建议检查串口桥接是否仍在运行。"
            advice.append("样本已超过 180 秒未更新，建议检查 USB 串口连接、供电和桥接进程。")

        return {
            "ok": True,
            "timestamp": _ts_now(),
            "summary": summary,
            "overall_status": overall_status,
            "alerts": alerts,
            "advice": advice[:6],
            "advice_text": " ".join(advice[:3]).strip(),
            "source": {
                **source,
                "updated_at": updated_at or None,
                "age_sec": None if age_sec is None else round(age_sec, 1),
                "sample_source": str(latest.get("sample_source") or "").strip() or None,
            },
            "metrics": metrics_payload,
            "latest": {
                "temperature_c": self._safe_float(latest.get("temperature_c"), fallback=None),
                "ph": self._safe_float(latest.get("ph"), fallback=None),
                "turbidity_ntu": self._safe_float(latest.get("turbidity_ntu"), fallback=None),
                "updated_at": updated_at or None,
                "sample_source": str(latest.get("sample_source") or "").strip() or None,
            },
            "thresholds": thresholds,
        }

    def status_payload(self) -> dict[str, Any]:
        with self._lock:
            return self._build_status_payload()

    def update_thresholds(self, body: dict[str, Any]) -> dict[str, Any]:
        changed: list[str] = []
        with self._lock:
            for raw_name, meta in self._METRICS.items():
                aliases = [raw_name, *list(meta.get("aliases") or ())]
                candidate_obj: dict[str, Any] = {}
                for alias in aliases:
                    if isinstance(body.get(alias), dict):
                        candidate_obj = dict(body.get(alias) or {})
                        break
                min_value = None
                max_value = None
                if candidate_obj:
                    min_value = self._safe_float(candidate_obj.get("min"), fallback=None)
                    max_value = self._safe_float(candidate_obj.get("max"), fallback=None)
                if min_value is None:
                    for alias in aliases:
                        min_value = self._safe_float(body.get(f"{alias}_min"), fallback=None)
                        if min_value is not None:
                            break
                if max_value is None:
                    for alias in aliases:
                        max_value = self._safe_float(body.get(f"{alias}_max"), fallback=None)
                        if max_value is not None:
                            break
                if min_value is None and max_value is None:
                    continue
                current = dict(self._state["thresholds"][raw_name])
                next_min = current["min"] if min_value is None else float(min_value)
                next_max = current["max"] if max_value is None else float(max_value)
                if next_max < next_min:
                    return {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"{meta['label']} 上限不能小于下限",
                    }
                self._state["thresholds"][raw_name] = {
                    "min": next_min,
                    "max": next_max,
                }
                changed.append(str(meta["label"]))
            if not changed:
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "未提供可更新的阈值字段",
                }
            self._persist()
            payload = self._build_status_payload()
        payload["changed"] = changed
        payload["summary"] = "已更新阈值：" + "、".join(changed) + "。"
        return payload

    def update_sample(self, body: dict[str, Any]) -> dict[str, Any]:
        applied: list[str] = []
        with self._lock:
            latest = self._state["latest"]
            for metric, meta in self._METRICS.items():
                aliases = [metric, *list(meta.get("aliases") or ())]
                value = None
                for alias in aliases:
                    value = self._safe_float(body.get(alias), fallback=None)
                    if value is not None:
                        break
                if value is None and isinstance(body.get(metric), dict):
                    value = self._safe_float((body.get(metric) or {}).get("value"), fallback=None)
                if value is None:
                    continue
                latest[metric] = float(value)
                applied.append(str(meta["label"]))
            if not applied:
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "未提供可写入的传感器样本",
                }
            latest["updated_at"] = str(body.get("updated_at") or _ts_now()).strip()
            latest["sample_source"] = str(body.get("source") or body.get("sample_source") or "manual").strip() or "manual"
            source = self._state["source"]
            if str(body.get("port") or "").strip():
                source["port"] = str(body.get("port")).strip()
            if str(body.get("protocol") or "").strip():
                source["protocol"] = str(body.get("protocol")).strip()
            if str(body.get("mode") or "").strip():
                source["mode"] = str(body.get("mode")).strip()
            source["status"] = "live"
            self._persist()
            payload = self._build_status_payload()
        payload["changed"] = applied
        payload["summary"] = "已更新传感器样本：" + "、".join(applied) + "。"
        return payload


_SENSOR_STORE = SensorStateStore()


def _ts_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _is_owned_route(route_path: str) -> bool:
    return route_path in VISION_API_ROUTES


def _normalize_detector(
    value: str,
    default: str = "none",
    *,
    allow_auto: bool = False,
) -> tuple[str | None, str]:
    detector = (value or default).strip().lower()
    if detector in ("yolo11", "yolo-11", "yolo_11"):
        detector = "yolo"
    if detector in ("head", "face-only", "face_only"):
        detector = "face"
    if detector in ("face+world", "face-world", "fusion"):
        detector = "face_world"
    if detector == "off":
        detector = "none"
    if allow_auto and detector in ("auto", "smart", "adaptive"):
        detector = "auto"
    if detector not in ("none", "rect", "yolo", "yolo_world", "face", "face_world", "auto"):
        return None, f"unsupported detector: {detector}"
    if detector == "auto" and not allow_auto:
        return None, "unsupported detector: auto"
    return detector, ""


def _parse_enabled(value: str) -> bool | None:
    raw = (value or "").strip().lower()
    if raw in ("1", "true", "on", "enable", "enabled", "yes"):
        return True
    if raw in ("0", "false", "off", "disable", "disabled", "no"):
        return False
    return None


def _parse_action_flag(value: str) -> int | None:
    raw = (value or "").strip().lower()
    if not raw:
        return None
    if raw in ("0", "false", "off", "disable", "disabled", "no"):
        return 0
    if raw in ("1", "true", "on", "enable", "enabled", "yes"):
        return 1
    if raw in ("2", "keep", "noop", "no_action", "none"):
        return 2
    return None


def _parse_face_only(query: dict[str, list[str]]) -> tuple[bool, str]:
    raw = (
        query.get("face_only", [""])[0]
        or query.get("only_face", [""])[0]
        or query.get("pure_face", [""])[0]
        or ""
    ).strip()
    if not raw:
        return False, ""
    enabled = _parse_enabled(raw)
    if enabled is None:
        return False, "face_only must be one of: 1/0 true/false on/off"
    return bool(enabled), ""


def _parse_optional_bool_arg(
    query: dict[str, list[str]],
    name: str,
) -> tuple[bool | None, str]:
    raw = (query.get(name, [""])[0] or "").strip()
    if not raw:
        return None, ""
    enabled = _parse_enabled(raw)
    if enabled is None:
        return None, f"{name} must be one of: 1/0 true/false on/off"
    return bool(enabled), ""


def _ensure_embedded_vision() -> tuple[Any | None, str]:
    global _EMBEDDED_VISION, _EMBEDDED_ERROR
    with _EMBEDDED_LOCK:
        if _EMBEDDED_VISION is not None:
            return _EMBEDDED_VISION, ""
        if _EMBEDDED_ERROR:
            return None, _EMBEDDED_ERROR

        try:
            runtime_mod = None
            import_errs: list[str] = []

            try:
                from vision_runtime import VisionService as RuntimeVisionService  # type: ignore

                runtime_mod = RuntimeVisionService
            except Exception as exc:
                import_errs.append(f"vision_runtime: {exc}")

            if runtime_mod is None:
                project_root = str(Path(__file__).resolve().parents[1])
                if project_root not in sys.path:
                    sys.path.insert(0, project_root)
                try:
                    from distributed_preview.vision_runtime import (  # type: ignore
                        VisionService as RuntimeVisionService,
                    )

                    runtime_mod = RuntimeVisionService
                except Exception as exc:
                    import_errs.append(f"distributed_preview.vision_runtime: {exc}")

            if runtime_mod is None:
                _EMBEDDED_ERROR = "embedded load failed: " + "; ".join(import_errs)
                return None, _EMBEDDED_ERROR

            _EMBEDDED_VISION = runtime_mod()
            return _EMBEDDED_VISION, ""
        except Exception as exc:
            _EMBEDDED_ERROR = f"embedded load failed: {exc}"
            return None, _EMBEDDED_ERROR


class VisionPreviewHandler(BaseHTTPRequestHandler):
    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-Request-Id, X-Trace-Id",
        )
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            return

    def _send_no_content(self) -> None:
        self.send_response(204)
        self.send_header("Allow", "GET,POST,HEAD,OPTIONS")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-Request-Id, X-Trace-Id",
        )
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _send_bytes(
        self,
        body: bytes,
        content_type: str,
        status: int = 200,
        extra_headers: dict[str, str] | None = None,
        head_only: bool = False,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-Request-Id, X-Trace-Id",
        )
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if head_only or self.command == "HEAD":
            return
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            return

    def _read_request_body(self, max_bytes: int = 8 * 1024 * 1024) -> tuple[bytes | None, str]:
        raw_length = str(self.headers.get("Content-Length") or "").strip()
        if not raw_length:
            return b"", ""
        try:
            length = int(raw_length)
        except (TypeError, ValueError):
            return None, "invalid Content-Length"
        if length < 0:
            return None, "invalid Content-Length"
        if length > max_bytes:
            return None, f"request body too large: {length}"
        try:
            return self.rfile.read(length), ""
        except Exception as exc:
            return None, f"request body read failed: {exc}"

    def _read_json_body(self, max_bytes: int = 8 * 1024 * 1024) -> tuple[dict[str, Any] | None, str]:
        body, err = self._read_request_body(max_bytes=max_bytes)
        if body is None:
            return None, err
        if not body:
            return {}, ""
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception as exc:
            return None, f"invalid json body: {exc}"
        if not isinstance(payload, dict):
            return None, "json body must be an object"
        return payload, ""

    def _stream_mjpeg(
        self,
        vision: Any,
        fps: float,
        detector: str = "none",
        wear_glasses: bool | None = None,
        emotion: bool | None = None,
        recognize: bool | None = None,
    ) -> None:
        mode = (detector or "none").strip().lower()
        target_fps = max(1.0, min(VISION_STREAM_MAX_FPS, fps))
        if mode in ("face", "face_world"):
            target_fps = min(target_fps, max(1.0, VISION_STREAM_FACE_MAX_FPS))
        elif mode == "yolo_world":
            target_fps = min(target_fps, max(1.0, VISION_STREAM_YOLO_WORLD_MAX_FPS))
        elif mode == "yolo":
            target_fps = min(target_fps, max(1.0, VISION_STREAM_YOLO_MAX_FPS))
        if bool(wear_glasses) or bool(emotion):
            target_fps = min(target_fps, max(1.0, VISION_STREAM_ATTR_MAX_FPS))
        interval = 1.0 / target_fps
        boundary = b"--frame\r\n"
        client_id = f"{threading.get_ident()}:{id(self)}"
        last_source_ts = 0.0
        self.send_response(200)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Pragma", "no-cache")
        self.send_header("Connection", "close")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        vision.register_stream_client(client_id)
        try:
            while True:
                loop_started = time.perf_counter()
                if not vision.is_stream_enabled():
                    return
                jpeg, _, meta = vision.frame_jpeg(
                    detector=detector,
                    wear_glasses=wear_glasses,
                    emotion=emotion,
                    recognize=recognize,
                )
                if jpeg is None:
                    sleep_for = max(0.0, interval - (time.perf_counter() - loop_started))
                    if sleep_for > 0:
                        time.sleep(sleep_for)
                    continue
                source_ts = 0.0
                try:
                    source_ts = float((meta or {}).get("source_frame_ts", 0.0) or 0.0)
                except Exception:
                    source_ts = 0.0
                if source_ts > 0 and last_source_ts > 0 and abs(source_ts - last_source_ts) < 1e-6:
                    sleep_for = max(0.0, interval - (time.perf_counter() - loop_started))
                    if sleep_for > 0:
                        time.sleep(sleep_for)
                    continue
                header = (
                    boundary
                    + b"Content-Type: image/jpeg\r\n"
                    + f"Content-Length: {len(jpeg)}\r\n\r\n".encode("ascii")
                )
                try:
                    self.wfile.write(header)
                    self.wfile.write(jpeg)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    return
                vision.note_stream_frame(client_id)
                if source_ts > 0:
                    last_source_ts = source_ts
                sleep_for = max(0.0, interval - (time.perf_counter() - loop_started))
                if sleep_for > 0:
                    time.sleep(sleep_for)
        finally:
            vision.unregister_stream_client(client_id)

    def _dispatch_embedded_vision(self, route_path: str, head_only: bool) -> bool:
        vision, load_err = _ensure_embedded_vision()
        if vision is None:
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": load_err or "embedded vision unavailable",
                    "execution_mode": VISION_EXECUTION_MODE,
                },
                status=503,
            )
            return True

        if self.command not in ("GET", "HEAD", "POST"):
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"method not allowed: {self.command}",
                },
                status=405,
            )
            return True

        query = parse_qs(urlsplit(self.path).query, keep_blank_values=True)
        if route_path in ("/api/vision/sensors", "/api/vision/sensors/status"):
            if self.command not in ("GET", "HEAD"):
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            self._send_json(_SENSOR_STORE.status_payload(), status=200)
            return True

        if route_path == "/api/vision/sensors/thresholds":
            if self.command in ("GET", "HEAD"):
                payload = _SENSOR_STORE.status_payload()
                self._send_json(
                    {
                        "ok": True,
                        "timestamp": payload.get("timestamp"),
                        "thresholds": payload.get("thresholds"),
                        "metrics": payload.get("metrics"),
                        "summary": "已获取传感器阈值配置",
                    },
                    status=200,
                )
                return True
            if self.command != "POST":
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            body, err = self._read_json_body()
            if body is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return True
            payload = _SENSOR_STORE.update_thresholds(body)
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/sensors/sample":
            if self.command in ("GET", "HEAD"):
                payload = _SENSOR_STORE.status_payload()
                self._send_json(
                    {
                        "ok": True,
                        "timestamp": payload.get("timestamp"),
                        "latest": payload.get("latest"),
                        "source": payload.get("source"),
                        "summary": "已获取最新传感器样本",
                    },
                    status=200,
                )
                return True
            if self.command != "POST":
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            body, err = self._read_json_body()
            if body is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return True
            payload = _SENSOR_STORE.update_sample(body)
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/accounts":
            if self.command not in ("GET", "HEAD"):
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            self._send_json(vision.accounts_status(), status=200)
            return True

        if route_path == "/api/vision/accounts/settings":
            if self.command in ("GET", "HEAD"):
                self._send_json(vision.accounts_status(), status=200)
                return True
            if self.command != "POST":
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            body, err = self._read_json_body()
            if body is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return True
            payload = vision.account_update_settings(
                attendance_recheck_interval_minutes=(
                    body.get("attendance_recheck_interval_minutes")
                    if isinstance(body, dict)
                    else None
                ),
            )
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/accounts/create":
            if self.command != "POST":
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            body, err = self._read_json_body()
            if body is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return True
            username = str(body.get("username") or "").strip()
            password = str(body.get("password") or "").strip()
            display_name = str(body.get("display_name") or body.get("name") or username).strip()
            portrait_data = str(
                body.get("portrait_data")
                or body.get("portrait_data_url")
                or body.get("portrait_base64")
                or ""
            ).strip()
            payload = vision.account_create(
                username=username,
                password=password,
                display_name=display_name,
                portrait_data=portrait_data,
            )
            status = 200
            if not payload.get("ok", False):
                err_text = str(payload.get("error") or "")
                status = 409 if "already exists" in err_text else 400
            self._send_json(payload, status=status)
            return True

        if route_path == "/api/vision/accounts/session":
            if self.command != "POST":
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            body, err = self._read_json_body()
            if body is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return True
            payload = vision.account_authenticate(
                username=str(body.get("username") or "").strip(),
                password=str(body.get("password") or "").strip(),
            )
            self._send_json(payload, status=200 if payload.get("ok", False) else 401)
            return True

        if route_path == "/api/vision/accounts/checkin":
            if self.command != "POST":
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            body, err = self._read_json_body()
            if body is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return True
            username = str(body.get("username") or "").strip()
            action = str(body.get("action") or "checkin").strip().lower()
            clear = action in ("clear", "reset", "undo", "uncheck")
            payload = vision.account_mark_check_in(username=username, clear=clear)
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/accounts/portrait":
            if self.command not in ("GET", "HEAD"):
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"method not allowed: {self.command}"},
                    status=405,
                )
                return True
            username = str(query.get("username", [""])[0] or "").strip()
            image_bytes, content_type, err = vision.account_portrait_bytes(username=username)
            if image_bytes is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=404)
                return True
            self._send_bytes(image_bytes, content_type, head_only=head_only)
            return True

        if route_path == "/api/vision/observe":
            face_only, face_only_err = _parse_face_only(query)
            if face_only_err:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": face_only_err}, status=400)
                return True
            detector = "face"
            if not face_only:
                detector, det_err = _normalize_detector(
                    query.get("detector", ["face"])[0], default="face"
                )
                if detector is None:
                    self._send_json({"ok": False, "timestamp": _ts_now(), "error": det_err}, status=400)
                    return True
            wear_glasses, wear_glasses_err = _parse_optional_bool_arg(query, "wear_glasses")
            if wear_glasses_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": wear_glasses_err,
                    },
                    status=400,
                )
                return True
            emotion, emotion_err = _parse_optional_bool_arg(query, "emotion")
            if emotion_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": emotion_err,
                    },
                    status=400,
                )
                return True
            recognize, recognize_err = _parse_optional_bool_arg(query, "recognize")
            if recognize_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": recognize_err,
                    },
                    status=400,
                )
                return True
            if face_only:
                wear_glasses = False
                emotion = False
            payload = vision.observe(
                detector=detector,
                wear_glasses=wear_glasses,
                emotion=emotion,
                recognize=recognize,
            )
            status = 200
            if not payload.get("ok", False):
                err = str(payload.get("error", ""))
                status = 400 if err.startswith("unsupported detector:") else 503
            self._send_json(payload, status=status)
            return True

        if route_path == "/api/vision/face_recognition":
            self._send_json(vision.face_recognition_status(), status=200)
            return True

        if route_path == "/api/vision/face_recognition/reload":
            self._send_json(vision.face_recognition_reload(), status=200)
            return True

        if route_path == "/api/vision/yolo_world/filter":
            self._send_json(vision.yolo_world_filter_status(), status=200)
            return True

        if route_path == "/api/vision/yolo_world/vocab":
            self._send_json(vision.yolo_world_vocab_status(), status=200)
            return True

        if route_path == "/api/vision/yolo_world/vocab/list":
            self._send_json(vision.yolo_world_vocab_list(), status=200)
            return True

        if route_path == "/api/vision/yolo_world/vocab/reload":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            payload = vision.reload_yolo_world_vocab(reason=reason)
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/yolo_world/vocab/apply":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            manifest = (query.get("manifest", [""])[0] or "").strip()
            name = (query.get("name", [""])[0] or "").strip()
            model = (
                (query.get("model", [""])[0] or "").strip()
                or (query.get("model_path", [""])[0] or "").strip()
            )
            text = (
                (query.get("text", [""])[0] or "").strip()
                or (query.get("text_path", [""])[0] or "").strip()
                or (query.get("embeddings", [""])[0] or "").strip()
            )
            labels = (
                (query.get("labels", [""])[0] or "").strip()
                or (query.get("labels_path", [""])[0] or "").strip()
            )
            aliases = (
                (query.get("aliases", [""])[0] or "").strip()
                or (query.get("aliases_path", [""])[0] or "").strip()
            )
            reset_raw = (query.get("reset", ["1"])[0] or "1").strip()
            reset = _parse_enabled(reset_raw)
            if reset is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "reset must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            safe_raw = (query.get("safe", [""])[0] or "").strip()
            safe = _parse_enabled(safe_raw) if safe_raw else None
            if safe_raw and safe is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "safe must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            payload = vision.apply_yolo_world_vocab(
                manifest=manifest,
                name=name,
                model_path=model,
                text_path=text,
                labels_path=labels,
                aliases_path=aliases,
                reason=reason,
                reset=bool(reset),
                safe=safe,
            )
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/yolo_world/filter/set":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            mode = (query.get("mode", [""])[0] or "").strip().lower()
            action = (query.get("action", [""])[0] or "").strip().lower()
            labels_values = (
                [v for v in query.get("labels", []) if str(v).strip()]
                + [v for v in query.get("classes", []) if str(v).strip()]
                + [v for v in query.get("class", []) if str(v).strip()]
            )
            labels = ",".join(str(v).strip() for v in labels_values if str(v).strip())
            if mode in ("all", "clear", "reset", "none", "off") or action in (
                "all",
                "clear",
                "reset",
                "none",
                "off",
            ):
                labels = "all"
            if not labels:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "labels/classes query is required, or use mode=all",
                    },
                    status=400,
                )
                return True
            payload = vision.set_yolo_world_filter(labels=labels, reason=reason)
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/yolo_world/prompt":
            self._send_json(vision.yolo_world_prompt_status(), status=200)
            return True

        if route_path == "/api/vision/yolo_world/prompt/set":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            prompt = (query.get("prompt", [""])[0] or "").strip()
            include_values = (
                [v for v in query.get("include", []) if str(v).strip()]
                + [v for v in query.get("terms", []) if str(v).strip()]
                + [v for v in query.get("labels", []) if str(v).strip()]
            )
            exclude_values = (
                [v for v in query.get("exclude", []) if str(v).strip()]
                + [v for v in query.get("exclude_terms", []) if str(v).strip()]
            )
            strict_raw = (query.get("strict", [""])[0] or "").strip()
            strict = _parse_enabled(strict_raw)
            if prompt == "" and not include_values and not exclude_values:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "prompt/include/terms/labels is required",
                    },
                    status=400,
                )
                return True
            payload = vision.set_yolo_world_prompt(
                prompt=prompt,
                include=include_values,
                exclude=exclude_values,
                reason=reason,
                strict=strict,
            )
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/gimbal/status":
            self._send_json(vision.gimbal_status(), status=200)
            return True

        if route_path == "/api/vision/gimbal/command":
            mode = (query.get("mode", [""])[0] or "").strip().lower()
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            if mode in ("stop", "halt", "idle"):
                yaw_rpm = 0.0
                pitch_rpm = 0.0
            else:
                yaw_raw = (
                    query.get("yaw_rpm", [""])[0]
                    or query.get("yaw", [""])[0]
                    or query.get("pan", [""])[0]
                    or "0"
                )
                pitch_raw = (
                    query.get("pitch_rpm", [""])[0]
                    or query.get("pitch", [""])[0]
                    or query.get("tilt", [""])[0]
                    or "0"
                )
                try:
                    yaw_rpm = float(str(yaw_raw).strip())
                except (TypeError, ValueError):
                    self._send_json(
                        {"ok": False, "timestamp": _ts_now(), "error": "invalid yaw_rpm"},
                        status=400,
                    )
                    return True
                try:
                    pitch_rpm = float(str(pitch_raw).strip())
                except (TypeError, ValueError):
                    self._send_json(
                        {"ok": False, "timestamp": _ts_now(), "error": "invalid pitch_rpm"},
                        status=400,
                    )
                    return True

            laser_raw = (
                query.get("laser_enabled", [""])[0]
                or query.get("laser", [""])[0]
                or ""
            )
            enabled_raw = (
                query.get("enabled", [""])[0]
                or query.get("gimbal_enabled", [""])[0]
                or ""
            )
            stability_raw = (
                query.get("stability_enabled", [""])[0]
                or query.get("stability", [""])[0]
                or ""
            )
            laser_flag = _parse_action_flag(str(laser_raw))
            enabled_flag = _parse_action_flag(str(enabled_raw))
            stability_flag = _parse_action_flag(str(stability_raw))
            if str(laser_raw).strip() and laser_flag is None:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": "invalid laser_enabled (use 0/1/2)"},
                    status=400,
                )
                return True
            if str(enabled_raw).strip() and enabled_flag is None:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": "invalid enabled (use 0/1/2)"},
                    status=400,
                )
                return True
            if str(stability_raw).strip() and stability_flag is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "invalid stability_enabled (use 0/1/2)",
                    },
                    status=400,
                )
                return True

            auto_stop_raw = (
                query.get("auto_stop_ms", [""])[0]
                or query.get("hold_ms", [""])[0]
                or ""
            )
            auto_stop_ms: int | None = None
            if str(auto_stop_raw).strip():
                try:
                    auto_stop_ms = max(0, min(5000, int(str(auto_stop_raw).strip())))
                except (TypeError, ValueError):
                    self._send_json(
                        {"ok": False, "timestamp": _ts_now(), "error": "invalid auto_stop_ms"},
                        status=400,
                    )
                    return True

            payload = vision.gimbal_command(
                yaw_rpm=float(yaw_rpm),
                pitch_rpm=float(pitch_rpm),
                laser_enabled=laser_flag,
                enabled=enabled_flag,
                stability_enabled=stability_flag,
                auto_stop_ms=auto_stop_ms,
                reason=reason,
            )
            self._send_json(payload, status=200 if payload.get("ok", False) else 503)
            return True

        if route_path == "/api/vision/gimbal/laser/blink":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()

            def _opt_int(*names: str) -> tuple[int | None, str]:
                for name in names:
                    raw = (query.get(name, [""])[0] or "").strip()
                    if not raw:
                        continue
                    try:
                        return int(raw), ""
                    except (TypeError, ValueError):
                        return None, name
                return None, ""

            def _opt_float(*names: str) -> tuple[float | None, str]:
                for name in names:
                    raw = (query.get(name, [""])[0] or "").strip()
                    if not raw:
                        continue
                    try:
                        return float(raw), ""
                    except (TypeError, ValueError):
                        return None, name
                return None, ""

            blinks, blinks_err = _opt_int("blinks", "count", "times")
            if blinks_err:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {blinks_err}"},
                    status=400,
                )
                return True

            period_ms, period_err = _opt_int("period_ms", "period", "cycle_ms")
            if period_err:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {period_err}"},
                    status=400,
                )
                return True

            period_sec, period_sec_err = _opt_float("period_sec", "cycle_sec")
            if period_sec_err:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {period_sec_err}"},
                    status=400,
                )
                return True
            if period_ms is None and period_sec is not None and period_sec > 0:
                period_ms = int(round(period_sec * 1000.0))

            hz_val, hz_err = _opt_float("hz", "frequency_hz", "freq_hz")
            if hz_err:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {hz_err}"},
                    status=400,
                )
                return True
            if period_ms is None and hz_val is not None and hz_val > 0:
                period_ms = int(round(1000.0 / hz_val))

            laser_on_ms, on_err = _opt_int("laser_on_ms", "on_ms")
            if on_err:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {on_err}"},
                    status=400,
                )
                return True
            laser_off_ms, off_err = _opt_int("laser_off_ms", "off_ms")
            if off_err:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {off_err}"},
                    status=400,
                )
                return True

            payload = vision.gimbal_laser_blink(
                blinks=blinks,
                period_ms=period_ms,
                laser_on_ms=laser_on_ms,
                laser_off_ms=laser_off_ms,
                reason=reason,
            )
            status = 200 if payload.get("ok", False) else 409
            self._send_json(payload, status=status)
            return True

        if route_path == "/api/vision/gimbal/lock/status":
            self._send_json(vision.gimbal_lock_status(), status=200)
            return True

        if route_path == "/api/vision/gimbal/lock/stop":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            wait_raw = (query.get("wait", [""])[0] or "").strip()
            wait = _parse_enabled(wait_raw) if wait_raw else False
            if wait_raw and wait is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "wait must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            payload = vision.gimbal_lock_stop(wait=bool(wait), reason=reason)
            self._send_json(payload, status=200)
            return True

        if route_path == "/api/vision/gimbal/lock/start":
            target = (
                query.get("target", [""])[0]
                or query.get("label", [""])[0]
                or query.get("class_name", [""])[0]
                or query.get("class", [""])[0]
                or query.get("object", [""])[0]
                or query.get("name", [""])[0]
                or ""
            )
            face_only, face_only_err = _parse_face_only(query)
            if face_only_err:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": face_only_err}, status=400)
                return True
            detector = "face" if face_only else None
            if detector is None:
                detector, det_err = _normalize_detector(
                    query.get("detector", ["auto"])[0],
                    default="auto",
                    allow_auto=True,
                )
                if detector is None:
                    self._send_json({"ok": False, "timestamp": _ts_now(), "error": det_err}, status=400)
                    return True

            def _to_float(name: str, default: float | None) -> float | None:
                raw = (query.get(name, [""])[0] or "").strip()
                if not raw:
                    return default
                try:
                    return float(raw)
                except (TypeError, ValueError):
                    raise ValueError(name)

            def _to_int(name: str, default: int | None) -> int | None:
                raw = (query.get(name, [""])[0] or "").strip()
                if not raw:
                    return default
                try:
                    return int(raw)
                except (TypeError, ValueError):
                    raise ValueError(name)

            try:
                timeout_sec = _to_float("timeout_sec", None)
                center_tolerance_px = _to_float("center_tolerance_px", None)
                stable_frames = _to_int("stable_frames", None)
                min_score = _to_float("min_score", None)
                max_rpm = _to_float("max_rpm", None)
                kp_yaw = _to_float("kp_yaw", None)
                kp_pitch = _to_float("kp_pitch", None)
                search_sweep_rpm = _to_float("search_sweep_rpm", None)
                search_sweep_pulse_ms = _to_int("search_sweep_pulse_ms", None)
                search_spin_deg = _to_float("search_spin_deg", None)
                laser_blinks = _to_int("laser_blinks", None)
                laser_on_ms = _to_int("laser_on_ms", None)
                laser_off_ms = _to_int("laser_off_ms", None)
            except ValueError as exc:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": f"invalid {str(exc)}"},
                    status=400,
                )
                return True

            invert_yaw_raw = (query.get("invert_yaw", [""])[0] or "").strip()
            invert_pitch_raw = (query.get("invert_pitch", [""])[0] or "").strip()
            search_spin_clockwise_raw = (query.get("search_spin_clockwise", [""])[0] or "").strip()
            invert_yaw = _parse_enabled(invert_yaw_raw) if invert_yaw_raw else None
            invert_pitch = _parse_enabled(invert_pitch_raw) if invert_pitch_raw else None
            search_spin_clockwise = (
                _parse_enabled(search_spin_clockwise_raw) if search_spin_clockwise_raw else None
            )
            wear_glasses_raw = (query.get("wear_glasses", [""])[0] or "").strip()
            wear_glasses = _parse_enabled(wear_glasses_raw) if wear_glasses_raw else None
            emotion_raw = (query.get("emotion", [""])[0] or "").strip()
            emotion = _parse_enabled(emotion_raw) if emotion_raw else None
            continuous_raw = (
                query.get("continuous", [""])[0]
                or query.get("follow", [""])[0]
                or query.get("persistent", [""])[0]
                or ""
            ).strip()
            continuous = _parse_enabled(continuous_raw) if continuous_raw else None
            if invert_yaw_raw and invert_yaw is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "invert_yaw must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            if invert_pitch_raw and invert_pitch is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "invert_pitch must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            if search_spin_clockwise_raw and search_spin_clockwise is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "search_spin_clockwise must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            if continuous_raw and continuous is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "continuous must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            if wear_glasses_raw and wear_glasses is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "wear_glasses must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            if emotion_raw and emotion is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "emotion must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            if face_only:
                wear_glasses = False
                emotion = False
                if not str(target or "").strip():
                    target = "person"

            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            payload = vision.gimbal_lock_start(
                target=str(target or "").strip(),
                detector=detector,
                timeout_sec=timeout_sec,
                continuous=continuous,
                center_tolerance_px=center_tolerance_px,
                stable_frames=stable_frames,
                min_score=min_score,
                max_rpm=max_rpm,
                kp_yaw=kp_yaw,
                kp_pitch=kp_pitch,
                invert_yaw=invert_yaw,
                invert_pitch=invert_pitch,
                search_sweep_rpm=search_sweep_rpm,
                search_sweep_pulse_ms=search_sweep_pulse_ms,
                search_spin_deg=search_spin_deg,
                search_spin_clockwise=search_spin_clockwise,
                laser_blinks=laser_blinks,
                laser_on_ms=laser_on_ms,
                laser_off_ms=laser_off_ms,
                wear_glasses=wear_glasses,
                emotion=emotion,
                face_only=bool(face_only),
                reason=reason,
            )
            status = 200 if payload.get("ok", False) else 409
            self._send_json(payload, status=status)
            return True

        if route_path == "/api/vision/profile":
            self._send_json(vision.profile_status(), status=200)
            return True

        if route_path == "/api/vision/profile/set":
            name = (query.get("name", [""])[0] or "").strip().lower()
            payload = vision.set_profile(name)
            self._send_json(payload, status=200 if payload.get("ok", False) else 400)
            return True

        if route_path == "/api/vision/enabled/set":
            action = (query.get("action", [""])[0] or "").strip().lower()
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            if action == "toggle":
                payload = vision.toggle_enabled(reason=reason)
                self._send_json(payload, status=200 if payload.get("ok", False) else 503)
                return True
            enabled_raw = (query.get("enabled", [""])[0] or "").strip()
            enabled = _parse_enabled(enabled_raw)
            if enabled is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "enabled must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            payload = vision.set_enabled(enabled=enabled, reason=reason)
            self._send_json(payload, status=200 if payload.get("ok", False) else 503)
            return True

        if route_path == "/api/vision/stream/set":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            enabled_raw = (query.get("enabled", [""])[0] or "").strip()
            enabled = _parse_enabled(enabled_raw)
            if enabled is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "enabled must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            payload = vision.set_stream_enabled(enabled=enabled, reason=reason)
            self._send_json(payload, status=200)
            return True

        if route_path == "/api/vision/emotion/set":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            enabled_raw = (query.get("enabled", [""])[0] or "").strip()
            enabled = _parse_enabled(enabled_raw)
            if enabled is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "enabled must be one of: 1/0 true/false on/off",
                    },
                    status=400,
                )
                return True
            payload = vision.set_emotion_enabled(enabled=enabled, reason=reason)
            self._send_json(payload, status=200)
            return True

        if route_path == "/api/vision/recover":
            reason = (query.get("reason", ["manual"])[0] or "manual").strip()
            payload = vision.trigger_recovery(reason=reason)
            status = 200 if payload.get("ok", False) else 429
            self._send_json(payload, status=status)
            return True

        if route_path == "/api/vision/frame.jpg":
            face_only, face_only_err = _parse_face_only(query)
            if face_only_err:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": face_only_err}, status=400)
                return True
            detector = "face"
            if not face_only:
                detector, det_err = _normalize_detector(
                    query.get("detector", ["face"])[0], default="face"
                )
                if detector is None:
                    self._send_json({"ok": False, "timestamp": _ts_now(), "error": det_err}, status=400)
                    return True
            wear_glasses, wear_glasses_err = _parse_optional_bool_arg(query, "wear_glasses")
            if wear_glasses_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": wear_glasses_err,
                    },
                    status=400,
                )
                return True
            emotion, emotion_err = _parse_optional_bool_arg(query, "emotion")
            if emotion_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": emotion_err,
                    },
                    status=400,
                )
                return True
            recognize, recognize_err = _parse_optional_bool_arg(query, "recognize")
            if recognize_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": recognize_err,
                    },
                    status=400,
                )
                return True
            if face_only:
                wear_glasses = False
                emotion = False
            jpeg, err, meta = vision.frame_jpeg(
                detector=detector,
                wear_glasses=wear_glasses,
                emotion=emotion,
                recognize=recognize,
            )
            if jpeg is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=503)
                return True
            headers = {
                "X-Vision-Detector": str(meta.get("detector", detector)),
                "X-Vision-Objects": str(int(meta.get("objects", 0))),
            }
            summary = str(meta.get("summary", "") or "")
            if summary:
                headers["X-Vision-Summary"] = summary[:160]
            self._send_bytes(jpeg, "image/jpeg", extra_headers=headers, head_only=head_only)
            return True

        if route_path == "/api/vision/stream.mjpg":
            if not vision.stream_enabled:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "vision stream disabled by VISION_STREAM_ENABLED=0",
                    },
                    status=503,
                )
                return True
            if VISION_STREAM_MAX_CLIENTS > 0:
                try:
                    stream_stats = vision.get_stream_stats()
                    active_clients = int((stream_stats or {}).get("clients", 0))
                except Exception:
                    active_clients = 0
                if active_clients >= VISION_STREAM_MAX_CLIENTS:
                    self._send_json(
                        {
                            "ok": False,
                            "timestamp": _ts_now(),
                            "error": "too many stream clients",
                            "active_clients": active_clients,
                            "max_clients": int(VISION_STREAM_MAX_CLIENTS),
                        },
                        status=429,
                    )
                    return True
            fps_raw = (query.get("fps", ["60"])[0] or "60").strip()
            try:
                fps = float(fps_raw)
            except ValueError:
                self._send_json(
                    {"ok": False, "timestamp": _ts_now(), "error": "invalid fps"},
                    status=400,
                )
                return True
            face_only, face_only_err = _parse_face_only(query)
            if face_only_err:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": face_only_err}, status=400)
                return True
            detector = "face"
            if not face_only:
                detector, det_err = _normalize_detector(
                    query.get("detector", ["face"])[0], default="face"
                )
                if detector is None:
                    self._send_json({"ok": False, "timestamp": _ts_now(), "error": det_err}, status=400)
                    return True
            wear_glasses, wear_glasses_err = _parse_optional_bool_arg(query, "wear_glasses")
            if wear_glasses_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": wear_glasses_err,
                    },
                    status=400,
                )
                return True
            emotion, emotion_err = _parse_optional_bool_arg(query, "emotion")
            if emotion_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": emotion_err,
                    },
                    status=400,
                )
                return True
            recognize, recognize_err = _parse_optional_bool_arg(query, "recognize")
            if recognize_err:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": recognize_err,
                    },
                    status=400,
                )
                return True
            if face_only:
                wear_glasses = False
                emotion = False
            if head_only:
                self.send_response(200)
                self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return True
            self._stream_mjpeg(
                vision=vision,
                fps=fps,
                detector=detector,
                wear_glasses=wear_glasses,
                emotion=emotion,
                recognize=recognize,
            )
            return True

        return False

    def _health_payload(self) -> tuple[int, dict[str, Any]]:
        vision, load_err = _ensure_embedded_vision()
        if vision is None:
            return 503, {
                "ok": False,
                "timestamp": _ts_now(),
                "service": "vision-preview-v2",
                "execution_mode": "embedded",
                "listen": f"{HOST}:{PORT}",
                "owned_routes": sorted(VISION_API_ROUTES),
                "vision_core": {
                    "up": False,
                    "status": 503,
                    "detail": load_err or "embedded vision unavailable",
                    "probe": "embedded:vision_runtime.VisionService",
                },
                "yolo_ready": False,
                "yolo_world_ready": False,
                "yolo_backend_requested": None,
                "yolo_backend_active": None,
            }

        profile = vision.profile_status()
        if not isinstance(profile, dict):
            profile = {}
        return 200, {
            "ok": True,
            "timestamp": _ts_now(),
            "service": "vision-preview-v2",
            "execution_mode": "embedded",
            "listen": f"{HOST}:{PORT}",
            "owned_routes": sorted(VISION_API_ROUTES),
            "vision_core": {
                "up": True,
                "status": 200,
                "detail": "embedded vision runtime active",
                "probe": "embedded:vision_runtime.VisionService",
            },
            "yolo_ready": bool(profile.get("yolo_ready")),
            "yolo_world_ready": bool(profile.get("yolo_world_ready")),
            "yolo_backend_requested": profile.get("yolo_backend_requested"),
            "yolo_backend_active": profile.get("yolo_backend_active"),
        }

    def do_OPTIONS(self) -> None:
        route_path = urlsplit(self.path).path
        if route_path == "/health":
            self._send_no_content()
            return
        if route_path.startswith("/api/vision/"):
            if not _is_owned_route(route_path):
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"vision route not owned by vision service: {route_path}",
                    },
                    status=404,
                )
                return
            self._send_no_content()
            return
        self._send_json(
            {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"not found: {route_path}",
            },
            status=404,
        )

    def do_HEAD(self) -> None:
        self._dispatch(head_only=True)

    def do_GET(self) -> None:
        self._dispatch(head_only=False)

    def do_POST(self) -> None:
        self._dispatch(head_only=False)

    def do_PUT(self) -> None:
        self._dispatch(head_only=False)

    def do_PATCH(self) -> None:
        self._dispatch(head_only=False)

    def do_DELETE(self) -> None:
        self._dispatch(head_only=False)

    def do_TRACE(self) -> None:
        self._dispatch(head_only=False)

    def do_CONNECT(self) -> None:
        self._dispatch(head_only=False)

    def _dispatch(self, head_only: bool) -> None:
        route_path = urlsplit(self.path).path

        if route_path == "/health":
            status, payload = self._health_payload()
            self._send_json(payload, status=status)
            return

        if route_path.startswith("/api/vision/"):
            if not _is_owned_route(route_path):
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"vision route not owned by vision service: {route_path}",
                    },
                    status=404,
                )
                return
            if self._dispatch_embedded_vision(route_path=route_path, head_only=head_only):
                return
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"unsupported embedded route: {route_path}",
                },
                status=404,
            )
            return

        self._send_json(
            {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"not found: {route_path}",
            },
            status=404,
        )

    def log_message(self, fmt: str, *args: Any) -> None:
        message = fmt % args if args else fmt
        remote = "local"
        port = 0
        if isinstance(self.client_address, tuple):
            if len(self.client_address) > 0:
                remote = str(self.client_address[0])
            if len(self.client_address) > 1:
                try:
                    port = int(self.client_address[1])
                except Exception:
                    port = 0
        print(
            f"{datetime.now().isoformat(timespec='seconds')} "
            f"vision-preview {remote}:{port} {message}"
        )


def main() -> None:
    server = bind_server(HOST, PORT, VisionPreviewHandler, unix_socket_path=UNIX_SOCKET_PATH)
    print(
        "vision preview v2 listening on "
        f"{('unix://' + UNIX_SOCKET_PATH) if UNIX_SOCKET_PATH else ('http://' + HOST + ':' + str(PORT))} "
        f"(mode={VISION_EXECUTION_MODE})"
    )
    server.serve_forever()


if __name__ == "__main__":
    main()
