#!/usr/bin/env bash
set -euo pipefail

SERVICE_NAME="custom-monitor-sensor-bridge.service"
PROJECT_ROOT="/root/custom-monitor"
SERVICE_SRC="${PROJECT_ROOT}/distributed_preview/systemd/${SERVICE_NAME}"
SERVICE_DST="/etc/systemd/system/${SERVICE_NAME}"

if [[ ! -f "${SERVICE_SRC}" ]]; then
  echo "[sensor-bridge-install] missing service file: ${SERVICE_SRC}" >&2
  exit 1
fi

if [[ ! -f "${PROJECT_ROOT}/distributed_preview/sensor_serial_bridge.py" ]]; then
  echo "[sensor-bridge-install] missing bridge script under ${PROJECT_ROOT}" >&2
  exit 1
fi

if [[ ! -f "${PROJECT_ROOT}/distributed_preview/runtime/split.env" ]]; then
  echo "[sensor-bridge-install] missing env file under ${PROJECT_ROOT}" >&2
  exit 1
fi

install -m 0644 "${SERVICE_SRC}" "${SERVICE_DST}"
systemctl daemon-reload
systemctl enable "${SERVICE_NAME}"
systemctl restart "${SERVICE_NAME}"
systemctl --no-pager --full status "${SERVICE_NAME}"
