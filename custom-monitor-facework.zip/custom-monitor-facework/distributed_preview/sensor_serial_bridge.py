#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from typing import Any


def _ts_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _env_text(name: str, default: str) -> str:
    return str(os.environ.get(name, default)).strip() or default


def _env_int(name: str, default: int) -> int:
    raw = str(os.environ.get(name, "")).strip()
    if not raw:
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    raw = str(os.environ.get(name, "")).strip()
    if not raw:
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


_FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)")


def _normalize_key(name: Any) -> str:
    text = str(name or "").strip().lower()
    if not text:
        return ""
    return re.sub(r"[^a-z0-9]+", "_", text).strip("_")


def _safe_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        if isinstance(value, str):
            match = _FLOAT_RE.search(value)
            if match:
                try:
                    return float(match.group(0))
                except (TypeError, ValueError):
                    return None
        return None


def _parse_json_line(text: str) -> dict[str, Any] | None:
    if not text.startswith("{"):
        return None
    try:
        payload = json.loads(text)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _parse_kv_line(text: str) -> dict[str, Any] | None:
    if "=" not in text and ":" not in text:
        return None
    cleaned = text.replace(";", ",").replace("|", ",")
    out: dict[str, Any] = {}
    for chunk in cleaned.split(","):
        part = chunk.strip()
        if not part:
            continue
        if "=" in part:
            key, value = part.split("=", 1)
        elif ":" in part:
            key, value = part.split(":", 1)
        else:
            continue
        normalized_key = _normalize_key(key)
        if not normalized_key:
            continue
        out[normalized_key] = str(value).strip()
    return out or None


def _parse_csv_line(text: str) -> dict[str, Any] | None:
    cleaned = text.replace(";", ",").replace("|", ",")
    parts = [item.strip() for item in cleaned.split(",") if item.strip()]
    if len(parts) < 3:
        return None
    return {
        "temperature": parts[0],
        "ph": parts[1],
        "turbidity": parts[2],
    }


def _normalize_sample(raw: dict[str, Any], *, source: str, port: str, protocol: str) -> dict[str, Any] | None:
    aliases = {
        "temperature": ("temperature", "temp", "temperature_c", "t"),
        "ph": ("ph", "ph_value", "p"),
        "turbidity": ("turbidity", "ntu", "turbidity_ntu", "tb"),
    }
    passthrough_fields = (
        "turbidity_adc",
        "turbidity_mv",
        "turbidity_level",
        "ph_adc",
        "ph_po_mv",
        "ph_probe_mv",
        "ph_level",
    )
    sample: dict[str, Any] = {}
    for target, names in aliases.items():
        value = None
        for name in names:
            value = _safe_float(raw.get(name))
            if value is not None:
                break
        if value is not None:
            sample[target] = value
    for field in passthrough_fields:
        value = raw.get(field)
        if value is None or value == "":
            continue
        numeric = _safe_float(value)
        sample[field] = numeric if numeric is not None else str(value).strip()
    if not sample:
        return None
    sample["source"] = str(raw.get("source") or source).strip() or source
    sample["port"] = str(raw.get("port") or port).strip() or port
    sample["protocol"] = str(raw.get("protocol") or protocol).strip() or protocol
    sample["mode"] = "usb_serial"
    sample["updated_at"] = str(raw.get("updated_at") or _ts_now()).strip() or _ts_now()
    return sample


def parse_line(text: str, *, source: str, port: str, protocol: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if not stripped:
        return None
    parsers = (_parse_json_line, _parse_kv_line, _parse_csv_line)
    for parser in parsers:
        raw = parser(stripped)
        if isinstance(raw, dict):
            sample = _normalize_sample(raw, source=source, port=port, protocol=protocol)
            if sample:
                return sample
    return None


def post_json(url: str, payload: dict[str, Any], timeout_sec: float) -> tuple[int, str]:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
        body = resp.read().decode("utf-8", "replace")
        return int(getattr(resp, "status", 200) or 200), body


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read water sensor samples from USB serial and push them into /api/vision/sensors/sample.",
    )
    parser.add_argument("--port", default=_env_text("VISION_SENSOR_SERIAL_PORT", "/dev/ttyUSB0"))
    parser.add_argument("--baudrate", type=int, default=_env_int("VISION_SENSOR_SERIAL_BAUD", 115200))
    parser.add_argument("--timeout-sec", type=float, default=_env_float("VISION_SENSOR_TIMEOUT_SEC", 1.0))
    parser.add_argument("--api-base", default=_env_text("VISION_SENSOR_API_BASE", "http://127.0.0.1:8090"))
    parser.add_argument("--api-path", default=_env_text("VISION_SENSOR_API_PATH", "/api/vision/sensors/sample"))
    parser.add_argument("--source", default=_env_text("VISION_SENSOR_SOURCE", "usb-serial-bridge"))
    parser.add_argument("--protocol", default=_env_text("VISION_SENSOR_PROTOCOL", "custom_ascii"))
    parser.add_argument(
        "--post-timeout-sec",
        type=float,
        default=_env_float("VISION_SENSOR_POST_TIMEOUT_SEC", 4.0),
    )
    parser.add_argument(
        "--reconnect-delay-sec",
        type=float,
        default=_env_float("VISION_SENSOR_RECONNECT_DELAY_SEC", 2.0),
    )
    parser.add_argument("--dry-run", action="store_true")
    return parser


def open_serial(port: str, baudrate: int, timeout_sec: float) -> Any:
    try:
        import serial  # type: ignore
    except Exception as exc:
        raise RuntimeError(f"pyserial unavailable: {exc}") from exc
    return serial.Serial(
        port=port,
        baudrate=int(baudrate),
        timeout=max(0.05, float(timeout_sec)),
        write_timeout=max(0.05, float(timeout_sec)),
    )


def main() -> int:
    args = build_arg_parser().parse_args()
    api_url = args.api_base.rstrip("/") + args.api_path
    print(
        f"[sensor-bridge] start port={args.port} baud={args.baudrate} "
        f"api={api_url} protocol={args.protocol} dry_run={int(args.dry_run)}"
    )
    while True:
        ser = None
        try:
            ser = open_serial(args.port, args.baudrate, args.timeout_sec)
            print(f"[sensor-bridge] serial open ok: {args.port}@{args.baudrate}")
            while True:
                raw = ser.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", "replace").strip()
                if not line:
                    continue
                sample = parse_line(
                    line,
                    source=args.source,
                    port=args.port,
                    protocol=args.protocol,
                )
                if sample is None:
                    print(f"[sensor-bridge] skip unparsed line: {line}")
                    continue
                if args.dry_run:
                    print(f"[sensor-bridge] sample {json.dumps(sample, ensure_ascii=False)}")
                    continue
                try:
                    status, body = post_json(api_url, sample, timeout_sec=args.post_timeout_sec)
                    print(f"[sensor-bridge] post ok status={status} sample={json.dumps(sample, ensure_ascii=False)}")
                    if body:
                        print(f"[sensor-bridge] resp {body[:240]}")
                except urllib.error.HTTPError as exc:
                    detail = exc.read().decode("utf-8", "replace")
                    print(f"[sensor-bridge] post http_error status={exc.code} body={detail[:240]}")
                except Exception as exc:
                    print(f"[sensor-bridge] post failed: {exc}")
        except KeyboardInterrupt:
            print("[sensor-bridge] stopped by user")
            return 0
        except Exception as exc:
            print(f"[sensor-bridge] serial loop error: {exc}")
            time.sleep(max(0.5, float(args.reconnect_delay_sec)))
        finally:
            try:
                if ser is not None:
                    ser.close()
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
