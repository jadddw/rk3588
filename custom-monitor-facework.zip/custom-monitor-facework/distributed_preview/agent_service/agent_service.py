﻿#!/usr/bin/env python3
from __future__ import annotations

import http.client
import hashlib
import json
import os
import re
import threading
import time
import uuid
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, urlencode, urlsplit

_AGENT_SERVICE_DIR = Path(__file__).resolve().parent
_DISTRIBUTED_PREVIEW_DIR = _AGENT_SERVICE_DIR.parent
import sys
if str(_DISTRIBUTED_PREVIEW_DIR) not in sys.path:
    sys.path.insert(0, str(_DISTRIBUTED_PREVIEW_DIR))

from ipc_http import bind_server, compose_request_path, open_connection, parse_base_target
try:
    from zoneinfo import ZoneInfo
except Exception:  # pragma: no cover - optional stdlib availability
    ZoneInfo = None  # type: ignore[assignment]

try:
    import numpy as np
except Exception:  # pragma: no cover - optional runtime dependency
    np = None  # type: ignore[assignment]

try:
    import joblib
except Exception:  # pragma: no cover - optional runtime dependency
    joblib = None  # type: ignore[assignment]

try:
    from scipy.sparse import csr_matrix, hstack as sparse_hstack
except Exception:  # pragma: no cover - optional runtime dependency
    csr_matrix = None  # type: ignore[assignment]
    sparse_hstack = None  # type: ignore[assignment]


try:
    _AGENT_GIMBAL_RPM_LIMIT_RAW = float(os.environ.get("AGENT_GIMBAL_RPM_LIMIT", "3.0"))
except (TypeError, ValueError):
    _AGENT_GIMBAL_RPM_LIMIT_RAW = 3.0
AGENT_GIMBAL_RPM_LIMIT = max(1.0, min(50.0, _AGENT_GIMBAL_RPM_LIMIT_RAW))

try:
    _AGENT_GIMBAL_LOCK_TIMEOUT_MAX_RAW = float(
        os.environ.get("AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC", "86400.0")
    )
except (TypeError, ValueError):
    _AGENT_GIMBAL_LOCK_TIMEOUT_MAX_RAW = 86400.0
AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC = max(1.0, min(86400.0, _AGENT_GIMBAL_LOCK_TIMEOUT_MAX_RAW))


_LOCAL_TZ_CACHE_KEY = ""
_LOCAL_TZ_CACHE: Any = None


def _preferred_tz_name() -> str:
    return str(os.environ.get("AGENT_LOCAL_TZ") or os.environ.get("TZ") or "").strip()


def _local_tzinfo() -> Any:
    global _LOCAL_TZ_CACHE_KEY, _LOCAL_TZ_CACHE
    tz_name = _preferred_tz_name()
    if tz_name == _LOCAL_TZ_CACHE_KEY and _LOCAL_TZ_CACHE is not None:
        return _LOCAL_TZ_CACHE
    tzinfo = None
    if tz_name and ZoneInfo is not None:
        try:
            tzinfo = ZoneInfo(tz_name)
        except Exception:
            tzinfo = None
    if tzinfo is None:
        try:
            tzinfo = datetime.now().astimezone().tzinfo
        except Exception:
            tzinfo = None
    _LOCAL_TZ_CACHE_KEY = tz_name
    _LOCAL_TZ_CACHE = tzinfo
    return tzinfo


def _local_now() -> datetime:
    tzinfo = _local_tzinfo()
    if tzinfo is None:
        return datetime.now()
    return datetime.now(tzinfo)


def _format_local_iso(dt: datetime, *, timespec: str) -> str:
    if getattr(dt, "tzinfo", None) is not None:
        dt = dt.replace(tzinfo=None)
    return dt.isoformat(timespec=timespec)


def _ts_now() -> str:
    return _format_local_iso(_local_now(), timespec="seconds")


def _ts_now_ms() -> str:
    return _format_local_iso(_local_now(), timespec="milliseconds")


def _iso_from_ts(ts: float) -> str:
    tzinfo = _local_tzinfo()
    if tzinfo is None:
        dt = datetime.fromtimestamp(float(ts))
    else:
        dt = datetime.fromtimestamp(float(ts), tz=tzinfo)
    return _format_local_iso(dt, timespec="seconds")


def _coerce_enabled(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(int(value))
    text = str(value or "").strip().lower()
    if text in ("1", "true", "on", "enable", "enabled", "yes", "y"):
        return True
    if text in ("0", "false", "off", "disable", "disabled", "no", "n"):
        return False
    return None


def _coerce_action_flag(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return 1 if value else 0
    if isinstance(value, (int, float)):
        iv = int(value)
        return iv if iv in (0, 1, 2) else None
    text = str(value or "").strip().lower()
    if not text:
        return None
    if text in ("0", "false", "off", "disable", "disabled", "no"):
        return 0
    if text in ("1", "true", "on", "enable", "enabled", "yes"):
        return 1
    if text in ("2", "keep", "noop", "no_action", "none"):
        return 2
    return None


def _clamp_int(value: Any, *, default: int, min_value: int, max_value: int) -> int:
    try:
        val = int(value)
    except (TypeError, ValueError):
        val = int(default)
    return max(min_value, min(max_value, val))


def _safe_text(value: Any, *, limit: int = 220) -> str:
    return str(value or "").strip()[:limit]


def _contains_cjk(text: str) -> bool:
    return bool(re.search(r"[\u4e00-\u9fff]", str(text or "")))


def _is_explicit_agent_memory_request(text: str, lower: str) -> bool:
    text = str(text or "").strip()
    lower = str(lower or "").strip()
    if not text and not lower:
        return False
    if any(
        token in text
        for token in (
            "记住",
            "记忆",
            "回忆",
            "历史记录",
            "最近记忆",
            "搜索记忆",
            "记忆列表",
            "记忆统计",
            "清空记忆",
            "清除记忆",
        )
    ):
        return True
    return bool(
        re.search(
            r"(^|\b)(remember|recall|memo|memory\s+(list|search|stats|clear|history)|"
            r"search\s+memory|clear\s+memory|recent\s+memory|chat\s+history|conversation\s+history)(\b|$)",
            lower,
            flags=re.IGNORECASE,
        )
    )


def _brief_vision_object_labels(objects: list[dict[str, Any]], *, limit: int = 3) -> str:
    stats: dict[str, dict[str, float]] = {}
    for row in objects[:80]:
        if not isinstance(row, dict):
            continue
        label = _safe_text(row.get("class_name") or row.get("class_id"), limit=32).lower()
        if not label:
            continue
        item = stats.setdefault(label, {"count": 0.0, "max_score": 0.0})
        item["count"] = float(item.get("count", 0.0)) + 1.0
        try:
            score = float(row.get("score"))
        except (TypeError, ValueError):
            score = 0.0
        if score > float(item.get("max_score", 0.0)):
            item["max_score"] = score
    if not stats:
        return ""
    parts: list[str] = []
    ranked = sorted(
        stats.items(),
        key=lambda item: (
            -float(item[1].get("max_score", 0.0)),
            -int(item[1].get("count", 0.0)),
            item[0],
        ),
    )
    for label, meta in ranked[: max(1, limit)]:
        count = int(meta.get("count", 0.0))
        parts.append(f"{label}x{count}" if count > 1 else label)
    return "、".join(parts)


def _cn_face_pose(attrs: dict[str, Any]) -> str:
    if not isinstance(attrs, dict):
        return ""
    label = _safe_text(attrs.get("face_pose_label"), limit=24).lower()
    label_map = {
        "front": "正视",
        "left": "向左",
        "right": "向右",
        "up": "抬头",
        "down": "低头",
        "left_up": "向左并抬头",
        "left_down": "向左并低头",
        "right_up": "向右并抬头",
        "right_down": "向右并低头",
    }
    if label in label_map:
        return label_map[label]
    horizontal = _safe_text(attrs.get("face_pose_horizontal"), limit=16).lower()
    vertical = _safe_text(attrs.get("face_pose_vertical"), limit=16).lower()
    h_map = {"left": "向左", "right": "向右"}
    v_map = {"up": "抬头", "down": "低头"}
    h_cn = h_map.get(horizontal, "")
    v_cn = v_map.get(vertical, "")
    if h_cn and v_cn:
        return f"{h_cn}并{v_cn}"
    if h_cn:
        return h_cn
    if v_cn:
        return v_cn
    return ""


def _cn_emotion_label(label: str) -> str:
    key = _safe_text(label, limit=32).lower().replace(" ", "_")
    mapping = {
        "anger": "生气",
        "angry": "生气",
        "contempt": "轻蔑",
        "disgust": "厌恶",
        "fear": "害怕",
        "happiness": "开心",
        "happy": "开心",
        "neutral": "平静",
        "sadness": "难过",
        "sad": "难过",
        "surprise": "惊讶",
    }
    return mapping.get(key, key or "未知")


def _brief_vision_face_detail(result: dict[str, Any]) -> str:
    if not isinstance(result, dict):
        return ""
    objects = result.get("objects") if isinstance(result.get("objects"), list) else []
    best = result.get("best_target") if isinstance(result.get("best_target"), dict) else {}

    candidate: dict[str, Any] | None = None
    for row in objects:
        if not isinstance(row, dict):
            continue
        obj_type = _safe_text(row.get("type"), limit=24).lower()
        cls_name = _safe_text(row.get("class_name"), limit=32).lower()
        attrs = row.get("attributes") if isinstance(row.get("attributes"), dict) else {}
        if obj_type == "face":
            candidate = row
            break
        if cls_name == "person":
            if candidate is None:
                candidate = row
            if any(
                key in attrs
                for key in ("face_pose_label", "face_pose_horizontal", "face_pose_vertical", "wear_glasses", "emotion_label")
            ):
                candidate = row
                break
    if candidate is None and isinstance(best, dict):
        best_cls = _safe_text(best.get("class_name"), limit=32).lower()
        if _safe_text(best.get("type"), limit=24).lower() == "face" or best_cls == "person":
            candidate = best
    if not isinstance(candidate, dict):
        return ""

    attrs = candidate.get("attributes") if isinstance(candidate.get("attributes"), dict) else {}
    pose_text = _cn_face_pose(attrs)

    wear_payload = result.get("wear_glasses") if isinstance(result.get("wear_glasses"), dict) else {}
    wear_items = wear_payload.get("items") if isinstance(wear_payload.get("items"), list) else []
    wear_val: bool | None = None
    if "wear_glasses" in attrs:
        wear_val = bool(attrs.get("wear_glasses"))
    elif wear_items and isinstance(wear_items[0], dict) and ("wear_glasses" in wear_items[0]):
        wear_val = bool(wear_items[0].get("wear_glasses"))

    emotion_payload = result.get("emotion") if isinstance(result.get("emotion"), dict) else {}
    emotion_items = emotion_payload.get("items") if isinstance(emotion_payload.get("items"), list) else []
    emotion_label = _safe_text(attrs.get("emotion_label"), limit=32).lower()
    emotion_accepted = bool(attrs.get("emotion_accepted", True))
    if (not emotion_label) and emotion_items and isinstance(emotion_items[0], dict):
        emotion_label = _safe_text(emotion_items[0].get("emotion_label"), limit=32).lower()
        emotion_accepted = bool(emotion_items[0].get("emotion_accepted", True))

    details: list[str] = []
    if pose_text:
        details.append(f"朝向{pose_text}")

    wear_requested = bool(wear_payload)
    if wear_val is True:
        details.append("戴眼镜")
    elif wear_val is False:
        details.append("未戴眼镜")
    elif wear_requested:
        details.append("眼镜未知")

    emotion_requested = bool(emotion_payload)
    if emotion_label:
        emotion_cn = _cn_emotion_label(emotion_label)
        if not emotion_accepted:
            details.append(f"情绪倾向{emotion_cn}(低置信)")
        else:
            details.append(f"情绪{emotion_cn}")
    elif emotion_requested:
        details.append("情绪未知")

    if not details:
        return ""
    return f"人脸信息：{'，'.join(details)}。"


def _normalize_runtime_error_cn(text: Any, *, limit: int = 220) -> str:
    raw = _safe_text(text, limit=limit)
    if not raw:
        return ""
    normalized = raw
    replacements = (
        ("frame unavailable", "帧不可用"),
        ("camera read failed", "相机读取失败"),
        ("cannot open camera", "无法打开相机"),
        ("stale frame", "帧已过期"),
        ("vision disabled", "视觉服务未启用"),
        ("not configured", "未配置"),
        ("timeout", "超时"),
        ("timed out", "超时"),
    )
    for src, dst in replacements:
        normalized = re.sub(re.escape(src), dst, normalized, flags=re.IGNORECASE)
    normalized = re.sub(r"\bcount\s*=\s*(\d+)\b", r"次数=\1", normalized, flags=re.IGNORECASE)
    normalized = re.sub(r"\bred\b", "红", normalized, flags=re.IGNORECASE)
    normalized = re.sub(r"\bgreen\b", "绿", normalized, flags=re.IGNORECASE)
    normalized = re.sub(r"\bblue\b", "蓝", normalized, flags=re.IGNORECASE)
    return normalized


def _brief_vision_observe_text(result: dict[str, Any]) -> str:
    if not isinstance(result, dict):
        return "已完成画面检测。"
    if not bool(result.get("ok", False)):
        err = _normalize_runtime_error_cn(result.get("error"), limit=120)
        return f"画面检测失败：{err}" if err else "画面检测失败。"

    objects = result.get("objects") if isinstance(result.get("objects"), list) else []
    if objects:
        labels = _brief_vision_object_labels(objects)
        face_detail = _brief_vision_face_detail(result)
        if labels:
            return f"检测到目标：{labels}。{face_detail}" if face_detail else f"检测到目标：{labels}。"
        if face_detail:
            return f"检测到{len(objects)}个目标。{face_detail}"
        return f"检测到{len(objects)}个目标。"

    detector_name = _safe_text(result.get("detector"), limit=24).lower()
    if detector_name == "none":
        return "已返回原始画面。"

    summary_raw = _safe_text(result.get("summary"), limit=180)
    summary_low = summary_raw.lower()
    if (
        "no target" in summary_low
        or "未检测到" in summary_raw
        or "未发现" in summary_raw
        or "没有检测到" in summary_raw
    ):
        return "未检测到目标。"

    best = result.get("best_target") if isinstance(result.get("best_target"), dict) else {}
    best_label = _safe_text(best.get("class_name") or best.get("class_id"), limit=32)
    if best_label:
        return f"检测到目标：{best_label}。"
    return "未检测到目标。"


def _looks_like_clarification_query(query: str) -> bool:
    text = str(query or "").strip()
    if not text:
        return False
    low = text.lower()
    tokens = (
        "什么意思",
        "啥意思",
        "什么情况",
        "怎么回事",
        "为啥",
        "为什么",
        "解释一下",
        "再说一遍",
        "听不懂",
        "what do you mean",
        "what meaning",
        "why",
        "explain",
    )
    if any(token in text for token in tokens if not token.isascii()):
        return True
    if any(token in low for token in tokens if token.isascii()):
        return True
    short = len(text) <= 6
    if short and text in ("啥", "啥啊", "什么", "然后呢"):
        return True
    return False


def _brief_tool_result_summary(tool: str, result: dict[str, Any], ok: bool) -> str:
    name = _safe_text(tool, limit=80).lower()
    row = result if isinstance(result, dict) else {}

    if name == "vision.observe":
        return _brief_vision_observe_text(row)

    if name in ("vision.yolo_world.prompt.set", "vision.yolo_world.filter.set"):
        if ok:
            include_terms = row.get("include_terms") if isinstance(row.get("include_terms"), list) else []
            terms = [_safe_text(v, limit=24) for v in include_terms if _safe_text(v, limit=24)]
            if terms:
                return f"已更新检测目标：{'、'.join(terms[:3])}。"
            return "已更新检测目标。"
        err = _safe_text(row.get("error") or row.get("summary"), limit=120)
        return f"更新检测目标失败：{err}" if err else "更新检测目标失败。"

    summary = _safe_text(row.get("summary"), limit=180)
    if summary:
        lower = summary.lower()
        if "no target" in lower:
            return "未检测到目标。"
        # Remove technical payload noise by default.
        summary = re.sub(r"\bscore=\d+(\.\d+)?\b", "", summary, flags=re.IGNORECASE)
        summary = re.sub(r"\bat\s*\([^)]*\)", "", summary, flags=re.IGNORECASE)
        summary = re.sub(r"\barea=\d+\b", "", summary, flags=re.IGNORECASE)
        summary = re.sub(r"\s{2,}", " ", summary).strip(" ;,")
        if summary:
            return _normalize_runtime_error_cn(summary, limit=180)

    err = _normalize_runtime_error_cn(row.get("error"), limit=180)
    if err and ("no target" in err.lower()):
        return "未检测到目标。"
    return err


def _normalize_detector(value: Any, default: str = "none") -> tuple[str | None, str]:
    detector = str(value or default).strip().lower()
    aliases = {
        "yolo11": "yolo",
        "yolo-11": "yolo",
        "yolo_11": "yolo",
        "head": "face",
        "face-only": "face",
        "face_only": "face",
        "off": "none",
    }
    detector = aliases.get(detector, detector)
    if detector not in ("none", "rect", "yolo", "yolo_world", "face"):
        return None, f"unsupported detector: {detector}"
    return detector, ""


def _normalize_dialogue_history(
    value: Any,
    *,
    max_items: int = 24,
    max_text: int = 220,
    max_chars: int = 2800,
) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []

    rows: list[dict[str, Any]] = []
    for raw in value[-max(1, max_items) :]:
        item: dict[str, Any]
        if isinstance(raw, dict):
            role = _safe_text(raw.get("role"), limit=20).lower()
            if role == "agent":
                role = "assistant"
            if role not in ("user", "assistant", "system"):
                role = "user"
            text = _safe_text(raw.get("text") or raw.get("content"), limit=max_text)
            if not text:
                continue
            item = {"role": role, "text": text}

            mode = _safe_text(raw.get("response_mode") or raw.get("mode"), limit=24)
            if mode:
                item["mode"] = mode

            tools_raw = raw.get("tools") if isinstance(raw.get("tools"), list) else []
            tools = [_safe_text(v, limit=48) for v in tools_raw if _safe_text(v, limit=48)]
            if tools:
                item["tools"] = tools[:6]

            actions_raw = raw.get("actions") if isinstance(raw.get("actions"), list) else []
            actions_norm: list[dict[str, Any]] = []
            for action_row in actions_raw[:4]:
                if not isinstance(action_row, dict):
                    continue
                tool = _safe_text(action_row.get("tool"), limit=80)
                if not tool:
                    continue
                action_item: dict[str, Any] = {"tool": tool}
                args_raw = action_row.get("arguments") if isinstance(action_row.get("arguments"), dict) else {}
                args_norm: dict[str, Any] = {}
                for key_raw, value in list(args_raw.items())[:6]:
                    key = _safe_text(key_raw, limit=32)
                    if not key:
                        continue
                    if value is None:
                        args_norm[key] = None
                    elif isinstance(value, bool):
                        args_norm[key] = bool(value)
                    elif isinstance(value, (int, float)):
                        try:
                            num = float(value)
                        except (TypeError, ValueError):
                            args_norm[key] = _safe_text(value, limit=80)
                        else:
                            args_norm[key] = int(num) if num.is_integer() else round(num, 4)
                    elif isinstance(value, list):
                        arr: list[Any] = []
                        for item_v in value[:4]:
                            if item_v is None:
                                arr.append(None)
                            elif isinstance(item_v, bool):
                                arr.append(bool(item_v))
                            elif isinstance(item_v, (int, float)):
                                try:
                                    num = float(item_v)
                                except (TypeError, ValueError):
                                    arr.append(_safe_text(item_v, limit=60))
                                else:
                                    arr.append(int(num) if num.is_integer() else round(num, 4))
                            else:
                                arr.append(_safe_text(item_v, limit=60))
                        args_norm[key] = arr
                    else:
                        args_norm[key] = _safe_text(value, limit=120)
                if args_norm:
                    action_item["arguments"] = args_norm
                actions_norm.append(action_item)
            if actions_norm:
                item["actions"] = actions_norm

            if isinstance(raw.get("executed"), bool):
                item["executed"] = bool(raw.get("executed"))
            if isinstance(raw.get("awaiting_confirmation"), bool):
                item["awaiting_confirmation"] = bool(raw.get("awaiting_confirmation"))

            err = _safe_text(raw.get("error"), limit=120)
            if err:
                item["error"] = err
        else:
            text = _safe_text(raw, limit=max_text)
            if not text:
                continue
            item = {"role": "user", "text": text}

        rows.append(item)

    if not rows:
        return []

    # Keep recent turns within a bounded character budget.
    out: deque[dict[str, Any]] = deque()
    used = 0
    for row in reversed(rows):
        try:
            row_size = len(json.dumps(row, ensure_ascii=False))
        except Exception:
            row_size = len(str(row))
        if out and (used + row_size > max(300, max_chars)):
            break
        out.appendleft(row)
        used += row_size
    return list(out)


def _format_dialogue_history_for_prompt(
    history_rows: list[dict[str, Any]] | None,
    *,
    max_rows: int = 20,
    max_chars: int = 1600,
) -> str:
    rows = list(history_rows or [])
    if not rows:
        return ""
    out_lines: list[str] = []
    seq = 0
    for row in rows[-max(1, int(max_rows)) :]:
        if not isinstance(row, dict):
            continue
        role = _safe_text(row.get("role"), limit=16).lower()
        if role == "agent":
            role = "assistant"
        if role not in ("user", "assistant", "system"):
            role = "user"
        text = _safe_text(row.get("text") or row.get("content"), limit=200)
        if not text:
            continue
        seq += 1
        line = f"{seq}. {role}: {text}"
        mode = _safe_text(row.get("mode") or row.get("response_mode"), limit=20)
        if mode:
            line += f" [mode={mode}]"
        tools_raw = row.get("tools") if isinstance(row.get("tools"), list) else []
        tools = [_safe_text(v, limit=48) for v in tools_raw if _safe_text(v, limit=48)]
        if tools:
            line += f" [tools={','.join(tools[:4])}]"
        actions_raw = row.get("actions") if isinstance(row.get("actions"), list) else []
        action_chunks: list[str] = []
        for action_row in actions_raw[:3]:
            if not isinstance(action_row, dict):
                continue
            tool = _safe_text(action_row.get("tool"), limit=80)
            if not tool:
                continue
            args_obj = action_row.get("arguments") if isinstance(action_row.get("arguments"), dict) else {}
            if args_obj:
                try:
                    arg_text = json.dumps(args_obj, ensure_ascii=False, separators=(",", ":"))
                except Exception:
                    arg_text = _safe_text(str(args_obj), limit=120)
                action_chunks.append(f"{tool}({_safe_text(arg_text, limit=120)})")
            else:
                action_chunks.append(tool)
        if action_chunks:
            line += f" [actions={';'.join(action_chunks)}]"
        out_lines.append(line)
    if not out_lines:
        return ""
    merged = "\n".join(out_lines)
    return _safe_text(merged, limit=max(200, min(4000, int(max_chars))))


def _extract_dialogue_action_facts(
    history_rows: list[dict[str, Any]] | None,
    *,
    max_rows: int = 20,
    max_facts: int = 20,
) -> list[dict[str, Any]]:
    rows = list(history_rows or [])
    if not rows:
        return []
    facts: list[dict[str, Any]] = []
    turn_no = 0
    for row in rows[-max(1, int(max_rows)) :]:
        if not isinstance(row, dict):
            continue
        role = _safe_text(row.get("role"), limit=16).lower()
        if role == "agent":
            role = "assistant"
        if role not in ("user", "assistant", "system"):
            role = "user"
        turn_no += 1
        actions = row.get("actions") if isinstance(row.get("actions"), list) else []
        if not actions:
            continue
        for action_row in actions[:4]:
            if not isinstance(action_row, dict):
                continue
            tool = _safe_text(action_row.get("tool"), limit=80)
            if not tool:
                continue
            item: dict[str, Any] = {
                "turn": turn_no,
                "role": role,
                "tool": tool,
            }
            mode = _safe_text(row.get("mode") or row.get("response_mode"), limit=20)
            if mode:
                item["mode"] = mode
            if isinstance(row.get("executed"), bool):
                item["executed"] = bool(row.get("executed"))
            args_obj = action_row.get("arguments") if isinstance(action_row.get("arguments"), dict) else {}
            if args_obj:
                item["arguments"] = args_obj
            facts.append(item)
    if not facts:
        return []
    return facts[-max(1, int(max_facts)) :]


def _normalize_gimbal_lock_detector(value: Any, default: str = "auto") -> tuple[str | None, str]:
    detector = str(value or default).strip().lower()
    aliases = {
        "yolo11": "yolo",
        "yolo-11": "yolo",
        "yolo_11": "yolo",
        "face-only": "face",
        "face_only": "face",
        "off": "auto",
    }
    detector = aliases.get(detector, detector)
    if detector in ("none", "rect"):
        detector = "auto"
    if detector not in ("auto", "face", "yolo", "yolo_world"):
        return None, f"unsupported detector: {detector}"
    return detector, ""


def _read_text(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8").strip()
    except (FileNotFoundError, PermissionError, OSError):
        return ""


def _read_int(path: str) -> int | None:
    text = _read_text(path)
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        return None


def _load_camera_labels(path: str | None = None) -> tuple[str, ...]:
    path = _safe_text(path, limit=600) or os.environ.get(
        "VISION_YOLO_WORLD_LABELS",
        "/root/custom-monitor/models/detect_classes.txt",
    )
    labels: list[str] = []
    open_vocab_seed = ("pear",)
    try:
        for row in Path(path).read_text(encoding="utf-8").splitlines():
            label = str(row or "").strip().lower()
            if label and label not in labels:
                labels.append(label)
    except Exception:
        pass
    if labels:
        for item in open_vocab_seed:
            if item not in labels:
                labels.append(item)
        return tuple(labels)
    return (
        "person",
        "bicycle",
        "car",
        "motorcycle",
        "bus",
        "truck",
        "traffic light",
        "fire hydrant",
        "stop sign",
        "bird",
        "cat",
        "dog",
        "pear",
        "backpack",
        "suitcase",
        "bottle",
        "cup",
        "chair",
        "couch",
        "dining table",
        "tv",
        "laptop",
        "mouse",
        "keyboard",
        "cell phone",
    )


CAMERA_DEFAULT_ALIAS_MAP: dict[str, tuple[str, ...]] = {
    "person": ("human", "people", "man", "woman", "boy", "girl", "行人", "人", "人员", "路人"),
    "bicycle": ("bike", "cycle", "自行车", "单车", "脚踏车"),
    "car": ("auto", "vehicle", "sedan", "轿车", "汽车", "小车", "车辆", "车"),
    "motorcycle": ("motorbike", "moto", "摩托", "摩托车", "电摩"),
    "airplane": ("plane", "aircraft", "飞机"),
    "bus": ("coach", "公交", "公交车", "大巴", "巴士"),
    "train": ("列车", "火车"),
    "truck": ("lorry", "货车", "卡车"),
    "boat": ("ship", "vessel", "船", "小船"),
    "traffic light": ("signal", "红绿灯", "交通灯"),
    "fire hydrant": ("hydrant", "消防栓"),
    "stop sign": ("stop", "停车标志", "停牌", "停车牌"),
    "parking meter": ("停车计时器", "咪表"),
    "bench": ("长凳", "凳子"),
    "bird": ("小鸟", "鸟"),
    "cat": ("kitty", "小猫", "猫", "猫咪"),
    "dog": ("puppy", "小狗", "狗", "狗狗"),
    "horse": ("马",),
    "cow": ("奶牛", "牛"),
    "sheep": ("羊",),
    "backpack": ("bagpack", "背包", "书包", "双肩包"),
    "umbrella": ("伞", "雨伞"),
    "handbag": ("purse", "bag", "手提包"),
    "tie": ("领带",),
    "suitcase": ("luggage", "行李箱", "箱子", "旅行箱"),
    "sports ball": ("ball", "球"),
    "baseball bat": ("bat", "球棒"),
    "tennis racket": ("racket", "网球拍", "球拍"),
    "bottle": ("瓶子", "水瓶", "饮料瓶"),
    "cup": ("mug", "杯子", "马克杯"),
    "fork": ("叉子",),
    "knife": ("刀", "小刀"),
    "spoon": ("勺子",),
    "bowl": ("碗",),
    "banana": ("香蕉",),
    "apple": ("苹果",),
    "pear": ("梨", "雪梨", "鸭梨"),
    "orange": ("橙子",),
    "pizza": ("披萨",),
    "cake": ("蛋糕",),
    "chair": ("seat", "椅子", "座椅"),
    "couch": ("sofa", "沙发"),
    "potted plant": ("plant", "盆栽", "植物"),
    "bed": ("床",),
    "dining table": ("table", "desk", "餐桌", "桌子"),
    "toilet": ("wc", "马桶"),
    "tv": ("television", "screen", "电视", "显示器", "电视机"),
    "laptop": ("notebook", "电脑", "笔记本", "笔电"),
    "mouse": ("鼠标",),
    "remote": ("遥控器",),
    "keyboard": ("键盘",),
    "cell phone": ("phone", "mobile", "smartphone", "手机", "电话"),
    "microwave": ("微波炉",),
    "oven": ("烤箱",),
    "toaster": ("烤面包机",),
    "refrigerator": ("fridge", "冰箱"),
    "book": ("书", "书本"),
    "clock": ("时钟", "钟表", "挂钟"),
    "vase": ("花瓶",),
    "scissors": ("剪刀",),
    "teddy bear": ("teddy", "玩具熊"),
    "toothbrush": ("牙刷",),
}


def _load_camera_alias_terms(
    labels: tuple[str, ...] | None = None,
    alias_paths: tuple[str, ...] | None = None,
) -> tuple[tuple[str, ...], tuple[str, ...], dict[str, str]]:
    labels = labels if isinstance(labels, tuple) and labels else _load_camera_labels()
    if isinstance(alias_paths, tuple) and alias_paths:
        paths = [str(p) for p in alias_paths if str(p).strip()]
    else:
        paths = [os.environ.get("VISION_YOLO_WORLD_ALIASES", "/root/custom-monitor/models/yolo_world_aliases.json")]
    terms: set[str] = set()
    alias_to_canon: dict[str, str] = {}

    def add_alias(alias: Any, canon: Any) -> None:
        alias_key = str(alias or "").strip().lower()
        canon_key = str(canon or "").strip().lower()
        if not alias_key or not canon_key:
            return
        terms.add(alias_key)
        terms.add(canon_key)
        alias_to_canon[alias_key] = canon_key

    for canon in labels:
        add_alias(canon, canon)

    for canon, aliases in CAMERA_DEFAULT_ALIAS_MAP.items():
        add_alias(canon, canon)
        for alias in aliases:
            add_alias(alias, canon)

    for alias_path in paths:
        try:
            obj = json.loads(Path(alias_path).read_text(encoding="utf-8"))
            if isinstance(obj, dict):
                for canon, aliases in obj.items():
                    add_alias(canon, canon)
                    if isinstance(aliases, list):
                        for alias in aliases:
                            add_alias(alias, canon)
        except Exception:
            continue

    normalized = sorted({t for t in terms if t})
    ascii_terms = tuple(sorted((t for t in normalized if t.isascii()), key=len, reverse=True))
    non_ascii_terms = tuple(sorted((t for t in normalized if not t.isascii()), key=len, reverse=True))
    return ascii_terms, non_ascii_terms, alias_to_canon


CAMERA_CANON_LABELS = _load_camera_labels()
CAMERA_ALIAS_ASCII_TERMS, CAMERA_ALIAS_NON_ASCII_TERMS, CAMERA_ALIAS_CANON_BY_TERM = _load_camera_alias_terms()
CAMERA_CANON_LABEL_SET = set(CAMERA_CANON_LABELS)
_CAMERA_ALIAS_STATE_LOCK = threading.Lock()

CAMERA_CAPABILITY_META_BY_NAME: dict[str, dict[str, Any]] = {}
CAMERA_CAPABILITY_ASCII_TERMS: tuple[str, ...] = ()
CAMERA_CAPABILITY_NON_ASCII_TERMS: tuple[str, ...] = ()
CAMERA_CAPABILITY_NAME_BY_TERM: dict[str, str] = {}
CAMERA_CAPABILITY_STATE_FINGERPRINT = ""
_CAMERA_CAPABILITY_STATE_LOCK = threading.Lock()
CAMERA_CAPABILITY_TOKEN_ALIASES: dict[str, tuple[str, ...]] = {
    "wear": ("wear", "put on", "戴", "佩戴"),
    "glasses": ("glasses", "glass", "eyeglasses", "spectacles", "sunglasses", "眼镜", "墨镜"),
    "emotion": ("emotion", "emotions", "mood", "feeling", "sentiment", "情绪", "表情", "心情"),
}
CAMERA_CAPABILITY_EXCLUDE_DEFAULT = {
    "stream",
    "pipeline",
    "preview",
    "vision",
    "camera",
    "yolo",
    "yolo_world",
}


def _refresh_camera_alias_state(labels_path: str = "", aliases_path: str = "") -> dict[str, Any]:
    global CAMERA_CANON_LABELS
    global CAMERA_ALIAS_ASCII_TERMS
    global CAMERA_ALIAS_NON_ASCII_TERMS
    global CAMERA_ALIAS_CANON_BY_TERM
    global CAMERA_CANON_LABEL_SET
    try:
        labels = _load_camera_labels(path=labels_path or None)
        merged_alias_paths: list[str] = []
        default_alias_path = os.environ.get("VISION_YOLO_WORLD_ALIASES", "/root/custom-monitor/models/yolo_world_aliases.json")
        if default_alias_path:
            merged_alias_paths.append(default_alias_path)
        if aliases_path and aliases_path not in merged_alias_paths:
            merged_alias_paths.append(aliases_path)
        ascii_terms, non_ascii_terms, alias_to_canon = _load_camera_alias_terms(
            labels=labels,
            alias_paths=tuple(merged_alias_paths),
        )
        with _CAMERA_ALIAS_STATE_LOCK:
            CAMERA_CANON_LABELS = labels
            CAMERA_ALIAS_ASCII_TERMS = ascii_terms
            CAMERA_ALIAS_NON_ASCII_TERMS = non_ascii_terms
            CAMERA_ALIAS_CANON_BY_TERM = alias_to_canon
            CAMERA_CANON_LABEL_SET = set(labels)
        return {
            "ok": True,
            "labels_count": len(labels),
            "alias_count": len(alias_to_canon),
            "labels_path": labels_path or "",
            "aliases_path": aliases_path or "",
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _split_capability_tokens(name: str) -> list[str]:
    tokens = re.split(r"[_\-\s]+", str(name or "").strip().lower())
    return [token for token in tokens if token]


def _normalize_capability_term(term: Any) -> str:
    text = str(term or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text


def _capability_terms_from_name(name: str) -> set[str]:
    name_key = _normalize_capability_term(name)
    if not name_key:
        return set()
    out: set[str] = {name_key, name_key.replace("_", " "), name_key.replace("_", "")}
    tokens = _split_capability_tokens(name_key)
    for token in tokens:
        out.add(token)
        alias_terms = CAMERA_CAPABILITY_TOKEN_ALIASES.get(token)
        if alias_terms:
            for alias in alias_terms:
                norm = _normalize_capability_term(alias)
                if norm:
                    out.add(norm)
    if len(tokens) >= 2:
        for idx in range(0, len(tokens) - 1):
            pair = f"{tokens[idx]} {tokens[idx + 1]}".strip()
            if pair:
                out.add(pair)
                out.add(pair.replace(" ", ""))
    return {term for term in out if term}


def _coerce_alias_terms(raw: Any) -> list[str]:
    if isinstance(raw, list):
        values = raw
    elif isinstance(raw, str):
        values = re.split(r"[,\n\r;|/]+", raw)
    else:
        values = []
    out: list[str] = []
    for item in values:
        text = _normalize_capability_term(item)
        if text and text not in out:
            out.append(text)
    return out


def _extract_camera_capabilities(profile_payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if not isinstance(profile_payload, dict):
        return {}

    capabilities_root = profile_payload.get("capabilities")
    capabilities_from_root = capabilities_root if isinstance(capabilities_root, dict) else {}

    candidates: set[str] = set()
    for raw_key, raw_val in profile_payload.items():
        key = str(raw_key or "")
        if key.endswith("_enabled") and key != "enabled":
            prefix = key[: -len("_enabled")].strip().lower()
            if prefix and isinstance(raw_val, (bool, int, float, str)):
                candidates.add(prefix)
        elif key.endswith("_auto"):
            prefix = key[: -len("_auto")].strip().lower()
            if prefix and isinstance(raw_val, (bool, int, float, str)):
                candidates.add(prefix)

    for raw_name in capabilities_from_root.keys():
        name = _normalize_capability_term(raw_name).replace(" ", "_")
        if name:
            candidates.add(name)

    extra_excludes = _safe_text(os.environ.get("AGENT_CAMERA_CAPABILITY_EXCLUDE", ""), limit=400)
    exclude_set = set(CAMERA_CAPABILITY_EXCLUDE_DEFAULT)
    for item in re.split(r"[,\s]+", extra_excludes):
        key = _normalize_capability_term(item).replace(" ", "_")
        if key:
            exclude_set.add(key)

    out: dict[str, dict[str, Any]] = {}
    for name in sorted(candidates):
        if not name or name in exclude_set:
            continue
        if name.startswith("yolo") or name.startswith("stream"):
            continue

        root_obj = capabilities_from_root.get(name)
        root_meta = root_obj if isinstance(root_obj, dict) else {}

        enabled = _coerce_enabled(profile_payload.get(f"{name}_enabled"))
        auto = _coerce_enabled(profile_payload.get(f"{name}_auto"))
        ready = _coerce_enabled(profile_payload.get(f"{name}_ready"))
        error = _safe_text(profile_payload.get(f"{name}_error"), limit=180)
        detector = _safe_text(profile_payload.get(f"{name}_detector"), limit=24).lower()
        if enabled is None:
            enabled = _coerce_enabled(root_meta.get("enabled"))
        if auto is None:
            auto = _coerce_enabled(root_meta.get("auto"))
        if ready is None:
            ready = _coerce_enabled(root_meta.get("ready"))
        if not error:
            error = _safe_text(root_meta.get("error"), limit=180)
        if not detector:
            detector = _safe_text(root_meta.get("detector"), limit=24).lower()
        if detector not in ("none", "rect", "yolo", "yolo_world"):
            detector = "yolo_world"

        aliases = _coerce_alias_terms(profile_payload.get(f"{name}_aliases"))
        aliases.extend(_coerce_alias_terms(root_meta.get("aliases")))
        aliases = [item for item in aliases if item]

        if enabled is None and auto is None and not root_meta:
            continue

        out[name] = {
            "name": name,
            "enabled": bool(enabled) if enabled is not None else False,
            "auto": bool(auto) if auto is not None else False,
            "ready": bool(ready) if ready is not None else False,
            "error": error,
            "detector": detector or "yolo_world",
            "aliases": aliases,
        }
    return out


def _camera_capability_state_snapshot() -> dict[str, dict[str, Any]]:
    with _CAMERA_CAPABILITY_STATE_LOCK:
        return {name: dict(meta) for name, meta in CAMERA_CAPABILITY_META_BY_NAME.items()}


def _camera_capability_names() -> tuple[str, ...]:
    with _CAMERA_CAPABILITY_STATE_LOCK:
        return tuple(sorted(CAMERA_CAPABILITY_META_BY_NAME.keys()))


def _refresh_camera_capability_state(profile_payload: dict[str, Any]) -> dict[str, Any]:
    global CAMERA_CAPABILITY_META_BY_NAME
    global CAMERA_CAPABILITY_ASCII_TERMS
    global CAMERA_CAPABILITY_NON_ASCII_TERMS
    global CAMERA_CAPABILITY_NAME_BY_TERM
    global CAMERA_CAPABILITY_STATE_FINGERPRINT
    try:
        capabilities = _extract_camera_capabilities(profile_payload)
        term_candidates: dict[str, set[str]] = {}
        for name, meta in capabilities.items():
            terms = _capability_terms_from_name(name)
            for alias in meta.get("aliases", []):
                norm = _normalize_capability_term(alias)
                if norm:
                    terms.add(norm)
            for term in terms:
                key = _normalize_capability_term(term)
                if not key:
                    continue
                if key.isascii() and len(key) < 2:
                    continue
                term_candidates.setdefault(key, set()).add(name)

        name_by_term: dict[str, str] = {}
        for term, names in term_candidates.items():
            if len(names) == 1:
                name_by_term[term] = next(iter(names))
        for name in capabilities.keys():
            name_by_term[name] = name
            name_by_term[name.replace("_", " ")] = name
            name_by_term[name.replace("_", "")] = name

        ascii_terms = tuple(sorted((term for term in name_by_term.keys() if term.isascii()), key=len, reverse=True))
        non_ascii_terms = tuple(sorted((term for term in name_by_term.keys() if not term.isascii()), key=len, reverse=True))
        fingerprint = json.dumps(
            {
                "capabilities": capabilities,
                "term_count": len(name_by_term),
            },
            ensure_ascii=True,
            sort_keys=True,
        )
        with _CAMERA_CAPABILITY_STATE_LOCK:
            changed = fingerprint != CAMERA_CAPABILITY_STATE_FINGERPRINT
            CAMERA_CAPABILITY_META_BY_NAME = capabilities
            CAMERA_CAPABILITY_ASCII_TERMS = ascii_terms
            CAMERA_CAPABILITY_NON_ASCII_TERMS = non_ascii_terms
            CAMERA_CAPABILITY_NAME_BY_TERM = name_by_term
            CAMERA_CAPABILITY_STATE_FINGERPRINT = fingerprint
        return {
            "ok": True,
            "changed": bool(changed),
            "capability_count": len(capabilities),
            "term_count": len(name_by_term),
            "fingerprint": fingerprint,
            "capabilities": [name for name in sorted(capabilities.keys())],
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


@dataclass(frozen=True)
class AgentConfig:
    host: str
    port: int
    unix_socket_path: str
    vision_api_base: str
    llm_api_base: str
    tool_runtime: str
    llm_chat_fallback_enabled: bool
    llm_chat_timeout_sec: float
    llm_fast_chat_route_enabled: bool
    llm_semantic_cache_enabled: bool
    llm_semantic_cache_ttl_sec: float
    llm_semantic_cache_max_items: int
    llm_semantic_cache_side_effect_enabled: bool
    command_embed_router_enabled: bool
    command_embed_router_model: str
    command_embed_router_min_score: float
    command_embed_router_min_margin: float
    command_embed_router_use_npu: bool
    command_embed_router_local_files_only: bool
    command_embed_router_prewarm: bool
    command_embed_classifier_enabled: bool
    command_embed_classifier_path: str
    command_embed_classifier_min_prob: float
    command_embed_model_only: bool
    llm_command_gate_timeout_sec: float
    llm_strict_mode: bool
    llm_tool_planner_enabled: bool
    llm_tool_planner_timeout_sec: float
    llm_planner_concurrency: int
    llm_planner_slot_wait_sec: float
    llm_tool_plan_native_history_enabled: bool
    llm_tool_plan_native_tools_enabled: bool
    llm_tool_plan_repair_enabled: bool
    llm_tool_plan_repair_timeout_sec: float
    llm_exec_feedback_enabled: bool
    llm_exec_feedback_timeout_sec: float
    llm_exec_feedback_temperature: float
    require_vision: bool
    timeout_short_sec: float
    timeout_long_sec: float
    body_limit_bytes: int
    stream_chunk_size: int
    command_max_actions: int
    exec_read_parallelism: int
    confirm_ttl_sec: float
    confirm_min_risk: str
    trigger_cooldown_sec: float
    trigger_temp_high_c: float
    trigger_mem_high_percent: float
    trigger_frame_stale_ms: float
    trace_capacity: int
    trace_retention_sec: float
    memory_enabled: bool
    memory_max_items: int
    memory_max_text: int
    memory_persist_enabled: bool
    memory_persist_path: str
    memory_auto_capture_enabled: bool
    memory_auto_capture_on_failure: bool
    knowledge_base_enabled: bool
    knowledge_base_path: str
    knowledge_base_max_hits: int
    knowledge_base_max_chars: int
    rgb_backend: str

    @classmethod
    def from_env(cls) -> "AgentConfig":
        # Proxy tool runtimes are retired; agent executor is local-only.
        tool_runtime = "local"
        rgb_backend = (os.environ.get("AGENT_RGB_BACKEND", "sysfs").strip().lower() or "sysfs")
        if rgb_backend not in ("sysfs", "virtual", "off"):
            rgb_backend = "sysfs"
        default_memory_path = str(
            (Path(__file__).resolve().parents[1] / "runtime" / "agent_memory.jsonl").resolve()
        )
        default_embed_model = os.environ.get("AGENT_COMMAND_EMBED_MODEL", "").strip()
        if not default_embed_model:
            try:
                repo_cache = (
                    Path.home()
                    / ".cache"
                    / "huggingface"
                    / "hub"
                    / "models--rk-transformers--all-MiniLM-L6-v2"
                )
                main_ref = repo_cache / "refs" / "main"
                if main_ref.exists():
                    rev = main_ref.read_text(encoding="utf-8").strip()
                    snap = repo_cache / "snapshots" / rev
                    if snap.exists():
                        default_embed_model = str(snap)
            except Exception:
                default_embed_model = ""
        if not default_embed_model:
            default_embed_model = "rk-transformers/all-MiniLM-L6-v2"
        default_embed_classifier = os.environ.get("AGENT_COMMAND_EMBED_CLASSIFIER", "").strip()
        if not default_embed_classifier:
            try:
                runtime_dir = (Path(__file__).resolve().parents[1] / "runtime").resolve()
                candidates = (
                    runtime_dir / "intent_classifier_plus_v16" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v15" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v14" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v13" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v12" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v11" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v10" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v9" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v8" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v7" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v5" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v4" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v2" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus_v3" / "classifier.joblib",
                    runtime_dir / "intent_classifier_plus" / "classifier.joblib",
                    runtime_dir / "intent_classifier" / "classifier.joblib",
                )
                for cand in candidates:
                    if cand.exists():
                        default_embed_classifier = str(cand)
                        break
            except Exception:
                default_embed_classifier = ""
        return cls(
            host=os.environ.get("AGENT_PREVIEW_HOST", "0.0.0.0"),
            port=_clamp_int(
                os.environ.get("AGENT_PREVIEW_PORT", "8093"),
                default=8093,
                min_value=1,
                max_value=65535,
            ),
            unix_socket_path=str(os.environ.get("AGENT_UNIX_SOCKET", "")).strip(),
            vision_api_base=os.environ.get(
                "AGENT_VISION_API_BASE",
                os.environ.get("VISION_API_BASE", "http://127.0.0.1:8092"),
            ).rstrip("/"),
            llm_api_base=os.environ.get(
                "AGENT_LLM_API_BASE",
                os.environ.get("LLM_API_BASE", "http://127.0.0.1:8091"),
            ).rstrip("/"),
            tool_runtime=tool_runtime,
            llm_chat_fallback_enabled=(
                os.environ.get("AGENT_LLM_CHAT_FALLBACK", "1") not in ("0", "false", "False")
            ),
            llm_chat_timeout_sec=max(
                1.2,
                min(40.0, float(os.environ.get("AGENT_LLM_CHAT_TIMEOUT_SEC", "2.5"))),
            ),
            llm_fast_chat_route_enabled=(
                os.environ.get("AGENT_LLM_FAST_CHAT_ROUTE", "0") not in ("0", "false", "False")
            ),
            llm_semantic_cache_enabled=(
                os.environ.get("AGENT_LLM_SEMANTIC_CACHE", "1") not in ("0", "false", "False")
            ),
            llm_semantic_cache_ttl_sec=max(
                5.0,
                min(3600.0, float(os.environ.get("AGENT_LLM_SEMANTIC_CACHE_TTL_SEC", "180"))),
            ),
            llm_semantic_cache_max_items=_clamp_int(
                os.environ.get("AGENT_LLM_SEMANTIC_CACHE_MAX", "240"),
                default=240,
                min_value=32,
                max_value=5000,
            ),
            llm_semantic_cache_side_effect_enabled=(
                os.environ.get("AGENT_LLM_SEMANTIC_CACHE_SIDE_EFFECT", "0")
                not in ("0", "false", "False")
            ),
            command_embed_router_enabled=(
                os.environ.get("AGENT_COMMAND_EMBED_ROUTER", "1") not in ("0", "false", "False")
            ),
            command_embed_router_model=default_embed_model,
            command_embed_router_min_score=max(
                0.4,
                min(0.999, float(os.environ.get("AGENT_COMMAND_EMBED_MIN_SCORE", "0.90"))),
            ),
            command_embed_router_min_margin=max(
                0.0,
                min(0.6, float(os.environ.get("AGENT_COMMAND_EMBED_MIN_MARGIN", "0.01"))),
            ),
            command_embed_router_use_npu=(
                os.environ.get("AGENT_COMMAND_EMBED_USE_NPU", "1") not in ("0", "false", "False")
            ),
            command_embed_router_local_files_only=(
                os.environ.get("AGENT_COMMAND_EMBED_LOCAL_ONLY", "1") not in ("0", "false", "False")
            ),
            command_embed_router_prewarm=(
                os.environ.get("AGENT_COMMAND_EMBED_PREWARM", "1") not in ("0", "false", "False")
            ),
            command_embed_classifier_enabled=(
                os.environ.get("AGENT_COMMAND_EMBED_CLASSIFIER_ENABLED", "1")
                not in ("0", "false", "False")
            ),
            command_embed_classifier_path=default_embed_classifier,
            command_embed_classifier_min_prob=max(
                0.05,
                min(0.99, float(os.environ.get("AGENT_COMMAND_EMBED_CLASSIFIER_MIN_PROB", "0.12"))),
            ),
            command_embed_model_only=(
                os.environ.get("AGENT_COMMAND_EMBED_MODEL_ONLY", "1") not in ("0", "false", "False")
            ),
            llm_command_gate_timeout_sec=max(
                1.0,
                min(20.0, float(os.environ.get("AGENT_LLM_COMMAND_GATE_TIMEOUT_SEC", "3.5"))),
            ),
            llm_strict_mode=(
                os.environ.get("AGENT_LLM_STRICT_MODE", "0") in ("1", "true", "True")
            ),
            llm_tool_planner_enabled=(
                os.environ.get("AGENT_LLM_TOOL_PLANNER", "1") not in ("0", "false", "False")
            ),
            llm_tool_planner_timeout_sec=max(
                1.5,
                float(os.environ.get("AGENT_LLM_TOOL_PLANNER_TIMEOUT_SEC", "2.5")),
            ),
            llm_planner_concurrency=_clamp_int(
                os.environ.get("AGENT_LLM_PLANNER_CONCURRENCY", "1"),
                default=1,
                min_value=1,
                max_value=4,
            ),
            llm_planner_slot_wait_sec=max(
                0.0,
                min(10.0, float(os.environ.get("AGENT_LLM_PLANNER_SLOT_WAIT_SEC", "1.2"))),
            ),
            llm_tool_plan_native_history_enabled=(
                os.environ.get("AGENT_LLM_TOOL_PLAN_NATIVE_HISTORY", "0")
                not in ("0", "false", "False")
            ),
            llm_tool_plan_native_tools_enabled=(
                os.environ.get("AGENT_LLM_TOOL_PLAN_NATIVE_TOOLS", "1")
                not in ("0", "false", "False")
            ),
            llm_tool_plan_repair_enabled=(
                os.environ.get("AGENT_LLM_TOOL_PLAN_REPAIR", "1") not in ("0", "false", "False")
            ),
            llm_tool_plan_repair_timeout_sec=max(
                1.0,
                min(8.0, float(os.environ.get("AGENT_LLM_TOOL_PLAN_REPAIR_TIMEOUT_SEC", "2.4"))),
            ),
            llm_exec_feedback_enabled=(
                os.environ.get("AGENT_LLM_EXEC_FEEDBACK", "1") not in ("0", "false", "False")
            ),
            llm_exec_feedback_timeout_sec=max(
                3.0,
                float(os.environ.get("AGENT_LLM_EXEC_FEEDBACK_TIMEOUT_SEC", "10")),
            ),
            llm_exec_feedback_temperature=max(
                0.0,
                min(1.5, float(os.environ.get("AGENT_LLM_EXEC_FEEDBACK_TEMPERATURE", "0.7"))),
            ),
            require_vision=os.environ.get("AGENT_REQUIRE_VISION", "0") not in ("0", "false", "False"),
            timeout_short_sec=max(1.0, float(os.environ.get("AGENT_TIMEOUT_SHORT_SEC", "8"))),
            timeout_long_sec=max(1.0, float(os.environ.get("AGENT_TIMEOUT_LONG_SEC", "130"))),
            body_limit_bytes=_clamp_int(
                os.environ.get("AGENT_BODY_LIMIT_BYTES", str(16 * 1024 * 1024)),
                default=16 * 1024 * 1024,
                min_value=1024,
                max_value=64 * 1024 * 1024,
            ),
            stream_chunk_size=_clamp_int(
                os.environ.get("AGENT_STREAM_CHUNK_SIZE", "65536"),
                default=65536,
                min_value=4096,
                max_value=1024 * 1024,
            ),
            command_max_actions=_clamp_int(
                os.environ.get("AGENT_COMMAND_MAX_ACTIONS", "4"),
                default=4,
                min_value=1,
                max_value=8,
            ),
            exec_read_parallelism=_clamp_int(
                os.environ.get("AGENT_EXEC_READ_PARALLELISM", "4"),
                default=4,
                min_value=1,
                max_value=16,
            ),
            confirm_ttl_sec=max(30.0, float(os.environ.get("AGENT_COMMAND_CONFIRM_TTL_SEC", "180"))),
            confirm_min_risk=(
                os.environ.get("AGENT_COMMAND_CONFIRM_MIN_RISK", "high").strip().lower() or "high"
            ),
            trigger_cooldown_sec=max(1.0, float(os.environ.get("AGENT_TRIGGER_COOLDOWN_SEC", "10"))),
            trigger_temp_high_c=float(os.environ.get("AGENT_TRIGGER_TEMP_HIGH_C", "78")),
            trigger_mem_high_percent=float(os.environ.get("AGENT_TRIGGER_MEM_HIGH_PERCENT", "92")),
            trigger_frame_stale_ms=float(os.environ.get("AGENT_TRIGGER_FRAME_STALE_MS", "1500")),
            trace_capacity=_clamp_int(
                os.environ.get("AGENT_TRACE_CAPACITY", "600"),
                default=600,
                min_value=100,
                max_value=4000,
            ),
            trace_retention_sec=max(60.0, float(os.environ.get("AGENT_TRACE_RETENTION_SEC", "7200"))),
            memory_enabled=os.environ.get("AGENT_MEMORY_ENABLED", "1") not in ("0", "false", "False"),
            memory_max_items=_clamp_int(
                os.environ.get("AGENT_MEMORY_MAX_ITEMS", "5000"),
                default=5000,
                min_value=200,
                max_value=50000,
            ),
            memory_max_text=_clamp_int(
                os.environ.get("AGENT_MEMORY_MAX_TEXT", "480"),
                default=480,
                min_value=64,
                max_value=4000,
            ),
            memory_persist_enabled=(
                os.environ.get("AGENT_MEMORY_PERSIST_ENABLED", "1") not in ("0", "false", "False")
            ),
            memory_persist_path=_safe_text(
                os.environ.get("AGENT_MEMORY_PERSIST_PATH", default_memory_path),
                limit=1200,
            ),
            memory_auto_capture_enabled=(
                os.environ.get("AGENT_MEMORY_AUTO_CAPTURE", "1") not in ("0", "false", "False")
            ),
            memory_auto_capture_on_failure=(
                os.environ.get("AGENT_MEMORY_AUTO_CAPTURE_ON_FAILURE", "1")
                not in ("0", "false", "False")
            ),
            knowledge_base_enabled=(
                os.environ.get("AGENT_KNOWLEDGE_BASE_ENABLED", "1") not in ("0", "false", "False")
            ),
            knowledge_base_path=_safe_text(
                os.environ.get(
                    "AGENT_KNOWLEDGE_BASE_PATH",
                    str((_DISTRIBUTED_PREVIEW_DIR.parent / "knowledge_base").resolve()),
                ),
                limit=1200,
            ),
            knowledge_base_max_hits=_clamp_int(
                os.environ.get("AGENT_KNOWLEDGE_BASE_MAX_HITS", "2"),
                default=2,
                min_value=1,
                max_value=6,
            ),
            knowledge_base_max_chars=_clamp_int(
                os.environ.get("AGENT_KNOWLEDGE_BASE_MAX_CHARS", "420"),
                default=420,
                min_value=180,
                max_value=1200,
            ),
            rgb_backend=rgb_backend,
        )


DEFAULT_TOOL_SPECS: tuple[dict[str, Any], ...] = (
    {
        "name": "system.time",
        "description": "Get local system time",
        "arguments": {"part": "datetime|date|time|weekday|date_weekday"},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "system.cpu",
        "description": "Get CPU usage snapshot",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "system.mem",
        "description": "Get memory usage snapshot",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "system.npu",
        "description": "Get NPU usage and driver version",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "system.thermal",
        "description": "Get temperature snapshot",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.sensors.get",
        "description": "Get water sensor snapshot, thresholds, alerts and advice for temperature, pH and turbidity; 查询水温、pH、浊度、阈值和建议",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.sensors.thresholds.set",
        "description": "Update water sensor thresholds for temperature, pH and turbidity; 设置水温、pH、浊度上下限阈值",
        "arguments": {
            "temperature_min": "number optional",
            "temperature_max": "number optional",
            "ph_min": "number optional",
            "ph_max": "number optional",
            "turbidity_min": "number optional",
            "turbidity_max": "number optional",
        },
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "vision.sensors.sample.set",
        "description": "Update latest water sensor sample for debugging or USB-serial bridge ingestion; 写入传感器样本联调",
        "arguments": {
            "temperature": "number optional",
            "ph": "number optional",
            "turbidity": "number optional",
            "source": "optional",
        },
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "vision.observe",
        "description": "Get camera observation",
        "arguments": {
            "detector": "none|rect|yolo|yolo_world",
            "capability_flags": "dynamic bool args from /api/vision/profile capability map",
        },
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.enabled.get",
        "description": "Get vision enabled status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.profile.get",
        "description": "Get vision profile status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.enabled.set",
        "description": "Enable/disable vision runtime",
        "arguments": {"enabled": "true|false", "reason": "optional"},
        "side_effect": True,
        "risk_level": "medium",
    },
    {
        "name": "vision.profile.set",
        "description": "Switch vision profile",
        "arguments": {"name": "stable|smooth|clear|clear60|fullhd30"},
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "vision.stream.set",
        "description": "Enable/disable preview stream",
        "arguments": {"enabled": "true|false", "reason": "optional"},
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "vision.recover",
        "description": "Trigger vision recovery",
        "arguments": {"reason": "optional"},
        "side_effect": True,
        "risk_level": "medium",
    },
    {
        "name": "vision.gimbal.status",
        "description": "Get gimbal serial runtime status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.gimbal.command",
        "description": "Send gimbal yaw/pitch speed command over serial (unit: rpm)",
        "arguments": {
            "yaw_rpm": "float",
            "pitch_rpm": "float",
            "laser_enabled": "0|1|2 optional (2=no action)",
            "enabled": "0|1|2 optional (2=no action)",
            "stability_enabled": "0|1|2 optional (2=no action)",
            "auto_stop_ms": "0..5000 optional",
            "reason": "optional",
        },
        "side_effect": True,
        "risk_level": "medium",
    },
    {
        "name": "vision.gimbal.laser.blink",
        "description": "Blink gimbal laser immediately",
        "arguments": {
            "blinks": "1..12 optional (default 6)",
            "period_ms": "80..2000 optional",
            "laser_on_ms": "40..2000 optional",
            "laser_off_ms": "40..2000 optional",
            "reason": "optional",
        },
        "side_effect": True,
        "risk_level": "medium",
    },
    {
        "name": "vision.gimbal.lock.status",
        "description": "Get gimbal target lock task status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.gimbal.lock.start",
        "description": "Start gimbal target lock task (detect, track, laser confirm)",
        "arguments": {
            "target": "target label/alias optional",
            "detector": "auto|face|yolo|yolo_world optional",
            "timeout_sec": "1..86400 optional",
            "continuous": "true|false optional (true=track until stop/timeout)",
            "center_tolerance_px": "2..320 optional",
            "stable_frames": "1..60 optional",
            "min_score": "0.01..0.99 optional",
            "max_rpm": "1..50 optional",
            "kp_yaw": "0.001..1 optional",
            "kp_pitch": "0.001..1 optional",
            "invert_yaw": "true|false optional",
            "invert_pitch": "true|false optional",
            "search_sweep_rpm": "0..40 optional",
            "search_sweep_pulse_ms": "0..1200 optional",
            "search_spin_deg": "30..2160 optional (default 360)",
            "search_spin_clockwise": "true|false optional (default true)",
            "laser_blinks": "0..12 optional",
            "laser_on_ms": "40..1000 optional",
            "laser_off_ms": "40..1000 optional",
            "wear_glasses": "true|false optional (person-only detail)",
            "emotion": "true|false optional (person-only detail)",
            "reason": "optional",
        },
        "side_effect": True,
        "risk_level": "medium",
    },
    {
        "name": "vision.gimbal.lock.stop",
        "description": "Stop gimbal target lock task",
        "arguments": {"wait": "true|false optional", "reason": "optional"},
        "side_effect": True,
        "risk_level": "medium",
    },
    {
        "name": "vision.yolo_world.filter.get",
        "description": "Get YOLO-World filter status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.yolo_world.filter.set",
        "description": "Set/clear YOLO-World class filter",
        "arguments": {
            "labels": "comma-separated labels optional",
            "mode": "all|clear optional",
            "reason": "optional",
        },
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "vision.yolo_world.prompt.get",
        "description": "Get YOLO-World prompt status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "vision.yolo_world.prompt.set",
        "description": "Set YOLO-World prompt/include/exclude terms",
        "arguments": {
            "prompt": "natural language prompt optional",
            "include_terms": ["optional"],
            "exclude_terms": ["optional"],
            "strict": "true|false optional",
            "reason": "optional",
        },
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "memory.add",
        "description": "Add volatile memory",
        "arguments": {"text": "string", "tags": ["optional"]},
        "side_effect": True,
        "risk_level": "low",
    },
    {
        "name": "memory.list",
        "description": "List volatile memory",
        "arguments": {"limit": "optional"},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "memory.search",
        "description": "Search volatile memory",
        "arguments": {"query": "string", "limit": "optional"},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "memory.clear",
        "description": "Clear volatile memory",
        "arguments": {},
        "side_effect": True,
        "risk_level": "high",
    },
    {
        "name": "memory.stats",
        "description": "Get memory stats",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "rgb.status",
        "description": "Get LED status",
        "arguments": {},
        "side_effect": False,
        "risk_level": "low",
    },
    {
        "name": "rgb.set",
        "description": "Set LED color",
        "arguments": {
            "color": "off|red|green|blue|yellow|cyan|magenta|white",
            "intensity": "1-255 optional",
            "duration_sec": "optional",
            "persist": "optional",
        },
        "side_effect": True,
        "risk_level": "low",
    },
)

EXEC_FEEDBACK_STYLE_HINTS: tuple[str, ...] = (
    "简洁专业，直接给结论。",
    "简洁口语化，语气自然。",
    "先结果后数字，1到2句。",
    "偏服务型表达，但不要夸张。",
)


class JsonHttpClient:
    def __init__(self, base_url: str) -> None:
        self.base_url = base_url.rstrip("/")

    def request_json(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        timeout_sec: float = 8.0,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, Any] | None, str]:
        conn: http.client.HTTPConnection | None = None
        try:
            target = parse_base_target(self.base_url)
            if (not target.is_unix) and (not target.host):
                return 0, None, "invalid base url: missing host"
            req_path = compose_request_path(self.base_url, path)
            body: bytes | None = None
            req_headers = {
                "Accept": "application/json",
                "User-Agent": "agent-service-v2",
                "Connection": "close",
            }
            if headers:
                req_headers.update(headers)
            if payload is not None:
                body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                req_headers["Content-Type"] = "application/json; charset=utf-8"
                req_headers["Content-Length"] = str(len(body))
            conn, _ = open_connection(self.base_url, timeout_sec=timeout_sec)
            conn.request(method=method.upper(), url=req_path, body=body, headers=req_headers)
            response = conn.getresponse()
            status = int(response.status)
            raw = response.read()
            text = raw.decode("utf-8", errors="replace") if raw else ""
            if not text:
                return status, None, ""
            try:
                obj = json.loads(text)
            except Exception:
                return status, None, text[:260]
            if isinstance(obj, dict):
                return status, obj, ""
            return status, {"value": obj}, ""
        except Exception as exc:
            return 0, None, str(exc)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass


class ToolRegistry:
    def __init__(self, specs: tuple[dict[str, Any], ...]) -> None:
        self._items: dict[str, dict[str, Any]] = {}
        for spec in specs:
            name = _safe_text(spec.get("name"), limit=80)
            if not name:
                continue
            self._items[name] = {
                "name": name,
                "description": str(spec.get("description") or ""),
                "arguments": spec.get("arguments", {}),
                "side_effect": bool(spec.get("side_effect", False)),
                "risk_level": str(spec.get("risk_level") or "low").strip().lower() or "low",
            }

    def get(self, name: str) -> dict[str, Any] | None:
        return self._items.get(str(name or "").strip())

    def has(self, name: str) -> bool:
        return self.get(name) is not None

    def list_dict(self) -> list[dict[str, Any]]:
        return [dict(item) for item in self._items.values()]


class RiskPolicy:
    _RISK_LEVELS: dict[str, int] = {"low": 1, "medium": 2, "high": 3}

    def __init__(self, tool_registry: ToolRegistry, confirm_min_risk: str) -> None:
        self.tool_registry = tool_registry
        self.confirm_min_risk = self._normalize_risk(confirm_min_risk, default="high")

    @classmethod
    def _normalize_risk(cls, value: Any, default: str = "low") -> str:
        text = str(value or "").strip().lower()
        if text in cls._RISK_LEVELS:
            return text
        if any(token in text for token in ("high", "critical", "danger")):
            return "high"
        if any(token in text for token in ("medium", "normal")):
            return "medium"
        if any(token in text for token in ("low", "safe")):
            return "low"
        return default

    def risk_rank(self, value: str) -> int:
        return int(self._RISK_LEVELS.get(self._normalize_risk(value), 1))

    def tool_risk(self, tool: str, args: dict[str, Any]) -> str:
        name = str(tool or "").strip()
        spec = self.tool_registry.get(name)
        risk = self._normalize_risk(spec.get("risk_level") if isinstance(spec, dict) else "low", default="low")
        if name == "memory.clear":
            return "high"
        if name == "vision.enabled.set":
            enabled = _coerce_enabled(args.get("enabled"))
            if enabled is False:
                return "high"
            return "medium"
        if name == "rgb.set":
            if _coerce_enabled(args.get("persist")) is True:
                return "medium"
            return "low"
        return risk

    def requires_confirmation(
        self,
        tool: str,
        args: dict[str, Any],
        side_effect: bool,
    ) -> tuple[bool, str]:
        risk_level = self.tool_risk(tool, args)
        if not side_effect:
            return False, risk_level
        need_confirm = self.risk_rank(risk_level) >= self.risk_rank(self.confirm_min_risk)
        return need_confirm, risk_level


class ConfirmTokenStore:
    def __init__(self, ttl_sec: float) -> None:
        self.ttl_sec = max(30.0, float(ttl_sec))
        self._lock = threading.Lock()
        self._rows: dict[str, dict[str, Any]] = {}

    def _cleanup_locked(self, now_ts: float | None = None) -> None:
        now_val = float(now_ts if now_ts is not None else time.time())
        expired = [
            token
            for token, row in self._rows.items()
            if float(row.get("expires_ts", 0.0)) <= now_val
        ]
        for token in expired:
            self._rows.pop(token, None)

    def create(self, client_id: str, query: str, plan: dict[str, Any]) -> dict[str, Any]:
        now_ts = time.time()
        expires_ts = now_ts + self.ttl_sec
        token = uuid.uuid4().hex[:20]
        row = {
            "token": token,
            "client_id": _safe_text(client_id, limit=96) or "local",
            "query": _safe_text(query, limit=220),
            "plan": dict(plan),
            "created_ts": now_ts,
            "created_at": _iso_from_ts(now_ts),
            "expires_ts": expires_ts,
            "expires_at": _iso_from_ts(expires_ts),
        }
        with self._lock:
            self._cleanup_locked(now_ts)
            self._rows[token] = row
        return {
            "token": token,
            "created_at": row["created_at"],
            "expires_at": row["expires_at"],
            "ttl_sec": int(self.ttl_sec),
        }

    def take(self, token: str, client_id: str, consume: bool) -> tuple[dict[str, Any] | None, str]:
        clean = _safe_text(token, limit=80)
        if not clean:
            return None, "confirm_token is required"
        with self._lock:
            self._cleanup_locked()
            row = self._rows.get(clean)
            if not isinstance(row, dict):
                return None, "confirm_token not found or expired"
            row_client = _safe_text(row.get("client_id"), limit=96)
            if row_client and row_client != _safe_text(client_id, limit=96):
                return None, "confirm_token client mismatch"
            if consume:
                self._rows.pop(clean, None)
            return dict(row), ""

    def count(self) -> int:
        with self._lock:
            self._cleanup_locked()
            return len(self._rows)


@dataclass
class TraceContext:
    trace: dict[str, Any]
    started_perf: float


class TraceStore:
    def __init__(self, capacity: int, retention_sec: float) -> None:
        self.capacity = max(100, int(capacity))
        self.retention_sec = max(60.0, float(retention_sec))
        self._lock = threading.Lock()
        self._rows: dict[str, dict[str, Any]] = {}
        self._order: deque[tuple[float, str]] = deque()

    def start(self, route: str, payload: dict[str, Any], raw_input: str) -> TraceContext:
        trace_id = uuid.uuid4().hex[:16]
        initiator = _safe_text(payload.get("initiator"), limit=48).lower() or "user"
        trace = {
            "trace_id": trace_id,
            "route": _safe_text(route, limit=120),
            "initiator": initiator,
            "raw_input": _safe_text(raw_input, limit=220),
            "started_at": _ts_now_ms(),
            "steps": [],
        }
        return TraceContext(trace=trace, started_perf=time.perf_counter())

    @staticmethod
    def step(
        ctx: TraceContext,
        name: str,
        ok: bool,
        detail: str,
        duration_ms: float | None = None,
        status: int | None = None,
    ) -> None:
        steps = ctx.trace.get("steps")
        if not isinstance(steps, list):
            steps = []
            ctx.trace["steps"] = steps
        row: dict[str, Any] = {
            "name": _safe_text(name, limit=64),
            "ok": bool(ok),
            "detail": _safe_text(detail, limit=260),
            "timestamp": _ts_now(),
        }
        if duration_ms is not None:
            row["duration_ms"] = round(max(0.0, float(duration_ms)), 2)
        if status is not None:
            row["status"] = int(status)
        steps.append(row)

    def finalize(self, ctx: TraceContext, ok: bool) -> dict[str, Any]:
        output = dict(ctx.trace)
        output["ok"] = bool(ok)
        output["finished_at"] = _ts_now_ms()
        output["duration_ms"] = round(max(0.0, (time.perf_counter() - ctx.started_perf) * 1000.0), 2)
        self._put(output)
        return output

    def _cleanup_locked(self, now_ts: float | None = None) -> None:
        now_val = float(now_ts if now_ts is not None else time.time())
        while self._order:
            ts, trace_id = self._order[0]
            if now_val - ts <= self.retention_sec and len(self._order) <= self.capacity:
                break
            self._order.popleft()
            self._rows.pop(trace_id, None)

    def _put(self, trace: dict[str, Any]) -> None:
        now_ts = time.time()
        trace_id = _safe_text(trace.get("trace_id"), limit=32)
        if not trace_id:
            return
        with self._lock:
            self._cleanup_locked(now_ts)
            self._rows[trace_id] = dict(trace)
            self._order.append((now_ts, trace_id))
            self._cleanup_locked(now_ts)

    def get(self, trace_id: str) -> dict[str, Any] | None:
        clean = _safe_text(trace_id, limit=32)
        if not clean:
            return None
        with self._lock:
            self._cleanup_locked()
            row = self._rows.get(clean)
            return dict(row) if isinstance(row, dict) else None

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        keep = _clamp_int(limit, default=20, min_value=1, max_value=200)
        with self._lock:
            self._cleanup_locked()
            out: list[dict[str, Any]] = []
            for _, trace_id in reversed(self._order):
                row = self._rows.get(trace_id)
                if not isinstance(row, dict):
                    continue
                out.append(
                    {
                        "trace_id": row.get("trace_id"),
                        "route": row.get("route"),
                        "ok": row.get("ok"),
                        "started_at": row.get("started_at"),
                        "finished_at": row.get("finished_at"),
                        "duration_ms": row.get("duration_ms"),
                    }
                )
                if len(out) >= keep:
                    break
            return out

    def count(self) -> int:
        with self._lock:
            self._cleanup_locked()
            return len(self._rows)


class LocalMetricSampler:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._prev_cpu_total, self._prev_cpu_idle = self._read_cpu_totals()
        self._prev_npu_active, self._prev_npu_suspended, _ = self._read_npu_runtime_counters()

    @staticmethod
    def _read_cpu_totals() -> tuple[int, int]:
        try:
            with open("/proc/stat", "r", encoding="utf-8") as f:
                first = f.readline().strip()
        except Exception:
            return 0, 0
        fields = first.split()
        if not fields or fields[0] != "cpu":
            return 0, 0
        values: list[int] = []
        for seg in fields[1:]:
            try:
                values.append(int(seg))
            except ValueError:
                values.append(0)
        total = sum(values)
        idle = values[3] + (values[4] if len(values) > 4 else 0)
        return total, idle

    def cpu_usage_percent(self) -> float:
        with self._lock:
            total, idle = self._read_cpu_totals()
            delta_total = total - self._prev_cpu_total
            delta_idle = idle - self._prev_cpu_idle
            self._prev_cpu_total = total
            self._prev_cpu_idle = idle
        if delta_total <= 0:
            return 0.0
        busy = delta_total - delta_idle
        return max(0.0, min(100.0, busy * 100.0 / delta_total))

    @staticmethod
    def memory_info() -> dict[str, Any]:
        info_kb: dict[str, int] = {}
        try:
            with open("/proc/meminfo", "r", encoding="utf-8") as f:
                lines = f.readlines()
        except Exception:
            lines = []
        for line in lines:
            if ":" not in line:
                continue
            key, rest = line.split(":", 1)
            value = rest.strip().split()[0]
            try:
                info_kb[key] = int(value)
            except ValueError:
                continue
        mem_total = info_kb.get("MemTotal", 0) * 1024
        mem_available = info_kb.get("MemAvailable", 0) * 1024
        mem_used = max(0, mem_total - mem_available)
        swap_total = info_kb.get("SwapTotal", 0) * 1024
        swap_free = info_kb.get("SwapFree", 0) * 1024
        swap_used = max(0, swap_total - swap_free)
        mem_used_pct = (mem_used * 100.0 / mem_total) if mem_total else 0.0
        swap_used_pct = (swap_used * 100.0 / swap_total) if swap_total else 0.0
        return {
            "total": mem_total,
            "used": mem_used,
            "available": mem_available,
            "used_percent": mem_used_pct,
            "swap_total": swap_total,
            "swap_used": swap_used,
            "swap_used_percent": swap_used_pct,
        }

    @staticmethod
    def thermal_info() -> tuple[list[dict[str, Any]], float | None]:
        zones: list[dict[str, Any]] = []
        base = Path("/sys/class/thermal")
        if base.exists():
            for zone in sorted(base.glob("thermal_zone*")):
                raw = _read_int(str(zone / "temp"))
                if raw is None:
                    continue
                celsius = raw / 1000.0 if raw > 1000 else float(raw)
                if celsius < -50 or celsius > 200:
                    continue
                zones.append(
                    {
                        "name": _read_text(str(zone / "type")) or zone.name,
                        "temp_c": celsius,
                    }
                )
        max_temp = max((row["temp_c"] for row in zones), default=None)
        return zones, max_temp

    @staticmethod
    def _read_npu_runtime_counters() -> tuple[int | None, int | None, str | None]:
        active = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_active_time")
        suspended = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_suspended_time")
        runtime_status = _read_text("/sys/devices/platform/fdab0000.npu/power/runtime_status") or None
        return active, suspended, runtime_status

    def npu_info(self) -> dict[str, Any]:
        usage_percent: float | None = None
        cores: list[float] = []
        freq_hz: int | None = None
        power_state = _read_text("/sys/kernel/debug/rknpu/power") or None
        runtime_active, runtime_suspended, runtime_status = self._read_npu_runtime_counters()
        runtime_usage_percent: float | None = None

        load_text = _read_text("/sys/kernel/debug/rknpu/load")
        if load_text:
            for value in re.findall(r"Core\d+:\s*([0-9]+)%", load_text):
                try:
                    cores.append(float(value))
                except ValueError:
                    continue
            if cores:
                usage_percent = sum(cores) / len(cores)

        freq_text = _read_text("/sys/kernel/debug/rknpu/freq")
        if freq_text:
            try:
                freq_hz = int(freq_text)
            except ValueError:
                match = re.search(r"([0-9]{6,})", freq_text)
                if match:
                    freq_hz = int(match.group(1))

        with self._lock:
            prev_active = self._prev_npu_active
            prev_suspended = self._prev_npu_suspended
            self._prev_npu_active = runtime_active
            self._prev_npu_suspended = runtime_suspended
        if (
            runtime_active is not None
            and runtime_suspended is not None
            and prev_active is not None
            and prev_suspended is not None
        ):
            delta_active = runtime_active - prev_active
            delta_suspended = runtime_suspended - prev_suspended
            total_delta = delta_active + delta_suspended
            if delta_active >= 0 and delta_suspended >= 0 and total_delta > 0:
                runtime_usage_percent = max(0.0, min(100.0, delta_active * 100.0 / total_delta))

        devfreq_text = _read_text("/sys/class/devfreq/fdab0000.npu/load")
        if devfreq_text:
            match = re.search(r"([0-9]+)\s*@\s*([0-9]+)\s*Hz", devfreq_text)
            if match:
                if freq_hz is None:
                    freq_hz = int(match.group(2))
            elif usage_percent is None and runtime_usage_percent is None and not load_text:
                match = re.search(r"([0-9]+)", devfreq_text)
                if match:
                    usage_percent = float(match.group(1))

        if runtime_usage_percent is not None:
            usage_percent = runtime_usage_percent
        elif usage_percent is None and runtime_status == "suspended" and power_state == "off":
            usage_percent = 0.0

        if usage_percent is not None:
            usage_percent = max(0.0, min(100.0, usage_percent))

        return {
            "available": bool(load_text or devfreq_text or freq_hz is not None or power_state),
            "usage_percent": usage_percent,
            "cores": cores,
            "freq_hz": freq_hz,
            "power_state": power_state,
            "runtime_status": runtime_status,
            "runtime_usage_percent": runtime_usage_percent,
            "usage_source": (
                "runtime_active_ratio"
                if runtime_usage_percent is not None
                else "debugfs_core_load"
                if cores
                else "devfreq_load"
                if devfreq_text
                else "unknown"
            ),
        }

    @staticmethod
    def npu_driver_version() -> str:
        for path in ("/sys/kernel/debug/rknpu/version", "/proc/rknpu/version"):
            raw = _read_text(path)
            if not raw:
                continue
            match = re.search(r"v\\d+\\.\\d+\\.\\d+", raw)
            if match:
                return match.group(0)
            line = raw.splitlines()[0].strip()
            if line:
                return line[:64]
        return "unknown"

    @staticmethod
    def uptime_seconds() -> float:
        raw = _read_text("/proc/uptime")
        if not raw:
            return 0.0
        try:
            return float(raw.split()[0])
        except (IndexError, ValueError):
            return 0.0

    @staticmethod
    def loadavg() -> list[float]:
        try:
            load1, load5, load15 = os.getloadavg()
            return [float(load1), float(load5), float(load15)]
        except Exception:
            return [0.0, 0.0, 0.0]


class LocalMemoryStore:
    def __init__(
        self,
        enabled: bool,
        max_items: int,
        max_text: int,
        *,
        persist_enabled: bool,
        persist_path: str,
    ) -> None:
        self.enabled = bool(enabled)
        self.max_items = max(200, int(max_items))
        self.max_text = max(64, int(max_text))
        self._lock = threading.Lock()
        self._seq = 0
        self._items: list[dict[str, Any]] = []
        self._persist_enabled = bool(persist_enabled and self.enabled and str(persist_path or "").strip())
        self._persist_path = Path(str(persist_path).strip()).expanduser() if self._persist_enabled else None
        if self._persist_enabled:
            self._load_from_jsonl()

    def _clean_text(self, text: str) -> str:
        raw = str(text or "").replace("\r", " ").replace("\n", " ").strip()
        if not raw:
            return ""
        return raw[: self.max_text]

    def _storage_name(self) -> str:
        return "jsonl+ram" if self._persist_enabled else "volatile_ram"

    @staticmethod
    def _sanitize_meta(value: Any, depth: int = 0) -> Any:
        if depth >= 5:
            return None
        if value is None:
            return None
        if isinstance(value, (bool, int, float)):
            return value
        if isinstance(value, str):
            return value[:600]
        if isinstance(value, dict):
            out: dict[str, Any] = {}
            for idx, (raw_key, raw_val) in enumerate(value.items()):
                if idx >= 32:
                    break
                key = str(raw_key or "").strip()[:48]
                if not key:
                    continue
                clean = LocalMemoryStore._sanitize_meta(raw_val, depth + 1)
                if clean is None:
                    continue
                out[key] = clean
            return out if out else None
        if isinstance(value, list):
            out_list: list[Any] = []
            for item in value[:32]:
                clean = LocalMemoryStore._sanitize_meta(item, depth + 1)
                if clean is None:
                    continue
                out_list.append(clean)
            return out_list if out_list else None
        return str(value)[:300]

    def _ensure_persist_parent(self) -> tuple[bool, str]:
        if not self._persist_enabled or self._persist_path is None:
            return True, ""
        try:
            self._persist_path.parent.mkdir(parents=True, exist_ok=True)
            return True, ""
        except Exception as exc:
            return False, str(exc)

    def _load_from_jsonl(self) -> None:
        if not self._persist_enabled or self._persist_path is None:
            return
        ok, err = self._ensure_persist_parent()
        if not ok:
            self._persist_enabled = False
            self._persist_path = None
            return
        if not self._persist_path.exists():
            return
        loaded: list[dict[str, Any]] = []
        seq_max = 0
        try:
            with self._persist_path.open("r", encoding="utf-8") as fh:
                for raw_line in fh:
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except Exception:
                        continue
                    row = obj.get("item") if isinstance(obj, dict) and isinstance(obj.get("item"), dict) else obj
                    if not isinstance(row, dict):
                        continue
                    text = self._clean_text(row.get("text"))
                    if not text:
                        continue
                    try:
                        row_id = int(row.get("id"))
                    except Exception:
                        row_id = seq_max + 1
                    seq_max = max(seq_max, row_id)
                    item: dict[str, Any] = {
                        "id": row_id,
                        "timestamp": _safe_text(row.get("timestamp"), limit=40) or _ts_now(),
                        "role": _safe_text(row.get("role"), limit=16) or "user",
                        "source": _safe_text(row.get("source"), limit=24) or "tool",
                        "text": text,
                        "tags": [
                            _safe_text(v, limit=32)
                            for v in (row.get("tags") if isinstance(row.get("tags"), list) else [])
                            if _safe_text(v, limit=32)
                        ][:8],
                    }
                    meta = self._sanitize_meta(row.get("meta"))
                    if meta is not None:
                        item["meta"] = meta
                    loaded.append(item)
        except Exception:
            return
        if len(loaded) > self.max_items:
            loaded = loaded[-self.max_items :]
        with self._lock:
            self._items = loaded
            self._seq = max(seq_max, max((int(row.get("id") or 0) for row in loaded), default=0))

    def _append_jsonl_locked(self, item: dict[str, Any]) -> tuple[bool, str]:
        if not self._persist_enabled or self._persist_path is None:
            return True, ""
        ok, err = self._ensure_persist_parent()
        if not ok:
            return False, err
        try:
            with self._persist_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")
            return True, ""
        except Exception as exc:
            return False, str(exc)

    def _rewrite_jsonl_locked(self) -> tuple[bool, str]:
        if not self._persist_enabled or self._persist_path is None:
            return True, ""
        ok, err = self._ensure_persist_parent()
        if not ok:
            return False, err
        tmp_path = self._persist_path.with_suffix(self._persist_path.suffix + ".tmp")
        try:
            with tmp_path.open("w", encoding="utf-8") as fh:
                for item in self._items:
                    fh.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")
            tmp_path.replace(self._persist_path)
            return True, ""
        except Exception as exc:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass
            return False, str(exc)

    def add(
        self,
        text: str,
        tags: list[Any] | None = None,
        source: str = "tool",
        *,
        role: str = "user",
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if not self.enabled:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "memory disabled",
                "storage": self._storage_name(),
            }
        clean = self._clean_text(text)
        if not clean:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "memory text is empty",
                "storage": self._storage_name(),
            }
        tag_list: list[str] = []
        if isinstance(tags, list):
            for seg in tags[:8]:
                token = _safe_text(seg, limit=32)
                if token:
                    tag_list.append(token)
        role_name = _safe_text(role, limit=16).lower() or "user"
        if role_name not in ("user", "assistant", "system", "tool"):
            role_name = "user"
        clean_meta = self._sanitize_meta(meta)
        persist_err = ""
        with self._lock:
            self._seq += 1
            item = {
                "id": self._seq,
                "timestamp": _ts_now(),
                "role": role_name,
                "source": _safe_text(source, limit=24) or "tool",
                "text": clean,
                "tags": tag_list,
            }
            if clean_meta is not None:
                item["meta"] = clean_meta
            self._items.append(item)
            overflow = max(0, len(self._items) - self.max_items)
            if overflow > 0:
                del self._items[:overflow]
            size = len(self._items)
            if self._persist_enabled:
                if overflow > 0:
                    _ok, persist_err = self._rewrite_jsonl_locked()
                else:
                    _ok, persist_err = self._append_jsonl_locked(item)
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "storage": self._storage_name(),
            "item": item,
            "size": size,
            "persistent": bool(self._persist_enabled),
            "persist_path": str(self._persist_path) if self._persist_path is not None else None,
            "persist_error": persist_err or None,
            "summary": f"memory added ({self._storage_name()})",
        }

    def stats(self) -> dict[str, Any]:
        with self._lock:
            size = len(self._items)
            last = self._items[-1] if self._items else None
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "enabled": bool(self.enabled),
            "storage": self._storage_name(),
            "size": size,
            "max_items": self.max_items,
            "last_item": last,
            "persistent": bool(self._persist_enabled),
            "persist_path": str(self._persist_path) if self._persist_path is not None else None,
            "summary": f"memory size={size}/{self.max_items}",
        }

    def list(self, limit: int) -> list[dict[str, Any]]:
        keep = _clamp_int(limit, default=20, min_value=1, max_value=200)
        with self._lock:
            return list(self._items[-keep:])

    def search(self, query: str, limit: int) -> list[dict[str, Any]]:
        text = _safe_text(query, limit=220).lower()
        keep = _clamp_int(limit, default=12, min_value=1, max_value=200)
        if not text:
            return self.list(keep)
        with self._lock:
            picked = [
                item
                for item in reversed(self._items)
                if text in str(item.get("text", "")).lower()
                or text in json.dumps(item.get("meta", {}), ensure_ascii=False).lower()
            ][:keep]
        picked.reverse()
        return picked

    def clear(self) -> dict[str, Any]:
        with self._lock:
            before = len(self._items)
            self._items = []
            self._seq = 0
            persist_err = ""
            if self._persist_enabled:
                _ok, persist_err = self._rewrite_jsonl_locked()
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "cleared": before,
            "storage": self._storage_name(),
            "persistent": bool(self._persist_enabled),
            "persist_path": str(self._persist_path) if self._persist_path is not None else None,
            "persist_error": persist_err or None,
            "summary": f"memory cleared count={before} ({self._storage_name()})",
        }


class LocalRgbController:
    def __init__(self, backend: str) -> None:
        self.backend = backend if backend in ("sysfs", "virtual", "off") else "sysfs"
        self._lock = threading.Lock()
        self._channels_cache: dict[str, str] | None = None
        self._restore_timer: threading.Timer | None = None
        self._virtual_state = {
            "color": "off",
            "intensity": 0,
            "temporary": False,
            "duration_sec": 0.0,
        }

    @staticmethod
    def _sysfs_write(path: Path, value: str) -> tuple[bool, str]:
        try:
            path.write_text(str(value), encoding="utf-8")
            return True, ""
        except Exception as exc:
            return False, str(exc)

    def _discover_channels(self, refresh: bool = False) -> dict[str, str]:
        if not refresh and isinstance(self._channels_cache, dict):
            return dict(self._channels_cache)
        base = Path("/sys/class/leds")
        mapping: dict[str, str] = {}
        if base.exists():
            for item in sorted(base.iterdir()):
                name = item.name.lower()
                if "red" in name and "red" not in mapping:
                    mapping["red"] = str(item)
                if "green" in name and "green" not in mapping:
                    mapping["green"] = str(item)
                if "blue" in name and "blue" not in mapping:
                    mapping["blue"] = str(item)
        self._channels_cache = dict(mapping)
        return mapping

    @staticmethod
    def _read_channel(path: Path) -> dict[str, Any]:
        bright = _read_int(str(path / "brightness"))
        trig_raw = _read_text(str(path / "trigger"))
        trigger = "unknown"
        if trig_raw:
            match = re.search(r"\[([^\]]+)\]", trig_raw)
            if match:
                trigger = match.group(1).strip()
            else:
                trigger = trig_raw.split()[0]
        return {
            "path": str(path),
            "brightness": int(bright) if bright is not None else 0,
            "trigger": trigger,
        }

    def _apply_snapshot(self, snapshot: dict[str, dict[str, Any]]) -> list[str]:
        errs: list[str] = []
        for _, data in snapshot.items():
            path = Path(str(data.get("path") or ""))
            if not path.exists():
                continue
            trig = str(data.get("trigger") or "none")
            bri = int(data.get("brightness") or 0)
            ok, err = self._sysfs_write(path / "trigger", trig)
            if not ok:
                errs.append(f"{path.name}: trigger restore failed ({err})")
                continue
            ok, err = self._sysfs_write(path / "brightness", str(bri))
            if not ok:
                errs.append(f"{path.name}: brightness restore failed ({err})")
        return errs

    def _schedule_restore(self, snapshot: dict[str, dict[str, Any]], duration_sec: float) -> None:
        def _restore_task() -> None:
            with self._lock:
                self._apply_snapshot(snapshot)
                self._restore_timer = None

        if self._restore_timer is not None:
            try:
                self._restore_timer.cancel()
            except Exception:
                pass
            self._restore_timer = None
        timer = threading.Timer(max(0.1, float(duration_sec)), _restore_task)
        timer.daemon = True
        self._restore_timer = timer
        timer.start()

    def status(self) -> dict[str, Any]:
        if self.backend == "off":
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "storage": "runtime_only",
                "available_channels": [],
                "error": "RGB 后端未启用",
                "summary": "RGB 后端未启用",
            }
        if self.backend == "virtual":
            return {
                "ok": True,
                "timestamp": _ts_now(),
                "storage": "runtime_only",
                "backend": "virtual",
                "state": dict(self._virtual_state),
                "available_channels": ["red", "green", "blue"],
                "missing_channels": [],
                "persistent": False,
                "summary": "虚拟 RGB 后端已启用",
            }

        channels = self._discover_channels()
        data: dict[str, Any] = {}
        for color, led_path in channels.items():
            data[color] = self._read_channel(Path(led_path))
        channel_name_map = {"red": "红", "green": "绿", "blue": "蓝"}
        channel_names_cn = [channel_name_map.get(c, c) for c in sorted(channels.keys())]
        return {
            "ok": len(channels) > 0,
            "timestamp": _ts_now(),
            "storage": "runtime_only",
            "backend": "sysfs",
            "channels": data,
            "available_channels": sorted(channels.keys()),
            "missing_channels": [c for c in ("red", "green", "blue") if c not in channels],
            "persistent": False,
            "summary": (
                f"RGB 通道：{','.join(channel_names_cn)}" if channels else "未发现 RGB 灯通道"
            ),
        }

    def set_color(self, color: str, intensity: int, persist: bool, duration_sec: float) -> dict[str, Any]:
        palette = {
            "off": (0, 0, 0),
            "red": (255, 0, 0),
            "green": (0, 255, 0),
            "blue": (0, 0, 255),
            "yellow": (255, 255, 0),
            "cyan": (0, 255, 255),
            "magenta": (255, 0, 255),
            "white": (255, 255, 255),
        }
        key = _safe_text(color, limit=20).lower() or "off"
        if key not in palette:
            return {"ok": False, "timestamp": _ts_now(), "error": f"不支持的颜色：{key}"}
        level = _clamp_int(intensity, default=255, min_value=0, max_value=255)
        keep_duration = max(1.0, float(duration_sec))

        if self.backend == "off":
            return {"ok": False, "timestamp": _ts_now(), "error": "RGB 后端未启用"}
        if self.backend == "virtual":
            with self._lock:
                self._virtual_state = {
                    "color": key,
                    "intensity": level,
                    "temporary": not persist,
                    "duration_sec": 0.0 if persist else keep_duration,
                }
            payload = self.status()
            payload.update(
                {
                    "requested_color": key,
                    "intensity": level,
                    "temporary": not persist,
                    "duration_sec": 0.0 if persist else keep_duration,
                    "summary": (
                        f"set rgb color={key} intensity={level}"
                        + (f", auto-restore in {keep_duration:.1f}s" if not persist else ", keep state")
                    ),
                }
            )
            return payload

        channels = self._discover_channels(refresh=True)
        if not channels:
            return {"ok": False, "timestamp": _ts_now(), "error": "rgb led channels not found"}
        target_rgb = palette[key]
        snapshot: dict[str, dict[str, Any]] = {}
        apply_errs: list[str] = []
        with self._lock:
            for color_name, led_path in channels.items():
                path = Path(led_path)
                prev = self._read_channel(path)
                snapshot[color_name] = prev
                chan_value = 0
                if color_name == "red":
                    chan_value = int(level * target_rgb[0] / 255)
                elif color_name == "green":
                    chan_value = int(level * target_rgb[1] / 255)
                elif color_name == "blue":
                    chan_value = int(level * target_rgb[2] / 255)
                ok, err = self._sysfs_write(path / "trigger", "none")
                if not ok:
                    apply_errs.append(f"{path.name}: trigger set failed ({err})")
                    continue
                ok, err = self._sysfs_write(path / "brightness", str(chan_value))
                if not ok:
                    apply_errs.append(f"{path.name}: brightness set failed ({err})")
            if not persist and not apply_errs:
                self._schedule_restore(snapshot, duration_sec=keep_duration)
            elif persist and self._restore_timer is not None:
                try:
                    self._restore_timer.cancel()
                except Exception:
                    pass
                self._restore_timer = None
        status = self.status()
        status.update(
            {
                "ok": len(apply_errs) == 0,
                "requested_color": key,
                "intensity": level,
                "temporary": not persist,
                "duration_sec": 0.0 if persist else keep_duration,
                "persistent": False,
                "apply_errors": apply_errs,
                "summary": (
                    f"set rgb color={key} intensity={level}"
                    + (f", auto-restore in {keep_duration:.1f}s" if not persist else ", keep state")
                ),
            }
        )
        return status


class VisionToolAdapter:
    def __init__(self, client: JsonHttpClient, timeout_short_sec: float, timeout_long_sec: float) -> None:
        self.client = client
        self.timeout_short_sec = max(1.0, float(timeout_short_sec))
        self.timeout_long_sec = max(1.0, float(timeout_long_sec))

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        timeout_sec: float | None = None,
    ) -> dict[str, Any]:
        status, body, err = self.client.request_json(
            method=method,
            path=path,
            payload=payload,
            timeout_sec=float(timeout_sec if timeout_sec is not None else self.timeout_short_sec),
        )
        if status <= 0:
            return {"ok": False, "timestamp": _ts_now(), "error": f"vision service unreachable: {err or 'connection failed'}"}
        if not isinstance(body, dict):
            detail = err or f"status={status}"
            return {"ok": False, "timestamp": _ts_now(), "error": f"invalid vision response: {detail}"}
        output = dict(body)
        output.setdefault("timestamp", _ts_now())
        if status < 200 or status >= 300:
            output["ok"] = False
            if not output.get("error"):
                output["error"] = f"vision status={status}"
        return output

    def _get(self, path: str, params: dict[str, Any] | None = None, timeout_sec: float | None = None) -> dict[str, Any]:
        route = path
        if isinstance(params, dict) and params:
            query = urlencode(params, doseq=True)
            route = f"{path}?{query}"
        return self._request("GET", route, timeout_sec=timeout_sec)

    def _post(self, path: str, payload: dict[str, Any] | None = None, timeout_sec: float | None = None) -> dict[str, Any]:
        return self._request("POST", path, payload=payload or {}, timeout_sec=timeout_sec)

    def profile_status(self) -> dict[str, Any]:
        return self._get("/api/vision/profile", timeout_sec=self.timeout_short_sec)

    def observe(self, detector: str, capability_flags: dict[str, bool] | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"detector": detector or "none"}
        if isinstance(capability_flags, dict):
            for raw_key, raw_value in capability_flags.items():
                key = _safe_text(raw_key, limit=64).lower()
                if not re.fullmatch(r"[a-z0-9_]{1,48}", key or ""):
                    continue
                enabled = _coerce_enabled(raw_value)
                if enabled is None:
                    continue
                params[key] = 1 if enabled else 0
        return self._get("/api/vision/observe", params=params, timeout_sec=self.timeout_long_sec)

    def set_profile(self, name: str) -> dict[str, Any]:
        return self._get(
            "/api/vision/profile/set",
            params={"name": name},
            timeout_sec=self.timeout_short_sec,
        )

    def set_enabled(self, enabled: bool, reason: str) -> dict[str, Any]:
        return self._get(
            "/api/vision/enabled/set",
            params={"enabled": 1 if enabled else 0, "reason": reason or "agent"},
            timeout_sec=self.timeout_short_sec,
        )

    def set_stream_enabled(self, enabled: bool, reason: str) -> dict[str, Any]:
        return self._get(
            "/api/vision/stream/set",
            params={"enabled": 1 if enabled else 0, "reason": reason or "agent"},
            timeout_sec=self.timeout_short_sec,
        )

    def recover(self, reason: str) -> dict[str, Any]:
        return self._get(
            "/api/vision/recover",
            params={"reason": reason or "agent"},
            timeout_sec=self.timeout_long_sec,
        )

    def gimbal_status(self) -> dict[str, Any]:
        return self._get("/api/vision/gimbal/status", timeout_sec=self.timeout_short_sec)

    def gimbal_command(
        self,
        *,
        yaw_rpm: float,
        pitch_rpm: float,
        laser_enabled: int | None,
        enabled: int | None,
        stability_enabled: int | None,
        auto_stop_ms: int,
        reason: str,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "yaw_rpm": f"{float(yaw_rpm):.3f}",
            "pitch_rpm": f"{float(pitch_rpm):.3f}",
            "auto_stop_ms": int(max(0, min(5000, auto_stop_ms))),
            "reason": reason or "agent",
        }
        if laser_enabled in (0, 1, 2):
            params["laser_enabled"] = int(laser_enabled)
        if enabled in (0, 1, 2):
            params["enabled"] = int(enabled)
        if stability_enabled in (0, 1, 2):
            params["stability_enabled"] = int(stability_enabled)
        return self._get("/api/vision/gimbal/command", params=params, timeout_sec=self.timeout_short_sec)

    def gimbal_laser_blink(
        self,
        *,
        blinks: int,
        period_ms: int | None,
        laser_on_ms: int | None,
        laser_off_ms: int | None,
        reason: str,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "blinks": int(max(1, min(12, int(blinks)))),
            "reason": reason or "agent",
        }
        if period_ms is not None:
            params["period_ms"] = int(max(80, min(2000, int(period_ms))))
        if laser_on_ms is not None:
            params["laser_on_ms"] = int(max(40, min(2000, int(laser_on_ms))))
        if laser_off_ms is not None:
            params["laser_off_ms"] = int(max(40, min(2000, int(laser_off_ms))))
        return self._get("/api/vision/gimbal/laser/blink", params=params, timeout_sec=self.timeout_long_sec)

    def gimbal_lock_status(self) -> dict[str, Any]:
        return self._get("/api/vision/gimbal/lock/status", timeout_sec=self.timeout_short_sec)

    def gimbal_lock_start(
        self,
        *,
        target: str,
        detector: str,
        timeout_sec: float,
        continuous: bool | None,
        center_tolerance_px: float,
        stable_frames: int,
        min_score: float,
        max_rpm: float,
        kp_yaw: float,
        kp_pitch: float,
        invert_yaw: bool | None,
        invert_pitch: bool | None,
        search_sweep_rpm: float,
        search_sweep_pulse_ms: int,
        search_spin_deg: float,
        search_spin_clockwise: bool | None,
        laser_blinks: int,
        laser_on_ms: int,
        laser_off_ms: int,
        wear_glasses: bool | None,
        emotion: bool | None,
        reason: str,
    ) -> dict[str, Any]:
        detector_name = _safe_text(detector, limit=24) or "auto"
        if detector_name in ("none", "rect"):
            detector_name = "auto"
        if detector_name not in ("auto", "face", "yolo", "yolo_world"):
            detector_name = "auto"
        params: dict[str, Any] = {
            "target": _safe_text(target, limit=120),
            "detector": detector_name,
            "timeout_sec": f"{max(1.0, min(AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC, float(timeout_sec))):.2f}",
            "center_tolerance_px": f"{max(2.0, min(320.0, float(center_tolerance_px))):.2f}",
            "stable_frames": int(max(1, min(60, int(stable_frames)))),
            "min_score": f"{max(0.01, min(0.99, float(min_score))):.3f}",
            "max_rpm": f"{max(1.0, min(50.0, float(max_rpm))):.3f}",
            "kp_yaw": f"{max(0.001, min(1.0, float(kp_yaw))):.4f}",
            "kp_pitch": f"{max(0.001, min(1.0, float(kp_pitch))):.4f}",
            "search_sweep_rpm": f"{max(0.0, min(40.0, float(search_sweep_rpm))):.3f}",
            "search_sweep_pulse_ms": int(max(0, min(1200, int(search_sweep_pulse_ms)))),
            "search_spin_deg": f"{max(30.0, min(2160.0, float(search_spin_deg))):.1f}",
            "laser_blinks": int(max(0, min(12, int(laser_blinks)))),
            "laser_on_ms": int(max(40, min(1000, int(laser_on_ms)))),
            "laser_off_ms": int(max(40, min(1000, int(laser_off_ms)))),
            "reason": reason or "agent",
        }
        if continuous is not None:
            params["continuous"] = 1 if bool(continuous) else 0
        if invert_yaw is not None:
            params["invert_yaw"] = 1 if bool(invert_yaw) else 0
        if invert_pitch is not None:
            params["invert_pitch"] = 1 if bool(invert_pitch) else 0
        if search_spin_clockwise is not None:
            params["search_spin_clockwise"] = 1 if bool(search_spin_clockwise) else 0
        if wear_glasses is not None:
            params["wear_glasses"] = 1 if bool(wear_glasses) else 0
        if emotion is not None:
            params["emotion"] = 1 if bool(emotion) else 0
        return self._get("/api/vision/gimbal/lock/start", params=params, timeout_sec=self.timeout_long_sec)

    def gimbal_lock_stop(self, *, wait: bool, reason: str) -> dict[str, Any]:
        params: dict[str, Any] = {"wait": 1 if wait else 0, "reason": reason or "agent"}
        return self._get("/api/vision/gimbal/lock/stop", params=params, timeout_sec=self.timeout_short_sec)

    def yolo_world_filter_status(self) -> dict[str, Any]:
        return self._get("/api/vision/yolo_world/filter", timeout_sec=self.timeout_short_sec)

    def yolo_world_vocab_status(self) -> dict[str, Any]:
        return self._get("/api/vision/yolo_world/vocab", timeout_sec=self.timeout_short_sec)

    def set_yolo_world_filter(self, labels: str, reason: str, mode: str = "") -> dict[str, Any]:
        params: dict[str, Any] = {"reason": reason or "agent"}
        if labels:
            params["labels"] = labels
        if mode:
            params["mode"] = mode
        return self._get("/api/vision/yolo_world/filter/set", params=params, timeout_sec=self.timeout_short_sec)

    def yolo_world_prompt_status(self) -> dict[str, Any]:
        return self._get("/api/vision/yolo_world/prompt", timeout_sec=self.timeout_short_sec)

    def set_yolo_world_prompt(
        self,
        *,
        prompt: str,
        include_terms: list[str],
        exclude_terms: list[str],
        reason: str,
        strict: bool | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"reason": reason or "agent"}
        if prompt:
            params["prompt"] = prompt
        if include_terms:
            params["include"] = include_terms
        if exclude_terms:
            params["exclude"] = exclude_terms
        if strict is not None:
            params["strict"] = 1 if strict else 0
        return self._get("/api/vision/yolo_world/prompt/set", params=params, timeout_sec=self.timeout_short_sec)

    def sensors_status(self) -> dict[str, Any]:
        return self._get("/api/vision/sensors", timeout_sec=self.timeout_short_sec)

    def set_sensor_thresholds(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("/api/vision/sensors/thresholds", payload, timeout_sec=self.timeout_short_sec)

    def set_sensor_sample(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("/api/vision/sensors/sample", payload, timeout_sec=self.timeout_short_sec)

    def health(self, timeout_sec: float = 2.0) -> dict[str, Any]:
        result = self._get("/health", timeout_sec=timeout_sec)
        return {
            "up": bool(result.get("ok", False)),
            "detail": _safe_text(result.get("error") or "ok", limit=180),
            "status": 200 if result.get("ok", False) else 503,
            "probe": "/health",
        }


class ActionExecutor:
    _PARALLEL_READ_TOOL_ALLOWLIST = frozenset(
        {
            "system.time",
            "system.cpu",
            "system.mem",
            "system.npu",
            "system.thermal",
            "vision.sensors.get",
            "memory.list",
            "memory.search",
            "memory.stats",
            "rgb.status",
            "vision.enabled.get",
            "vision.profile.get",
            "vision.gimbal.status",
            "vision.gimbal.lock.status",
            "vision.yolo_world.filter.get",
            "vision.yolo_world.prompt.get",
        }
    )
    _DAG_GROUP_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,39}$")

    def __init__(
        self,
        runtime_mode: str,
        vision_adapter: VisionToolAdapter,
        sampler: LocalMetricSampler,
        memory_store: LocalMemoryStore,
        rgb_controller: LocalRgbController,
        timeout_short_sec: float,
        timeout_long_sec: float,
        exec_read_parallelism: int,
    ) -> None:
        _ = runtime_mode
        self.runtime_mode = "local"
        self.vision_adapter = vision_adapter
        self.sampler = sampler
        self.memory_store = memory_store
        self.rgb_controller = rgb_controller
        self.timeout_short_sec = max(1.0, float(timeout_short_sec))
        self.timeout_long_sec = max(1.0, float(timeout_long_sec))
        self.exec_read_parallelism = _clamp_int(
            exec_read_parallelism,
            default=4,
            min_value=1,
            max_value=16,
        )
        self.local_handlers: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
            "system.time": self._tool_system_time,
            "system.cpu": self._tool_system_cpu,
            "system.mem": self._tool_system_mem,
            "system.npu": self._tool_system_npu,
            "system.thermal": self._tool_system_thermal,
            "memory.add": self._tool_memory_add,
            "memory.list": self._tool_memory_list,
            "memory.search": self._tool_memory_search,
            "memory.clear": self._tool_memory_clear,
            "memory.stats": self._tool_memory_stats,
            "rgb.status": self._tool_rgb_status,
            "rgb.set": self._tool_rgb_set,
            "vision.observe": self._tool_vision_observe,
            "vision.sensors.get": self._tool_vision_sensors_get,
            "vision.sensors.thresholds.set": self._tool_vision_sensors_thresholds_set,
            "vision.sensors.sample.set": self._tool_vision_sensors_sample_set,
            "vision.enabled.get": self._tool_vision_enabled_get,
            "vision.profile.get": self._tool_vision_profile_get,
            "vision.enabled.set": self._tool_vision_enabled_set,
            "vision.profile.set": self._tool_vision_profile_set,
            "vision.stream.set": self._tool_vision_stream_set,
            "vision.recover": self._tool_vision_recover,
            "vision.gimbal.status": self._tool_vision_gimbal_status,
            "vision.gimbal.command": self._tool_vision_gimbal_command,
            "vision.gimbal.laser.blink": self._tool_vision_gimbal_laser_blink,
            "vision.gimbal.lock.status": self._tool_vision_gimbal_lock_status,
            "vision.gimbal.lock.start": self._tool_vision_gimbal_lock_start,
            "vision.gimbal.lock.stop": self._tool_vision_gimbal_lock_stop,
            "vision.yolo_world.filter.get": self._tool_vision_yolo_world_filter_get,
            "vision.yolo_world.filter.set": self._tool_vision_yolo_world_filter_set,
            "vision.yolo_world.prompt.get": self._tool_vision_yolo_world_prompt_get,
            "vision.yolo_world.prompt.set": self._tool_vision_yolo_world_prompt_set,
        }

    def run_tool(
        self,
        tool: str,
        args: dict[str, Any],
        timeout_sec: float | None = None,
    ) -> dict[str, Any]:
        timeout = float(timeout_sec if timeout_sec is not None else self.timeout_short_sec)
        name = _safe_text(tool, limit=80)
        payload = args if isinstance(args, dict) else {}
        local_handler = self.local_handlers.get(name)
        if local_handler is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"unsupported tool: {name}",
            }
        return local_handler(payload)

    def _tool_system_time(self, args: dict[str, Any]) -> dict[str, Any]:
        now = _local_now()
        weekday_cn = ("星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日")[now.weekday()]
        part = _safe_text((args or {}).get("part"), limit=24).lower()
        if part not in ("datetime", "date", "time", "weekday", "date_weekday"):
            part = "datetime"
        tz_name = _preferred_tz_name() or str(now.tzname() or "").strip()
        offset = now.utcoffset()
        utc_offset = ""
        if offset is not None:
            total_minutes = int(offset.total_seconds() // 60)
            sign = "+" if total_minutes >= 0 else "-"
            total_minutes = abs(total_minutes)
            utc_offset = f"{sign}{total_minutes // 60:02d}:{total_minutes % 60:02d}"
        summary_cn = ""
        if part == "weekday":
            summary_cn = f"今天是{weekday_cn}。"
        elif part == "date":
            summary_cn = f"今天日期：{now.strftime('%Y-%m-%d')}。"
        elif part == "date_weekday":
            summary_cn = f"今天日期：{now.strftime('%Y-%m-%d')}，{weekday_cn}。"
        elif part == "time":
            summary_cn = f"当前时间：{now.strftime('%H:%M:%S')}。"
        else:
            summary_cn = f"当前本地时间：{now.strftime('%Y-%m-%d %H:%M:%S')}（{weekday_cn}）。"
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "iso": now.isoformat(timespec="seconds"),
            "epoch_ms": int(time.time() * 1000),
            "local": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "weekday_cn": weekday_cn,
            "weekday_en": now.strftime("%A"),
            "weekday_index": int(now.weekday() + 1),
            "part": part,
            "timezone": tz_name,
            "utc_offset": utc_offset,
            "summary_cn": summary_cn,
            "summary": f"local time {now.strftime('%Y-%m-%d %H:%M:%S')} ({weekday_cn})",
        }

    def _tool_system_cpu(self, _args: dict[str, Any]) -> dict[str, Any]:
        usage = self.sampler.cpu_usage_percent()
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "cpu": {"usage_percent": usage, "load": self.sampler.loadavg()},
            "uptime_seconds": self.sampler.uptime_seconds(),
            "summary": f"cpu usage {usage:.2f}%",
        }

    def _tool_system_mem(self, _args: dict[str, Any]) -> dict[str, Any]:
        mem = self.sampler.memory_info()
        usage = float(mem.get("used_percent", 0.0))
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "memory": mem,
            "summary": f"memory usage {usage:.2f}%",
        }

    def _tool_system_npu(self, _args: dict[str, Any]) -> dict[str, Any]:
        npu = self.sampler.npu_info()
        usage = npu.get("usage_percent")
        usage_label = "unknown"
        try:
            usage_label = f"{float(usage):.2f}%"
        except (TypeError, ValueError):
            pass
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "npu_driver_version": self.sampler.npu_driver_version(),
            "npu": npu,
            "summary": f"npu usage {usage_label}",
        }

    def _tool_system_thermal(self, _args: dict[str, Any]) -> dict[str, Any]:
        thermal, max_temp = self.sampler.thermal_info()
        max_label = "unknown"
        try:
            max_label = f"{float(max_temp):.2f}C"
        except (TypeError, ValueError):
            pass
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "max_temp_c": max_temp,
            "thermal": thermal,
            "summary": f"max temperature {max_label}",
        }

    def _tool_vision_sensors_get(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.sensors_status()
        if "metrics" in result and "error" not in result:
            result["ok"] = True
        result.setdefault("summary", str(result.get("summary") or "sensor status fetched"))
        return result

    def _tool_vision_sensors_thresholds_set(self, args: dict[str, Any]) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if "temperature_min" in args or "temperature_max" in args:
            payload["temperature"] = {
                "min": args.get("temperature_min"),
                "max": args.get("temperature_max"),
            }
        if "ph_min" in args or "ph_max" in args:
            payload["ph"] = {
                "min": args.get("ph_min"),
                "max": args.get("ph_max"),
            }
        if "turbidity_min" in args or "turbidity_max" in args:
            payload["turbidity"] = {
                "min": args.get("turbidity_min"),
                "max": args.get("turbidity_max"),
            }
        if not payload:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "at least one threshold field is required",
            }
        result = self.vision_adapter.set_sensor_thresholds(payload)
        result.setdefault("summary", str(result.get("summary") or "sensor thresholds updated"))
        return result

    def _tool_vision_sensors_sample_set(self, args: dict[str, Any]) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if "temperature" in args:
            payload["temperature"] = args.get("temperature")
        if "ph" in args:
            payload["ph"] = args.get("ph")
        if "turbidity" in args:
            payload["turbidity"] = args.get("turbidity")
        source = _safe_text(args.get("source"), limit=80)
        if source:
            payload["source"] = source
        if not payload:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "at least one sample field is required",
            }
        result = self.vision_adapter.set_sensor_sample(payload)
        result.setdefault("summary", str(result.get("summary") or "sensor sample updated"))
        return result

    def _tool_memory_add(self, args: dict[str, Any]) -> dict[str, Any]:
        text = _safe_text(args.get("text") or args.get("content"), limit=4000)
        tags = args.get("tags") if isinstance(args.get("tags"), list) else []
        return self.memory_store.add(text=text, tags=tags, source="tool")

    def _tool_memory_list(self, args: dict[str, Any]) -> dict[str, Any]:
        limit = _clamp_int(args.get("limit", 20), default=20, min_value=1, max_value=200)
        items = self.memory_store.list(limit=limit)
        stats = self.memory_store.stats()
        storage = _safe_text(stats.get("storage"), limit=24) or "volatile_ram"
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "storage": storage,
            "items": items,
            "summary": f"memory list size={len(items)}",
        }

    def _tool_memory_search(self, args: dict[str, Any]) -> dict[str, Any]:
        query = _safe_text(args.get("query"), limit=220)
        limit = _clamp_int(args.get("limit", 12), default=12, min_value=1, max_value=200)
        items = self.memory_store.search(query=query, limit=limit)
        stats = self.memory_store.stats()
        storage = _safe_text(stats.get("storage"), limit=24) or "volatile_ram"
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "storage": storage,
            "query": query,
            "items": items,
            "summary": f"memory search hits={len(items)}",
        }

    def _tool_memory_clear(self, _args: dict[str, Any]) -> dict[str, Any]:
        return self.memory_store.clear()

    def _tool_memory_stats(self, _args: dict[str, Any]) -> dict[str, Any]:
        return self.memory_store.stats()

    def _tool_rgb_status(self, _args: dict[str, Any]) -> dict[str, Any]:
        return self.rgb_controller.status()

    def _tool_rgb_set(self, args: dict[str, Any]) -> dict[str, Any]:
        color = _safe_text(args.get("color"), limit=16) or "off"
        intensity = _clamp_int(args.get("intensity", 255), default=255, min_value=1, max_value=255)
        persist_flag = _coerce_enabled(args.get("persist"))
        persist = bool(persist_flag) if persist_flag is not None else False
        try:
            duration_sec = float(args.get("duration_sec", 5.0))
        except (TypeError, ValueError):
            duration_sec = 5.0
        duration_sec = max(1.0, duration_sec)
        return self.rgb_controller.set_color(color=color, intensity=intensity, persist=persist, duration_sec=duration_sec)

    def _tool_vision_observe(self, args: dict[str, Any]) -> dict[str, Any]:
        detector, _ = _normalize_detector(args.get("detector", "none"), default="none")
        capability_flags: dict[str, bool] = {}
        for name in _camera_capability_names():
            if name not in args:
                continue
            flag = _coerce_enabled(args.get(name))
            if flag is None:
                continue
            capability_flags[name] = bool(flag)
        result = self.vision_adapter.observe(detector=detector or "none", capability_flags=capability_flags)
        result["detector"] = detector or "none"
        capability_errors: list[str] = []
        for name in capability_flags.keys():
            payload = result.get(name)
            if not isinstance(payload, dict):
                continue
            if bool(payload.get("ok", False)):
                continue
            err = _safe_text(payload.get("error"), limit=120)
            if err:
                capability_errors.append(f"{name}: {err}")
        if bool(result.get("ok", False)) and "summary" not in result:
            result["summary"] = f"vision observe done ({detector or 'none'})"
        if capability_errors:
            base_summary = _safe_text(result.get("summary"), limit=220) or f"vision observe done ({detector or 'none'})"
            result["summary"] = f"{base_summary}; {'; '.join(capability_errors[:2])}"
        return result

    def _tool_vision_enabled_get(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.profile_status()
        # Profile endpoint may return ok=false when vision runtime is disabled;
        # status queries should still be considered successful if payload is readable.
        if "enabled" in result and "error" not in result:
            result["ok"] = True
        enabled = bool(result.get("enabled", False))
        result["summary"] = "vision enabled" if enabled else "vision disabled"
        return result

    def _tool_vision_profile_get(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.profile_status()
        if "current" in result and "error" not in result:
            result["ok"] = True
        current = _safe_text(result.get("current"), limit=40) or "unknown"
        result["summary"] = f"current profile {current}"
        return result

    def _tool_vision_enabled_set(self, args: dict[str, Any]) -> dict[str, Any]:
        enabled = _coerce_enabled(args.get("enabled"))
        if enabled is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "enabled must be bool-like (true/false/1/0)",
            }
        reason = _safe_text(args.get("reason"), limit=80) or "tool"
        result = self.vision_adapter.set_enabled(enabled=enabled, reason=reason)
        result.setdefault("summary", str(result.get("message") or "vision enabled state updated"))
        return result

    def _tool_vision_profile_set(self, args: dict[str, Any]) -> dict[str, Any]:
        profile_name = _safe_text(args.get("name") or args.get("profile"), limit=32).lower()
        if not profile_name:
            return {"ok": False, "timestamp": _ts_now(), "error": "profile name required"}
        result = self.vision_adapter.set_profile(profile_name)
        result.setdefault("summary", str(result.get("message") or f"profile set {profile_name}"))
        return result

    def _tool_vision_stream_set(self, args: dict[str, Any]) -> dict[str, Any]:
        enabled = _coerce_enabled(args.get("enabled"))
        if enabled is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "enabled must be bool-like (true/false/1/0)",
            }
        reason = _safe_text(args.get("reason"), limit=80) or "tool"
        result = self.vision_adapter.set_stream_enabled(enabled=enabled, reason=reason)
        result.setdefault("summary", str(result.get("message") or "stream updated"))
        return result

    def _tool_vision_recover(self, args: dict[str, Any]) -> dict[str, Any]:
        reason = _safe_text(args.get("reason"), limit=80) or "tool"
        result = self.vision_adapter.recover(reason=reason)
        result.setdefault("summary", str(result.get("message") or result.get("error") or "recover executed"))
        return result

    def _tool_vision_gimbal_status(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.gimbal_status()
        if "connected" in result and "error" not in result:
            result["ok"] = True
        result.setdefault("summary", str(result.get("summary") or "gimbal status fetched"))
        return result

    def _tool_vision_gimbal_command(self, args: dict[str, Any]) -> dict[str, Any]:
        try:
            yaw_rpm = float(args.get("yaw_rpm", args.get("yaw", 0.0)))
        except (TypeError, ValueError):
            return {"ok": False, "timestamp": _ts_now(), "error": "yaw_rpm must be number"}
        try:
            pitch_rpm = float(args.get("pitch_rpm", args.get("pitch", 0.0)))
        except (TypeError, ValueError):
            return {"ok": False, "timestamp": _ts_now(), "error": "pitch_rpm must be number"}

        mode = _safe_text(args.get("mode"), limit=16).lower()
        if mode in ("stop", "halt", "idle"):
            yaw_rpm = 0.0
            pitch_rpm = 0.0
        yaw_rpm = max(-120.0, min(120.0, float(yaw_rpm)))
        pitch_rpm = max(-120.0, min(120.0, float(pitch_rpm)))

        laser_enabled = _coerce_action_flag(args.get("laser_enabled", args.get("laser")))
        enabled = _coerce_action_flag(args.get("enabled"))
        stability_enabled = _coerce_action_flag(args.get("stability_enabled", args.get("stability")))

        auto_stop_ms = _clamp_int(
            args.get("auto_stop_ms", 220),
            default=220,
            min_value=0,
            max_value=5000,
        )
        reason = _safe_text(args.get("reason"), limit=80) or "tool"

        result = self.vision_adapter.gimbal_command(
            yaw_rpm=yaw_rpm,
            pitch_rpm=pitch_rpm,
            laser_enabled=laser_enabled,
            enabled=enabled,
            stability_enabled=stability_enabled,
            auto_stop_ms=auto_stop_ms,
            reason=reason,
        )
        result.setdefault(
            "summary",
            str(
                result.get("message")
                or result.get("summary")
                or result.get("error")
                or f"gimbal command yaw={yaw_rpm:.2f} pitch={pitch_rpm:.2f}"
            ),
        )
        return result

    def _tool_vision_gimbal_laser_blink(self, args: dict[str, Any]) -> dict[str, Any]:
        blinks = _clamp_int(args.get("blinks", args.get("count", 6)), default=6, min_value=1, max_value=12)

        def _opt_int(value: Any) -> int | None:
            if value is None:
                return None
            text = str(value).strip()
            if not text:
                return None
            try:
                return int(float(text))
            except (TypeError, ValueError):
                return None

        period_input = args.get("period_ms", args.get("period"))
        on_input = args.get("laser_on_ms", args.get("on_ms"))
        off_input = args.get("laser_off_ms", args.get("off_ms"))
        period_ms = _opt_int(period_input)
        laser_on_ms = _opt_int(on_input)
        laser_off_ms = _opt_int(off_input)
        if period_input is not None and str(period_input).strip() and period_ms is None:
            return {"ok": False, "timestamp": _ts_now(), "error": "period_ms must be numeric"}
        if on_input is not None and str(on_input).strip() and laser_on_ms is None:
            return {"ok": False, "timestamp": _ts_now(), "error": "laser_on_ms must be numeric"}
        if off_input is not None and str(off_input).strip() and laser_off_ms is None:
            return {"ok": False, "timestamp": _ts_now(), "error": "laser_off_ms must be numeric"}

        reason = _safe_text(args.get("reason"), limit=80) or "tool"
        result = self.vision_adapter.gimbal_laser_blink(
            blinks=blinks,
            period_ms=period_ms,
            laser_on_ms=laser_on_ms,
            laser_off_ms=laser_off_ms,
            reason=reason,
        )
        result.setdefault(
            "summary",
            str(
                result.get("message")
                or result.get("summary")
                or result.get("error")
                or f"laser blink request ({blinks} times)"
            ),
        )
        return result

    def _tool_vision_gimbal_lock_status(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.gimbal_lock_status()
        if "active" in result and "error" not in result:
            result["ok"] = True
        active = bool(result.get("active", False))
        status = _safe_text(result.get("status"), limit=40).lower() or ("running" if active else "idle")
        target = _safe_text(result.get("target_raw"), limit=80)
        if active:
            label = f" target={target}" if target else ""
            result.setdefault("summary", f"gimbal lock active ({status}){label}")
        else:
            suffix = ""
            if status and status not in ("idle", "ready"):
                suffix = f" (last={status})"
            result.setdefault("summary", f"gimbal lock idle{suffix}")
        return result

    def _tool_vision_gimbal_lock_start(self, args: dict[str, Any]) -> dict[str, Any]:
        target = _safe_text(
            args.get("target")
            or args.get("label")
            or args.get("class_name")
            or args.get("class")
            or args.get("object")
            or args.get("name"),
            limit=120,
        )
        target, target_human = IntentRegistry._normalize_gimbal_lock_target(target)
        detector, det_err = _normalize_gimbal_lock_detector(args.get("detector"), default="auto")
        if detector is None:
            return {"ok": False, "timestamp": _ts_now(), "error": det_err}

        def _float_value(name: str, default: float) -> float:
            raw = args.get(name)
            if raw is None or not str(raw).strip():
                return float(default)
            try:
                return float(raw)
            except (TypeError, ValueError):
                raise ValueError(name)

        def _int_value(name: str, default: int) -> int:
            raw = args.get(name)
            if raw is None or not str(raw).strip():
                return int(default)
            try:
                return int(raw)
            except (TypeError, ValueError):
                raise ValueError(name)

        try:
            timeout_sec = _float_value("timeout_sec", 12.0)
            center_tolerance_px = _float_value("center_tolerance_px", 26.0)
            stable_frames = _int_value("stable_frames", 10)
            min_score = _float_value("min_score", 0.35)
            max_rpm = _float_value("max_rpm", 18.0)
            kp_yaw = _float_value("kp_yaw", 0.035)
            kp_pitch = _float_value("kp_pitch", 0.035)
            search_sweep_rpm = _float_value("search_sweep_rpm", 7.0)
            search_sweep_pulse_ms = _int_value("search_sweep_pulse_ms", 180)
            search_spin_deg = _float_value("search_spin_deg", 360.0)
            laser_blinks = _int_value("laser_blinks", 3)
            laser_on_ms = _int_value("laser_on_ms", 150)
            laser_off_ms = _int_value("laser_off_ms", 150)
        except ValueError as exc:
            return {"ok": False, "timestamp": _ts_now(), "error": f"{str(exc)} must be numeric"}

        invert_yaw_raw = args.get("invert_yaw")
        invert_pitch_raw = args.get("invert_pitch")
        invert_yaw = _coerce_enabled(invert_yaw_raw) if invert_yaw_raw is not None and str(invert_yaw_raw).strip() else None
        invert_pitch = (
            _coerce_enabled(invert_pitch_raw)
            if invert_pitch_raw is not None and str(invert_pitch_raw).strip()
            else None
        )
        if invert_yaw_raw is not None and str(invert_yaw_raw).strip() and invert_yaw is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "invert_yaw must be one of: 1/0 true/false on/off",
            }
        if invert_pitch_raw is not None and str(invert_pitch_raw).strip() and invert_pitch is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "invert_pitch must be one of: 1/0 true/false on/off",
            }
        continuous_raw = args.get("continuous")
        continuous = (
            _coerce_enabled(continuous_raw)
            if continuous_raw is not None and str(continuous_raw).strip()
            else None
        )
        if continuous_raw is not None and str(continuous_raw).strip() and continuous is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "continuous must be one of: 1/0 true/false on/off",
            }
        search_spin_clockwise_raw = args.get("search_spin_clockwise")
        search_spin_clockwise = (
            _coerce_enabled(search_spin_clockwise_raw)
            if search_spin_clockwise_raw is not None and str(search_spin_clockwise_raw).strip()
            else None
        )
        if (
            search_spin_clockwise_raw is not None
            and str(search_spin_clockwise_raw).strip()
            and search_spin_clockwise is None
        ):
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "search_spin_clockwise must be one of: 1/0 true/false on/off",
            }

        wear_raw = args.get("wear_glasses")
        emotion_raw = args.get("emotion")
        detail_note_hint = _safe_text(args.get("observe_detail_note"), limit=180)
        wear_glasses = _coerce_enabled(wear_raw) if wear_raw is not None and str(wear_raw).strip() else None
        emotion = _coerce_enabled(emotion_raw) if emotion_raw is not None and str(emotion_raw).strip() else None
        if wear_raw is not None and str(wear_raw).strip() and wear_glasses is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "wear_glasses must be one of: 1/0 true/false on/off",
            }
        if emotion_raw is not None and str(emotion_raw).strip() and emotion is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "emotion must be one of: 1/0 true/false on/off",
            }
        detail_requested = (
            (wear_raw is not None and str(wear_raw).strip() != "")
            or (emotion_raw is not None and str(emotion_raw).strip() != "")
            or bool(detail_note_hint)
        )
        if not target_human:
            wear_glasses = None
            emotion = None

        reason = _safe_text(args.get("reason"), limit=80) or "tool"
        result = self.vision_adapter.gimbal_lock_start(
            target=target,
            detector=detector,
            timeout_sec=timeout_sec,
            continuous=continuous,
            center_tolerance_px=center_tolerance_px,
            stable_frames=stable_frames,
            min_score=min_score,
            max_rpm=max_rpm,
            kp_yaw=kp_yaw,
            kp_pitch=kp_pitch,
            invert_yaw=invert_yaw,
            invert_pitch=invert_pitch,
            search_sweep_rpm=search_sweep_rpm,
            search_sweep_pulse_ms=search_sweep_pulse_ms,
            search_spin_deg=search_spin_deg,
            search_spin_clockwise=search_spin_clockwise,
            laser_blinks=laser_blinks,
            laser_on_ms=laser_on_ms,
            laser_off_ms=laser_off_ms,
            wear_glasses=wear_glasses,
            emotion=emotion,
            reason=reason,
        )
        if detail_requested and (not target_human):
            result["observe_detail_requested"] = True
            note = detail_note_hint or "person-only detail flags ignored for non-human target"
            if not _safe_text(result.get("observe_detail_note"), limit=180):
                result["observe_detail_note"] = note
        result["summary"] = str(
            result.get("message")
            or result.get("error")
            or result.get("summary")
            or ("gimbal lock task started" if result.get("ok", False) else "gimbal lock task request failed")
        )
        return result

    def _tool_vision_gimbal_lock_stop(self, args: dict[str, Any]) -> dict[str, Any]:
        wait_raw = args.get("wait")
        wait = _coerce_enabled(wait_raw)
        if wait_raw is not None and str(wait_raw).strip() and wait is None:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "wait must be one of: 1/0 true/false on/off",
            }
        reason = _safe_text(args.get("reason"), limit=80) or "tool"
        result = self.vision_adapter.gimbal_lock_stop(wait=bool(wait), reason=reason)
        result["summary"] = str(
            result.get("message")
            or result.get("error")
            or result.get("summary")
            or "gimbal lock stop requested"
        )
        return result

    def _tool_vision_yolo_world_filter_get(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.yolo_world_filter_status()
        enabled = bool(result.get("filter_enabled", False))
        count = _clamp_int(result.get("filter_count", 0), default=0, min_value=0, max_value=100000)
        result.setdefault(
            "summary",
            f"yolo_world filter {'enabled' if enabled else 'disabled'} ({count} classes)"
        )
        return result

    def _tool_vision_yolo_world_filter_set(self, args: dict[str, Any]) -> dict[str, Any]:
        reason = _safe_text(args.get("reason"), limit=80) or "intent-rule"
        mode = _safe_text(args.get("mode"), limit=16).lower()
        labels = _safe_text(args.get("labels"), limit=4096)
        if mode in ("all", "clear", "reset", "none", "off"):
            labels = "all"
            mode = "all"
        if not labels:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "labels is required (or mode=all)",
            }
        result = self.vision_adapter.set_yolo_world_filter(labels=labels, reason=reason, mode=mode)
        result.setdefault(
            "summary",
            str(result.get("message") or result.get("error") or f"yolo_world filter set ({labels})"),
        )
        return result

    def _tool_vision_yolo_world_prompt_get(self, _args: dict[str, Any]) -> dict[str, Any]:
        result = self.vision_adapter.yolo_world_prompt_status()
        include_terms = (
            result.get("include_terms")
            if isinstance(result.get("include_terms"), list)
            else (
                result.get("yolo_world_prompt_include_terms")
                if isinstance(result.get("yolo_world_prompt_include_terms"), list)
                else []
            )
        )
        exclude_terms = (
            result.get("exclude_terms")
            if isinstance(result.get("exclude_terms"), list)
            else (
                result.get("yolo_world_prompt_exclude_terms")
                if isinstance(result.get("yolo_world_prompt_exclude_terms"), list)
                else []
            )
        )
        result.setdefault(
            "summary",
            f"yolo_world prompt include={len(include_terms)}, exclude={len(exclude_terms)}",
        )
        return result

    def _tool_vision_yolo_world_prompt_set(self, args: dict[str, Any]) -> dict[str, Any]:
        reason = _safe_text(args.get("reason"), limit=80) or "intent-rule"
        prompt = _safe_text(args.get("prompt"), limit=220)
        include_terms = args.get("include_terms") if isinstance(args.get("include_terms"), list) else []
        exclude_terms = args.get("exclude_terms") if isinstance(args.get("exclude_terms"), list) else []
        include_terms = [_safe_text(v, limit=48) for v in include_terms if _safe_text(v, limit=48)]
        exclude_terms = [_safe_text(v, limit=48) for v in exclude_terms if _safe_text(v, limit=48)]
        strict_flag = _coerce_enabled(args.get("strict"))
        if not prompt and not include_terms and not exclude_terms:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "prompt/include_terms/exclude_terms is required",
            }
        result = self.vision_adapter.set_yolo_world_prompt(
            prompt=prompt,
            include_terms=include_terms,
            exclude_terms=exclude_terms,
            reason=reason,
            strict=strict_flag,
        )
        result.setdefault(
            "summary",
            str(result.get("message") or result.get("error") or "yolo_world prompt updated"),
        )
        return result

    def execute_actions(
        self,
        actions: list[dict[str, Any]],
        trace_ctx: TraceContext,
        trace_store: TraceStore,
    ) -> list[dict[str, Any]]:
        _ = trace_store
        rows: list[dict[str, Any]] = []
        prepared = self._prepare_actions_for_dag(actions)
        if not prepared:
            return rows

        group_order, group_actions, group_deps = self._build_dag_graph(prepared)
        TraceStore.step(
            trace_ctx,
            name="executor.dag.start",
            ok=True,
            detail=f"groups={len(group_order)}, actions={len(prepared)}",
        )

        pending = set(group_order)
        completed: set[str] = set()
        failed = False

        while pending and not failed:
            ready_groups = [
                group
                for group in group_order
                if group in pending and group_deps.get(group, set()).issubset(completed)
            ]
            if not ready_groups:
                failed = True
                blocked = ",".join(sorted(pending)[:4])
                TraceStore.step(
                    trace_ctx,
                    name="executor.dag.invalid",
                    ok=False,
                    detail=f"unresolved dependencies: {blocked}",
                )
                break

            for group in ready_groups:
                deps = sorted(group_deps.get(group, set()))
                batch = group_actions.get(group) or []
                TraceStore.step(
                    trace_ctx,
                    name="executor.dag.group.start",
                    ok=True,
                    detail=f"group={group}, deps={','.join(deps) if deps else '-'}, actions={len(batch)}",
                )

                if len(batch) > 1 and all(self._is_parallel_read_action(action) for _, action in batch):
                    batch_rows = self._flush_parallel_read_batch(batch, trace_ctx=trace_ctx)
                else:
                    batch_rows = []
                    for idx, action in batch:
                        row = self._execute_single_action(idx=idx, action=action, trace_ctx=trace_ctx)
                        batch_rows.append(row)
                        if not bool(row.get("ok", False)):
                            break

                rows.extend(batch_rows)
                group_ok = len(batch_rows) == len(batch) and all(bool(row.get("ok", False)) for row in batch_rows)
                TraceStore.step(
                    trace_ctx,
                    name="executor.dag.group.finish",
                    ok=group_ok,
                    detail=f"group={group}, executed={len(batch_rows)}/{len(batch)}",
                )
                pending.discard(group)
                completed.add(group)

                if not group_ok:
                    failed = True
                    break

        all_ok = (not failed) and (not pending)
        TraceStore.step(
            trace_ctx,
            name="executor.dag.finish",
            ok=all_ok,
            detail=f"groups_done={len(completed)}/{len(group_order)}, actions={len(rows)}/{len(prepared)}",
        )
        return rows

    def _normalize_group_id(self, value: Any, *, fallback: str = "") -> str:
        text = _safe_text(value, limit=64).strip().lower()
        if not text:
            return fallback
        text = re.sub(r"\s+", ".", text)
        text = re.sub(r"[^a-z0-9._-]+", "", text)
        if not text:
            return fallback
        text = text[:40]
        if self._DAG_GROUP_RE.fullmatch(text):
            return text
        return fallback

    def _normalize_depends_on(self, value: Any, *, limit: int = 6) -> list[str]:
        out: list[str] = []
        raw_values: list[Any] = []
        if isinstance(value, list):
            raw_values = list(value)
        elif isinstance(value, str):
            raw_values = [seg for seg in re.split(r"[,;\s]+", value) if seg]
        elif value is not None:
            raw_values = [value]

        for raw in raw_values:
            group = self._normalize_group_id(raw)
            if not group or group in out:
                continue
            out.append(group)
            if len(out) >= max(1, int(limit)):
                break
        return out

    def _semantic_group_base(self, action: dict[str, Any]) -> str:
        tool = _safe_text(action.get("tool"), limit=80)
        side_effect = bool(action.get("side_effect", False))
        if not tool:
            return "action"

        if tool.startswith("system."):
            return "system.snapshot"

        if tool.startswith("memory."):
            if tool in ("memory.add", "memory.clear"):
                return "memory.write"
            return "memory.read"

        if tool.startswith("rgb."):
            return "rgb.control" if side_effect else "rgb.status"

        if tool == "vision.observe":
            return "camera.observe"

        if tool in ("vision.yolo_world.prompt.set", "vision.yolo_world.filter.set"):
            return "camera.prepare"
        if tool in ("vision.yolo_world.prompt.get", "vision.yolo_world.filter.get"):
            return "camera.state"

        if tool in ("vision.enabled.get", "vision.profile.get"):
            return "camera.state"
        if tool in ("vision.enabled.set", "vision.profile.set", "vision.stream.set", "vision.recover"):
            return "camera.control"

        if tool == "vision.gimbal.status":
            return "gimbal.status"
        if tool == "vision.gimbal.command":
            return "gimbal.control"
        if tool == "vision.gimbal.laser.blink":
            return "gimbal.control"
        if tool == "vision.gimbal.lock.status":
            return "gimbal.lock.status"
        if tool == "vision.gimbal.lock.start":
            return "gimbal.lock.start"
        if tool == "vision.gimbal.lock.stop":
            return "gimbal.lock.stop"

        if tool.startswith("vision."):
            return "vision.control" if side_effect else "vision.read"

        return "action.control" if side_effect else "action.read"

    def _allocate_semantic_group(self, base: str, counters: dict[str, int]) -> str:
        normalized_base = self._normalize_group_id(base, fallback="step")
        if not normalized_base:
            normalized_base = "step"
        seq = int(counters.get(normalized_base, 0)) + 1
        counters[normalized_base] = seq
        group = self._normalize_group_id(f"{normalized_base}.{seq}", fallback=normalized_base)
        return group or normalized_base

    def _prepare_actions_for_dag(self, actions: list[dict[str, Any]]) -> list[tuple[int, dict[str, Any]]]:
        prepared: list[tuple[int, dict[str, Any]]] = []
        has_dag_metadata = any(
            isinstance(action, dict) and ("group" in action or "depends_on" in action)
            for action in actions
        )
        prev_group = ""
        group_counters: dict[str, int] = {}
        active_read_group = ""
        active_read_base = ""

        for idx, action in enumerate(actions, start=1):
            row = dict(action) if isinstance(action, dict) else {}
            group = self._normalize_group_id(row.get("group"))
            deps = self._normalize_depends_on(row.get("depends_on"))

            if not group:
                base = self._semantic_group_base(row)
                if self._is_parallel_read_action(row):
                    if active_read_group and active_read_base == base:
                        group = active_read_group
                    else:
                        group = self._allocate_semantic_group(base, group_counters)
                        active_read_group = group
                        active_read_base = base
                else:
                    group = self._allocate_semantic_group(base, group_counters)
                    active_read_group = ""
                    active_read_base = ""
            elif not self._is_parallel_read_action(row):
                active_read_group = ""
                active_read_base = ""
            else:
                active_read_base = self._semantic_group_base(row)

            deps = [dep for dep in deps if dep != group]
            if not deps and prev_group and group != prev_group and not has_dag_metadata:
                deps = [prev_group]

            row["group"] = group
            row["depends_on"] = deps
            prepared.append((idx, row))
            prev_group = group

        return prepared

    def _build_dag_graph(
        self,
        prepared: list[tuple[int, dict[str, Any]]],
    ) -> tuple[list[str], dict[str, list[tuple[int, dict[str, Any]]]], dict[str, set[str]]]:
        group_order: list[str] = []
        group_actions: dict[str, list[tuple[int, dict[str, Any]]]] = {}
        group_deps: dict[str, set[str]] = {}

        for idx, action in prepared:
            group = self._normalize_group_id(action.get("group"), fallback=f"step.{idx}")
            deps = self._normalize_depends_on(action.get("depends_on"))
            action["group"] = group
            action["depends_on"] = [dep for dep in deps if dep != group]

            if group not in group_actions:
                group_actions[group] = []
                group_order.append(group)
            group_actions[group].append((idx, action))
            dep_set = group_deps.setdefault(group, set())
            dep_set.update(action.get("depends_on") if isinstance(action.get("depends_on"), list) else [])

        known_groups = set(group_actions.keys())
        for group in group_order:
            deps = group_deps.get(group, set())
            group_deps[group] = {dep for dep in deps if dep in known_groups and dep != group}

        return group_order, group_actions, group_deps

    def _is_parallel_read_action(self, action: dict[str, Any]) -> bool:
        if not isinstance(action, dict):
            return False
        if bool(action.get("side_effect", False)):
            return False
        if bool(action.get("requires_confirmation", False)):
            return False
        risk = _safe_text(action.get("risk_level"), limit=16).lower() or "low"
        if risk != "low":
            return False
        tool = _safe_text(action.get("tool"), limit=80)
        if tool not in self._PARALLEL_READ_TOOL_ALLOWLIST:
            return False
        return True

    def _execute_single_action(
        self,
        *,
        idx: int,
        action: dict[str, Any],
        trace_ctx: TraceContext,
    ) -> dict[str, Any]:
        tool = _safe_text(action.get("tool"), limit=80)
        args = action.get("arguments")
        tool_args = dict(args) if isinstance(args, dict) else {}
        started = time.perf_counter()
        try:
            result = self.run_tool(tool, tool_args, timeout_sec=self.timeout_long_sec)
        except Exception as exc:
            result = {
                "ok": False,
                "timestamp": _ts_now(),
                "error": _safe_text(f"tool exception: {exc}", limit=220),
            }
        ok = bool(result.get("ok", False))
        detail = _safe_text(result.get("summary") or result.get("error") or "ok", limit=220)
        TraceStore.step(
            trace_ctx,
            name=f"tool.{tool}",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
        )
        return {
            "index": idx,
            "tool": tool,
            "arguments": tool_args,
            "side_effect": bool(action.get("side_effect", False)),
            "risk_level": _safe_text(action.get("risk_level"), limit=16) or "low",
            "requires_confirmation": bool(action.get("requires_confirmation", False)),
            "group": self._normalize_group_id(action.get("group"), fallback=f"step.{idx}"),
            "depends_on": self._normalize_depends_on(action.get("depends_on")),
            "ok": ok,
            "result": result,
        }

    def _flush_parallel_read_batch(
        self,
        batch: list[tuple[int, dict[str, Any]]],
        *,
        trace_ctx: TraceContext,
    ) -> list[dict[str, Any]]:
        if not batch:
            return []
        if len(batch) == 1 or self.exec_read_parallelism <= 1:
            idx, action = batch[0]
            return [self._execute_single_action(idx=idx, action=action, trace_ctx=trace_ctx)]

        workers = max(1, min(self.exec_read_parallelism, len(batch)))
        TraceStore.step(
            trace_ctx,
            name="executor.read.parallel.start",
            ok=True,
            detail=f"batch={len(batch)}, workers={workers}",
        )

        out: list[dict[str, Any]] = []
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="agent-read") as pool:
            futures = {
                pool.submit(self._execute_single_action, idx=idx, action=action, trace_ctx=trace_ctx): (idx, action)
                for idx, action in batch
            }
            for future in as_completed(futures):
                try:
                    out.append(future.result())
                except Exception as exc:
                    idx, action = futures[future]
                    tool = _safe_text(action.get("tool"), limit=80)
                    tool_args = (
                        dict(action.get("arguments"))
                        if isinstance(action.get("arguments"), dict)
                        else {}
                    )
                    result = {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": _safe_text(f"parallel execution error: {exc}", limit=220),
                    }
                    TraceStore.step(
                        trace_ctx,
                        name=f"tool.{tool}",
                        ok=False,
                        detail=_safe_text(result.get("error"), limit=220),
                    )
                    out.append(
                        {
                            "index": idx,
                            "tool": tool,
                            "arguments": tool_args,
                            "side_effect": bool(action.get("side_effect", False)),
                            "risk_level": _safe_text(action.get("risk_level"), limit=16) or "low",
                            "requires_confirmation": bool(action.get("requires_confirmation", False)),
                            "group": self._normalize_group_id(action.get("group"), fallback=f"step.{idx}"),
                            "depends_on": self._normalize_depends_on(action.get("depends_on")),
                            "ok": False,
                            "result": result,
                        }
                    )

        out.sort(key=lambda row: _clamp_int(row.get("index"), default=0, min_value=0, max_value=10_000))
        ok = all(bool(row.get("ok", False)) for row in out)
        TraceStore.step(
            trace_ctx,
            name="executor.read.parallel.finish",
            ok=ok,
            detail=f"executed={len(out)}/{len(batch)}",
        )
        return out


@dataclass(frozen=True)
class IntentRule:
    rule_id: str
    priority: int
    matcher: Callable[[str, str], bool]
    producer: Callable[[str, str, str], list[dict[str, Any]]]


class IntentRegistry:
    def __init__(self) -> None:
        self.command_rules = self._build_command_rules()
        self.status_rules = self._build_status_rules()

    @staticmethod
    def _is_cjk_char(ch: str) -> bool:
        return bool(ch) and ("\u4e00" <= ch <= "\u9fff")

    @classmethod
    def _match_short_cjk_token(cls, text: str, token: str) -> bool:
        t = str(token or "").strip()
        if not t:
            return False
        if text == t:
            return True

        # Short CJK token must be context-bounded; avoid naive substring hits.
        modal_tail = set("吗么呢吧呀啊哈哦噢了啦嘛")
        prefix_hint = set("向往朝给把请让令对将按从往")
        punct_re = re.compile(r"[\s，。！？!?；;,:：、/\-()（）\[\]{}\"'`]")

        start = 0
        t_len = len(t)
        while True:
            idx = text.find(t, start)
            if idx < 0:
                return False
            prev = text[idx - 1] if idx > 0 else ""
            nxt_idx = idx + t_len
            nxt = text[nxt_idx] if nxt_idx < len(text) else ""

            prev_boundary = (not prev) or bool(punct_re.match(prev))
            next_boundary = (not nxt) or bool(punct_re.match(nxt))
            if prev_boundary or next_boundary:
                return True
            if nxt and nxt in modal_tail:
                return True
            if prev and prev in prefix_hint:
                return True

            # Accept duplicated colloquial form like "开开/关关/猫猫".
            if nxt == t:
                after2_idx = idx + (t_len * 2)
                after2 = text[after2_idx] if after2_idx < len(text) else ""
                if (not after2) or (after2 in modal_tail) or bool(punct_re.match(after2)):
                    return True

            start = idx + t_len

    @classmethod
    def _contains_any(cls, text: str, lower: str, tokens: tuple[str, ...]) -> bool:
        for token in tokens:
            t = str(token or "").strip()
            if not t:
                continue
            if t.isascii():
                tl = t.lower()
                # Avoid naive matching for very short ASCII tokens.
                if len(tl) <= 2 and re.fullmatch(r"[a-z0-9_+\-]+", tl):
                    if re.search(rf"(?<![a-z0-9_+\-]){re.escape(tl)}(?![a-z0-9_+\-])", lower):
                        return True
                    continue
                if tl in lower:
                    return True
                continue

            # Avoid direct substring for single-character CJK tokens.
            if len(t) == 1 and cls._is_cjk_char(t):
                if cls._match_short_cjk_token(text, t):
                    return True
                continue

            if t in text:
                return True
        return False

    @staticmethod
    def _keyword_rule(
        *,
        rule_id: str,
        priority: int,
        tokens: tuple[str, ...],
        producer: Callable[[str, str, str], list[dict[str, Any]]],
    ) -> IntentRule:
        def matcher(text: str, lower: str) -> bool:
            return IntentRegistry._contains_any(text, lower, tokens)

        return IntentRule(rule_id=rule_id, priority=priority, matcher=matcher, producer=producer)

    @staticmethod
    def _is_question_like(text: str, lower: str) -> bool:
        if "?" in text or "？" in text:
            return True
        return IntentRegistry._contains_any(
            text,
            lower,
            ("吗", "么", "是否", "是不是", "有没", "有没有", "在吗", "咋样", "how", "status", "state"),
        )

    @classmethod
    def _laser_toggle_intent(cls, text: str, lower: str) -> int | None:
        if cls._is_question_like(text, lower):
            return None
        if not cls._contains_any(text, lower, ("激光", "laser")):
            return None

        cn_on_expr = r"(?:打开|开启|开一下|开下|开开|开了|点亮|亮起|开(?!关))"
        cn_off_expr = r"(?:关闭|关掉|关一下|关下|关了|熄灭|熄掉|灭掉|灭了|(?<!开)关(?!于))"
        near_sep = r"[^。！？!?；;，,\n]{0,10}"

        on_hit = bool(
            re.search(rf"(?:激光(?:灯)?){near_sep}{cn_on_expr}", text, flags=re.IGNORECASE)
            or re.search(rf"{cn_on_expr}{near_sep}(?:激光(?:灯)?)", text, flags=re.IGNORECASE)
        )
        off_hit = bool(
            re.search(rf"(?:激光(?:灯)?){near_sep}{cn_off_expr}", text, flags=re.IGNORECASE)
            or re.search(rf"{cn_off_expr}{near_sep}(?:激光(?:灯)?)", text, flags=re.IGNORECASE)
        )

        lower_nospace = re.sub(r"\s+", " ", lower).strip()
        if "laser" in lower_nospace:
            if any(token in lower_nospace for token in ("turn on", "switch on", "enable laser", "laser on")):
                on_hit = True
            if any(token in lower_nospace for token in ("turn off", "switch off", "disable laser", "laser off")):
                off_hit = True
            if re.search(r"\bopen\b[^a-z0-9]{0,8}\blaser\b|\blaser\b[^a-z0-9]{0,8}\bopen\b", lower_nospace):
                on_hit = True
            if re.search(r"\bclose\b[^a-z0-9]{0,8}\blaser\b|\blaser\b[^a-z0-9]{0,8}\bclose\b", lower_nospace):
                off_hit = True

        if on_hit and not off_hit:
            return 1
        if off_hit and not on_hit:
            return 0
        return None

    @classmethod
    def _is_camera_state_query(cls, text: str, lower: str) -> bool:
        has_camera_domain = cls._contains_any(
            text,
            lower,
            ("摄像头", "相机", "镜头", "camera", "vision"),
        )
        if not has_camera_domain:
            return False
        has_state_hint = cls._contains_any(
            text,
            lower,
            ("状态", "开关", "开", "关", "开启", "关闭", "打开", "启用", "停用", "on", "off", "enabled", "disabled"),
        )
        if not has_state_hint:
            return False
        return cls._is_question_like(text, lower)

    @staticmethod
    def _extract_memory_note(text: str, lower: str) -> str:
        if text.startswith("记住"):
            return text[2:].strip(" ：:，,。")
        if lower.startswith("remember"):
            return text[len("remember") :].strip(" ：:，,。")
        return ""

    @staticmethod
    def _extract_memory_search_query(text: str, lower: str) -> str:
        if text.startswith("搜索记忆"):
            return text.replace("搜索记忆", "", 1).strip(" ：:，,。")
        if lower.startswith("search memory"):
            return text[len("search memory") :].strip(" ：:，,。")
        return ""

    @staticmethod
    def _pick_profile_from_text(text: str, lower: str) -> str:
        table: tuple[tuple[str, tuple[str, ...]], ...] = (
            ("stable", ("stable", "稳", "省电", "低功耗", "低负载")),
            ("smooth", ("smooth", "流畅", "高帧", "60fps", "60帧")),
            ("clear", ("clear", "清晰", "画质", "清楚")),
            ("clear60", ("clear60", "清晰60", "高帧清晰")),
            ("fullhd30", ("fullhd", "1080", "fullhd30", "fhd30")),
        )
        for profile, words in table:
            for word in words:
                if word.isascii():
                    if word in lower:
                        return profile
                else:
                    if word in text:
                        return profile
        return ""

    @staticmethod
    def _rgb_color_from_text(text: str, lower: str) -> str:
        table: tuple[tuple[str, tuple[str, ...]], ...] = (
            ("off", ("关灯", "熄灯", "off")),
            ("red", ("红灯", "red")),
            ("green", ("绿灯", "green")),
            ("blue", ("蓝灯", "blue")),
            ("yellow", ("黄灯", "yellow")),
            ("white", ("白灯", "white")),
            ("cyan", ("cyan", "青灯")),
            ("magenta", ("magenta", "紫灯")),
        )
        for color, words in table:
            for word in words:
                if word.isascii():
                    if word in lower:
                        return color
                else:
                    if word in text:
                        return color
        return ""

    @staticmethod
    def _extract_gimbal_speed_hint(text: str, lower: str, default_speed: float = 8.0) -> float:
        min_speed = 0.05
        m = re.search(
            r"([+-]?\d+(?:\.\d+)?)\s*(?:rpm|r/min|转每分钟|转每分|转/分)",
            lower,
            flags=re.IGNORECASE,
        )
        if m is not None:
            try:
                speed = abs(float(m.group(1)))
                return max(min_speed, min(50.0, speed))
            except (TypeError, ValueError):
                pass
        m = re.search(r"速度\s*([+-]?\d+(?:\.\d+)?)", text)
        if m is not None:
            try:
                speed = abs(float(m.group(1)))
                return max(min_speed, min(50.0, speed))
            except (TypeError, ValueError):
                pass
        if "慢" in text or "slow" in lower:
            return 4.0
        if "快" in text or "fast" in lower:
            return 14.0
        return max(min_speed, min(50.0, float(default_speed)))

    @staticmethod
    def _extract_time_seconds_hint(text: str, lower: str) -> float | None:
        ms_patterns = (
            r"([+-]?\d+(?:\.\d+)?)\s*(?:ms|msec|msecs|millisecond|milliseconds)\b",
            r"([+-]?\d+(?:\.\d+)?)\s*(?:毫秒)",
        )
        for pattern in ms_patterns:
            source = lower if pattern.isascii() else text
            match = re.search(pattern, source, flags=re.IGNORECASE)
            if match is None:
                continue
            try:
                sec_val = float(match.group(1)) / 1000.0
                return max(0.0, sec_val)
            except (TypeError, ValueError):
                continue

        sec_patterns = (
            r"([+-]?\d+(?:\.\d+)?)\s*(?:s|sec|secs|second|seconds)\b",
            r"([+-]?\d+(?:\.\d+)?)\s*(?:秒钟|秒)",
        )
        for pattern in sec_patterns:
            source = lower if pattern.isascii() else text
            match = re.search(pattern, source, flags=re.IGNORECASE)
            if match is None:
                continue
            try:
                sec_val = float(match.group(1))
                return max(0.0, sec_val)
            except (TypeError, ValueError):
                continue
        return None

    @staticmethod
    def _extract_gimbal_axis_rpm(text: str, lower: str) -> tuple[float | None, float | None]:
        yaw_rpm: float | None = None
        pitch_rpm: float | None = None
        yaw_match = re.search(r"(?:yaw|pan)\s*([+-]?\d+(?:\.\d+)?)", lower)
        if yaw_match is None:
            yaw_match = re.search(r"(?:偏航|左右|横摆)\s*([+-]?\d+(?:\.\d+)?)", text)
        if yaw_match is not None:
            try:
                yaw_rpm = max(-50.0, min(50.0, float(yaw_match.group(1))))
            except (TypeError, ValueError):
                yaw_rpm = None

        pitch_match = re.search(r"(?:pitch|tilt)\s*([+-]?\d+(?:\.\d+)?)", lower)
        if pitch_match is None:
            pitch_match = re.search(r"(?:俯仰|上下)\s*([+-]?\d+(?:\.\d+)?)", text)
        if pitch_match is not None:
            try:
                pitch_rpm = max(-50.0, min(50.0, float(pitch_match.group(1))))
            except (TypeError, ValueError):
                pitch_rpm = None
        return yaw_rpm, pitch_rpm

    @classmethod
    def _extract_gimbal_lock_target(cls, text: str, lower: str) -> str:
        alias_terms = cls._extract_alias_terms_from_text(text, lower, max_terms=4)
        if alias_terms:
            return alias_terms[0]

        patterns = (
            r"(?:找(?:一下|下|个|一)?|寻找|搜索|查找)\s*([^，。！？!?；;]{1,40}?)\s*(?:并|然后|后|再)?\s*(?:锁定|跟踪|追踪)",
            r"(?:锁定|跟踪|追踪)\s*(?:一下|下|目标|物体|对象)?\s*([^，。！？!?；;]{1,40})",
            r"(?:find|look\s*for|search\s*for)\s+([^,.;!?]{1,40}?)(?:\s+(?:and|then)\s+(?:lock|track|follow))?$",
            r"(?:lock(?:\s*on)?|track|follow)\s+([^,.;!?]{1,40})",
        )
        for pattern in patterns:
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match is None:
                continue
            segment = _safe_text(match.group(1), limit=96).strip(" ：:，,。！？!?；;")
            if not segment:
                continue
            segment = re.sub(r"^(?:这个|那个|一下|下|一只|一个|一台|the|a|an)\s*", "", segment, flags=re.IGNORECASE)
            segment = re.sub(r"\s*(?:并且|然后|后|并|and|then)\s*$", "", segment, flags=re.IGNORECASE)
            parts = cls._split_terms_text(segment, max_terms=3)
            if parts:
                normalized = cls._normalize_camera_term(parts[0]) or parts[0]
                if normalized and normalized.lower() not in {
                    "了",
                    "谁",
                    "什么",
                    "哪个",
                    "现在",
                    "状态",
                    "吗",
                    "么",
                }:
                    return normalized[:48]
            normalized = cls._normalize_camera_term(segment) or segment
            if normalized and normalized.lower() not in {
                "了",
                "谁",
                "什么",
                "哪个",
                "现在",
                "状态",
                "吗",
                "么",
            }:
                return normalized[:48]

        fallback_terms = cls._split_terms_text(text, max_terms=8)
        ignore_terms = {
            "云台",
            "gimbal",
            "锁定",
            "追踪",
            "跟踪",
            "目标",
            "物体",
            "对象",
            "摄像头",
            "相机",
            "镜头",
            "camera",
            "vision",
            "track",
            "follow",
            "lock",
            "了",
            "谁",
            "什么",
            "哪个",
            "现在",
            "状态",
            "吗",
            "么",
        }
        for term in fallback_terms:
            normalized = cls._normalize_camera_term(term) or term
            if normalized.lower() in ignore_terms:
                continue
            if len(normalized) <= 1 and not normalized.isascii():
                continue
            return normalized[:48]
        return ""

    @classmethod
    def _normalize_gimbal_lock_target(cls, target: str) -> tuple[str, bool]:
        raw = _safe_text(target, limit=160)
        if not raw:
            return "", False
        person_ascii = {
            "person",
            "human",
            "people",
            "man",
            "woman",
            "boy",
            "girl",
            "pedestrian",
            "face",
            "head",
            "me",
            "myself",
            "i",
            "this person",
            "that person",
        }
        person_non_ascii = {"人", "人物", "人类", "行人", "那个人", "这个人", "我", "自己", "我自己", "人脸", "脸部", "脸"}
        out: list[str] = []
        human_target = False
        parts = [seg.strip() for seg in re.split(r"[，,;；/|]+", raw) if str(seg).strip()]
        for part in parts:
            token = _safe_text(part, limit=64).strip()
            if not token:
                continue
            token = re.sub(r"^(?:这|那|这个|那个|一个|一位|一名)\s*", "", token)
            token = re.sub(r"^(?:the|a|an)\s+", "", token, flags=re.IGNORECASE)
            token = token.strip()
            if not token:
                continue
            token_key = token.lower()
            if token_key in person_ascii or token in person_non_ascii:
                canon = "person"
            else:
                canon = cls._normalize_camera_term(token)
                if not canon:
                    canon = token_key if token.isascii() else token
            if canon == "person":
                human_target = True
            if canon not in out:
                out.append(canon)
            if len(out) >= 6:
                break
        return ",".join(out[:6]), human_target

    @classmethod
    def _extract_gimbal_lock_detail_preferences(cls, text: str, lower: str) -> tuple[bool | None, bool | None, bool]:
        wear_pos_tokens = (
            "眼镜",
            "戴眼镜",
            "有眼镜",
            "有没有戴眼镜",
            "glasses",
            "eyeglasses",
            "spectacles",
            "sunglasses",
        )
        wear_neg_tokens = (
            "不要眼镜",
            "别看眼镜",
            "不看眼镜",
            "别检查眼镜",
            "不要看眼镜",
            "without glasses",
            "no glasses",
            "dont check glasses",
            "don't check glasses",
        )
        emotion_pos_tokens = (
            "情绪",
            "表情",
            "心情",
            "脸色",
            "看我脸色",
            "emotion",
            "emotions",
            "mood",
            "feeling",
        )
        emotion_neg_tokens = (
            "不要情绪",
            "别看情绪",
            "不看情绪",
            "不要表情",
            "别看表情",
            "不要心情",
            "别看心情",
            "without emotion",
            "no emotion",
            "dont check emotion",
            "don't check emotion",
        )
        wear_pos = cls._contains_any(text, lower, wear_pos_tokens)
        wear_neg = cls._contains_any(text, lower, wear_neg_tokens)
        emotion_pos = cls._contains_any(text, lower, emotion_pos_tokens)
        emotion_neg = cls._contains_any(text, lower, emotion_neg_tokens)
        wear_pref = False if wear_neg else (True if wear_pos else None)
        emotion_pref = False if emotion_neg else (True if emotion_pos else None)
        detail_requested = bool(wear_pos or wear_neg or emotion_pos or emotion_neg)
        return wear_pref, emotion_pref, detail_requested

    @staticmethod
    def _pick_gimbal_lock_detector(text: str, lower: str, default: str = "yolo_world") -> str:
        if IntentRegistry._contains_any(text, lower, ("face", "人脸", "脸部", "头部", "head")):
            return "face"
        detector = IntentRegistry._pick_detector_from_text(text, lower, default)
        if detector in ("none", "rect"):
            return "yolo_world"
        if detector not in ("face", "yolo", "yolo_world"):
            return "yolo_world"
        return detector

    @staticmethod
    def _extract_gimbal_lock_blinks(text: str, lower: str, default_value: int = 3) -> int:
        patterns = (
            r"(?:闪(?:烁)?|blink)\s*([1-9]\d?)\s*(?:次|下|x|times?)",
            r"([1-9]\d?)\s*(?:次|下|x|times?)\s*(?:闪(?:烁)?|blink)",
        )
        for pattern in patterns:
            source = text if "闪" in pattern else lower
            match = re.search(pattern, source, flags=re.IGNORECASE)
            if match is None:
                continue
            try:
                value = int(match.group(1))
                return max(0, min(12, value))
            except (TypeError, ValueError):
                continue
        return max(0, min(12, int(default_value)))

    @staticmethod
    def _extract_gimbal_lock_blink_period_ms(text: str, lower: str) -> int | None:
        if not IntentRegistry._contains_any(
            text,
            lower,
            ("闪", "闪烁", "blink", "频率", "周期", "hz", "赫兹"),
        ):
            return None

        hz_match = re.search(r"([+-]?\d+(?:\.\d+)?)\s*(?:hz|赫兹)", lower, flags=re.IGNORECASE)
        if hz_match is not None:
            try:
                hz_val = float(hz_match.group(1))
                if hz_val > 0.01:
                    period_ms = int(round(1000.0 / hz_val))
                    return max(80, min(2000, period_ms))
            except (TypeError, ValueError):
                pass

        sec_match = re.search(
            r"([+-]?\d+(?:\.\d+)?)\s*(?:秒钟|秒|s|sec|second|seconds)",
            lower,
            flags=re.IGNORECASE,
        )
        if sec_match is not None:
            try:
                sec_val = float(sec_match.group(1))
                if sec_val > 0:
                    period_ms = int(round(sec_val * 1000.0))
                    return max(80, min(2000, period_ms))
            except (TypeError, ValueError):
                pass

        if re.search(r"(?:一秒|1秒|1\s*s|1\s*sec|1\s*second)", lower, flags=re.IGNORECASE):
            return 1000
        return None

    @classmethod
    def _gimbal_lock_semantic_actions(cls, text: str, lower: str) -> list[dict[str, Any]]:
        watch_tokens = (
            "看着",
            "盯着",
            "看住",
            "盯住",
            "跟随",
            "跟拍",
            "watch",
            "watching",
            "look at",
        )
        lock_tokens = (
            "锁定",
            "跟踪",
            "追踪",
            "跟随",
            "跟拍",
            "跟着我",
            "lock",
            "track",
            "follow",
            *watch_tokens,
        )
        face_tokens = ("face", "人脸", "脸部", "脸", "头部", "head")
        center_tokens = ("正中", "中间", "居中", "中心", "center")
        anti_jitter_tokens = ("不抖", "别抖", "不要抖", "平稳", "稳定", "smooth", "jitter")
        gimbal_context_tokens = ("云台", "gimbal", "摄像头", "相机", "镜头", "camera", "vision")
        center_track_hint = (
            cls._contains_any(text, lower, face_tokens)
            and cls._contains_any(text, lower, center_tokens)
            and cls._contains_any(text, lower, gimbal_context_tokens)
        )
        if not cls._contains_any(text, lower, lock_tokens) and not center_track_hint:
            return []

        status_tokens = ("锁定状态", "追踪状态", "跟踪状态", "跟随状态", "lock status", "tracking status")
        status_query_tokens = (
            "锁定目标了吗",
            "锁住了吗",
            "现在在锁定",
            "还在锁定",
            "还锁着没",
            "锁着没",
            "是不是在追踪",
            "还在追踪",
            "在追踪吗",
            "还在跟踪",
            "在跟踪吗",
            "在锁定谁",
            "锁定谁",
            "who is locked",
            "who are you tracking",
            "tracking who",
        )
        stop_tokens = (
            "停止锁定",
            "取消锁定",
            "解除锁定",
            "结束锁定",
            "停止追踪",
            "结束追踪",
            "停止跟踪",
            "停止跟随",
            "结束跟随",
            "取消跟随",
            "stop lock",
            "unlock",
            "stop tracking",
            "cancel lock",
            "别看了",
            "不要看着",
            "别盯着",
            "stop watching",
        )

        status_semantic_pattern = bool(
            re.search(
                r"(还|是否|是不是|有无|有没有|在不在|现在).{0,6}(锁定|锁着|追踪|跟踪|跟随)"
                r"|"
                r"(锁定|锁着|追踪|跟踪|跟随).{0,6}(吗|没|么|呢|\?|？)",
                lower,
                flags=re.IGNORECASE,
            )
        )
        if (
            cls._contains_any(text, lower, status_tokens)
            or cls._contains_any(text, lower, status_query_tokens)
            or status_semantic_pattern
        ):
            return [{"tool": "vision.gimbal.lock.status", "arguments": {}, "reason": "gimbal lock status"}]

        if cls._contains_any(text, lower, ("激光", "laser")) and cls._is_question_like(text, lower):
            return [
                {"tool": "vision.gimbal.lock.status", "arguments": {}, "reason": "gimbal lock status"},
                {"tool": "vision.gimbal.status", "arguments": {}, "reason": "laser status"},
            ]

        stop_semantic_pattern = bool(
            re.search(
                r"(停止|结束|取消|解除|停掉|停下|先停|别).{0,10}(锁定|追踪|跟踪|跟随|跟拍)"
                r"|"
                r"(锁定|追踪|跟踪|跟随|跟拍).{0,10}(停止|结束|取消|解除|停掉|停下|先停|别)"
                r"|"
                r"(stop|cancel|end|halt).{0,12}(lock|tracking|track|follow)"
                r"|"
                r"(lock|tracking|track|follow).{0,12}(stop|cancel|end|halt)",
                lower,
                flags=re.IGNORECASE,
            )
        )
        if cls._contains_any(text, lower, stop_tokens) or stop_semantic_pattern:
            return [
                {
                    "tool": "vision.gimbal.lock.stop",
                    "arguments": {"wait": False, "reason": "intent-rule"},
                    "reason": "gimbal lock stop",
                }
            ]

        start_tokens = (
            "锁定",
            "跟踪",
            "追踪",
            "跟随",
            "跟拍",
            "跟着我",
            "找",
            "寻找",
            "搜索",
            "查找",
            "开始",
            "启动",
            "并锁定",
            "并追踪",
            "并跟踪",
            "并跟随",
            "find",
            "search",
            "look for",
            "start",
            "lock on",
            *watch_tokens,
        )
        has_start_hint = cls._contains_any(text, lower, start_tokens)
        has_context = cls._contains_any(
            text,
            lower,
            (
                "云台",
                "gimbal",
                "摄像头",
                "相机",
                "镜头",
                "camera",
                "vision",
            ),
        )
        if not has_start_hint and not has_context:
            return []

        watch_mode = cls._contains_any(text, lower, watch_tokens)
        watch_me = cls._contains_any(
            text,
            lower,
            (
                "看着我",
                "盯着我",
                "跟着我",
                "跟随我",
                "追踪我",
                "锁定我",
                "盯住我",
                "track me",
                "follow me",
                "watch me",
                "look at me",
                "lock on me",
                "lock me",
            ),
        )
        alias_terms = cls._extract_alias_terms_from_text(text, lower, max_terms=6)
        ignore_target_terms = {
            "person" if watch_me else "",
            "cloud",
            "gimbal",
            "camera",
            "vision",
        }
        target_terms: list[str] = []
        for term in alias_terms:
            normalized = cls._normalize_camera_term(term) or term
            key = normalized.strip().lower()
            if not key or key in ignore_target_terms:
                continue
            if normalized not in target_terms:
                target_terms.append(normalized)
        face_focus = cls._contains_any(text, lower, face_tokens)
        if face_focus:
            # Face tracking should default to person target for stable behavior.
            target_terms = [term for term in target_terms if str(term).strip().lower() != "person"]
            target_terms.insert(0, "person")
        if watch_me and "person" not in target_terms:
            target_terms.insert(0, "person")

        target_raw = ",".join(target_terms[:6]) if target_terms else cls._extract_gimbal_lock_target(text, lower)
        target, target_human = cls._normalize_gimbal_lock_target(target_raw)
        human_target_hint = (
            watch_me
            or face_focus
            or cls._contains_any(
                text,
                lower,
                ("我", "人", "人物", "行人", "人脸", "那个人", "这个人", "person", "human", "people"),
            )
        )
        if watch_me:
            target = "person"
            target_human = True
        elif not target and human_target_hint:
            target = "person"
            target_human = True
        detector = "auto"
        wear_pref, emotion_pref, detail_requested = cls._extract_gimbal_lock_detail_preferences(text, lower)
        laser_blinks = cls._extract_gimbal_lock_blinks(text, lower, default_value=3)
        continuous_tokens = (
            "一直看着",
            "一直跟踪",
            "一直追踪",
            "一直跟着",
            "一直跟随",
            "持续跟踪",
            "持续追踪",
            "持续跟随",
            "持续看着",
            "不要停",
            "别停",
            "keep tracking",
            "keep following",
            "continuous",
            "continuously",
            *watch_tokens,
        )
        continuous = cls._contains_any(text, lower, continuous_tokens)
        if (
            cls._contains_any(text, lower, ("不要一直抖", "别一直抖", "不想一直抖", "no jitter", "less jitter"))
            and (not watch_mode)
            and (not watch_me)
        ):
            continuous = False

        blink_period_ms = cls._extract_gimbal_lock_blink_period_ms(text, lower)
        after_done_blink = (
            blink_period_ms is not None
            and cls._contains_any(
                text,
                lower,
                ("搞完之后", "完成后", "结束后", "锁定后", "done then", "after done", "after lock"),
            )
        )
        if after_done_blink:
            continuous = False

        timeout_hint_sec = cls._extract_time_seconds_hint(text, lower)
        arguments: dict[str, Any] = {
            "detector": detector,
            "laser_blinks": int(laser_blinks),
            "reason": "intent-rule",
        }

        if face_focus and cls._contains_any(text, lower, center_tokens):
            arguments["center_tolerance_px"] = 30.0
            arguments["stable_frames"] = 14
            arguments["kp_yaw"] = 0.022
            arguments["kp_pitch"] = 0.022
            arguments["max_rpm"] = min(2.2, AGENT_GIMBAL_RPM_LIMIT)
            arguments["search_sweep_rpm"] = min(1.8, AGENT_GIMBAL_RPM_LIMIT)
            if cls._contains_any(text, lower, anti_jitter_tokens):
                arguments["center_tolerance_px"] = 34.0
                arguments["stable_frames"] = 16
                arguments["kp_yaw"] = 0.018
                arguments["kp_pitch"] = 0.018
                arguments["max_rpm"] = min(2.0, AGENT_GIMBAL_RPM_LIMIT)

        if blink_period_ms is not None:
            half_ms = int(max(40, min(1000, round(float(blink_period_ms) * 0.5))))
            arguments["laser_on_ms"] = half_ms
            arguments["laser_off_ms"] = half_ms

        if continuous:
            arguments["continuous"] = True
            arguments["laser_blinks"] = 0
            arguments["timeout_sec"] = min(3600.0, AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC)
        if timeout_hint_sec is not None and timeout_hint_sec > 0:
            arguments["timeout_sec"] = max(
                1.0,
                min(AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC, float(timeout_hint_sec)),
            )
        if target:
            arguments["target"] = target
        if target_human:
            if wear_pref is not None:
                arguments["wear_glasses"] = bool(wear_pref)
            if emotion_pref is not None:
                arguments["emotion"] = bool(emotion_pref)
        elif detail_requested:
            arguments["_warning"] = "person-only details ignored for non-human target"
        actions: list[dict[str, Any]] = []
        if continuous:
            actions.append(
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "laser_enabled": 0,
                        "enabled": 2,
                        "stability_enabled": 2,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "laser off before watch",
                }
            )
        actions.append({"tool": "vision.gimbal.lock.start", "arguments": arguments, "reason": "gimbal lock start"})
        return actions

    @classmethod
    def _gimbal_semantic_actions(cls, text: str, lower: str) -> list[dict[str, Any]]:
        if cls._contains_any(text, lower, ("锁定", "追踪", "跟踪", "lock", "track", "follow")):
            return []
        domain_tokens = (
            "云台",
            "gimbal",
            "pan-tilt",
            "pan tilt",
            "yaw",
            "pitch",
            "tilt",
            "串口",
        )
        direction_tokens = ("左", "右", "上", "下", "left", "right", "up", "down")
        has_direction_hint = cls._contains_any(text, lower, direction_tokens)
        soft_move_tokens = (
            "一点",
            "一点点",
            "一点儿",
            "稍微",
            "轻微",
            "微微",
            "轻轻",
            "小幅",
            "稍稍",
            "a little",
            "slightly",
        )
        direction_phrase_tokens = (
            "向左",
            "向右",
            "向上",
            "向下",
            "往左",
            "往右",
            "往上",
            "往下",
            "左转",
            "右转",
            "抬头",
            "低头",
            "move left",
            "move right",
            "move up",
            "move down",
            "turn left",
            "turn right",
        )
        has_soft_move_hint = cls._contains_any(text, lower, soft_move_tokens)
        has_direction_phrase_hint = cls._contains_any(text, lower, direction_phrase_tokens)
        stability_hint = cls._contains_any(text, lower, ("稳像", "防抖", "稳定模式", "stability", "stabilization"))
        has_numeric_motion_hint = bool(
            re.search(
                r"([+-]?\d+(?:\.\d+)?)\s*(?:rpm|r/min|转每分钟|转每分|转/分|ms|毫秒|s|sec|second|seconds|秒)",
                lower,
                flags=re.IGNORECASE,
            )
        ) or bool(re.search(r"(?:yaw|pan|pitch|tilt|偏航|俯仰|左右|上下)\s*[+-]?\d", text, flags=re.IGNORECASE))
        has_soft_direction_motion_hint = bool(has_direction_phrase_hint and has_soft_move_hint)
        if not cls._contains_any(text, lower, domain_tokens) and not (
            (has_direction_hint and has_numeric_motion_hint) or has_soft_direction_motion_hint
        ) and not stability_hint:
            return []

        status_tokens = (
            "状态",
            "status",
            "在线",
            "连接",
            "连通",
            "port",
            "串口状态",
        )
        stop_tokens = (
            "停止",
            "停下",
            "别动",
            "刹车",
            "stop",
            "halt",
            "idle",
            "静止",
        )
        enable_tokens = ("开启云台", "启用云台", "打开云台", "enable gimbal")
        disable_tokens = ("关闭云台", "禁用云台", "停用云台", "disable gimbal")
        hold_tokens = ("持续", "一直", "保持", "hold", "keep")
        stability_status_tokens = ("稳像状态", "防抖状态", "稳定模式状态", "stability status")
        stability_enable_tokens = (
            "开稳像",
            "开启稳像",
            "打开稳像",
            "开启防抖",
            "打开防抖",
            "开启稳定模式",
            "打开稳定模式",
            "stability on",
            "enable stability",
            "enable stabilization",
        )
        stability_disable_tokens = (
            "关稳像",
            "关闭稳像",
            "关闭防抖",
            "关闭稳定模式",
            "stability off",
            "disable stability",
            "disable stabilization",
        )

        if cls._contains_any(text, lower, status_tokens):
            return [{"tool": "vision.gimbal.status", "arguments": {}, "reason": "gimbal status"}]

        if cls._contains_any(text, lower, stability_status_tokens):
            return [{"tool": "vision.gimbal.status", "arguments": {}, "reason": "gimbal stability status"}]

        if cls._contains_any(text, lower, stability_enable_tokens):
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "stability_enabled": 1,
                        "laser_enabled": 2,
                        "enabled": 2,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "gimbal stability enable",
                }
            ]

        if cls._contains_any(text, lower, stability_disable_tokens):
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "stability_enabled": 0,
                        "laser_enabled": 2,
                        "enabled": 2,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "gimbal stability disable",
                }
            ]

        if cls._contains_any(text, lower, disable_tokens):
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "enabled": 0,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "gimbal disable",
                }
            ]

        if cls._contains_any(text, lower, enable_tokens):
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "enabled": 1,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "gimbal enable",
                }
            ]

        if cls._contains_any(text, lower, stop_tokens):
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "gimbal stop",
                }
            ]

        speed = cls._extract_gimbal_speed_hint(text, lower, default_speed=AGENT_GIMBAL_RPM_LIMIT)
        yaw_rpm, pitch_rpm = cls._extract_gimbal_axis_rpm(text, lower)
        test_move_tokens = (
            "动一动",
            "动一下",
            "转一下",
            "轻轻动",
            "稍微动",
            "wiggle",
            "move a bit",
            "move a little",
        )

        left_tokens = ("左", "向左", "左转", "left")
        right_tokens = ("右", "向右", "右转", "right")
        up_tokens = ("上", "向上", "抬头", "上抬", "up")
        down_tokens = ("下", "向下", "低头", "下压", "down")

        if yaw_rpm is None:
            yaw = 0.0
            if cls._contains_any(text, lower, left_tokens):
                yaw -= speed
            if cls._contains_any(text, lower, right_tokens):
                yaw += speed
            yaw_rpm = yaw
        if pitch_rpm is None:
            pitch = 0.0
            if cls._contains_any(text, lower, up_tokens):
                pitch -= speed
            if cls._contains_any(text, lower, down_tokens):
                pitch += speed
            pitch_rpm = pitch

        if abs(float(yaw_rpm or 0.0)) <= 1e-6 and abs(float(pitch_rpm or 0.0)) <= 1e-6:
            if cls._contains_any(text, lower, test_move_tokens):
                return [
                    {
                        "tool": "vision.gimbal.command",
                        "arguments": {
                            "yaw_rpm": min(0.8, AGENT_GIMBAL_RPM_LIMIT),
                            "pitch_rpm": 0.0,
                            "auto_stop_ms": 220,
                            "reason": "intent-rule",
                        },
                        "reason": "gimbal test move",
                    }
                ]
            # Generic neutral command fallback for gimbal-domain requests that
            # lack explicit direction/velocity details.
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "auto_stop_ms": 0,
                        "reason": "intent-rule",
                    },
                    "reason": "gimbal neutral command",
                }
            ]

        duration_sec_hint = cls._extract_time_seconds_hint(text, lower)
        if cls._contains_any(text, lower, hold_tokens):
            auto_stop_ms = 0
        elif duration_sec_hint is not None and duration_sec_hint > 0:
            auto_stop_ms = int(max(0, min(5000, round(duration_sec_hint * 1000.0))))
        else:
            auto_stop_ms = 220
        return [
            {
                "tool": "vision.gimbal.command",
                "arguments": {
                    "yaw_rpm": max(-AGENT_GIMBAL_RPM_LIMIT, min(AGENT_GIMBAL_RPM_LIMIT, float(yaw_rpm))),
                    "pitch_rpm": max(-AGENT_GIMBAL_RPM_LIMIT, min(AGENT_GIMBAL_RPM_LIMIT, float(pitch_rpm))),
                    "auto_stop_ms": int(auto_stop_ms),
                    "reason": "intent-rule",
                },
                "reason": "gimbal semantic command",
            }
        ]

    @staticmethod
    def _split_terms_text(raw: str, *, max_terms: int = 8) -> list[str]:
        text = _safe_text(raw, limit=320)
        if not text:
            return []
        text = re.sub(r"[\"“”‘’'`]+", " ", text)
        text = re.sub(r"[，,、;；/|]+", " ", text)
        text = re.sub(r"\b(and|or|plus|with|then)\b", " ", text, flags=re.IGNORECASE)
        text = re.sub(r"(和|与|及|跟|还有|并且|并|再|然后|之后)", " ", text)
        text = re.sub(
            r"(摄像头|相机|镜头|监控|画面|画面里|画面中|画面内|图里|图中|里面|里边|里|中|一下|观察|检测|识别|目标|物体|内容|对象|camera|vision|snapshot)",
            " ",
            text,
            flags=re.IGNORECASE,
        )
        text = re.sub(
            r"(有没有|有无|是否有|在不在|在哪|在哪里|有吗|呢|吗|吧|呀|啊)",
            " ",
            text,
        )
        text = re.sub(r"(有几(个|只|辆|台|名)?|多少(个|只|辆|台|名)?|几个|几只|几辆|几台|几名)", " ", text)
        text = re.sub(r"(左边|右边|中间|前面|后面|门口|门外|门内|远处|近处|上方|下方|角落|画面左侧|画面右侧)", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            return []
        stop_words = {
            "有什么",
            "有无",
            "有没有",
            "是否有",
            "什么",
            "有吗",
            "吗",
            "呢",
            "请",
            "帮我",
            "帮",
            "一下",
            "下",
            "看",
            "看看",
            "一下子",
            "当前",
            "现在",
            "摄像头",
            "相机",
            "画面",
            "camera",
            "vision",
            "what",
            "which",
            "there",
            "inside",
            "object",
            "objects",
            "show",
            "please",
            "the",
            "a",
            "an",
        }
        out: list[str] = []
        for item in text.split(" "):
            term = _safe_text(item, limit=64).strip()
            term = re.sub(
                r"^(看下|看一下|看一看|看|找一下|找找|找|查一下|查找|查|检测|识别|observe|scan|detect|find|look\s*for|see|watch)\s*",
                "",
                term,
                flags=re.IGNORECASE,
            )
            term = re.sub(
                r"^(有没有|有无|是否有|有没|还有|除了|排除|不要|不看|别看|忽略|exclude|without|except|ignore|skip)\s*",
                "",
                term,
                flags=re.IGNORECASE,
            )
            term = term.lstrip("的").rstrip("的")
            term = re.sub(r"[呢吗嘛么啊呀吧啦噢哦哇哈]+$", "", term)
            term = term.strip(" .:：,-_")
            if not term:
                continue
            if term.lower() in stop_words:
                continue
            out.append(term)
            if len(out) >= max_terms:
                break
        return out

    @staticmethod
    def _normalize_camera_term(term: str) -> str:
        key = str(term or "").strip().lower()
        if not key:
            return ""
        canon = CAMERA_ALIAS_CANON_BY_TERM.get(key, key)
        if canon in CAMERA_CANON_LABEL_SET:
            return canon
        if key in CAMERA_CANON_LABEL_SET:
            return key
        return ""

    @staticmethod
    def _camera_capability_term_state() -> tuple[tuple[str, ...], tuple[str, ...], dict[str, str], dict[str, dict[str, Any]]]:
        with _CAMERA_CAPABILITY_STATE_LOCK:
            return (
                tuple(CAMERA_CAPABILITY_ASCII_TERMS),
                tuple(CAMERA_CAPABILITY_NON_ASCII_TERMS),
                dict(CAMERA_CAPABILITY_NAME_BY_TERM),
                {name: dict(meta) for name, meta in CAMERA_CAPABILITY_META_BY_NAME.items()},
            )

    @staticmethod
    def _capability_polarity_from_window(
        text: str,
        lower: str,
        *,
        start: int,
        end: int,
        ascii_term: bool,
    ) -> bool:
        if ascii_term:
            source = lower
            left = max(0, start - 24)
            right = min(len(source), end + 24)
            window = source[left:right]
            prefix = source[max(0, start - 20):start]
        else:
            source = text
            left = max(0, start - 8)
            right = min(len(source), end + 8)
            window = source[left:right]
            prefix = source[max(0, start - 8):start]
        if any(prefix.endswith(token) for token in ("不要", "别", "不看", "不识别", "不检测", "关闭", "停用", "禁用")):
            return False
        if any(prefix.endswith(token) for token in ("只看", "看", "识别", "检测", "开启", "打开", "启用")):
            return True
        if re.search(r"(without|disable|disabled|off|no)\s*$", prefix):
            return False
        if re.search(r"(only|with|enable|enabled|on|check|detect|find|see|watch)\s*$", prefix):
            return True
        negative_tokens = (
            "不要",
            "别",
            "不看",
            "不识别",
            "不检测",
            "关闭",
            "停用",
            "禁用",
            "without",
            "exclude",
            "disable",
            "off",
            "no ",
        )
        positive_tokens = (
            "开启",
            "打开",
            "启用",
            "看",
            "识别",
            "检测",
            "分析",
            "with",
            "enable",
            "on",
        )
        has_neg = any(token in window for token in negative_tokens)
        has_pos = any(token in window for token in positive_tokens)
        if has_neg and not has_pos:
            return False
        return True

    @classmethod
    def _extract_camera_capability_requests(cls, text: str, lower: str, *, max_caps: int = 6) -> dict[str, bool]:
        blob = _safe_text(text, limit=360)
        key_text = _safe_text(lower or blob.lower(), limit=360).lower()
        if not blob:
            return {}
        ascii_terms, non_ascii_terms, name_by_term, _meta_by_name = cls._camera_capability_term_state()
        if not name_by_term:
            return {}

        hits: list[tuple[int, int, str, bool]] = []
        for term in non_ascii_terms:
            name = name_by_term.get(term)
            if not name:
                continue
            start = 0
            while True:
                idx = blob.find(term, start)
                if idx < 0:
                    break
                hits.append((idx, idx + len(term), name, False))
                start = idx + max(1, len(term))

        for term in ascii_terms:
            name = name_by_term.get(term)
            if not name:
                continue
            pattern = rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])"
            for match in re.finditer(pattern, key_text):
                hits.append((match.start(), match.end(), name, True))

        if not hits:
            return {}
        hits.sort(key=lambda item: (item[0], item[1]))
        out: dict[str, bool] = {}
        for start, end, name, is_ascii in hits:
            if len(out) >= max_caps and name not in out:
                continue
            out[name] = cls._capability_polarity_from_window(
                blob,
                key_text,
                start=start,
                end=end,
                ascii_term=is_ascii,
            )
        return out

    @classmethod
    def _preferred_detector_for_capabilities(cls, capability_requests: dict[str, bool]) -> str:
        _, _, _, meta_by_name = cls._camera_capability_term_state()
        if not isinstance(capability_requests, dict) or not capability_requests:
            return "yolo_world"
        chosen: list[str] = []
        for name, enabled in capability_requests.items():
            if not bool(enabled):
                continue
            meta = meta_by_name.get(str(name))
            if not isinstance(meta, dict):
                continue
            detector = _safe_text(meta.get("detector"), limit=24).lower()
            if detector in ("none", "rect", "yolo", "yolo_world"):
                chosen.append(detector)
        if "yolo_world" in chosen:
            return "yolo_world"
        if chosen:
            return chosen[0]
        return "yolo_world"

    @staticmethod
    def _contains_camera_alias_term(text: str, lower: str) -> bool:
        _ = lower
        return bool(IntentRegistry._extract_alias_terms_from_text(text, text.lower(), max_terms=1))

    @classmethod
    def _extract_alias_terms_from_text(cls, text: str, lower: str, *, max_terms: int = 8) -> list[str]:
        blob = _safe_text(text, limit=360)
        key_text = _safe_text(lower or blob.lower(), limit=360).lower()
        if not blob:
            return []

        hits: list[tuple[int, int, str]] = []

        for term in CAMERA_ALIAS_NON_ASCII_TERMS:
            if not term:
                continue
            start = 0
            while True:
                idx = blob.find(term, start)
                if idx < 0:
                    break
                canon = cls._normalize_camera_term(CAMERA_ALIAS_CANON_BY_TERM.get(term, term))
                if canon:
                    hits.append((idx, -len(term), canon))
                start = idx + max(1, len(term))

        for term in CAMERA_ALIAS_ASCII_TERMS:
            if not term:
                continue
            pattern = rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])"
            for match in re.finditer(pattern, key_text):
                canon = cls._normalize_camera_term(CAMERA_ALIAS_CANON_BY_TERM.get(term, term))
                if canon:
                    hits.append((match.start(), -len(term), canon))

        if not hits:
            for cand in cls._split_terms_text(blob, max_terms=max_terms * 4):
                canon = cls._normalize_camera_term(cand)
                if not canon:
                    continue
                idx = key_text.find(cand.lower())
                hits.append((idx if idx >= 0 else 9999, -len(cand), canon))

        hits.sort(key=lambda item: (item[0], item[1], item[2]))
        out: list[str] = []
        seen: set[str] = set()
        for _, _, canon in hits:
            if canon in seen:
                continue
            seen.add(canon)
            out.append(canon)
            if len(out) >= max_terms:
                break
        return out

    @staticmethod
    def _pick_detector_from_text(text: str, lower: str, default: str) -> str:
        detector = default if default in ("none", "rect", "yolo", "yolo_world") else "none"
        has_yolo_token = any(token in lower for token in ("yolo11", "yolo-11", "yolo"))
        if any(token in lower for token in ("yolo world", "yolo_world", "world")) or any(
            token in text for token in ("世界模型", "世界检测")
        ):
            return "yolo_world"
        if any(
            token in lower
            for token in (
                "face detector",
                "detector face",
                "use face",
                "face mode",
                "face-only",
                "face only",
                "only face",
            )
        ) or any(token in text for token in ("人脸检测", "人脸模式", "只看人脸", "仅看人脸", "只看脸", "仅看脸")):
            return "face"
        if has_yolo_token and (
            any(token in lower for token in ("prompt", "提示词", "目标词"))
            or any(token in text for token in ("提示词", "目标词"))
        ):
            # In this project, prompt/filter semantics belong to YOLO-World.
            return "yolo_world"
        if any(token in lower for token in ("yolo11", "yolo-11", "use yolo11", "detector yolo", "纯yolo")) or any(
            token in text for token in ("yolo11", "只用yolo", "纯yolo")
        ):
            return "yolo"
        if any(token in lower for token in ("rect", "rectangle", "contour")) or any(
            token in text for token in ("矩形", "轮廓", "框选")
        ):
            return "rect"
        if any(token in lower for token in ("raw", "no detect", "no detection", "none")) or any(
            token in text for token in ("原图", "不检测", "关闭检测", "仅画面")
        ):
            return "none"
        return detector

    @classmethod
    def _infer_observe_target(cls, text: str, lower: str, include_terms: list[str], prompt: str) -> tuple[str, bool]:
        target_seed: list[str] = []
        for raw_term in include_terms[:8]:
            term = _safe_text(raw_term, limit=64)
            if not term:
                continue
            target_seed.append(term)
            if len(target_seed) >= 6:
                break

        prompt_text = _safe_text(prompt, limit=160)
        if (not target_seed) and prompt_text:
            prompt_terms = cls._extract_alias_terms_from_text(prompt_text, prompt_text.lower(), max_terms=6)
            for term in prompt_terms:
                if not term:
                    continue
                target_seed.append(term)
                if len(target_seed) >= 6:
                    break

        target_raw = ",".join(target_seed[:6]) if target_seed else cls._extract_gimbal_lock_target(text, lower)
        target, target_human = cls._normalize_gimbal_lock_target(target_raw)

        human_tokens = (
            "人脸",
            "脸部",
            "面部",
            "人物",
            "行人",
            "那个人",
            "这个人",
            "我的脸",
            "我脸",
            "person",
            "human",
            "people",
            "pedestrian",
            "my face",
            "that person",
            "this person",
        )

        look_me_short = bool(
            re.search(
                r"^\s*(看|看看|看下|看一下|观察|识别|检测|observe|detect|look(?:\s+at)?)\s*(我|我自己|本人|me|myself)\s*$",
                text,
                flags=re.IGNORECASE,
            )
        )

        if (not target_human) and target:
            if cls._contains_any(target, target.lower(), ("人脸", "脸部", "面部", "face", "head", "person", "human")):
                target = "person"
                target_human = True

        if (not target_human) and (look_me_short or cls._contains_any(text, lower, human_tokens)):
            if not target:
                target = "person"
            target_human = bool(target)
        return target, target_human

    @staticmethod
    def _extract_after_marker(text: str, markers: tuple[str, ...]) -> str:
        for marker in markers:
            idx = text.find(marker)
            if idx < 0:
                continue
            seg = text[idx + len(marker) :].strip()
            if seg:
                return seg
        return ""

    @classmethod
    def _extract_camera_targets(cls, text: str, lower: str) -> tuple[list[str], list[str], str, bool]:
        clear_tokens = (
            "取消过滤",
            "清空过滤",
            "清除过滤",
            "恢复全类别",
            "全类别",
            "看全部",
            "不过滤",
            "清空提示词",
            "清除提示词",
            "重置提示词",
            "清空目标词",
            "清除目标词",
            "重置目标词",
            "恢复默认提示词",
            "恢复默认目标词",
            "clear filter",
            "reset filter",
            "clear prompt",
            "reset prompt",
            "clear target",
            "reset target",
            "all classes",
        )
        clear_filter = cls._contains_any(text, lower, clear_tokens)

        prompt = ""
        include_terms: list[str] = []
        exclude_terms: list[str] = []

        include_only_patterns = (
            r"(?:除了|除开|除去)\s*([^，。！？!?；;]+?)\s*(?:都别看|都不看|都不要|都忽略|只看|仅看)",
            r"(?:except|only)\s+([^,.;!?]+)\s+(?:only|please|just)?",
        )
        for pattern in include_only_patterns:
            for match in re.findall(pattern, text, flags=re.IGNORECASE):
                include_terms.extend(cls._extract_alias_terms_from_text(str(match), str(match).lower(), max_terms=16))

        quoted = re.findall(r"[\"“”'‘’]([^\"“”'‘’]{1,48})[\"“”'‘’]", text)
        for q in quoted:
            include_terms.extend(cls._extract_alias_terms_from_text(q, q.lower(), max_terms=8))

        exclude_patterns = (
            r"(?:排除|不要看|不要|别看|不看|忽略|去掉)\s*([^，。！？!?；;]+)",
            r"(?:exclude|without|except|ignore|skip)\s+([^,.;!?]+)",
            r"(?:除了|除开|除去)\s*([^，。！？!?；;]+?)\s*(?:之外|以外)",
            r"(?:除了|除开|除去)\s*([^，。！？!?；;]+?)\s*都看",
        )
        for pattern in exclude_patterns:
            for match in re.findall(pattern, text, flags=re.IGNORECASE):
                exclude_terms.extend(cls._extract_alias_terms_from_text(str(match), str(match).lower(), max_terms=16))

        include_patterns = (
            r"(?:只看|只检测|只识别|只关注|仅看|仅检测|仅识别|仅关注|关注|检测|识别|找一下|找找|查找|查看|看看|看一下|看下|看|有没有|有无|是否有)\s*([^，。！？!?；;]+)",
            r"(?:only|just|detect|find|look\s*for|check|see|watch|show|is\s+there|are\s+there)\s+([^,.;!?]+)",
        )
        for pattern in include_patterns:
            for match in re.findall(pattern, text, flags=re.IGNORECASE):
                seg = _safe_text(match, limit=180).strip(" ：:，,。！？!?；;")
                if not seg:
                    continue
                if not prompt:
                    prompt = seg
                include_terms.extend(cls._extract_alias_terms_from_text(seg, seg.lower(), max_terms=16))

        if not include_terms and not exclude_terms:
            include_terms.extend(cls._extract_alias_terms_from_text(text, lower, max_terms=12))

        deduped_include: list[str] = []
        seen_include: set[str] = set()
        exclude_set = {str(v).lower() for v in exclude_terms}
        for term in include_terms:
            key = term.lower()
            if key.startswith(("排除", "不要", "不看", "忽略", "exclude ", "without ", "except ")):
                continue
            if key in seen_include:
                continue
            if key in exclude_set:
                continue
            seen_include.add(key)
            deduped_include.append(term)

        deduped_exclude: list[str] = []
        seen_exclude: set[str] = set()
        for term in exclude_terms:
            key = term.lower()
            if key in seen_exclude:
                continue
            seen_exclude.add(key)
            deduped_exclude.append(term)

        if deduped_include:
            prompt = ", ".join(deduped_include[:4])
        else:
            prompt = ""
        return deduped_include[:8], deduped_exclude[:8], prompt, clear_filter

    @classmethod
    def _looks_like_camera_freeform_query(cls, text: str, lower: str) -> bool:
        observe_tokens = (
            "看",
            "看看",
            "看一下",
            "看下",
            "查看",
            "观察",
            "检测",
            "识别",
            "拍照",
            "拍一张",
            "快照",
            "snapshot",
            "observe",
            "scan",
            "detect",
            "see",
            "look",
            "find",
        )
        question_tokens = (
            "有没有",
            "有无",
            "是否有",
            "有吗",
            "有几",
            "多少",
            "在哪",
            "在哪里",
            "where",
            "what",
            "is there",
            "are there",
            "any",
        )
        if cls._has_non_camera_context(text, lower):
            return False
        if len(text.strip()) > 36:
            return False
        has_observe = cls._contains_any(text, lower, observe_tokens)
        has_question = bool(
            cls._contains_any(text, lower, question_tokens)
            or re.search(r"[？?]$", text.strip())
            or re.search(r"有[^，。！？!?；;\s]{0,12}吗", text)
        )
        return bool(has_observe and has_question)

    @classmethod
    def _has_non_camera_context(cls, text: str, lower: str) -> bool:
        non_camera_tokens = (
            "电量",
            "battery",
            "续航",
            "充电",
            "cpu",
            "内存",
            "memory",
            "ram",
            "温度",
            "thermal",
            "temperature",
            "时间",
            "time",
            "日期",
            "date",
            "天气",
            "weather",
            "网速",
            "网络",
            "wifi",
            "ping",
            "npu",
            "磁盘",
            "存储",
            "硬盘",
        )
        return cls._contains_any(text, lower, non_camera_tokens)

    @classmethod
    def _is_camera_observe_query(cls, text: str, lower: str) -> bool:
        domain_tokens = (
            "摄像头",
            "相机",
            "镜头",
            "画面",
            "监控",
            "camera",
            "vision",
            "yolo",
        )
        observe_tokens = (
            "看",
            "查看",
            "看看",
            "看一下",
            "看下",
            "观察",
            "识别",
            "检测",
            "扫描",
            "observe",
            "scan",
            "有什么",
            "有无",
            "有没有",
            "是否有",
            "what do you see",
            "what is in",
            "拍照",
            "拍一张",
            "截图",
            "快照",
            "snapshot",
            "photo",
            "take photo",
            "see",
            "look",
            "find",
            "detect",
            "is there",
            "are there",
        )
        has_domain = cls._contains_any(text, lower, domain_tokens)
        if cls._has_non_camera_context(text, lower) and not has_domain:
            return False
        has_observe = cls._contains_any(text, lower, observe_tokens)
        has_alias = cls._contains_camera_alias_term(text, lower)
        capability_requests = cls._extract_camera_capability_requests(text, lower, max_caps=4)
        has_capability = bool(capability_requests)
        followup_short = bool(re.search(r"[呢吗嘛么啊呀吧][？?]?$", text.strip()))
        question_short = bool(
            re.search(r"(有无|有没有|是否有|有吗|在不在|在哪|在哪里|is there|are there|where)", lower)
            or re.search(r"有[^，。！？!?；;\s]{0,12}吗", text)
        )
        if has_domain and has_observe:
            return True
        if has_alias and (has_observe or followup_short or question_short):
            return True
        if has_capability and (has_observe or followup_short or question_short or has_domain):
            return True
        if cls._looks_like_camera_freeform_query(text, lower):
            return True
        return False

    @classmethod
    def _camera_semantic_actions(cls, text: str, lower: str, detector: str) -> list[dict[str, Any]]:
        domain_tokens = ("摄像头", "相机", "镜头", "画面", "监控", "camera", "vision", "yolo")
        has_domain = cls._contains_any(text, lower, domain_tokens)
        if cls._has_non_camera_context(text, lower) and not has_domain:
            return []
        lock_domain_tokens = ("锁定", "锁住", "追踪", "跟踪", "跟随", "跟拍", "云台", "gimbal", "lock", "track", "follow")
        explicit_observe_tokens = (
            "看",
            "看看",
            "看一下",
            "查看",
            "观察",
            "snapshot",
            "拍照",
            "拍一张",
            "observe",
            "scan",
            "detect",
            "look",
            "see",
        )
        has_lock_domain = cls._contains_any(text, lower, lock_domain_tokens) or (
            cls._contains_any(text, lower, ("锁",))
            and cls._contains_any(text, lower, ("激光", "laser", "云台", "gimbal", "追踪", "跟踪", "track", "follow"))
        )
        if has_lock_domain and not cls._contains_any(text, lower, explicit_observe_tokens):
            return []
        has_alias = cls._contains_camera_alias_term(text, lower)
        capability_requests = cls._extract_camera_capability_requests(text, lower)
        has_capability = bool(capability_requests)
        has_capability_positive = any(bool(v) for v in capability_requests.values())
        capability_observe_hint = bool(
            has_capability_positive
            and cls._contains_any(
                text,
                lower,
                (
                    "只看",
                    "仅看",
                    "看一下",
                    "看下",
                    "看看",
                    "观察",
                    "检测",
                    "识别",
                    "瞅一眼",
                    "瞧一眼",
                    "look at",
                    "take a look",
                    "observe",
                    "scan",
                    "detect",
                ),
            )
        )
        inferred_freeform = cls._looks_like_camera_freeform_query(text, lower)
        followup_short = bool(re.search(r"[呢吗嘛么啊呀吧][？?]?$", text.strip()))
        question_like = bool(re.search(r"(有无|有没有|是否有|在不在|在哪|看见|看到|发现|识别到|检测到|is there|are there)", lower))
        include_terms, exclude_terms, prompt, clear_filter = cls._extract_camera_targets(text, lower)
        _, human_observe_hint = cls._infer_observe_target(
            text,
            lower,
            include_terms=include_terms,
            prompt=prompt,
        )
        if cls._contains_any(text, lower, ("提示词", "目标词", "prompt")) and not (
            include_terms or exclude_terms or clear_filter
        ):
            prompt_query_tokens = (
                "查看",
                "查询",
                "状态",
                "是什么",
                "现在",
                "当前",
                "show",
                "get",
                "check",
                "view",
            )
            if cls._contains_any(text, lower, prompt_query_tokens) or cls._is_question_like(text, lower):
                return []
        if not has_domain and not has_alias and not inferred_freeform and not clear_filter and not has_capability and not human_observe_hint:
            return []
        if not has_domain and not inferred_freeform and not human_observe_hint:
            if len(text.strip()) > 24 and not question_like and not has_capability:
                return []
            if not (followup_short or question_like or has_capability or cls._is_camera_observe_query(text, lower)):
                return []
        observe_query = cls._is_camera_observe_query(text, lower)
        if cls._contains_any(text, lower, ("状态", "开关", "status")) and not (include_terms or exclude_terms or has_capability):
            return []
        # Capability terms alone (e.g. "我今天情绪不好") should not force camera observe.
        if not observe_query and not capability_observe_hint and not human_observe_hint and not (
            include_terms or exclude_terms or clear_filter
        ):
            return []

        actions: list[dict[str, Any]] = []
        if clear_filter:
            actions.append(
                {
                    "tool": "vision.yolo_world.filter.set",
                    "arguments": {"mode": "all", "reason": "intent-rule"},
                    "reason": "clear yolo_world filter",
                }
            )

        exclude_set = {item.lower() for item in exclude_terms}
        include_terms = [item for item in include_terms if item.lower() not in exclude_set]

        if exclude_terms and not include_terms:
            labels = [label for label in CAMERA_CANON_LABELS if label.lower() not in exclude_set]
            if labels:
                actions.append(
                    {
                        "tool": "vision.yolo_world.filter.set",
                        "arguments": {
                            "labels": ",".join(labels),
                            "reason": "intent-rule",
                        },
                        "reason": "exclude-only filter from semantic camera query",
                    }
                )
        elif include_terms or prompt:
            actions.append(
                {
                    "tool": "vision.yolo_world.prompt.set",
                    "arguments": {
                        "prompt": prompt,
                        "include_terms": include_terms,
                        "exclude_terms": exclude_terms,
                        "reason": "intent-rule",
                    },
                    "reason": "set yolo_world prompt",
                }
            )

        observe_tokens = ("再看", "再看一下", "看一下", "看看", "观察", "拍一张", "snapshot", "observe", "scan", "detect")
        should_observe = bool(
            observe_query
            or capability_observe_hint
            or human_observe_hint
            or cls._contains_any(text, lower, observe_tokens)
        )

        if not should_observe:
            return actions

        target_hint, target_human = cls._infer_observe_target(
            text,
            lower,
            include_terms=include_terms,
            prompt=prompt,
        )
        person_detail_names = {"wear_glasses", "emotion"}
        person_detail_enabled = any(bool(capability_requests.get(name)) for name in person_detail_names)
        if person_detail_enabled and (not target_human) and (not target_hint):
            # Person-detail capabilities imply a human target unless user explicitly asked for a non-human class.
            target_human = True
            target_hint = "person"
        explicit_detector = cls._pick_detector_from_text(text, lower, "none")
        obs_detector = cls._pick_detector_from_text(text, lower, detector)
        explicit_none = cls._contains_any(
            text,
            lower,
            ("原图", "不检测", "关闭检测", "仅画面", "raw", "no detect", "no detection"),
        )
        if explicit_none:
            obs_detector = "none"
        elif explicit_detector in ("face", "rect", "yolo", "yolo_world"):
            obs_detector = explicit_detector
        if obs_detector == "none" and not explicit_none:
            obs_detector = "face" if target_human else "yolo_world"
        if any(bool(v) for v in capability_requests.values()) and (not explicit_none):
            if target_human:
                if explicit_detector == "none" and obs_detector in ("none", "rect", "yolo", "yolo_world"):
                    obs_detector = "face"
            elif explicit_detector == "none":
                preferred_detector = cls._preferred_detector_for_capabilities(capability_requests)
                if preferred_detector in ("none", "rect", "yolo", "yolo_world"):
                    obs_detector = preferred_detector
        observe_args: dict[str, Any] = {"detector": obs_detector}
        detail_names = {"wear_glasses", "emotion"}
        detail_ignored = False
        for name, enabled in capability_requests.items():
            if (name in detail_names) and (not target_human):
                detail_ignored = True
                continue
            observe_args[name] = bool(enabled)
        if detail_ignored:
            observe_args["_warning"] = "person-only details ignored for non-human target"
        actions.append(
            {
                "tool": "vision.observe",
                "arguments": observe_args,
                "reason": "camera semantic observe",
            }
        )
        return actions

    def _build_command_rules(self) -> list[IntentRule]:
        rules: list[IntentRule] = []

        def memory_add_producer(text: str, lower: str, _detector: str) -> list[dict[str, Any]]:
            note = self._extract_memory_note(text, lower)
            if not note:
                return []
            return [{"tool": "memory.add", "arguments": {"text": note, "tags": ["tool-first"]}, "reason": "remember note"}]

        rules.append(
            IntentRule(
                rule_id="memory.add",
                priority=10,
                matcher=lambda text, lower: bool(self._extract_memory_note(text, lower)),
                producer=memory_add_producer,
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="memory.clear",
                priority=20,
                tokens=("清空记忆", "清除记忆", "忘掉全部", "clear memory"),
                producer=lambda _text, _lower, _detector: [{"tool": "memory.clear", "arguments": {}, "reason": "clear memory"}],
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="memory.stats",
                priority=22,
                tokens=("记忆状态", "memory stats", "记忆统计"),
                producer=lambda _text, _lower, _detector: [{"tool": "memory.stats", "arguments": {}, "reason": "memory stats"}],
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="memory.list",
                priority=24,
                tokens=("记忆列表", "memory list", "最近记忆"),
                producer=lambda _text, _lower, _detector: [{"tool": "memory.list", "arguments": {"limit": 20}, "reason": "memory list"}],
            )
        )

        def memory_search_producer(text: str, lower: str, _detector: str) -> list[dict[str, Any]]:
            query = self._extract_memory_search_query(text, lower)
            if not query:
                return []
            return [{"tool": "memory.search", "arguments": {"query": query, "limit": 12}, "reason": "memory search"}]

        rules.append(
            IntentRule(
                rule_id="memory.search",
                priority=26,
                matcher=lambda text, lower: bool(self._extract_memory_search_query(text, lower)),
                producer=memory_search_producer,
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="rgb.status",
                priority=30,
                tokens=("灯状态", "rgb状态", "rgb status", "led status"),
                producer=lambda _text, _lower, _detector: [{"tool": "rgb.status", "arguments": {}, "reason": "rgb status"}],
            )
        )

        def rgb_set_producer(text: str, lower: str, _detector: str) -> list[dict[str, Any]]:
            color = self._rgb_color_from_text(text, lower)
            if not color:
                return []
            return [{"tool": "rgb.set", "arguments": {"color": color, "persist": False}, "reason": "rgb set"}]

        rules.append(
            IntentRule(
                rule_id="rgb.set",
                priority=32,
                matcher=lambda text, lower: bool(self._rgb_color_from_text(text, lower)),
                producer=rgb_set_producer,
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.recover",
                priority=40,
                tokens=("恢复相机", "重置相机", "相机恢复", "recover camera", "reset camera"),
                producer=lambda _text, _lower, _detector: [{"tool": "vision.recover", "arguments": {"reason": "intent-rule"}, "reason": "vision recover"}],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.enable",
                priority=42,
                matcher=lambda text, lower: (
                    self._contains_any(
                        text,
                        lower,
                        ("开启相机", "打开相机", "开启视觉", "启用视觉", "enable camera", "enable vision"),
                    )
                    and (not self._is_camera_state_query(text, lower))
                ),
                producer=lambda _text, _lower, _detector: [
                    {
                        "tool": "vision.enabled.set",
                        "arguments": {"enabled": True, "reason": "intent-rule"},
                        "reason": "vision enable",
                    }
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.disable",
                priority=44,
                matcher=lambda text, lower: (
                    self._contains_any(
                        text,
                        lower,
                        ("关闭相机", "停用视觉", "关闭视觉", "disable camera", "disable vision", "stop camera"),
                    )
                    and (not self._is_camera_state_query(text, lower))
                ),
                producer=lambda _text, _lower, _detector: [
                    {
                        "tool": "vision.enabled.set",
                        "arguments": {"enabled": False, "reason": "intent-rule"},
                        "reason": "vision disable",
                    }
                ],
            )
        )

        def laser_blink_matcher(text: str, lower: str) -> bool:
            if self._is_question_like(text, lower):
                return False
            has_laser_domain = self._contains_any(text, lower, ("激光", "laser", "镭射"))
            if not has_laser_domain:
                has_laser_domain = bool(
                    re.search(r"^\s*光[^，。！？!?；;\n]{0,24}(闪|频率|周期|hz|赫兹)", text, flags=re.IGNORECASE)
                )
            if not has_laser_domain:
                return False
            if not self._contains_any(text, lower, ("闪", "闪烁", "blink", "频率", "周期", "hz", "赫兹")):
                return False
            lock_tokens = ("锁定", "追踪", "跟踪", "跟随", "跟拍", "lock", "track", "follow", "看着", "盯着")
            if self._contains_any(text, lower, lock_tokens):
                return False
            return True

        def laser_blink_producer(text: str, lower: str, _detector: str) -> list[dict[str, Any]]:
            blinks = self._extract_gimbal_lock_blinks(text, lower, default_value=6)
            period_ms = self._extract_gimbal_lock_blink_period_ms(text, lower)
            args: dict[str, Any] = {
                "blinks": int(max(1, min(12, blinks))),
                "reason": "intent-rule",
            }
            if period_ms is not None:
                args["period_ms"] = int(period_ms)
            return [
                {
                    "tool": "vision.gimbal.laser.blink",
                    "arguments": args,
                    "reason": "laser blink",
                }
            ]

        rules.append(
            IntentRule(
                rule_id="vision.laser.blink",
                priority=45,
                matcher=laser_blink_matcher,
                producer=laser_blink_producer,
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.laser.enable",
                priority=45,
                matcher=lambda text, lower: (self._laser_toggle_intent(text, lower) == 1),
                producer=lambda _text, _lower, _detector: [
                    {
                        "tool": "vision.gimbal.command",
                        "arguments": {
                            "yaw_rpm": 0,
                            "pitch_rpm": 0,
                            "laser_enabled": 1,
                            "enabled": 2,
                            "stability_enabled": 2,
                            "auto_stop_ms": 0,
                            "reason": "intent-rule",
                        },
                        "reason": "laser enable",
                    }
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.laser.disable",
                priority=45,
                matcher=lambda text, lower: (self._laser_toggle_intent(text, lower) == 0),
                producer=lambda _text, _lower, _detector: [
                    {
                        "tool": "vision.gimbal.command",
                        "arguments": {
                            "yaw_rpm": 0,
                            "pitch_rpm": 0,
                            "laser_enabled": 0,
                            "enabled": 2,
                            "stability_enabled": 2,
                            "auto_stop_ms": 0,
                            "reason": "intent-rule",
                        },
                        "reason": "laser disable",
                    }
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.stream.status",
                priority=45,
                matcher=lambda text, lower: self._contains_any(
                    text,
                    lower,
                    (
                        "预览开着吗",
                        "预览状态",
                        "相机流",
                        "视频流",
                        "直播流",
                        "stream status",
                        "preview status",
                        "preview on",
                    ),
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.profile.get", "arguments": {}, "reason": "vision stream status"}
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.camera.runtime.health",
                priority=45,
                matcher=lambda text, lower: (
                    self._contains_any(text, lower, ("摄像头", "相机", "镜头", "camera", "vision"))
                    and self._contains_any(
                        text,
                        lower,
                        (
                            "断流",
                            "掉流",
                            "卡住",
                            "卡了吗",
                            "卡顿",
                            "在工作",
                            "工作吗",
                            "在线吗",
                            "活着吗",
                            "stale",
                            "stream down",
                            "is working",
                        ),
                    )
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.profile.get", "arguments": {}, "reason": "vision runtime health"},
                    {"tool": "vision.observe", "arguments": {"detector": "none"}, "reason": "camera frame health"},
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.recover.status",
                priority=45,
                matcher=lambda text, lower: (
                    self._contains_any(text, lower, ("视觉", "相机", "摄像头", "camera", "vision", "recover"))
                    and self._contains_any(
                        text,
                        lower,
                        ("恢复过吗", "恢复了吗", "有没有恢复", "是否恢复", "recover过吗", "recovered"),
                    )
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.profile.get", "arguments": {}, "reason": "vision recover status"},
                    {"tool": "vision.enabled.get", "arguments": {}, "reason": "vision enable status"},
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.runtime.status",
                priority=45,
                matcher=lambda text, lower: self._contains_any(
                    text,
                    lower,
                    (
                        "yolo11还是yolo_world",
                        "yolo还是yolo_world",
                        "检测模式",
                        "yolo后端",
                        "yolo backend",
                        "detector mode",
                    ),
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.profile.get", "arguments": {}, "reason": "vision runtime status"}
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.gimbal.lock.laser.question",
                priority=45,
                matcher=lambda text, lower: (
                    self._contains_any(text, lower, ("锁", "锁定", "追踪", "跟踪", "lock", "track", "follow"))
                    and self._contains_any(text, lower, ("激光", "laser"))
                    and self._is_question_like(text, lower)
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.gimbal.lock.status", "arguments": {}, "reason": "gimbal lock status"},
                    {"tool": "vision.gimbal.status", "arguments": {}, "reason": "laser status"},
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.gimbal.orientation.status",
                priority=45,
                matcher=lambda text, lower: (
                    self._contains_any(text, lower, ("云台", "gimbal"))
                    and self._contains_any(
                        text,
                        lower,
                        (
                            "朝哪",
                            "朝哪边",
                            "现在朝哪边",
                            "方向",
                            "朝向",
                            "姿态",
                            "direction",
                            "heading",
                        ),
                    )
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.gimbal.status", "arguments": {}, "reason": "gimbal orientation status"}
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.laser.status",
                priority=45,
                matcher=lambda text, lower: self._contains_any(
                    text,
                    lower,
                    (
                        "激光状态",
                        "激光开了吗",
                        "激光关了吗",
                        "激光现在",
                        "laser status",
                        "laser on",
                        "laser off",
                    ),
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.gimbal.status", "arguments": {}, "reason": "laser status"}
                ],
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.status",
                priority=46,
                matcher=lambda text, lower: (
                    self._contains_any(
                        text,
                        lower,
                        ("视觉状态", "相机状态", "摄像头状态", "视觉开关", "vision status", "camera status", "camera enabled"),
                    )
                    or self._is_camera_state_query(text, lower)
                ),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.enabled.get", "arguments": {}, "reason": "vision status"}
                ],
            )
        )

        def yolo_prompt_get_matcher(text: str, lower: str) -> bool:
            prompt_domain = self._contains_any(
                text,
                lower,
                (
                    "提示词",
                    "目标词",
                    "prompt",
                ),
            )
            if not prompt_domain:
                return False
            set_tokens = ("设置", "设为", "改为", "加上", "加入", "添加", "set", "update")
            clear_tokens = ("清空", "清除", "重置", "恢复", "clear", "reset", "remove", "delete")
            if self._contains_any(text, lower, set_tokens) or self._contains_any(text, lower, clear_tokens):
                return False
            query_tokens = (
                "查看",
                "查询",
                "状态",
                "是什么",
                "现在",
                "当前",
                "show",
                "get",
                "check",
                "view",
                "status",
            )
            return bool(self._contains_any(text, lower, query_tokens) or self._is_question_like(text, lower))

        rules.append(
            IntentRule(
                rule_id="vision.yolo_world.prompt.get",
                priority=47,
                matcher=yolo_prompt_get_matcher,
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.yolo_world.prompt.get", "arguments": {}, "reason": "yolo_world prompt status"}
                ],
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.yolo_world.filter.get",
                priority=47,
                tokens=("过滤状态", "类别过滤", "filter状态", "vision filter", "camera filter"),
                producer=lambda _text, _lower, _detector: [
                    {"tool": "vision.yolo_world.filter.get", "arguments": {}, "reason": "yolo_world filter status"}
                ],
            )
        )

        def yolo_prompt_clear_matcher(text: str, lower: str) -> bool:
            prompt_domain = self._contains_any(text, lower, ("提示词", "目标词", "prompt"))
            if not prompt_domain:
                return False
            clear_tokens = ("清空", "清除", "重置", "恢复默认", "clear", "reset", "remove", "delete")
            return self._contains_any(text, lower, clear_tokens)

        rules.append(
            IntentRule(
                rule_id="vision.yolo_world.prompt.clear",
                priority=47,
                matcher=yolo_prompt_clear_matcher,
                producer=lambda _text, _lower, _detector: [
                    {
                        "tool": "vision.yolo_world.filter.set",
                        "arguments": {"mode": "all", "reason": "intent-rule"},
                        "reason": "clear yolo_world prompt/filter",
                    }
                ],
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.yolo_world.filter.clear",
                priority=47,
                tokens=("清空过滤", "清除过滤", "重置过滤", "clear filter", "reset filter", "恢复全类别"),
                producer=lambda _text, _lower, _detector: [
                    {
                        "tool": "vision.yolo_world.filter.set",
                        "arguments": {"mode": "all", "reason": "intent-rule"},
                        "reason": "clear yolo_world filter",
                    }
                ],
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.stream.on",
                priority=48,
                tokens=("开启预览", "打开预览", "开预览", "stream on", "enable stream"),
                producer=lambda _text, _lower, _detector: [{"tool": "vision.stream.set", "arguments": {"enabled": True, "reason": "intent-rule"}, "reason": "stream on"}],
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.stream.off",
                priority=50,
                tokens=("关闭预览", "关预览", "停止预览", "stream off", "disable stream"),
                producer=lambda _text, _lower, _detector: [{"tool": "vision.stream.set", "arguments": {"enabled": False, "reason": "intent-rule"}, "reason": "stream off"}],
            )
        )

        def vision_profile_set_producer(text: str, lower: str, _detector: str) -> list[dict[str, Any]]:
            profile = self._pick_profile_from_text(text, lower)
            if not profile:
                return []
            return [{"tool": "vision.profile.set", "arguments": {"name": profile}, "reason": f"profile set {profile}"}]

        def vision_profile_set_matcher(text: str, lower: str) -> bool:
            profile = self._pick_profile_from_text(text, lower)
            if not profile:
                return False
            context_tokens = (
                "模式",
                "配置",
                "画质",
                "清晰度",
                "分辨率",
                "帧率",
                "fps",
                "profile",
                "切到",
                "切换",
                "改成",
            )
            if self._contains_any(text, lower, context_tokens):
                return True
            plain = re.sub(r"\s+", "", lower)
            return plain in ("stable", "smooth", "clear60", "fullhd30")

        rules.append(
            IntentRule(
                rule_id="vision.profile.set",
                priority=52,
                matcher=vision_profile_set_matcher,
                producer=vision_profile_set_producer,
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.gimbal.lock.semantic",
                priority=53,
                matcher=lambda text, lower: bool(self._gimbal_lock_semantic_actions(text, lower)),
                producer=lambda text, lower, _detector: self._gimbal_lock_semantic_actions(text, lower),
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.gimbal.semantic",
                priority=54,
                matcher=lambda text, lower: bool(self._gimbal_semantic_actions(text, lower)),
                producer=lambda text, lower, _detector: self._gimbal_semantic_actions(text, lower),
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.profile.get",
                priority=54,
                tokens=("当前模式", "当前配置", "vision profile", "profile status", "profile"),
                producer=lambda _text, _lower, _detector: [{"tool": "vision.profile.get", "arguments": {}, "reason": "profile get"}],
            )
        )

        def vision_what_you_see_matcher(text: str, lower: str) -> bool:
            if self._contains_any(
                text,
                lower,
                (
                    "你看到什么了",
                    "你看到了什么",
                    "你看见什么了",
                    "你看见了什么",
                    "看到了什么",
                    "看到什么了",
                    "看见什么了",
                    "看见了什么",
                    "what do you see",
                    "what can you see",
                ),
            ):
                return True
            return False

        def vision_what_you_see_producer(text: str, lower: str, detector: str) -> list[dict[str, Any]]:
            observe_detector = self._pick_detector_from_text(text, lower, detector)
            explicit_none = self._contains_any(
                text,
                lower,
                ("原图", "不检测", "关闭检测", "仅画面", "raw", "no detect", "no detection"),
            )
            if observe_detector in ("none", "rect") and not explicit_none:
                observe_detector = "yolo_world"
            return [
                {
                    "tool": "vision.observe",
                    "arguments": {"detector": observe_detector},
                    "reason": "vision what-you-see query",
                }
            ]

        rules.append(
            IntentRule(
                rule_id="vision.observe.what_you_see",
                priority=55,
                matcher=vision_what_you_see_matcher,
                producer=vision_what_you_see_producer,
            )
        )

        rules.append(
            IntentRule(
                rule_id="vision.observe.semantic",
                priority=56,
                matcher=lambda text, lower: bool(self._camera_semantic_actions(text, lower, "none")),
                producer=lambda text, lower, detector: self._camera_semantic_actions(text, lower, detector),
            )
        )

        rules.append(
            self._keyword_rule(
                rule_id="vision.observe",
                priority=57,
                tokens=("observe", "what do you see", "camera snapshot", "vision snapshot"),
                producer=lambda _text, _lower, detector: [{"tool": "vision.observe", "arguments": {"detector": detector}, "reason": "vision observe"}],
            )
        )

        return sorted(rules, key=lambda item: item.priority)

    @classmethod
    def _infer_time_query_part(cls, text: str, lower: str) -> str:
        has_weekday = bool(
            re.search(
                r"(星期(?:几|[一二三四五六日天])?|周(?:几|[一二三四五六日天])?|礼拜(?:几|[一二三四五六日天])?|weekday|day of week)",
                text,
                flags=re.IGNORECASE,
            )
        )
        has_date = bool(re.search(r"(几号|几月几号|几月几日|日期|date|what date)", text, flags=re.IGNORECASE))
        has_time = bool(re.search(r"(几点|几时|时间|time|clock|what time)", lower, flags=re.IGNORECASE))
        if has_date and has_weekday:
            return "date_weekday"
        if has_weekday and has_time:
            return "datetime"
        if has_date and has_time:
            return "datetime"
        if has_weekday:
            return "weekday"
        if has_date:
            return "date"
        if has_time:
            return "time"
        return "datetime"

    def _build_status_rules(self) -> list[IntentRule]:

        time_keywords = (
            "时间",
            "几点",
            "现在几号",
            "今天几号",
            "今天几月几号",
            "今天几月几日",
            "什么时候",
            "啥时候",
            "何时",
            "现在日期",
            "当前日期",
            "日期",
            "几号",
            "几月几号",
            "几月几日",
            "星期几",
            "周几",
            "礼拜几",
            "什么日子",
            "today",
            "date",
            "time",
            "clock",
            "current time",
            "what day is it",
            "what date is it",
            "day of week",
        )
        thermal_keywords = (
            "温度",
            "发热",
            "热",
            "烫",
            "烫不烫",
            "thermal",
            "temperature",
            "temp",
            "cpu temperature",
        )
        cpu_keywords = (
            "cpu",
            "处理器",
            "负载",
            "cpu占用",
            "cpu使用率",
            "cpu usage",
            "cpu utilization",
            "utilization",
        )
        mem_keywords = (
            "内存",
            "ram",
            "memory",
            "mem",
            "内存占用",
            "内存使用率",
        )
        npu_keywords = (
            "npu",
            "rknpu",
            "tops",
            "ai core",
            "神经网络处理器",
            "npu usage",
            "npu占用",
        )

        def is_time_query(text: str, lower: str) -> bool:
            if text in ("今天", "今天?", "今天？", "today", "date", "time"):
                return True
            if self._contains_any(text, lower, time_keywords):
                return True
            if re.search(r"(今天|现在).*(几号|日期|星期几|周几|礼拜几|什么日子|什么时候|啥时候|何时)", text):
                return True
            if re.search(r"(what day is it|what date is it|what time is it|today\\??)$", lower):
                return True
            return False

        def metric_matcher(text: str, lower: str) -> bool:
            return any(
                (
                    is_time_query(text, lower),
                    self._contains_any(text, lower, thermal_keywords),
                    self._contains_any(text, lower, cpu_keywords),
                    self._contains_any(text, lower, mem_keywords),
                    self._contains_any(text, lower, npu_keywords),
                )
            )

        def metric_producer(text: str, lower: str, _detector: str) -> list[dict[str, Any]]:
            actions: list[dict[str, Any]] = []
            if is_time_query(text, lower):
                time_part = self._infer_time_query_part(text, lower)
                actions.append(
                    {
                        "tool": "system.time",
                        "arguments": {"part": time_part},
                        "reason": "time query",
                    }
                )
            if self._contains_any(text, lower, thermal_keywords):
                actions.append({"tool": "system.thermal", "arguments": {}, "reason": "thermal query"})
            if self._contains_any(text, lower, npu_keywords):
                actions.append({"tool": "system.npu", "arguments": {}, "reason": "npu query"})
            if self._contains_any(text, lower, mem_keywords):
                actions.append({"tool": "system.mem", "arguments": {}, "reason": "memory query"})
            if self._contains_any(text, lower, cpu_keywords):
                actions.append({"tool": "system.cpu", "arguments": {}, "reason": "cpu query"})
            return actions

        return [
            IntentRule(
                rule_id="metrics.bundle",
                priority=100,
                matcher=metric_matcher,
                producer=metric_producer,
            )
        ]

    def plan(self, query: str, detector: str, max_actions: int) -> tuple[list[dict[str, Any]], list[str]]:
        text = str(query or "").strip()
        lower = text.lower()
        warnings: list[str] = []
        proposals: list[dict[str, Any]] = []
        seen: set[str] = set()

        def push(items: list[dict[str, Any]]) -> None:
            for item in items:
                tool = _safe_text(item.get("tool"), limit=80)
                args = item.get("arguments") if isinstance(item.get("arguments"), dict) else {}
                reason = _safe_text(item.get("reason"), limit=120)
                if not tool:
                    continue
                dedupe = f"{tool}:{json.dumps(args, sort_keys=True, ensure_ascii=True)}"
                if dedupe in seen:
                    continue
                seen.add(dedupe)
                proposals.append({"tool": tool, "arguments": args, "reason": reason})

        for rule in self.command_rules:
            if rule.matcher(text, lower):
                push(rule.producer(text, lower, detector))

        for rule in self.status_rules:
            if rule.matcher(text, lower):
                push(rule.producer(text, lower, detector))

        keep = _clamp_int(max_actions, default=4, min_value=1, max_value=8)
        if len(proposals) > keep:
            warnings.append(f"actions trimmed from {len(proposals)} to {keep}")
            proposals = proposals[:keep]

        return proposals, warnings


class SemanticIntentRouter:
    def __init__(
        self,
        *,
        enabled: bool,
        model_name_or_path: str,
        min_score: float,
        min_margin: float,
        use_npu: bool,
        local_files_only: bool,
        classifier_enabled: bool,
        classifier_path: str,
        classifier_min_prob: float,
        model_only: bool,
    ) -> None:
        self.enabled = bool(enabled) and (np is not None)
        self.model_name_or_path = _safe_text(model_name_or_path, limit=600)
        self.min_score = float(min_score)
        self.min_margin = float(min_margin)
        self.use_npu = bool(use_npu)
        self.local_files_only = bool(local_files_only)
        self.classifier_enabled = bool(classifier_enabled)
        self.classifier_path = _safe_text(classifier_path, limit=800)
        self.classifier_min_prob = float(classifier_min_prob)
        self.model_only = bool(model_only)
        self._lock = threading.Lock()
        self._model: Any | None = None
        self._prototypes_matrix: Any | None = None
        self._prototype_intents: list[str] = []
        self._classifier_payload: dict[str, Any] | None = None
        self._stats: dict[str, Any] = {
            "ready": False,
            "load_error": "",
            "load_ms": 0.0,
            "hits": 0,
            "misses": 0,
            "last_intent": "",
            "last_score": 0.0,
            "last_margin": 0.0,
            "backend": "",
            "classifier_ready": False,
            "classifier_error": "",
            "classifier_hits": 0,
            "classifier_misses": 0,
            "classifier_last_intent": "",
            "classifier_last_prob": 0.0,
            "classifier_last_margin": 0.0,
            "classifier_vectorizer_enabled": False,
            "action_gate_enabled": False,
            "action_gate_threshold": 0.5,
            "action_gate_last_prob": 0.0,
        }
        self._catalog = self._build_catalog()

    @staticmethod
    def _build_catalog() -> dict[str, dict[str, Any]]:
        return {
            "system.time": {
                "guard": ("时间", "几点", "日期", "星期", "time", "date", "clock", "weekday"),
                "prototypes": [
                    "现在几点",
                    "报一下当前时间",
                    "今天几号",
                    "今天星期几",
                    "what time is it now",
                    "tell me current time",
                ],
            },
            "system.cpu": {
                "guard": ("cpu", "处理器", "占用", "负载", "usage"),
                "prototypes": [
                    "查看cpu占用",
                    "看下处理器使用率",
                    "cpu usage now",
                ],
            },
            "system.mem": {
                "guard": ("内存", "memory", "mem", "ram"),
                "prototypes": [
                    "查看内存占用",
                    "当前内存情况",
                    "memory usage now",
                ],
            },
            "system.npu": {
                "guard": ("npu", "推理", "算力"),
                "prototypes": [
                    "查看npu占用",
                    "npu现在忙吗",
                    "current npu usage",
                ],
            },
            "system.thermal": {
                "guard": ("温度", "发热", "热", "烫", "thermal", "temperature", "temp"),
                "prototypes": [
                    "查看设备温度",
                    "现在温度多少",
                    "机器现在烫不烫",
                    "设备热不热",
                    "device temperature now",
                ],
            },
            "system.summary": {
                "guard": (
                    "汇总",
                    "摘要",
                    "summary",
                    "cpu",
                    "mem",
                    "内存",
                    "npu",
                    "系统状态",
                    "状态总览",
                    "system status",
                    "overall status",
                    "health",
                ),
                "prototypes": [
                    "给我一个cpu内存npu摘要",
                    "汇总系统状态",
                    "system status summary",
                    "查看当前系统状态",
                    "系统状态总览",
                    "show current system status",
                    "overall system health",
                ],
            },
            "vision.enabled.get": {
                "guard": ("视觉", "相机", "摄像头", "vision", "camera", "状态"),
                "prototypes": [
                    "查看摄像头状态",
                    "视觉是否启用",
                    "camera status",
                ],
            },
            "vision.observe": {
                "guard": (
                    "画面",
                    "观察",
                    "看看",
                    "看一眼",
                    "检测",
                    "识别",
                    "摄像头",
                    "相机",
                    "镜头",
                    "脸色",
                    "表情",
                    "情绪",
                    "眼镜",
                    "抬头",
                    "低头",
                    "observe",
                    "camera",
                ),
                "prototypes": [
                    "观察画面",
                    "看看摄像头里有什么",
                    "麻烦看一眼摄像头现在啥情况",
                    "看下摄像头现在情况",
                    "看我脸色",
                    "看我有没有戴眼镜",
                    "看下我是不是抬头低头",
                    "check camera view",
                ],
            },
            "vision.observe.raw": {
                "guard": (
                    "原图",
                    "原始画面",
                    "原始图",
                    "原始帧",
                    "raw",
                    "raw frame",
                    "no detect",
                    "不检测",
                    "不要检测",
                    "不带检测",
                    "不做检测",
                    "仅画面",
                ),
                "prototypes": [
                    "给我一张原图",
                    "抓一帧原始画面",
                    "来张不带检测的原图",
                    "给我原始帧",
                    "raw camera frame no detection",
                ],
            },
            "vision.gimbal.laser.enable": {
                "guard": ("激光", "镭射", "laser", "打开", "开启", "on"),
                "prototypes": [
                    "打开激光",
                    "给我把激光打开",
                    "开启云台激光",
                    "turn laser on",
                ],
            },
            "vision.gimbal.laser.disable": {
                "guard": ("激光", "镭射", "laser", "关闭", "关掉", "off"),
                "prototypes": [
                    "关闭激光",
                    "把激光关掉",
                    "云台激光先关掉",
                    "turn laser off",
                ],
            },
            "vision.gimbal.laser.status": {
                "guard": ("激光", "镭射", "laser", "状态", "开着", "关着"),
                "prototypes": [
                    "激光现在开着吗",
                    "查看激光状态",
                    "laser status",
                ],
            },
            "vision.gimbal.laser.blink": {
                "guard": ("激光", "镭射", "laser", "闪", "闪烁", "blink", "频率", "hz", "赫兹"),
                "prototypes": [
                    "激光闪烁五次",
                    "让激光按2hz闪",
                    "激光每0.5秒闪一下",
                    "blink laser",
                ],
            },
            "vision.gimbal.lock.start": {
                "guard": ("锁定", "跟踪", "追踪", "跟随", "跟拍", "lock", "track", "follow", "看着"),
                "prototypes": [
                    "锁定人脸并跟踪",
                    "锁定那只狗",
                    "锁定这个物体",
                    "start gimbal tracking",
                ],
            },
            "chat.smalltalk": {
                "guard": (
                    "如果你",
                    "假如你",
                    "要是你",
                    "if you",
                    "would you",
                    "你是谁",
                    "你会不会",
                    "你最怕",
                    "诗人",
                    "记仇",
                ),
                "prototypes": [
                    "如果你是一只猫你会先做什么",
                    "你是谁",
                    "你会不会偷偷记仇",
                    "你最怕听到什么命令",
                    "你能不能假装自己是诗人说一句",
                    "would you get annoyed if I ask who you are repeatedly",
                ],
            },
        }

    @staticmethod
    def _l2_normalize(vec: Any) -> Any:
        if np is None:
            return vec
        arr = np.asarray(vec, dtype=np.float32)
        denom = float(np.linalg.norm(arr) or 0.0)
        if denom <= 1e-12:
            return arr
        return arr / denom

    def _query_has_guard(self, intent: str, query_text: str, query_lower: str) -> bool:
        meta = self._catalog.get(intent) if isinstance(self._catalog.get(intent), dict) else {}
        guard_vals = meta.get("guard") if isinstance(meta.get("guard"), tuple) else ()
        if not guard_vals:
            return True
        for token in guard_vals:
            if not token:
                continue
            if token.isascii():
                if token in query_lower:
                    return True
            elif token in query_text:
                return True
        return False

    def _intent_to_actions(
        self,
        intent: str,
        query: str,
        detector: str,
        *,
        model_only: bool,
    ) -> list[dict[str, Any]]:
        low = str(query or "").lower()
        if intent == "system.time":
            part = "datetime" if model_only else IntentRegistry._infer_time_query_part(query, low)
            return [{"tool": "system.time", "arguments": {"part": part}, "reason": "semantic intent embed"}]
        if intent == "system.cpu":
            return [{"tool": "system.cpu", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "system.mem":
            return [{"tool": "system.mem", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "system.npu":
            return [{"tool": "system.npu", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "system.thermal":
            return [{"tool": "system.thermal", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "system.summary":
            return [
                {"tool": "system.npu", "arguments": {}, "reason": "semantic intent embed"},
                {"tool": "system.mem", "arguments": {}, "reason": "semantic intent embed"},
                {"tool": "system.cpu", "arguments": {}, "reason": "semantic intent embed"},
            ]
        if intent == "vision.enabled.get":
            return [{"tool": "vision.enabled.get", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "vision.observe":
            pose_requested = IntentRegistry._contains_any(
                query,
                low,
                ("抬头", "低头", "向左看", "向右看", "face pose", "head pose"),
            )
            if re.search(
                r"(原图|原始画面|原始图|原始帧|raw(?:\s*frame)?|no\s*detect|不检测|不要检测|仅画面)",
                low,
                flags=re.IGNORECASE,
            ):
                obs_detector = "none"
            else:
                obs_detector = detector if detector != "none" else "yolo_world"
                if model_only:
                    explicit_detector = IntentRegistry._pick_detector_from_text(query, low, "none")
                    if explicit_detector in ("face", "rect", "yolo", "yolo_world"):
                        obs_detector = explicit_detector
                    else:
                        capability_requests = IntentRegistry._extract_camera_capability_requests(query, low, max_caps=8)
                        _, target_human = IntentRegistry._infer_observe_target(
                            query,
                            low,
                            include_terms=[],
                            prompt="",
                        )
                        person_detail_enabled = any(
                            bool(capability_requests.get(name))
                            for name in ("wear_glasses", "emotion")
                        )
                        if person_detail_enabled and (not target_human):
                            target_human = True
                        if pose_requested and (not target_human):
                            target_human = True
                        if target_human:
                            obs_detector = "face"
                        elif any(bool(v) for v in capability_requests.values()):
                            obs_detector = IntentRegistry._preferred_detector_for_capabilities(capability_requests)
            return [
                {
                    "tool": "vision.observe",
                    "arguments": {"detector": obs_detector},
                    "reason": "semantic intent embed",
                }
            ]
        if intent == "vision.observe.raw":
            return [
                {
                    "tool": "vision.observe",
                    "arguments": {"detector": "none"},
                    "reason": "semantic intent embed",
                }
            ]
        if intent == "vision.gimbal.command":
            if not model_only:
                actions = IntentRegistry._gimbal_semantic_actions(query, low)
                if actions:
                    return actions
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {"reason": "semantic intent embed"},
                    "reason": "gimbal semantic normalize",
                }
            ]
        if intent == "vision.gimbal.laser.enable":
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "auto_stop_ms": 0,
                        "laser_enabled": 1,
                        "reason": "semantic intent embed",
                    },
                    "reason": "laser enable",
                }
            ]
        if intent == "vision.gimbal.laser.disable":
            return [
                {
                    "tool": "vision.gimbal.command",
                    "arguments": {
                        "yaw_rpm": 0.0,
                        "pitch_rpm": 0.0,
                        "auto_stop_ms": 0,
                        "laser_enabled": 0,
                        "reason": "semantic intent embed",
                    },
                    "reason": "laser disable",
                }
            ]
        if intent == "vision.gimbal.laser.status":
            return [{"tool": "vision.gimbal.status", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "vision.gimbal.laser.blink":
            blinks = IntentRegistry._extract_gimbal_lock_blinks(query, low, default_value=6)
            period_ms = IntentRegistry._extract_gimbal_lock_blink_period_ms(query, low)
            args: dict[str, Any] = {
                "blinks": int(max(1, min(12, blinks))),
                "reason": "semantic intent embed",
            }
            if period_ms is not None:
                half_ms = int(max(40, min(2000, round(float(period_ms) * 0.5))))
                args["laser_on_ms"] = half_ms
                args["laser_off_ms"] = half_ms
            return [{"tool": "vision.gimbal.laser.blink", "arguments": args, "reason": "semantic intent embed"}]
        if intent == "vision.gimbal.lock.start":
            target = IntentRegistry._extract_gimbal_lock_target(query, low)
            target, target_human = IntentRegistry._normalize_gimbal_lock_target(target)
            if target:
                target_low = target.lower()
                if (
                    ("我" in target)
                    or ("自己" in target)
                    or ("本人" in target)
                    or ("me" in target_low)
                    or ("myself" in target_low)
                ):
                    target = "person"
                    target_human = True
                target_tokens = {str(item or "").strip().lower() for item in target.split(",") if str(item or "").strip()}
                animal_generic_tokens = {"动物", "宠物", "animal", "pet"}
                object_generic_tokens = {"物品", "物体", "目标物", "东西", "object", "item", "target"}
                if target_tokens & animal_generic_tokens:
                    target = "cat,dog,bird"
                    target_human = False
                elif target_tokens & object_generic_tokens:
                    target = "car,bottle,cup,chair,backpack,suitcase"
                    target_human = False
                elif "person" in target_tokens:
                    target_human = True
                elif IntentRegistry._contains_any(
                    target,
                    target.lower(),
                    ("我", "自己", "人脸", "脸", "person", "human", "face", "head"),
                ):
                    target = "person"
                    target_human = True
            if (not target) and IntentRegistry._contains_any(
                query,
                low,
                (
                    "人脸",
                    "脸部",
                    "脸",
                    "face",
                    "head",
                    "person",
                    "human",
                    "行人",
                    "跟着我",
                    "看着我",
                    "track me",
                    "follow me",
                    "watch me",
                ),
            ):
                target = "person"
                target_human = True
            elif (not target) and IntentRegistry._contains_any(
                query,
                low,
                ("动物", "宠物", "猫", "狗", "鸟", "cat", "dog", "bird", "animal", "pet"),
            ):
                target = "cat,dog,bird"
            elif (not target) and IntentRegistry._contains_any(
                query,
                low,
                ("物品", "物体", "东西", "目标物", "object", "item"),
            ):
                target = "car,bottle,cup,chair,backpack,suitcase"
            explicit_detector = IntentRegistry._pick_detector_from_text(query, low, "none")
            if explicit_detector in ("face", "yolo", "yolo_world"):
                lock_detector = explicit_detector
            else:
                lock_detector = "auto"
            args: dict[str, Any] = {
                "detector": lock_detector,
                "reason": "semantic intent embed",
            }
            if target:
                args["target"] = target
            return [{"tool": "vision.gimbal.lock.start", "arguments": args, "reason": "semantic intent embed"}]
        if intent == "vision.gimbal.lock.status":
            return [{"tool": "vision.gimbal.lock.status", "arguments": {}, "reason": "semantic intent embed"}]
        if intent == "vision.gimbal.lock.stop":
            return [
                {
                    "tool": "vision.gimbal.lock.stop",
                    "arguments": {"wait": False, "reason": "semantic intent embed"},
                    "reason": "semantic intent embed",
                }
            ]
        return []

    @staticmethod
    def _is_non_action_intent(intent: str) -> bool:
        return intent in ("chat.smalltalk",)

    def _load_classifier_payload(self) -> tuple[bool, str]:
        if not self.classifier_enabled:
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "disabled"
            return False, "disabled"
        if self._classifier_payload is not None:
            return True, ""
        path_text = _safe_text(self.classifier_path, limit=800)
        if not path_text:
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "empty classifier path"
            return False, "empty classifier path"
        if joblib is None:
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "joblib unavailable"
            return False, "joblib unavailable"
        path = Path(path_text)
        if not path.exists():
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "classifier file not found"
            return False, "classifier file not found"
        try:
            payload = joblib.load(str(path))
        except Exception as exc:
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = _safe_text(str(exc), limit=220)
            return False, self._stats["classifier_error"]
        if not isinstance(payload, dict):
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "invalid classifier payload"
            return False, "invalid classifier payload"
        clf = payload.get("classifier")
        le = payload.get("label_encoder")
        if clf is None or le is None:
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "missing classifier or label_encoder"
            return False, "missing classifier or label_encoder"
        if not callable(getattr(clf, "predict_proba", None)):
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "classifier has no predict_proba"
            return False, "classifier has no predict_proba"
        if not callable(getattr(le, "inverse_transform", None)):
            self._stats["classifier_ready"] = False
            self._stats["classifier_error"] = "label_encoder has no inverse_transform"
            return False, "label_encoder has no inverse_transform"
        action_clf = payload.get("action_classifier")
        action_gate_enabled = callable(getattr(action_clf, "predict_proba", None))
        action_threshold = self._resolve_action_gate_threshold(payload)
        vectorizer = payload.get("vectorizer")
        vectorizer_enabled = callable(getattr(vectorizer, "transform", None))
        self._classifier_payload = payload
        self._stats["classifier_ready"] = True
        self._stats["classifier_error"] = ""
        self._stats["action_gate_enabled"] = bool(action_gate_enabled)
        self._stats["action_gate_threshold"] = float(action_threshold)
        self._stats["classifier_vectorizer_enabled"] = bool(vectorizer_enabled)
        return True, ""

    @staticmethod
    def _resolve_action_gate_threshold(payload: dict[str, Any]) -> float:
        action_threshold_raw = payload.get("action_threshold") if isinstance(payload, dict) else None
        try:
            action_threshold = float(action_threshold_raw if action_threshold_raw is not None else 0.5)
        except (TypeError, ValueError):
            action_threshold = 0.5
        override_text = os.environ.get("AGENT_COMMAND_ACTION_GATE_THRESHOLD", "").strip()
        if override_text:
            try:
                action_threshold = float(override_text)
            except (TypeError, ValueError):
                pass
        return max(0.01, min(0.99, action_threshold))

    def _route_by_classifier(
        self,
        *,
        qv: Any | None,
        query: str,
        detector: str,
        max_actions: int,
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        if self._classifier_payload is None:
            self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
            return [], None
        payload = self._classifier_payload
        clf = payload.get("classifier")
        le = payload.get("label_encoder")
        if clf is None or le is None:
            self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
            return [], None
        try:
            vectorizer = payload.get("vectorizer")
            text_feat: Any | None = None
            tfidf_dim = 0
            if callable(getattr(vectorizer, "transform", None)):
                try:
                    text_feat = vectorizer.transform([query])
                    tfidf_dim = int(getattr(text_feat, "shape", (0, 0))[1] or 0)
                except Exception:
                    text_feat = None
                    tfidf_dim = 0
            if qv is None:
                coef = getattr(clf, "coef_", None)
                total_dim = 0
                if coef is not None:
                    try:
                        total_dim = int(np.asarray(coef).shape[1] or 0)
                    except Exception:
                        total_dim = 0
                embed_dim = max(0, total_dim - tfidf_dim)
                row_dense = np.zeros((1, embed_dim), dtype=np.float32)
            else:
                row_dense = np.asarray(qv, dtype=np.float32).reshape(1, -1)

            row_model: Any = row_dense
            if text_feat is not None:
                if csr_matrix is not None and sparse_hstack is not None:
                    row_model = sparse_hstack([csr_matrix(row_dense), text_feat], format="csr")
                else:
                    text_arr = np.asarray(text_feat.toarray(), dtype=np.float32)
                    row_model = np.hstack([row_dense, text_arr])
            prob_mat = np.asarray(clf.predict_proba(row_model), dtype=np.float32)
            if prob_mat.ndim != 2 or prob_mat.shape[0] <= 0:
                self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
                return [], None
            probs = prob_mat[0]
            if probs.ndim != 1 or probs.shape[0] <= 0:
                self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
                return [], None
            ranked_idx = np.argsort(probs)[::-1]
            top_idx = int(ranked_idx[0])
            top_prob = float(probs[top_idx])
            second_prob = float(probs[int(ranked_idx[1])]) if probs.shape[0] > 1 else 0.0
            margin = float(top_prob - second_prob)
            top_label = str(le.inverse_transform([top_idx])[0])
        except Exception as exc:
            self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": _safe_text(str(exc), limit=180),
                "source": "classifier",
            }
        self._stats["classifier_last_intent"] = top_label
        self._stats["classifier_last_prob"] = round(top_prob, 6)
        self._stats["classifier_last_margin"] = round(margin, 6)
        action_clf = payload.get("action_classifier")
        action_gate_enabled = callable(getattr(action_clf, "predict_proba", None))
        action_threshold = self._resolve_action_gate_threshold(payload)
        self._stats["action_gate_enabled"] = bool(action_gate_enabled)
        self._stats["action_gate_threshold"] = float(action_threshold)
        if action_gate_enabled:
            try:
                action_prob_mat = np.asarray(action_clf.predict_proba(row_model), dtype=np.float32)
                action_prob = float(action_prob_mat[0][1]) if action_prob_mat.ndim == 2 and action_prob_mat.shape[1] >= 2 else 1.0
            except Exception:
                action_prob = 1.0
            self._stats["action_gate_last_prob"] = round(action_prob, 6)
            if action_prob < action_threshold:
                self._stats["classifier_hits"] = int(self._stats.get("classifier_hits") or 0) + 1
                return [], {
                    "ok": True,
                    "non_action": True,
                    "intent": "chat.smalltalk",
                    "score": round(max(0.0, 1.0 - action_prob), 6),
                    "margin": round(action_threshold - action_prob, 6),
                    "detail": f"action gate non-action: action_prob={action_prob:.4f}<th={action_threshold:.4f}",
                    "source": "classifier",
                }
            # If gate says this is likely an action command, but multiclass top label
            # is chat.smalltalk with low confidence, pick the strongest non-chat intent.
            if self._is_non_action_intent(top_label) and top_prob <= 0.45:
                alt_idx: int | None = None
                for idx in ranked_idx:
                    cand_idx = int(idx)
                    cand_label = str(le.inverse_transform([cand_idx])[0])
                    if self._is_non_action_intent(cand_label):
                        continue
                    cand_prob = float(probs[cand_idx])
                    if cand_prob >= self.classifier_min_prob:
                        alt_idx = cand_idx
                        break
                if alt_idx is not None:
                    top_idx = int(alt_idx)
                    top_label = str(le.inverse_transform([top_idx])[0])
                    top_prob = float(probs[top_idx])
                    second_prob = float(probs[int(ranked_idx[0])]) if probs.shape[0] > 1 else 0.0
                    margin = float(max(0.0, top_prob - second_prob))
                    self._stats["classifier_last_intent"] = top_label
                    self._stats["classifier_last_prob"] = round(top_prob, 6)
                    self._stats["classifier_last_margin"] = round(margin, 6)
        if top_prob < self.classifier_min_prob:
            self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": f"classifier prob too low: {top_prob:.4f}",
                "intent": top_label,
                "score": round(top_prob, 6),
                "margin": round(margin, 6),
                "source": "classifier",
            }
        if self._is_non_action_intent(top_label):
            self._stats["classifier_hits"] = int(self._stats.get("classifier_hits") or 0) + 1
            return [], {
                "ok": True,
                "non_action": True,
                "intent": top_label,
                "score": round(top_prob, 6),
                "margin": round(margin, 6),
                "detail": "classifier non-action intent matched",
                "source": "classifier",
            }
        actions = self._intent_to_actions(
            top_label,
            query=query,
            detector=detector,
            model_only=self.model_only,
        )
        keep = _clamp_int(max_actions, default=3, min_value=1, max_value=8)
        actions = list(actions or [])[:keep]
        if not actions:
            self._stats["classifier_misses"] = int(self._stats.get("classifier_misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": "classifier intent has no actions",
                "intent": top_label,
                "score": round(top_prob, 6),
                "margin": round(margin, 6),
                "source": "classifier",
            }
        self._stats["classifier_hits"] = int(self._stats.get("classifier_hits") or 0) + 1
        return actions, {
            "ok": True,
            "intent": top_label,
            "score": round(top_prob, 6),
            "margin": round(margin, 6),
            "detail": "classifier intent matched",
            "source": "classifier",
        }

    def _ensure_ready(self) -> tuple[bool, str]:
        if not self.enabled:
            return False, "disabled"
        if self._model is None and self.model_only and self._classifier_payload is not None:
            self._stats["ready"] = True
            if not _safe_text(self._stats.get("backend"), limit=24):
                self._stats["backend"] = "classifier_only"
            return True, ""
        if self._model is not None and (self.model_only or self._prototypes_matrix is not None):
            if self.classifier_enabled and self._classifier_payload is None:
                self._load_classifier_payload()
            return True, ""
        with self._lock:
            if self._model is not None and (self.model_only or self._prototypes_matrix is not None):
                if self.classifier_enabled and self._classifier_payload is None:
                    self._load_classifier_payload()
                return True, ""
            started = time.perf_counter()
            try:
                from rktransformers import RKSentenceTransformer
            except Exception as exc:
                load_err = _safe_text(str(exc), limit=220)
                self._stats["load_error"] = load_err
                self._stats["load_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                if self.model_only and self.classifier_enabled:
                    cls_ok, cls_err = self._load_classifier_payload()
                    if cls_ok:
                        self._stats["ready"] = True
                        self._stats["backend"] = "classifier_only"
                        self._stats["load_error"] = f"embed unavailable: {load_err}"
                        return True, ""
                    self._stats["load_error"] = _safe_text(
                        f"{load_err}; classifier: {cls_err or 'load failed'}",
                        limit=260,
                    )
                return False, self._stats["load_error"]
            backend = "rknn" if self.use_npu else "torch"
            try:
                model = RKSentenceTransformer(
                    self.model_name_or_path,
                    backend=backend,
                    local_files_only=self.local_files_only,
                )
                self._model = model
                if self.model_only:
                    self._prototypes_matrix = None
                    self._prototype_intents = []
                else:
                    proto_texts: list[str] = []
                    proto_intents: list[str] = []
                    for intent, meta in self._catalog.items():
                        rows = meta.get("prototypes") if isinstance(meta.get("prototypes"), list) else []
                        for text in rows[:16]:
                            value = _safe_text(text, limit=220)
                            if not value:
                                continue
                            proto_texts.append(value)
                            proto_intents.append(intent)
                    if not proto_texts:
                        self._stats["load_error"] = "empty catalog"
                        return False, "empty catalog"
                    emb = model.encode(proto_texts)
                    mat = np.asarray(emb, dtype=np.float32)
                    if mat.ndim != 2 or mat.shape[0] != len(proto_intents):
                        self._stats["load_error"] = "invalid prototype embedding shape"
                        return False, "invalid prototype embedding shape"
                    norms = np.linalg.norm(mat, axis=1, keepdims=True)
                    norms = np.where(norms <= 1e-12, 1.0, norms)
                    mat = mat / norms
                    self._prototypes_matrix = mat
                    self._prototype_intents = proto_intents
                self._stats["ready"] = True
                self._stats["backend"] = backend
                self._stats["load_error"] = ""
                self._stats["load_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                if self.classifier_enabled:
                    self._load_classifier_payload()
                return True, ""
            except Exception as exc:
                self._stats["ready"] = False
                load_err = _safe_text(str(exc), limit=220)
                self._stats["load_error"] = load_err
                self._stats["load_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                if self.model_only and self.classifier_enabled:
                    cls_ok, cls_err = self._load_classifier_payload()
                    if cls_ok:
                        self._stats["ready"] = True
                        self._stats["backend"] = "classifier_only"
                        self._stats["load_error"] = f"embed unavailable: {load_err}"
                        return True, ""
                    self._stats["load_error"] = _safe_text(
                        f"{load_err}; classifier: {cls_err or 'load failed'}",
                        limit=260,
                    )
                return False, self._stats["load_error"]

    def route(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        text = str(query or "").strip()
        if not text:
            return [], {"ok": False, "detail": "empty query"}
        ready, err = self._ensure_ready()
        if not ready:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {"ok": False, "detail": err or "router not ready"}
        if not self.model_only and self._prototypes_matrix is not None:
            assert self._model is not None
        qv: Any | None = None
        if self._model is not None:
            try:
                qv_raw = self._model.encode([text])
                qv = np.asarray(qv_raw, dtype=np.float32)
                if qv.ndim == 2:
                    qv = qv[0]
                qv = self._l2_normalize(qv)
            except Exception as exc:
                self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
                return [], {"ok": False, "detail": _safe_text(str(exc), limit=220)}
        elif not self.model_only:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {"ok": False, "detail": "semantic embed model unavailable"}
        classifier_actions, classifier_meta = self._route_by_classifier(
            qv=qv,
            query=text,
            detector=detector,
            max_actions=max_actions,
        )
        if classifier_meta and bool(classifier_meta.get("ok", False)):
            top_intent = _safe_text(classifier_meta.get("intent"), limit=80)
            top_score = float(classifier_meta.get("score") or 0.0)
            top_margin = float(classifier_meta.get("margin") or 0.0)
            self._stats["last_intent"] = top_intent
            self._stats["last_score"] = round(top_score, 6)
            self._stats["last_margin"] = round(top_margin, 6)
            if bool(classifier_meta.get("non_action", False)):
                self._stats["hits"] = int(self._stats.get("hits") or 0) + 1
                return [], classifier_meta
            if classifier_actions:
                self._stats["hits"] = int(self._stats.get("hits") or 0) + 1
                return classifier_actions, classifier_meta
        if self.model_only:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            miss_meta = classifier_meta if isinstance(classifier_meta, dict) else {}
            detail = _safe_text(miss_meta.get("detail"), limit=160) or "classifier miss in model_only mode"
            return [], {
                "ok": False,
                "detail": detail,
                "intent": _safe_text(miss_meta.get("intent"), limit=80),
                "score": float(miss_meta.get("score") or 0.0),
                "margin": float(miss_meta.get("margin") or 0.0),
                "source": "classifier",
            }
        if qv is None:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {"ok": False, "detail": "prototype route unavailable: empty embedding"}
        scores_vec = np.asarray(self._prototypes_matrix @ qv, dtype=np.float32).reshape(-1)
        intent_best: dict[str, float] = {}
        for idx, intent in enumerate(self._prototype_intents):
            score = float(scores_vec[idx]) if idx < scores_vec.shape[0] else 0.0
            prev = intent_best.get(intent)
            if prev is None or score > prev:
                intent_best[intent] = score
        ranked = sorted(intent_best.items(), key=lambda item: item[1], reverse=True)
        if not ranked:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {"ok": False, "detail": "empty ranked intents"}
        top_intent, top_score = ranked[0]
        second_score = float(ranked[1][1]) if len(ranked) > 1 else 0.0
        margin = float(top_score - second_score)
        self._stats["last_intent"] = top_intent
        self._stats["last_score"] = round(top_score, 6)
        self._stats["last_margin"] = round(margin, 6)
        low = text.lower()
        if top_score < self.min_score:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": f"score too low: {top_score:.4f}",
                "intent": top_intent,
                "score": round(top_score, 6),
                "margin": round(margin, 6),
                "source": "prototype",
            }
        margin_threshold = 0.0 if self._is_non_action_intent(top_intent) else self.min_margin
        if margin < margin_threshold:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": f"margin too low: {margin:.4f}",
                "intent": top_intent,
                "score": round(top_score, 6),
                "margin": round(margin, 6),
                "source": "prototype",
            }
        if not self._query_has_guard(top_intent, text, low):
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": "guard mismatch",
                "intent": top_intent,
                "score": round(top_score, 6),
                "margin": round(margin, 6),
                "source": "prototype",
            }
        if self._is_non_action_intent(top_intent):
            self._stats["hits"] = int(self._stats.get("hits") or 0) + 1
            return [], {
                "ok": True,
                "non_action": True,
                "intent": top_intent,
                "score": round(top_score, 6),
                "margin": round(margin, 6),
                "detail": "semantic non-action intent matched",
                "source": "prototype",
            }
        proposals = self._intent_to_actions(
            top_intent,
            query=text,
            detector=detector,
            model_only=self.model_only,
        )
        keep = _clamp_int(max_actions, default=3, min_value=1, max_value=8)
        proposals = proposals[:keep]
        if not proposals:
            self._stats["misses"] = int(self._stats.get("misses") or 0) + 1
            return [], {
                "ok": False,
                "detail": "intent has no actions",
                "intent": top_intent,
                "score": round(top_score, 6),
                "margin": round(margin, 6),
                "source": "prototype",
            }
        self._stats["hits"] = int(self._stats.get("hits") or 0) + 1
        return proposals, {
            "ok": True,
            "intent": top_intent,
            "score": round(top_score, 6),
            "margin": round(margin, 6),
            "detail": "semantic intent matched",
            "source": "prototype",
        }

    def snapshot(self) -> dict[str, Any]:
        return {
            "enabled": bool(self.enabled),
            "model": self.model_name_or_path,
            "ready": bool(self._stats.get("ready", False)),
            "load_error": _safe_text(self._stats.get("load_error"), limit=180),
            "load_ms": float(self._stats.get("load_ms") or 0.0),
            "hits": int(self._stats.get("hits") or 0),
            "misses": int(self._stats.get("misses") or 0),
            "last_intent": _safe_text(self._stats.get("last_intent"), limit=80),
            "last_score": float(self._stats.get("last_score") or 0.0),
            "last_margin": float(self._stats.get("last_margin") or 0.0),
            "backend": _safe_text(self._stats.get("backend"), limit=24),
            "min_score": float(self.min_score),
            "min_margin": float(self.min_margin),
            "use_npu": bool(self.use_npu),
            "local_files_only": bool(self.local_files_only),
            "classifier_enabled": bool(self.classifier_enabled),
            "classifier_path": _safe_text(self.classifier_path, limit=220),
            "classifier_min_prob": float(self.classifier_min_prob),
            "model_only": bool(self.model_only),
            "classifier_ready": bool(self._stats.get("classifier_ready", False)),
            "classifier_error": _safe_text(self._stats.get("classifier_error"), limit=180),
            "classifier_hits": int(self._stats.get("classifier_hits") or 0),
            "classifier_misses": int(self._stats.get("classifier_misses") or 0),
            "classifier_last_intent": _safe_text(self._stats.get("classifier_last_intent"), limit=80),
            "classifier_last_prob": float(self._stats.get("classifier_last_prob") or 0.0),
            "classifier_last_margin": float(self._stats.get("classifier_last_margin") or 0.0),
            "classifier_vectorizer_enabled": bool(self._stats.get("classifier_vectorizer_enabled", False)),
            "action_gate_enabled": bool(self._stats.get("action_gate_enabled", False)),
            "action_gate_threshold": float(self._stats.get("action_gate_threshold") or 0.0),
            "action_gate_last_prob": float(self._stats.get("action_gate_last_prob") or 0.0),
        }

    def prewarm(self) -> dict[str, Any]:
        _ready, _err = self._ensure_ready()
        return self.snapshot()


class CommandPlanner:
    _DAG_GROUP_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,39}$")

    ALIASES: dict[str, str] = {
        "time": "system.time",
        "clock": "system.time",
        "cpu": "system.cpu",
        "memory": "system.mem",
        "mem": "system.mem",
        "ram": "system.mem",
        "npu": "system.npu",
        "temp": "system.thermal",
        "thermal": "system.thermal",
        "传感器": "vision.sensors.get",
        "水温": "vision.sensors.get",
        "浊度": "vision.sensors.get",
        "ph": "vision.sensors.get",
        "sensor": "vision.sensors.get",
        "sensors": "vision.sensors.get",
        "sensor.status": "vision.sensors.get",
        "sensors.status": "vision.sensors.get",
        "sensor.thresholds.set": "vision.sensors.thresholds.set",
        "sensors.thresholds.set": "vision.sensors.thresholds.set",
        "sensor.sample.set": "vision.sensors.sample.set",
        "sensors.sample.set": "vision.sensors.sample.set",
        "observe": "vision.observe",
        "vision.observe": "vision.observe",
        "vision.status": "vision.enabled.get",
        "vision.get": "vision.enabled.get",
        "vision.profile": "vision.profile.get",
        "vision.enable": "vision.enabled.set",
        "vision.disable": "vision.enabled.set",
        "vision.stream": "vision.stream.set",
        "vision.filter": "vision.yolo_world.filter.get",
        "vision.filter.set": "vision.yolo_world.filter.set",
        "vision.prompt": "vision.yolo_world.prompt.get",
        "vision.prompt.set": "vision.yolo_world.prompt.set",
        "gimbal": "vision.gimbal.status",
        "gimbal.status": "vision.gimbal.status",
        "gimbal.command": "vision.gimbal.command",
        "gimbal.move": "vision.gimbal.command",
        "gimbal.stop": "vision.gimbal.command",
        "gimbal.laser.blink": "vision.gimbal.laser.blink",
        "laser.blink": "vision.gimbal.laser.blink",
        "gimbal.lock": "vision.gimbal.lock.status",
        "gimbal.lock.status": "vision.gimbal.lock.status",
        "gimbal.lock.start": "vision.gimbal.lock.start",
        "gimbal.lock.stop": "vision.gimbal.lock.stop",
        "vision.gimbal": "vision.gimbal.status",
        "vision.gimbal.laser.blink": "vision.gimbal.laser.blink",
        "vision.gimbal.lock": "vision.gimbal.lock.status",
        "vision.gimbal.lock.status": "vision.gimbal.lock.status",
        "vision.gimbal.lock.start": "vision.gimbal.lock.start",
        "vision.gimbal.lock.stop": "vision.gimbal.lock.stop",
        "camera.filter": "vision.yolo_world.filter.get",
        "camera.prompt": "vision.yolo_world.prompt.get",
        "recover": "vision.recover",
        "memory.add": "memory.add",
        "memory.list": "memory.list",
        "memory.search": "memory.search",
        "memory.clear": "memory.clear",
        "memory.stats": "memory.stats",
        "rgb.status": "rgb.status",
        "rgb.off": "rgb.set",
        "led.status": "rgb.status",
        "led.set": "rgb.set",
    }

    def __init__(
        self,
        intent_registry: IntentRegistry,
        tool_registry: ToolRegistry,
        risk_policy: RiskPolicy,
    ) -> None:
        self.intent_registry = intent_registry
        self.tool_registry = tool_registry
        self.risk_policy = risk_policy
        self._arg_normalizers: dict[str, Callable[[dict[str, Any], str, str], dict[str, Any]]] = {
            "vision.observe": self._normalize_vision_observe,
            "vision.enabled.set": self._normalize_vision_enabled_set,
            "vision.stream.set": self._normalize_vision_stream_set,
            "vision.profile.set": self._normalize_vision_profile_set,
            "vision.gimbal.command": self._normalize_vision_gimbal_command,
            "vision.gimbal.laser.blink": self._normalize_vision_gimbal_laser_blink,
            "vision.gimbal.lock.start": self._normalize_vision_gimbal_lock_start,
            "vision.gimbal.lock.stop": self._normalize_vision_gimbal_lock_stop,
            "vision.yolo_world.filter.set": self._normalize_vision_yolo_world_filter_set,
            "vision.yolo_world.prompt.set": self._normalize_vision_yolo_world_prompt_set,
            "memory.list": self._normalize_memory_list,
            "memory.search": self._normalize_memory_search,
            "memory.add": self._normalize_memory_add,
            "rgb.set": self._normalize_rgb_set,
        }

    def _normalize_tool_name(self, value: Any) -> str:
        raw = str(value or "").strip().lower()
        if not raw:
            return ""
        return self.ALIASES.get(raw, raw)

    @classmethod
    def _normalize_group_id(cls, value: Any, *, fallback: str = "") -> str:
        text = _safe_text(value, limit=64).strip().lower()
        if not text:
            return fallback
        text = re.sub(r"\s+", ".", text)
        text = re.sub(r"[^a-z0-9._-]+", "", text)
        if not text:
            return fallback
        text = text[:40]
        if cls._DAG_GROUP_RE.fullmatch(text):
            return text
        return fallback

    @classmethod
    def _normalize_depends_on(cls, value: Any, *, limit: int = 6) -> list[str]:
        out: list[str] = []
        raw_values: list[Any] = []
        if isinstance(value, list):
            raw_values = list(value)
        elif isinstance(value, str):
            raw_values = [seg for seg in re.split(r"[,;\s]+", value) if seg]
        elif value is not None:
            raw_values = [value]

        for raw in raw_values:
            group = cls._normalize_group_id(raw)
            if not group or group in out:
                continue
            out.append(group)
            if len(out) >= max(1, int(limit)):
                break
        return out

    @staticmethod
    def _is_low_risk_read_action(action: dict[str, Any]) -> bool:
        if not isinstance(action, dict):
            return False
        if bool(action.get("side_effect", False)):
            return False
        if bool(action.get("requires_confirmation", False)):
            return False
        risk = _safe_text(action.get("risk_level"), limit=16).lower() or "low"
        return risk == "low"

    def _semantic_group_base(self, action: dict[str, Any]) -> str:
        tool = _safe_text(action.get("tool"), limit=80)
        side_effect = bool(action.get("side_effect", False))
        if not tool:
            return "action"

        if tool.startswith("system."):
            return "system.snapshot"

        if tool.startswith("memory."):
            if tool in ("memory.add", "memory.clear"):
                return "memory.write"
            return "memory.read"

        if tool.startswith("rgb."):
            return "rgb.control" if side_effect else "rgb.status"

        if tool == "vision.observe":
            return "camera.observe"

        if tool in ("vision.yolo_world.prompt.set", "vision.yolo_world.filter.set"):
            return "camera.prepare"
        if tool in ("vision.yolo_world.prompt.get", "vision.yolo_world.filter.get"):
            return "camera.state"

        if tool in ("vision.enabled.get", "vision.profile.get"):
            return "camera.state"
        if tool in ("vision.enabled.set", "vision.profile.set", "vision.stream.set", "vision.recover"):
            return "camera.control"

        if tool == "vision.gimbal.status":
            return "gimbal.status"
        if tool == "vision.gimbal.command":
            return "gimbal.control"
        if tool == "vision.gimbal.laser.blink":
            return "gimbal.control"
        if tool == "vision.gimbal.lock.status":
            return "gimbal.lock.status"
        if tool == "vision.gimbal.lock.start":
            return "gimbal.lock.start"
        if tool == "vision.gimbal.lock.stop":
            return "gimbal.lock.stop"

        if tool.startswith("vision."):
            return "vision.control" if side_effect else "vision.read"

        return "action.control" if side_effect else "action.read"

    def _allocate_semantic_group(self, base: str, counters: dict[str, int]) -> str:
        normalized_base = self._normalize_group_id(base, fallback="step")
        if not normalized_base:
            normalized_base = "step"
        seq = int(counters.get(normalized_base, 0)) + 1
        counters[normalized_base] = seq
        group = self._normalize_group_id(f"{normalized_base}.{seq}", fallback=normalized_base)
        return group or normalized_base

    def _attach_dag_metadata(self, actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        prev_group = ""
        group_counters: dict[str, int] = {}
        active_read_group = ""
        active_read_base = ""

        for action in actions:
            row = dict(action) if isinstance(action, dict) else {}
            explicit_group = self._normalize_group_id(row.get("group"))
            deps = self._normalize_depends_on(row.get("depends_on"))

            if explicit_group:
                group = explicit_group
                if self._is_low_risk_read_action(row):
                    active_read_group = group
                    active_read_base = self._semantic_group_base(row)
                else:
                    active_read_group = ""
                    active_read_base = ""
            else:
                base = self._semantic_group_base(row)
                if self._is_low_risk_read_action(row):
                    if active_read_group and active_read_base == base:
                        group = active_read_group
                    else:
                        group = self._allocate_semantic_group(base, group_counters)
                        active_read_group = group
                        active_read_base = base
                else:
                    group = self._allocate_semantic_group(base, group_counters)
                    active_read_group = ""
                    active_read_base = ""

            deps = [dep for dep in deps if dep != group]
            if not deps and prev_group and group != prev_group:
                deps = [prev_group]

            row["group"] = group
            row["depends_on"] = deps
            out.append(row)
            prev_group = group

        return out

    def _normalize_vision_observe(self, args: dict[str, Any], _query: str, detector: str) -> dict[str, Any]:
        out = dict(args)
        warning_parts: list[str] = []
        raw_detector_arg = _safe_text(out.get("detector"), limit=24).lower()
        det, det_err = _normalize_detector(out.get("detector") or detector, default=detector)
        if det is None:
            out["detector"] = detector
            if det_err:
                warning_parts.append(det_err)
        else:
            out["detector"] = det
        query = str(_query or "")
        query_lower = query.lower()
        capability_names = set(_camera_capability_names())
        query_capability_flags = IntentRegistry._extract_camera_capability_requests(query, query_lower, max_caps=8)
        # Built-in colloquial aliases for person-detail observe intents.
        if ("emotion" in capability_names) and ("emotion" not in query_capability_flags):
            if IntentRegistry._contains_any(
                query,
                query_lower,
                ("脸色", "看我脸色", "情绪", "表情", "心情", "emotion", "mood", "feeling"),
            ):
                query_capability_flags["emotion"] = True
        if ("wear_glasses" in capability_names) and ("wear_glasses" not in query_capability_flags):
            if IntentRegistry._contains_any(
                query,
                query_lower,
                ("眼镜", "戴眼镜", "有没有戴眼镜", "glasses", "eyeglasses", "spectacles"),
            ):
                query_capability_flags["wear_glasses"] = True
        pose_requested = IntentRegistry._contains_any(
            query,
            query_lower,
            (
                "抬头",
                "低头",
                "向左看",
                "向右看",
                "脸朝左",
                "脸朝右",
                "face pose",
                "head pose",
            ),
        )
        for name in capability_names:
            if name in out:
                parsed = _coerce_enabled(out.get(name))
                if parsed is None:
                    out.pop(name, None)
                else:
                    out[name] = bool(parsed)
                continue
            if name in query_capability_flags:
                out[name] = bool(query_capability_flags.get(name))
        enable_requested = pose_requested or any(bool(out.get(name)) for name in capability_names if name in out)
        explicit_none = IntentRegistry._contains_any(
            query,
            query_lower,
            (
                "原图",
                "不检测",
                "不要检测",
                "别检测",
                "别识别",
                "不识别",
                "关闭检测",
                "仅画面",
                "生图",
                "raw",
                "no detect",
                "no detection",
            ),
        )
        explicit_detector_text = IntentRegistry._pick_detector_from_text(query, query_lower, "none")
        explicit_detector = explicit_detector_text in ("face", "rect", "yolo", "yolo_world") or raw_detector_arg in (
            "face",
            "rect",
            "yolo",
            "yolo_world",
        )

        include_terms_raw = out.get("include_terms")
        include_terms = include_terms_raw if isinstance(include_terms_raw, list) else []
        prompt_hint = _safe_text(out.get("prompt"), limit=160)
        target_hint = _safe_text(
            out.get("target")
            or out.get("label")
            or out.get("class_name")
            or out.get("class")
            or out.get("object")
            or out.get("name"),
            limit=120,
        )
        include_for_infer: list[str] = []
        if target_hint:
            include_for_infer.append(target_hint)
        for item in include_terms:
            text_item = _safe_text(item, limit=64)
            if text_item:
                include_for_infer.append(text_item)
            if len(include_for_infer) >= 8:
                break
        _, target_human = IntentRegistry._infer_observe_target(
            query,
            query_lower,
            include_terms=include_for_infer,
            prompt=prompt_hint,
        )
        person_detail_names = {"wear_glasses", "emotion"}
        person_detail_enabled = any(bool(out.get(name)) for name in person_detail_names if name in out)
        if person_detail_enabled and (not target_human) and (not target_hint):
            # Person-detail capabilities imply human target unless explicit non-human target is provided.
            target_human = True
        if pose_requested and (not target_human) and (not target_hint):
            target_human = True

        if explicit_detector_text in ("face", "rect", "yolo", "yolo_world") and raw_detector_arg in ("", "none"):
            out["detector"] = explicit_detector_text

        if out.get("detector") == "none" and (not explicit_none) and (not explicit_detector):
            out["detector"] = "face" if target_human else "yolo_world"

        detail_ignored = False
        for name in person_detail_names:
            if name not in out:
                continue
            if target_human:
                continue
            detail_ignored = True
            out.pop(name, None)
        if detail_ignored:
            warning_parts.append("person-only details ignored for non-human target")

        if enable_requested and (not explicit_none):
            if target_human:
                if (not explicit_detector) and out.get("detector") in ("none", "rect", "yolo", "yolo_world"):
                    out["detector"] = "face"
            else:
                preferred = IntentRegistry._preferred_detector_for_capabilities(
                    {name: bool(out.get(name)) for name in capability_names if name in out}
                )
                if (not explicit_detector) and preferred in ("none", "rect", "yolo", "yolo_world"):
                    out["detector"] = preferred

        if warning_parts:
            out["_warning"] = "; ".join(warning_parts[:3])
        return out

    def _normalize_vision_enabled_set(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        enabled = _coerce_enabled(out.get("enabled"))
        if enabled is None:
            q = query.lower()
            if any(token in q for token in ("disable", "stop", "off")) or any(
                token in query for token in ("关闭", "停用")
            ):
                enabled = False
            elif any(token in q for token in ("enable", "start", "on")) or any(
                token in query for token in ("开启", "打开", "启用")
            ):
                enabled = True
        out["enabled"] = enabled if enabled is not None else False
        out["reason"] = _safe_text(out.get("reason"), limit=80) or "agent"
        return out

    def _normalize_vision_stream_set(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        enabled = _coerce_enabled(out.get("enabled"))
        if enabled is None:
            q = query.lower()
            if any(token in q for token in ("disable", "stop", "off")) or any(
                token in query for token in ("关闭", "停止")
            ):
                enabled = False
            elif any(token in q for token in ("enable", "start", "on")) or any(
                token in query for token in ("开启", "打开")
            ):
                enabled = True
        out["enabled"] = enabled if enabled is not None else False
        out["reason"] = _safe_text(out.get("reason"), limit=80) or "agent"
        return out

    def _normalize_vision_profile_set(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        name = _safe_text(out.get("name"), limit=32).lower()
        if not name:
            name = IntentRegistry._pick_profile_from_text(query, query.lower())
        out["name"] = name or "stable"
        return out

    @staticmethod
    def _pick_float_value(*values: Any) -> float | None:
        for value in values:
            if value is None:
                continue
            text = str(value).strip()
            if not text:
                continue
            try:
                return float(text)
            except (TypeError, ValueError):
                continue
        return None

    def _normalize_vision_gimbal_command(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        text = str(query or "").strip()
        lower = text.lower()
        test_mode = IntentRegistry._contains_any(
            text,
            lower,
            ("测试", "试试", "试一下", "调试", "demo", "debug"),
        )

        mode = _safe_text(out.get("mode"), limit=16).lower()
        if mode not in ("stop", "halt", "idle"):
            mode = ""
        if not mode and IntentRegistry._contains_any(text, lower, ("停止", "停下", "别动", "静止", "stop", "halt", "idle")):
            mode = "stop"
        smooth_pref = IntentRegistry._contains_any(
            text,
            lower,
            ("平滑", "稳定", "不抖", "别抖", "缓一点", "smooth", "stable", "jitter"),
        )

        yaw = self._pick_float_value(out.get("yaw_rpm"), out.get("yaw"), out.get("pan"))
        pitch = self._pick_float_value(out.get("pitch_rpm"), out.get("pitch"), out.get("tilt"))
        hint_yaw, hint_pitch = IntentRegistry._extract_gimbal_axis_rpm(text, lower)
        if yaw is None:
            yaw = hint_yaw
        if pitch is None:
            pitch = hint_pitch

        speed = IntentRegistry._extract_gimbal_speed_hint(
            text, lower, default_speed=AGENT_GIMBAL_RPM_LIMIT
        )
        if yaw is None:
            yaw = 0.0
            if IntentRegistry._contains_any(text, lower, ("左", "向左", "左转", "left")):
                yaw -= speed
            if IntentRegistry._contains_any(text, lower, ("右", "向右", "右转", "right")):
                yaw += speed
        if pitch is None:
            pitch = 0.0
            if IntentRegistry._contains_any(text, lower, ("上", "向上", "抬头", "上抬", "up")):
                pitch -= speed
            if IntentRegistry._contains_any(text, lower, ("下", "向下", "低头", "下压", "down")):
                pitch += speed

        if mode in ("stop", "halt", "idle"):
            yaw = 0.0
            pitch = 0.0
        elif test_mode:
            # Test-mode safety: keep movement small by default to avoid large swings.
            test_rpm_cap = 0.8
            yaw = max(-test_rpm_cap, min(test_rpm_cap, float(yaw)))
            pitch = max(-test_rpm_cap, min(test_rpm_cap, float(pitch)))
        out["mode"] = mode
        out["yaw_rpm"] = max(-AGENT_GIMBAL_RPM_LIMIT, min(AGENT_GIMBAL_RPM_LIMIT, float(yaw)))
        out["pitch_rpm"] = max(-AGENT_GIMBAL_RPM_LIMIT, min(AGENT_GIMBAL_RPM_LIMIT, float(pitch)))

        laser_enabled = _coerce_action_flag(out.get("laser_enabled", out.get("laser")))
        enabled = _coerce_action_flag(out.get("enabled"))
        stability_enabled = _coerce_action_flag(out.get("stability_enabled", out.get("stability")))
        if laser_enabled in (0, 1, 2):
            out["laser_enabled"] = laser_enabled
        else:
            out.pop("laser_enabled", None)
        if enabled in (0, 1, 2):
            out["enabled"] = enabled
        else:
            out.pop("enabled", None)
        if stability_enabled in (0, 1, 2):
            out["stability_enabled"] = stability_enabled
        else:
            out.pop("stability_enabled", None)
            if smooth_pref or (
                abs(float(out.get("yaw_rpm", 0.0) or 0.0)) <= 1e-6
                and abs(float(out.get("pitch_rpm", 0.0) or 0.0)) <= 1e-6
            ):
                out["stability_enabled"] = 1

        raw_auto_stop = out.get("auto_stop_ms", out.get("hold_ms"))
        auto_stop_explicit = str(raw_auto_stop).strip() if raw_auto_stop is not None else ""
        if auto_stop_explicit:
            auto_stop_ms = _clamp_int(raw_auto_stop, default=220, min_value=0, max_value=5000)
        else:
            hold_mode = IntentRegistry._contains_any(text, lower, ("持续", "一直", "保持", "hold", "keep"))
            duration_sec_hint = IntentRegistry._extract_time_seconds_hint(text, lower)
            if hold_mode:
                auto_stop_ms = 0
            elif duration_sec_hint is not None and duration_sec_hint > 0:
                auto_stop_ms = int(max(0, min(5000, round(duration_sec_hint * 1000.0))))
            else:
                auto_stop_ms = 220
        if mode in ("stop", "halt", "idle"):
            auto_stop_ms = 0
        elif test_mode:
            if auto_stop_explicit:
                auto_stop_ms = int(max(120, min(1200, int(auto_stop_ms))))
            else:
                auto_stop_ms = int(max(160, min(500, int(auto_stop_ms))))
        out["auto_stop_ms"] = int(auto_stop_ms)
        out["reason"] = _safe_text(out.get("reason"), limit=80) or "agent"
        if test_mode and mode not in ("stop", "halt", "idle"):
            out["_warning"] = "test mode: rpm/auto_stop limited for safety"
        return out

    def _normalize_vision_gimbal_laser_blink(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        text = str(query or "").strip()
        lower = text.lower()
        warning_parts: list[str] = []

        def _to_int_opt(value: Any) -> int | None:
            if value is None:
                return None
            raw = str(value).strip()
            if not raw:
                return None
            try:
                return int(float(raw))
            except (TypeError, ValueError):
                return None

        def _to_float_opt(value: Any) -> float | None:
            if value is None:
                return None
            raw = str(value).strip()
            if not raw:
                return None
            try:
                return float(raw)
            except (TypeError, ValueError):
                return None

        blinks_input = out.get("blinks", out.get("count", out.get("times")))
        blinks_value = _to_int_opt(blinks_input)
        if blinks_input is not None and str(blinks_input).strip() and blinks_value is None:
            warning_parts.append("invalid blinks ignored")
        if blinks_value is None:
            blinks_value = IntentRegistry._extract_gimbal_lock_blinks(text, lower, default_value=6)
        blinks_value = int(max(1, min(12, int(blinks_value))))

        period_hint = IntentRegistry._extract_gimbal_lock_blink_period_ms(text, lower)
        period_value = _to_float_opt(
            out.get("period_ms", out.get("period", out.get("cycle_ms")))
        )
        period_sec_value = _to_float_opt(out.get("period_sec", out.get("cycle_sec")))
        hz_value = _to_float_opt(out.get("hz", out.get("frequency_hz", out.get("freq_hz"))))
        if period_value is None and period_sec_value is not None:
            period_value = period_sec_value * 1000.0
        if period_value is None and hz_value is not None and hz_value > 0:
            period_value = 1000.0 / hz_value
        if period_value is None and period_hint is not None:
            period_value = float(period_hint)

        on_input = out.get("laser_on_ms", out.get("on_ms"))
        off_input = out.get("laser_off_ms", out.get("off_ms"))
        on_value = _to_int_opt(on_input)
        off_value = _to_int_opt(off_input)
        if on_input is not None and str(on_input).strip() and on_value is None:
            warning_parts.append("invalid laser_on_ms ignored")
        if off_input is not None and str(off_input).strip() and off_value is None:
            warning_parts.append("invalid laser_off_ms ignored")

        normalized: dict[str, Any] = {
            "blinks": blinks_value,
            "reason": _safe_text(out.get("reason"), limit=80) or "agent",
        }
        if period_value is not None and period_value > 0:
            normalized["period_ms"] = int(max(80, min(2000, int(round(period_value)))))
        if on_value is not None:
            normalized["laser_on_ms"] = int(max(40, min(2000, int(on_value))))
        if off_value is not None:
            normalized["laser_off_ms"] = int(max(40, min(2000, int(off_value))))
        if warning_parts:
            normalized["_warning"] = "; ".join(warning_parts)
        return normalized

    def _normalize_vision_gimbal_lock_start(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        text = str(query or "").strip()
        lower = text.lower()

        warning_parts: list[str] = []

        target = _safe_text(
            out.get("target")
            or out.get("label")
            or out.get("class_name")
            or out.get("class")
            or out.get("object")
            or out.get("name"),
            limit=120,
        )
        if not target:
            target = IntentRegistry._extract_gimbal_lock_target(text, lower)
        target, target_human = IntentRegistry._normalize_gimbal_lock_target(target)
        target_low = target.lower() if target else ""
        if target and (
            ("我" in target)
            or ("自己" in target)
            or ("本人" in target)
            or ("me" in target_low)
            or ("myself" in target_low)
        ):
            target = "person"
            target_human = True
        if (not target) and IntentRegistry._contains_any(
            text,
            lower,
            ("跟着我", "盯着我", "看着我", "锁定我", "track me", "follow me", "watch me", "look at me", "lock on me"),
        ):
            target = "person"
            target_human = True

        detector_raw = out.get("detector") or "auto"
        detector, det_err = _normalize_gimbal_lock_detector(detector_raw, default="auto")
        if detector is None:
            detector = "auto"
            if det_err:
                warning_parts.append(det_err)

        def _float_range(key: str, default: float, min_value: float, max_value: float) -> float:
            value = self._pick_float_value(out.get(key))
            if value is None:
                value = default
            return max(min_value, min(max_value, float(value)))

        def _int_range(key: str, default: int, min_value: int, max_value: int) -> int:
            raw = out.get(key)
            if raw is None or not str(raw).strip():
                return int(default)
            return _clamp_int(raw, default=default, min_value=min_value, max_value=max_value)

        invert_yaw_raw = out.get("invert_yaw")
        invert_pitch_raw = out.get("invert_pitch")
        invert_yaw = _coerce_enabled(invert_yaw_raw) if invert_yaw_raw is not None else None
        invert_pitch = _coerce_enabled(invert_pitch_raw) if invert_pitch_raw is not None else None
        if invert_yaw_raw is not None and str(invert_yaw_raw).strip() and invert_yaw is None:
            warning_parts.append("invalid invert_yaw ignored")
        if invert_pitch_raw is not None and str(invert_pitch_raw).strip() and invert_pitch is None:
            warning_parts.append("invalid invert_pitch ignored")
        continuous_raw = out.get("continuous")
        continuous = _coerce_enabled(continuous_raw) if continuous_raw is not None else None
        if continuous_raw is not None and str(continuous_raw).strip() and continuous is None:
            warning_parts.append("invalid continuous ignored")
        search_spin_clockwise_raw = out.get("search_spin_clockwise")
        search_spin_clockwise = (
            _coerce_enabled(search_spin_clockwise_raw)
            if search_spin_clockwise_raw is not None
            else None
        )
        if (
            search_spin_clockwise_raw is not None
            and str(search_spin_clockwise_raw).strip()
            and search_spin_clockwise is None
        ):
            warning_parts.append("invalid search_spin_clockwise ignored")
        watch_tokens = ("看着", "盯着", "看住", "跟随", "跟拍", "跟着", "watch", "track", "follow")
        if continuous is None and IntentRegistry._contains_any(text, lower, watch_tokens):
            continuous = True
        if search_spin_clockwise is None:
            if IntentRegistry._contains_any(
                text,
                lower,
                ("逆时针", "逆向", "counterclockwise", "anti-clockwise", "anticlockwise", "ccw"),
            ):
                search_spin_clockwise = False
            elif IntentRegistry._contains_any(text, lower, ("顺时针", "clockwise", "cw")):
                search_spin_clockwise = True

        wear_raw = out.get("wear_glasses")
        emotion_raw = out.get("emotion")
        wear_glasses = _coerce_enabled(wear_raw) if wear_raw is not None else None
        emotion = _coerce_enabled(emotion_raw) if emotion_raw is not None else None
        if wear_raw is not None and str(wear_raw).strip() and wear_glasses is None:
            warning_parts.append("invalid wear_glasses ignored")
        if emotion_raw is not None and str(emotion_raw).strip() and emotion is None:
            warning_parts.append("invalid emotion ignored")
        query_wear_pref, query_emotion_pref, query_detail_requested = IntentRegistry._extract_gimbal_lock_detail_preferences(
            text, lower
        )
        if wear_glasses is None:
            wear_glasses = query_wear_pref
        if emotion is None:
            emotion = query_emotion_pref
        detail_requested = bool(
            query_detail_requested
            or (wear_raw is not None and str(wear_raw).strip())
            or (emotion_raw is not None and str(emotion_raw).strip())
        )

        query_blinks = IntentRegistry._extract_gimbal_lock_blinks(text, lower, default_value=3)
        query_blink_period_ms = IntentRegistry._extract_gimbal_lock_blink_period_ms(text, lower)
        timeout_default = 3600.0 if bool(continuous) else 12.0
        timeout_hint_sec = IntentRegistry._extract_time_seconds_hint(text, lower)
        timeout_value = _float_range(
            "timeout_sec",
            timeout_default,
            1.0,
            AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC,
        )
        if timeout_hint_sec is not None and timeout_hint_sec > 0:
            timeout_value = max(1.0, min(AGENT_GIMBAL_LOCK_TIMEOUT_MAX_SEC, float(timeout_hint_sec)))
        laser_default_blinks = 0 if bool(continuous) else query_blinks
        center_focus = IntentRegistry._contains_any(text, lower, ("正中", "中间", "居中", "中心", "center"))
        anti_jitter_focus = IntentRegistry._contains_any(
            text,
            lower,
            ("不抖", "别抖", "不要抖", "平稳", "稳定", "smooth", "jitter"),
        )
        face_focus = detector == "face" or IntentRegistry._contains_any(
            text, lower, ("face", "人脸", "脸", "脸部", "头部", "head")
        )

        default_center_tol = 26.0
        default_stable_frames = 10
        default_kp = 0.035
        default_max_rpm = AGENT_GIMBAL_RPM_LIMIT
        default_sweep_rpm = AGENT_GIMBAL_RPM_LIMIT
        if face_focus and center_focus:
            default_center_tol = 30.0
            default_stable_frames = 14
            default_kp = 0.022
            default_max_rpm = min(2.2, AGENT_GIMBAL_RPM_LIMIT)
            default_sweep_rpm = min(1.8, AGENT_GIMBAL_RPM_LIMIT)
            if anti_jitter_focus:
                default_center_tol = 34.0
                default_stable_frames = 16
                default_kp = 0.018
                default_max_rpm = min(2.0, AGENT_GIMBAL_RPM_LIMIT)

        normalized: dict[str, Any] = {
            "detector": detector,
            "timeout_sec": timeout_value,
            "center_tolerance_px": _float_range("center_tolerance_px", default_center_tol, 2.0, 320.0),
            "stable_frames": _int_range("stable_frames", default_stable_frames, 1, 60),
            "min_score": _float_range("min_score", 0.35, 0.01, 0.99),
            "max_rpm": _float_range("max_rpm", default_max_rpm, 1.0, AGENT_GIMBAL_RPM_LIMIT),
            "kp_yaw": _float_range("kp_yaw", default_kp, 0.001, 1.0),
            "kp_pitch": _float_range("kp_pitch", default_kp, 0.001, 1.0),
            "search_sweep_rpm": _float_range(
                "search_sweep_rpm", default_sweep_rpm, 0.0, AGENT_GIMBAL_RPM_LIMIT
            ),
            "search_sweep_pulse_ms": _int_range("search_sweep_pulse_ms", 180, 0, 1200),
            "search_spin_deg": _float_range("search_spin_deg", 360.0, 30.0, 2160.0),
            "laser_blinks": _int_range("laser_blinks", laser_default_blinks, 0, 12),
            "laser_on_ms": _int_range("laser_on_ms", 150, 40, 1000),
            "laser_off_ms": _int_range("laser_off_ms", 150, 40, 1000),
            "reason": _safe_text(out.get("reason"), limit=80) or "agent",
        }
        if query_blink_period_ms is not None:
            half_ms = int(max(40, min(1000, round(float(query_blink_period_ms) * 0.5))))
            if out.get("laser_on_ms") in (None, ""):
                normalized["laser_on_ms"] = half_ms
            if out.get("laser_off_ms") in (None, ""):
                normalized["laser_off_ms"] = half_ms
        if target:
            normalized["target"] = target
        if target_human:
            if wear_glasses is not None:
                normalized["wear_glasses"] = bool(wear_glasses)
            if emotion is not None:
                normalized["emotion"] = bool(emotion)
        elif detail_requested:
            warning_parts.append("person-only details ignored for non-human target")
            normalized["observe_detail_note"] = "person-only detail flags ignored for non-human target"
        if continuous is not None:
            normalized["continuous"] = bool(continuous)
        if invert_yaw is not None:
            normalized["invert_yaw"] = bool(invert_yaw)
        if invert_pitch is not None:
            normalized["invert_pitch"] = bool(invert_pitch)
        if search_spin_clockwise is not None:
            normalized["search_spin_clockwise"] = bool(search_spin_clockwise)
        if warning_parts:
            normalized["_warning"] = "; ".join(warning_parts)
        return normalized

    def _normalize_vision_gimbal_lock_stop(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        text = str(query or "").strip()
        lower = text.lower()
        wait_raw = out.get("wait")
        wait = _coerce_enabled(wait_raw)
        warning = ""
        if wait_raw is not None and str(wait_raw).strip() and wait is None:
            warning = "invalid wait ignored"
        if wait is None:
            wait = IntentRegistry._contains_any(text, lower, ("等待", "等一下", "wait", "同步", "阻塞"))
        normalized: dict[str, Any] = {
            "wait": bool(wait),
            "reason": _safe_text(out.get("reason"), limit=80) or "agent",
        }
        if warning:
            normalized["_warning"] = warning
        return normalized

    @staticmethod
    def _coerce_terms(value: Any, *, limit: int = 8) -> list[str]:
        out: list[str] = []
        if isinstance(value, list):
            for item in value:
                raw = _safe_text(item, limit=96)
                if not raw:
                    continue
                canon = IntentRegistry._normalize_camera_term(raw)
                if canon and canon not in out:
                    out.append(canon)
                    if len(out) >= limit:
                        return out
                    continue
                parts = IntentRegistry._split_terms_text(raw, max_terms=limit)
                for part in parts:
                    normalized = IntentRegistry._normalize_camera_term(part) or part
                    if normalized and normalized not in out:
                        out.append(normalized)
                        if len(out) >= limit:
                            return out
            return out
        rows: list[str] = [value] if isinstance(value, str) else []
        for row in rows:
            parts = IntentRegistry._split_terms_text(row, max_terms=limit)
            for part in parts:
                normalized = IntentRegistry._normalize_camera_term(part) or part
                if normalized and normalized not in out:
                    out.append(normalized)
                    if len(out) >= limit:
                        return out
        return out

    def _normalize_vision_yolo_world_filter_set(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        mode = _safe_text(out.get("mode") or out.get("action"), limit=16).lower()
        labels = _safe_text(out.get("labels") or out.get("classes") or out.get("class"), limit=4096)
        if not labels and mode not in ("all", "clear", "reset", "none", "off"):
            include_terms, _exclude_terms, prompt, clear_filter = IntentRegistry._extract_camera_targets(
                query, query.lower()
            )
            if clear_filter:
                mode = "all"
            elif include_terms:
                labels = ",".join(include_terms)
            elif prompt:
                labels = prompt
        if mode in ("all", "clear", "reset", "none", "off"):
            out["mode"] = "all"
            out["labels"] = "all"
        else:
            out["mode"] = ""
            out["labels"] = labels
        out["reason"] = _safe_text(out.get("reason"), limit=80) or "agent"
        return out

    def _normalize_vision_yolo_world_prompt_set(self, args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        prompt = _safe_text(out.get("prompt"), limit=220)
        include_terms = self._coerce_terms(
            out.get("include_terms") or out.get("include") or out.get("terms") or out.get("labels"),
            limit=8,
        )
        exclude_terms = self._coerce_terms(out.get("exclude_terms") or out.get("exclude"), limit=8)
        if not prompt and not include_terms and not exclude_terms:
            q_include, q_exclude, q_prompt, _clear = IntentRegistry._extract_camera_targets(query, query.lower())
            include_terms = q_include
            exclude_terms = q_exclude
            prompt = q_prompt
        strict_flag = _coerce_enabled(out.get("strict"))
        out["prompt"] = prompt
        out["include_terms"] = include_terms
        out["exclude_terms"] = exclude_terms
        out["strict"] = strict_flag
        out["reason"] = _safe_text(out.get("reason"), limit=80) or "agent"
        return out

    @staticmethod
    def _normalize_memory_list(args: dict[str, Any], _query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        out["limit"] = _clamp_int(out.get("limit", 20), default=20, min_value=1, max_value=200)
        return out

    @staticmethod
    def _normalize_memory_search(args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        text = _safe_text(out.get("query"), limit=120) or _safe_text(query, limit=120)
        out["query"] = text
        out["limit"] = _clamp_int(out.get("limit", 12), default=12, min_value=1, max_value=200)
        return out

    @staticmethod
    def _normalize_memory_add(args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        text = _safe_text(out.get("text") or out.get("content"), limit=220)
        if not text:
            text = _safe_text(query, limit=220)
        out["text"] = text
        tags = out.get("tags")
        out["tags"] = tags if isinstance(tags, list) else []
        return out

    @staticmethod
    def _normalize_rgb_set(args: dict[str, Any], query: str, _detector: str) -> dict[str, Any]:
        out = dict(args)
        color = _safe_text(out.get("color"), limit=16).lower()
        if not color:
            color = IntentRegistry._rgb_color_from_text(query, query.lower()) or "off"
        out["color"] = color
        out["persist"] = bool(_coerce_enabled(out.get("persist"))) if out.get("persist") is not None else False
        out["intensity"] = _clamp_int(out.get("intensity", 255), default=255, min_value=1, max_value=255)
        try:
            duration = float(out.get("duration_sec", 5.0))
        except (TypeError, ValueError):
            duration = 5.0
        out["duration_sec"] = max(1.0, duration)
        return out

    def _normalize_action(self, action: dict[str, Any], query: str, detector: str) -> tuple[dict[str, Any] | None, str]:
        raw_tool = action.get("tool")
        tool = self._normalize_tool_name(raw_tool)
        if not tool:
            return None, "missing tool name"
        if not self.tool_registry.has(tool):
            return None, f"unsupported tool skipped: {tool}"

        args = action.get("arguments")
        normalized_args = dict(args) if isinstance(args, dict) else {}
        normalizer = self._arg_normalizers.get(tool)
        if normalizer is not None:
            normalized_args = normalizer(normalized_args, query, detector)

        warning = _safe_text(normalized_args.pop("_warning", ""), limit=200)
        spec = self.tool_registry.get(tool) or {}
        side_effect = bool(spec.get("side_effect", False))
        need_confirm, risk_level = self.risk_policy.requires_confirmation(tool, normalized_args, side_effect)
        group = self._normalize_group_id(action.get("group"))
        depends_on = self._normalize_depends_on(action.get("depends_on"))

        row = {
            "tool": tool,
            "arguments": normalized_args,
            "reason": _safe_text(action.get("reason"), limit=120),
            "side_effect": side_effect,
            "risk_level": risk_level,
            "requires_confirmation": need_confirm,
        }
        if group:
            row["group"] = group
        if depends_on:
            row["depends_on"] = depends_on
        return row, warning

    def _build_plan_from_proposals(
        self,
        proposals: list[dict[str, Any]],
        query: str,
        detector: str,
        max_actions: int,
        source: str,
    ) -> tuple[dict[str, Any], list[str]]:
        keep = _clamp_int(max_actions, default=4, min_value=1, max_value=8)
        warnings: list[str] = []
        actions: list[dict[str, Any]] = []

        for item in proposals:
            if len(actions) >= keep:
                warnings.append(f"actions trimmed to {keep}")
                break
            normalized, warn = self._normalize_action(item, query, detector)
            if warn:
                warnings.append(warn)
            if normalized is None:
                continue
            actions.append(normalized)

        actions = self._attach_dag_metadata(actions)

        plan = {
            "summary": _safe_text(query or "tool command", limit=220),
            "actions": actions,
            "source": _safe_text(source, limit=32) or "intent_registry",
            "needs_clarification": False,
            "clarification_question": "",
            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
            "needs_confirmation": any(bool(row.get("requires_confirmation", False)) for row in actions),
        }
        return plan, warnings

    def build_plan(
        self,
        query: str,
        detector: str,
        max_actions: int,
        force_llm: bool,
    ) -> tuple[dict[str, Any], list[str]]:
        proposals, warnings = self.intent_registry.plan(query, detector, max_actions)
        plan, normalize_warnings = self._build_plan_from_proposals(
            proposals,
            query=query,
            detector=detector,
            max_actions=max_actions,
            source="intent_registry",
        )
        warnings.extend(normalize_warnings)
        return plan, warnings

    def build_plan_from_proposals(
        self,
        proposals: list[dict[str, Any]],
        *,
        query: str,
        detector: str,
        max_actions: int,
        source: str = "llm_tool_planner",
    ) -> tuple[dict[str, Any], list[str]]:
        return self._build_plan_from_proposals(
            proposals,
            query=query,
            detector=detector,
            max_actions=max_actions,
            source=source,
        )

    def rebuild_plan(
        self,
        pending_plan: dict[str, Any],
        query: str,
        detector: str,
        max_actions: int,
    ) -> tuple[dict[str, Any], list[str]]:
        actions_raw = pending_plan.get("actions")
        proposals: list[dict[str, Any]] = []
        if isinstance(actions_raw, list):
            for item in actions_raw:
                if not isinstance(item, dict):
                    continue
                proposals.append(
                    {
                        "tool": item.get("tool"),
                        "arguments": item.get("arguments") if isinstance(item.get("arguments"), dict) else {},
                        "reason": item.get("reason") or "pending plan",
                        "group": item.get("group"),
                        "depends_on": item.get("depends_on"),
                    }
                )
        if not proposals:
            return self.build_plan(query=query, detector=detector, max_actions=max_actions, force_llm=False)
        source = _safe_text(pending_plan.get("source"), limit=32) or "pending"
        return self._build_plan_from_proposals(
            proposals,
            query=query,
            detector=detector,
            max_actions=max_actions,
            source=source,
        )


class AssistantFeedbackComposer:
    def __init__(self) -> None:
        self._summaries: dict[str, Callable[[dict[str, Any]], str]] = {
            "system.time": self._summary_system_time,
            "system.cpu": self._summary_system_cpu,
            "system.mem": self._summary_system_mem,
            "system.npu": self._summary_system_npu,
            "system.thermal": self._summary_system_thermal,
            "vision.sensors.get": self._summary_vision_sensors_get,
            "vision.sensors.thresholds.set": self._summary_vision_sensors_thresholds_set,
            "vision.sensors.sample.set": self._summary_vision_sensors_sample_set,
            "vision.enabled.get": self._summary_vision_enabled,
            "vision.profile.get": self._summary_vision_profile,
            "vision.gimbal.status": self._summary_vision_gimbal_status,
            "vision.gimbal.command": self._summary_vision_gimbal_command,
            "vision.gimbal.laser.blink": self._summary_vision_gimbal_laser_blink,
            "vision.gimbal.lock.status": self._summary_vision_gimbal_lock_status,
            "vision.gimbal.lock.start": self._summary_vision_gimbal_lock_start,
            "vision.gimbal.lock.stop": self._summary_vision_gimbal_lock_stop,
            "vision.observe": self._summary_vision_observe,
            "vision.yolo_world.prompt.set": self._summary_vision_yolo_world_prompt_set,
            "vision.yolo_world.filter.set": self._summary_vision_yolo_world_filter_set,
        }

    @staticmethod
    def _summary_system_time(result: dict[str, Any]) -> str:
        summary_cn = _safe_text(result.get("summary_cn"), limit=96)
        if summary_cn:
            return summary_cn
        part = _safe_text(result.get("part"), limit=24).lower()
        if part == "weekday":
            weekday = _safe_text(result.get("weekday_cn") or result.get("weekday_en"), limit=16)
            return f"今天是{weekday}。" if weekday else "已获取星期信息。"
        if part == "date":
            date_text = _safe_text(result.get("date"), limit=32)
            return f"今天日期：{date_text}。" if date_text else "已获取日期信息。"
        if part == "time":
            time_text = _safe_text(result.get("time"), limit=32)
            return f"当前时间：{time_text}。" if time_text else "已获取时间信息。"
        local = _safe_text(result.get("local"), limit=64)
        weekday = _safe_text(result.get("weekday_cn") or result.get("weekday_en"), limit=16)
        if local and weekday:
            return f"当前本地时间：{local}（{weekday}）。"
        return f"当前本地时间：{local}。" if local else "已获取时间快照。"

    @staticmethod
    def _summary_system_cpu(result: dict[str, Any]) -> str:
        cpu = result.get("cpu") if isinstance(result.get("cpu"), dict) else {}
        usage = cpu.get("usage_percent")
        try:
            return f"当前 CPU 占用：{float(usage):.2f}%。"
        except (TypeError, ValueError):
            return "已获取 CPU 快照。"

    @staticmethod
    def _summary_system_mem(result: dict[str, Any]) -> str:
        mem = result.get("memory") if isinstance(result.get("memory"), dict) else {}
        usage = mem.get("used_percent")
        try:
            return f"当前内存占用：{float(usage):.2f}%。"
        except (TypeError, ValueError):
            return "已获取内存快照。"

    @staticmethod
    def _summary_system_npu(result: dict[str, Any]) -> str:
        npu = result.get("npu") if isinstance(result.get("npu"), dict) else {}
        usage = npu.get("usage_percent")
        try:
            return f"当前 NPU 占用：{float(usage):.2f}%。"
        except (TypeError, ValueError):
            return "已获取 NPU 快照。"

    @staticmethod
    def _summary_system_thermal(result: dict[str, Any]) -> str:
        value = result.get("max_temp_c")
        try:
            return f"当前最高温度：{float(value):.2f}C。"
        except (TypeError, ValueError):
            return "已获取温度快照。"

    @staticmethod
    def _summary_vision_sensors_get(result: dict[str, Any]) -> str:
        overall = _safe_text(result.get("overall_status"), limit=24).lower()
        latest = result.get("latest") if isinstance(result.get("latest"), dict) else {}
        alerts = result.get("alerts") if isinstance(result.get("alerts"), list) else []
        advice_text = _safe_text(result.get("advice_text"), limit=180)

        def _fmt(name: str, unit: str) -> str:
            try:
                return f"{float(latest.get(name)):.2f}{unit}"
            except (TypeError, ValueError):
                return "--"

        if overall == "waiting":
            return "传感器页面已就绪，正在等待 USB 串口样本。"
        base = (
            f"当前传感器：温度 {_fmt('temperature_c', '°C')}，"
            f"pH {_fmt('ph', '')}，浊度 {_fmt('turbidity_ntu', ' NTU')}。"
        )
        if alerts:
            alert_text = "、".join(_safe_text(item, limit=40) for item in alerts[:3] if _safe_text(item, limit=40))
            if alert_text:
                base += f" 告警：{alert_text}。"
        if advice_text:
            base += f" 建议：{advice_text}"
        return base

    @staticmethod
    def _summary_vision_sensors_thresholds_set(result: dict[str, Any]) -> str:
        changed = result.get("changed") if isinstance(result.get("changed"), list) else []
        summary = _safe_text(result.get("summary"), limit=160)
        if summary:
            return summary
        if changed:
            labels = "、".join(_safe_text(item, limit=24) for item in changed[:3] if _safe_text(item, limit=24))
            if labels:
                return f"已更新传感器阈值：{labels}。"
        return "已更新传感器阈值。"

    @staticmethod
    def _summary_vision_sensors_sample_set(result: dict[str, Any]) -> str:
        summary = _safe_text(result.get("summary"), limit=160)
        return summary or "已更新最新传感器样本。"

    @staticmethod
    def _summary_vision_enabled(result: dict[str, Any]) -> str:
        enabled = bool(result.get("enabled", False))
        return "视觉服务已启用。" if enabled else "视觉服务未启用。"

    @staticmethod
    def _summary_vision_profile(result: dict[str, Any]) -> str:
        current = _safe_text(result.get("current"), limit=48) or "unknown"
        stream_enabled = bool(result.get("stream_enabled", False))
        yolo_backend = _safe_text(result.get("yolo_backend_requested"), limit=24) or "unknown"
        yolo_world_ready = bool(result.get("yolo_world_ready", False))
        return (
            f"视觉配置={current}，预览流={'开' if stream_enabled else '关'}，"
            f"yolo_backend={yolo_backend}，yolo_world_ready={int(yolo_world_ready)}。"
        )

    @staticmethod
    def _summary_vision_gimbal_status(result: dict[str, Any]) -> str:
        if not bool(result.get("enabled", False)):
            return "云台串口桥未启用（无法获取激光状态）。"
        if not bool(result.get("configured", False)):
            return "云台串口未配置（无法获取激光状态）。"
        default_flags = result.get("default_flags") if isinstance(result.get("default_flags"), dict) else {}
        laser_raw = _coerce_action_flag(default_flags.get("laser_enabled"))
        stability_raw = _coerce_action_flag(default_flags.get("stability_enabled"))
        if laser_raw == 1:
            laser_state = "开"
        elif laser_raw == 0:
            laser_state = "关"
        else:
            laser_state = "保持"
        if stability_raw == 1:
            stability_state = "开"
        elif stability_raw == 0:
            stability_state = "关"
        else:
            stability_state = "保持"
        link = "已连接" if bool(result.get("connected", False)) else "未连接"
        return (
            f"云台串口链路{link}；默认激光={laser_state}，"
            f"默认稳像={stability_state}。"
        )

    @staticmethod
    def _summary_vision_gimbal_command(result: dict[str, Any]) -> str:
        cmd = result.get("command") if isinstance(result.get("command"), dict) else {}
        yaw = cmd.get("yaw_rpm")
        pitch = cmd.get("pitch_rpm")
        laser_raw = _coerce_action_flag(cmd.get("laser_enabled"))
        laser_note = ""
        if laser_raw == 1:
            laser_note = "激光=开"
        elif laser_raw == 0:
            laser_note = "激光=关"
        try:
            base = f"云台速度命令已发送（偏航速度 {float(yaw):.2f} rpm，俯仰速度 {float(pitch):.2f} rpm）"
        except (TypeError, ValueError):
            base = "云台速度命令已发送"
        if laser_note:
            return f"{base}，{laser_note}。"
        return f"{base}。"

    @staticmethod
    def _summary_vision_gimbal_laser_blink(result: dict[str, Any]) -> str:
        if not bool(result.get("ok", False)):
            err = _safe_text(result.get("error"), limit=120) or "激光闪烁失败"
            return f"激光闪烁失败：{err}。"
        blink_done = _clamp_int(result.get("blink_done", 0), default=0, min_value=0, max_value=99)
        blinks = _clamp_int(result.get("blinks", blink_done), default=blink_done, min_value=0, max_value=99)
        period = _clamp_int(result.get("period_ms", 0), default=0, min_value=0, max_value=10000)
        if period > 0:
            return f"激光已闪烁 {blink_done}/{blinks} 次，周期 {period} ms。"
        return f"激光已闪烁 {blink_done}/{blinks} 次。"

    @staticmethod
    def _summary_vision_gimbal_lock_status(result: dict[str, Any]) -> str:
        active = bool(result.get("active", False))
        status = _safe_text(result.get("status"), limit=40).lower()
        target = _safe_text(result.get("target_raw"), limit=64)
        state_map = {
            "running": "运行中",
            "starting": "启动中",
            "stopping": "停止中",
            "stopped": "已停止",
            "idle": "空闲",
            "ready": "就绪",
            "error": "异常",
        }
        state = state_map.get(status, status) if status else "运行中"
        if active:
            if target:
                return f"云台锁定{state}，目标：{target}。"
            return f"云台锁定{state}。"
        if status and status not in ("idle", "ready"):
            return f"云台锁定当前空闲（最近状态：{state_map.get(status, status)}）。"
        return "云台锁定当前空闲。"

    @staticmethod
    def _summary_vision_gimbal_lock_start(result: dict[str, Any]) -> str:
        if not bool(result.get("ok", False)):
            err = _safe_text(result.get("error"), limit=120) or "启动失败"
            return f"云台锁定启动失败：{err}。"
        target = _safe_text(result.get("target_raw"), limit=64)
        detail_note = _safe_text(result.get("observe_detail_note"), limit=160)
        if not detail_note:
            detail_requested = bool(result.get("observe_detail_requested", False))
            target_human = bool(result.get("target_human", False))
            if detail_requested and (not target_human):
                detail_note = "已忽略仅对人物生效的细节标志（当前目标不是人物）"
        if target:
            summary = f"云台锁定任务已启动，目标：{target}。"
        else:
            summary = "云台锁定任务已启动。"
        if detail_note:
            summary = f"{summary} {detail_note}。"
        return summary

    @staticmethod
    def _summary_vision_gimbal_lock_stop(result: dict[str, Any]) -> str:
        if not bool(result.get("ok", False)):
            err = _safe_text(result.get("error"), limit=120) or "停止失败"
            return f"云台锁定停止失败：{err}。"
        if bool(result.get("thread_alive", False)):
            return "已请求停止云台锁定，后台任务正在退出。"
        return "云台锁定已停止。"

    @staticmethod
    def _summary_vision_observe(result: dict[str, Any]) -> str:
        return _brief_vision_observe_text(result)

    @staticmethod
    def _summary_vision_yolo_world_prompt_set(result: dict[str, Any]) -> str:
        return _brief_tool_result_summary("vision.yolo_world.prompt.set", result, bool(result.get("ok", False)))

    @staticmethod
    def _summary_vision_yolo_world_filter_set(result: dict[str, Any]) -> str:
        return _brief_tool_result_summary("vision.yolo_world.filter.set", result, bool(result.get("ok", False)))

    def compose_no_action(self, query: str, force_llm: bool, llm_fallback_enabled: bool) -> str:
        _ = llm_fallback_enabled
        if force_llm:
            return "规则规划器与 LLM 工具规划器都未产出可执行动作。"
        q = _safe_text(query, limit=80)
        return f"未规划到可执行动作：{q}" if q else "未规划到可执行动作。"

    @staticmethod
    def compose_pending(confirm_actions: int) -> str:
        return (
            f"该计划包含{confirm_actions}个高风险操作。"
            "请携带 `confirm_token` 并设置 `allow_execute=true` 后重新提交执行。"
        )

    @staticmethod
    def compose_plan_only(side_effect_actions: int) -> str:
        if side_effect_actions <= 1:
            return "当前是预览模式：已生成可执行操作，但尚未真正执行。"
        return f"当前是预览模式：已生成{side_effect_actions}个可执行操作，但尚未真正执行。"

    def _action_summary(self, action_result: dict[str, Any]) -> str:
        tool = _safe_text(action_result.get("tool"), limit=80)
        ok = bool(action_result.get("ok", False))
        result = action_result.get("result") if isinstance(action_result.get("result"), dict) else {}
        if not ok:
            brief_err = _brief_tool_result_summary(tool, result, ok=False)
            if brief_err:
                return brief_err
            err = _safe_text(result.get("error") or "执行失败", limit=180)
            return f"{tool} 执行失败：{err}"
        custom = self._summaries.get(tool)
        if custom is not None:
            return custom(result)
        summary = _brief_tool_result_summary(tool, result, ok=True)
        if summary:
            return summary
        return f"{tool} 已执行。"

    def compose_execution(self, action_results: list[dict[str, Any]], all_ok: bool) -> str:
        if not action_results:
            return "未执行任何操作。"
        if len(action_results) == 1:
            return self._action_summary(action_results[0])
        parts = [self._action_summary(row).rstrip("。.;；") for row in action_results[:3]]
        merged = "；".join(part for part in parts if part)
        if not merged:
            merged = "已执行多项操作。"
        if not merged.endswith(("。", "！", "？")):
            merged += "。"
        if not all_ok:
            merged += "部分操作执行失败。"
        return merged


class TriggerPolicyEngine:
    def __init__(
        self,
        cooldown_sec: float,
        temp_high_c: float,
        mem_high_percent: float,
        frame_stale_ms: float,
    ) -> None:
        self.cooldown_sec = max(1.0, float(cooldown_sec))
        self.temp_high_c = float(temp_high_c)
        self.mem_high_percent = float(mem_high_percent)
        self.frame_stale_ms = float(frame_stale_ms)
        self._lock = threading.Lock()
        self._last_fired: dict[str, float] = {}

    def _can_fire(self, key: str) -> bool:
        now_ts = time.monotonic()
        with self._lock:
            last = float(self._last_fired.get(key, 0.0))
            if (now_ts - last) < self.cooldown_sec:
                return False
            self._last_fired[key] = now_ts
            return True

    @staticmethod
    def _extract_mem_used_pct(mem_result: dict[str, Any]) -> float:
        mem = mem_result.get("memory") if isinstance(mem_result.get("memory"), dict) else {}
        try:
            return float(mem.get("used_percent", 0.0))
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _extract_max_temp(thermal_result: dict[str, Any]) -> float | None:
        value = thermal_result.get("max_temp_c")
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _extract_frame_age_ms(observe_result: dict[str, Any]) -> float | None:
        camera = observe_result.get("camera") if isinstance(observe_result.get("camera"), dict) else {}
        value = camera.get("frame_age_ms")
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def evaluate(
        self,
        dry_run: bool,
        executor: ActionExecutor,
        trace_ctx: TraceContext,
        trace_store: TraceStore,
    ) -> dict[str, Any]:
        thermal_started = time.perf_counter()
        thermal = executor.run_tool("system.thermal", {}, timeout_sec=executor.timeout_short_sec)
        TraceStore.step(
            trace_ctx,
            "trigger.sensor.thermal",
            bool(thermal.get("ok", False)),
            _safe_text(thermal.get("summary") or thermal.get("error") or "thermal sampled", limit=220),
            duration_ms=(time.perf_counter() - thermal_started) * 1000.0,
        )

        mem_started = time.perf_counter()
        mem = executor.run_tool("system.mem", {}, timeout_sec=executor.timeout_short_sec)
        TraceStore.step(
            trace_ctx,
            "trigger.sensor.mem",
            bool(mem.get("ok", False)),
            _safe_text(mem.get("summary") or mem.get("error") or "memory sampled", limit=220),
            duration_ms=(time.perf_counter() - mem_started) * 1000.0,
        )

        obs_started = time.perf_counter()
        observe = executor.run_tool(
            "vision.observe",
            {"detector": "none"},
            timeout_sec=executor.timeout_short_sec,
        )
        TraceStore.step(
            trace_ctx,
            "trigger.sensor.observe",
            bool(observe.get("ok", False)),
            _safe_text(observe.get("summary") or observe.get("error") or "observe sampled", limit=220),
            duration_ms=(time.perf_counter() - obs_started) * 1000.0,
        )

        max_temp = self._extract_max_temp(thermal)
        mem_used_pct = self._extract_mem_used_pct(mem)
        frame_age_ms = self._extract_frame_age_ms(observe)

        candidates: list[tuple[str, str, dict[str, Any], str]] = []
        if max_temp is not None and max_temp >= self.temp_high_c and self._can_fire("temp.high"):
            candidates.append(
                (
                    "temp.high",
                    "vision.profile.set",
                    {"name": "stable"},
                    f"temp_high({max_temp:.1f} >= {self.temp_high_c:.1f})",
                )
            )
        if mem_used_pct >= self.mem_high_percent and self._can_fire("mem.high"):
            candidates.append(
                (
                    "mem.high",
                    "vision.stream.set",
                    {"enabled": False, "reason": "auto-mem-protect"},
                    f"mem_high({mem_used_pct:.1f}% >= {self.mem_high_percent:.1f}%)",
                )
            )
        if frame_age_ms is not None and frame_age_ms >= self.frame_stale_ms and self._can_fire("frame.stale"):
            candidates.append(
                (
                    "frame.stale",
                    "vision.recover",
                    {"reason": "auto-frame-stale"},
                    f"frame_stale({frame_age_ms:.1f}ms >= {self.frame_stale_ms:.1f}ms)",
                )
            )

        actions: list[dict[str, Any]] = []
        for trig_key, tool_name, args, reason in candidates:
            row: dict[str, Any] = {
                "trigger": trig_key,
                "action": tool_name,
                "arguments": args,
                "dry_run": bool(dry_run),
                "reason": reason,
                "timestamp": _ts_now(),
            }
            if dry_run:
                row["ok"] = True
                row["result"] = {"ok": True, "summary": "dry-run"}
                TraceStore.step(trace_ctx, f"trigger.action.{tool_name}", True, f"dry-run: {reason}")
            else:
                started = time.perf_counter()
                result = executor.run_tool(tool_name, args, timeout_sec=executor.timeout_long_sec)
                row["ok"] = bool(result.get("ok", False))
                row["result"] = result
                TraceStore.step(
                    trace_ctx,
                    f"trigger.action.{tool_name}",
                    bool(row["ok"]),
                    _safe_text(result.get("summary") or result.get("error") or reason, limit=220),
                    duration_ms=(time.perf_counter() - started) * 1000.0,
                )
            actions.append(row)

        return {
            "ok": True,
            "timestamp": _ts_now(),
            "dry_run": bool(dry_run),
            "thresholds": {
                "temp_high_c": self.temp_high_c,
                "mem_high_percent": self.mem_high_percent,
                "frame_stale_ms": self.frame_stale_ms,
                "cooldown_sec": self.cooldown_sec,
            },
            "sensors": {
                "max_temp_c": max_temp,
                "mem_used_percent": round(mem_used_pct, 2),
                "frame_age_ms": frame_age_ms,
            },
            "actions": actions,
        }


@dataclass(frozen=True)
class RouteSpec:
    key: str
    path_regex: re.Pattern[str]
    methods: frozenset[str]


class AgentServiceApp:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config
        self.vision_client = JsonHttpClient(config.vision_api_base)
        self.llm_client = JsonHttpClient(config.llm_api_base)
        self._feedback_style_lock = threading.Lock()
        self._feedback_style_seq = 0
        self.tool_registry = ToolRegistry(DEFAULT_TOOL_SPECS)
        self.risk_policy = RiskPolicy(self.tool_registry, config.confirm_min_risk)
        self.intent_registry = IntentRegistry()
        self.planner = CommandPlanner(self.intent_registry, self.tool_registry, self.risk_policy)
        self.confirm_store = ConfirmTokenStore(config.confirm_ttl_sec)
        self.trace_store = TraceStore(config.trace_capacity, config.trace_retention_sec)
        self.sampler = LocalMetricSampler()
        self.memory_store = LocalMemoryStore(
            enabled=config.memory_enabled,
            max_items=config.memory_max_items,
            max_text=config.memory_max_text,
            persist_enabled=config.memory_persist_enabled,
            persist_path=config.memory_persist_path,
        )
        self.memory_auto_capture_enabled = bool(config.memory_auto_capture_enabled)
        self.memory_auto_capture_on_failure = bool(config.memory_auto_capture_on_failure)
        self._knowledge_docs_lock = threading.Lock()
        self._knowledge_docs_signature: tuple[tuple[str, int, int], ...] = ()
        self._knowledge_docs_cache: list[dict[str, Any]] = []
        self.rgb_controller = LocalRgbController(backend=config.rgb_backend)
        self.vision_adapter = VisionToolAdapter(
            client=self.vision_client,
            timeout_short_sec=config.timeout_short_sec,
            timeout_long_sec=config.timeout_long_sec,
        )
        self._camera_alias_sync_lock = threading.Lock()
        self._camera_alias_sync_last_ts = 0.0
        self._camera_alias_sync_interval_sec = max(
            3.0,
            float(os.environ.get("AGENT_CAMERA_ALIAS_SYNC_SEC", "3")),
        )
        self._camera_alias_sync_last_active_vocab = ""
        self._camera_alias_sync_last_labels_path = ""
        self._camera_alias_sync_last_aliases_path = ""
        self._camera_capability_sync_lock = threading.Lock()
        self._camera_capability_sync_last_ts = 0.0
        self._camera_capability_sync_interval_sec = max(
            3.0,
            float(os.environ.get("AGENT_CAMERA_CAPABILITY_SYNC_SEC", "3")),
        )
        self._camera_capability_sync_last_fingerprint = ""
        self._llm_planner_concurrency = _clamp_int(
            self.config.llm_planner_concurrency,
            default=1,
            min_value=1,
            max_value=4,
        )
        self._llm_planner_slot_wait_sec = max(0.0, float(self.config.llm_planner_slot_wait_sec))
        self._llm_planner_slot = threading.BoundedSemaphore(value=self._llm_planner_concurrency)
        self._llm_planner_metrics_lock = threading.Lock()
        self._llm_planner_counters: dict[str, int] = {
            "pure_llm_hit": 0,
            "parse_fail": 0,
            "repair_success": 0,
            "strict_fail": 0,
            "fallback_used": 0,
        }
        self._llm_planner_latency_ms: deque[float] = deque(maxlen=1024)
        self._fast_chat_cache_lock = threading.Lock()
        self._fast_chat_cache: dict[str, dict[str, Any]] = {}
        self._fast_chat_cache_enabled = os.environ.get("AGENT_LLM_FAST_CHAT_CACHE", "1") not in (
            "0",
            "false",
            "False",
        )
        self._fast_chat_cache_ttl_sec = max(
            30.0,
            min(1200.0, float(os.environ.get("AGENT_LLM_FAST_CHAT_CACHE_TTL_SEC", "180"))),
        )
        self._fast_chat_cache_max_items = _clamp_int(
            os.environ.get("AGENT_LLM_FAST_CHAT_CACHE_MAX", "120"),
            default=120,
            min_value=20,
            max_value=1000,
        )
        self._semantic_plan_cache_lock = threading.Lock()
        self._semantic_plan_cache: dict[str, dict[str, Any]] = {}
        self._semantic_plan_cache_hits = 0
        self._semantic_plan_cache_misses = 0
        self._semantic_plan_cache_puts = 0
        self.semantic_intent_router = SemanticIntentRouter(
            enabled=self.config.command_embed_router_enabled,
            model_name_or_path=self.config.command_embed_router_model,
            min_score=self.config.command_embed_router_min_score,
            min_margin=self.config.command_embed_router_min_margin,
            use_npu=self.config.command_embed_router_use_npu,
            local_files_only=self.config.command_embed_router_local_files_only,
            classifier_enabled=self.config.command_embed_classifier_enabled,
            classifier_path=self.config.command_embed_classifier_path,
            classifier_min_prob=self.config.command_embed_classifier_min_prob,
            model_only=self.config.command_embed_model_only,
        )
        if bool(self.config.command_embed_router_prewarm):
            self.semantic_intent_router.prewarm()
        self.executor = ActionExecutor(
            runtime_mode=config.tool_runtime,
            vision_adapter=self.vision_adapter,
            sampler=self.sampler,
            memory_store=self.memory_store,
            rgb_controller=self.rgb_controller,
            timeout_short_sec=config.timeout_short_sec,
            timeout_long_sec=config.timeout_long_sec,
            exec_read_parallelism=config.exec_read_parallelism,
        )
        self.feedback = AssistantFeedbackComposer()
        self.trigger_engine = TriggerPolicyEngine(
            cooldown_sec=config.trigger_cooldown_sec,
            temp_high_c=config.trigger_temp_high_c,
            mem_high_percent=config.trigger_mem_high_percent,
            frame_stale_ms=config.trigger_frame_stale_ms,
        )
        self.routes: tuple[RouteSpec, ...] = (
            RouteSpec(
                key="agent.health",
                path_regex=re.compile(r"^/api/agent/health$"),
                methods=frozenset({"GET"}),
            ),
            RouteSpec(
                key="agent.command",
                path_regex=re.compile(r"^/api/agent/command$"),
                methods=frozenset({"POST"}),
            ),
            RouteSpec(
                key="agent.command.llm_first",
                path_regex=re.compile(r"^/api/agent/command_llm_first$"),
                methods=frozenset({"POST"}),
            ),
            RouteSpec(
                key="agent.chat.manual",
                path_regex=re.compile(r"^/api/agent/chat_manual$"),
                methods=frozenset({"POST"}),
            ),
            RouteSpec(
                key="agent.command.manual",
                path_regex=re.compile(r"^/api/agent/command_manual$"),
                methods=frozenset({"POST"}),
            ),
            RouteSpec(
                key="agent.triggers.evaluate",
                path_regex=re.compile(r"^/api/agent/triggers/evaluate$"),
                methods=frozenset({"GET", "POST"}),
            ),
            RouteSpec(
                key="agent.trace.collection",
                path_regex=re.compile(r"^/api/agent/trace$"),
                methods=frozenset({"GET"}),
            ),
            RouteSpec(
                key="agent.trace.item",
                path_regex=re.compile(r"^/api/agent/trace/[A-Za-z0-9_-]{8,64}$"),
                methods=frozenset({"GET"}),
            ),
        )
        self._maybe_sync_camera_capabilities(trace_ctx=None, force=True)
        self._maybe_sync_camera_alias_terms(trace_ctx=None, force=True)

    @staticmethod
    def _percentile_ms(rows: list[float], ratio: float) -> float:
        values = [float(v) for v in rows if float(v) >= 0.0]
        if not values:
            return 0.0
        values.sort()
        rank = int(max(0, min(len(values) - 1, int((len(values) - 1) * ratio))))
        return round(values[rank], 2)

    def _record_llm_planner_metrics(
        self,
        *,
        pure_llm_hit: bool = False,
        parse_fail: bool = False,
        repair_success: bool = False,
        strict_fail: bool = False,
        fallback_used: bool = False,
        latency_ms: float | None = None,
    ) -> None:
        with self._llm_planner_metrics_lock:
            if pure_llm_hit:
                self._llm_planner_counters["pure_llm_hit"] = int(self._llm_planner_counters.get("pure_llm_hit", 0)) + 1
            if parse_fail:
                self._llm_planner_counters["parse_fail"] = int(self._llm_planner_counters.get("parse_fail", 0)) + 1
            if repair_success:
                self._llm_planner_counters["repair_success"] = int(self._llm_planner_counters.get("repair_success", 0)) + 1
            if strict_fail:
                self._llm_planner_counters["strict_fail"] = int(self._llm_planner_counters.get("strict_fail", 0)) + 1
            if fallback_used:
                self._llm_planner_counters["fallback_used"] = int(self._llm_planner_counters.get("fallback_used", 0)) + 1
            if latency_ms is not None:
                try:
                    latency_value = float(latency_ms)
                except (TypeError, ValueError):
                    latency_value = -1.0
                if latency_value >= 0.0:
                    self._llm_planner_latency_ms.append(latency_value)

    def _llm_planner_metrics_snapshot(self) -> dict[str, Any]:
        with self._llm_planner_metrics_lock:
            counters = {key: int(value) for key, value in self._llm_planner_counters.items()}
            rows = list(self._llm_planner_latency_ms)
        counters["latency_count"] = len(rows)
        counters["latency_p95_ms"] = self._percentile_ms(rows, 0.95)
        return counters

    def _llm_agent_task_request(
        self,
        *,
        payload: dict[str, Any],
        timeout_sec: float,
        use_planner_slot: bool,
    ) -> tuple[int, dict[str, Any] | None, str, float]:
        slot_wait_ms = 0.0
        slot_acquired = False
        if use_planner_slot:
            wait_started = time.perf_counter()
            wait_sec = max(0.0, float(self._llm_planner_slot_wait_sec))
            if wait_sec > 0.0:
                slot_acquired = self._llm_planner_slot.acquire(timeout=wait_sec)
            else:
                slot_acquired = self._llm_planner_slot.acquire(blocking=False)
            slot_wait_ms = (time.perf_counter() - wait_started) * 1000.0
            if not slot_acquired:
                return (
                    0,
                    None,
                    f"planner_slot_timeout(wait_ms={slot_wait_ms:.1f})",
                    round(slot_wait_ms, 2),
                )
        try:
            status, body, err = self.llm_client.request_json(
                "POST",
                "/api/llm/agent_task",
                payload=payload,
                timeout_sec=float(timeout_sec),
            )
            return status, body, err, round(slot_wait_ms, 2)
        finally:
            if use_planner_slot and slot_acquired:
                try:
                    self._llm_planner_slot.release()
                except Exception:
                    pass

    @staticmethod
    def _normalize_cache_query(text: str, *, limit: int) -> str:
        raw = _safe_text(text, limit=limit).strip().lower()
        if not raw:
            return ""
        raw = re.sub(r"[\t\r\n]+", " ", raw)
        raw = re.sub(r"[，,。.!！？?；;：:“”\"'`~·、（）()\[\]{}<>《》—\-_]+", " ", raw)
        raw = re.sub(r"\s+", " ", raw).strip()
        return raw

    @staticmethod
    def _fast_chat_cache_key(query: str) -> str:
        return AgentServiceApp._normalize_cache_query(query, limit=240)

    def _fast_chat_cache_get(self, query: str) -> str:
        if not bool(self._fast_chat_cache_enabled):
            return ""
        key = self._fast_chat_cache_key(query)
        if not key:
            return ""
        now = time.time()
        with self._fast_chat_cache_lock:
            row = self._fast_chat_cache.get(key)
            if not isinstance(row, dict):
                return ""
            ts = float(row.get("ts") or 0.0)
            if (now - ts) > self._fast_chat_cache_ttl_sec:
                self._fast_chat_cache.pop(key, None)
                return ""
            return self._normalize_feedback_text(_safe_text(row.get("reply"), limit=160))

    def _fast_chat_cache_put(self, query: str, reply: str) -> None:
        if not bool(self._fast_chat_cache_enabled):
            return
        key = self._fast_chat_cache_key(query)
        text = self._normalize_feedback_text(_safe_text(reply, limit=160))
        if not key or not text:
            return
        now = time.time()
        with self._fast_chat_cache_lock:
            self._fast_chat_cache[key] = {"reply": text, "ts": now}
            if len(self._fast_chat_cache) <= self._fast_chat_cache_max_items:
                return
            stale = sorted(
                self._fast_chat_cache.items(),
                key=lambda item: float((item[1] or {}).get("ts") or 0.0),
            )
            drop = max(1, len(self._fast_chat_cache) - self._fast_chat_cache_max_items)
            for cache_key, _row in stale[:drop]:
                self._fast_chat_cache.pop(cache_key, None)

    @staticmethod
    def _is_fast_chat_cacheable_query(query: str) -> bool:
        text = _safe_text(query, limit=220)
        if not text:
            return False
        low = text.lower()
        # Context/time-sensitive questions should always go through fresh reasoning.
        dynamic_tokens = (
            "刚刚",
            "刚才",
            "上一句",
            "第一句",
            "本次",
            "回顾",
            "总结一下对话",
            "现在",
            "当前",
            "几点",
            "时间",
            "温度",
            "cpu",
            "mem",
            "memory",
            "npu",
            "what did i just",
            "last message",
            "first message",
            "current",
            "now",
            "status",
        )
        return not any(token in low for token in dynamic_tokens)

    @staticmethod
    def _semantic_plan_cache_history_signature(dialogue_history: list[dict[str, Any]] | None) -> str:
        rows: list[dict[str, Any]] = []
        for raw in list(dialogue_history or [])[-6:]:
            if not isinstance(raw, dict):
                continue
            role = _safe_text(raw.get("role"), limit=20).lower() or "user"
            text = _safe_text(raw.get("text"), limit=120)
            if not text:
                continue
            item: dict[str, Any] = {"role": role, "text": text}
            mode = _safe_text(raw.get("mode"), limit=24).lower()
            if mode:
                item["mode"] = mode
            tools_raw = raw.get("tools") if isinstance(raw.get("tools"), list) else []
            tools = [_safe_text(v, limit=60) for v in tools_raw if _safe_text(v, limit=60)]
            if tools:
                item["tools"] = tools[:4]
            actions_raw = raw.get("actions") if isinstance(raw.get("actions"), list) else []
            action_tools: list[str] = []
            for action_row in actions_raw[:3]:
                if not isinstance(action_row, dict):
                    continue
                tool = _safe_text(action_row.get("tool"), limit=80)
                if tool:
                    action_tools.append(tool)
            if action_tools:
                item["action_tools"] = action_tools
            rows.append(item)
        if not rows:
            return ""
        return json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))[:1800]

    def _semantic_plan_cache_key(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
        strict_llm_mode: bool,
        dialogue_history: list[dict[str, Any]] | None,
    ) -> str:
        query_norm = self._normalize_cache_query(query, limit=360)
        if not query_norm:
            return ""
        key_obj = {
            "query": query_norm,
            "detector": _safe_text(detector, limit=20).lower(),
            "max_actions": int(_clamp_int(max_actions, default=4, min_value=1, max_value=8)),
            "strict": 1 if strict_llm_mode else 0,
            "history": self._semantic_plan_cache_history_signature(dialogue_history),
        }
        raw = json.dumps(key_obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha1(raw.encode("utf-8")).hexdigest()

    @staticmethod
    def _json_deep_copy(value: Any) -> Any:
        try:
            return json.loads(json.dumps(value, ensure_ascii=False))
        except Exception:
            return value

    def _semantic_plan_cache_get(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
        strict_llm_mode: bool,
        dialogue_history: list[dict[str, Any]] | None,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
        if not bool(self.config.llm_semantic_cache_enabled):
            return None, None
        key = self._semantic_plan_cache_key(
            query=query,
            detector=detector,
            max_actions=max_actions,
            strict_llm_mode=strict_llm_mode,
            dialogue_history=dialogue_history,
        )
        if not key:
            return None, None
        now = time.time()
        with self._semantic_plan_cache_lock:
            row = self._semantic_plan_cache.get(key)
            if not isinstance(row, dict):
                self._semantic_plan_cache_misses += 1
                return None, None
            ts = float(row.get("ts") or 0.0)
            if (now - ts) > float(self.config.llm_semantic_cache_ttl_sec):
                self._semantic_plan_cache.pop(key, None)
                self._semantic_plan_cache_misses += 1
                return None, None
            plan = row.get("plan") if isinstance(row.get("plan"), dict) else {}
            meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
            if not isinstance(plan.get("actions"), list):
                self._semantic_plan_cache.pop(key, None)
                self._semantic_plan_cache_misses += 1
                return None, None
            self._semantic_plan_cache_hits += 1
            age_ms = round(max(0.0, (now - ts) * 1000.0), 2)
            copied_plan = self._json_deep_copy(plan)
            copied_meta = self._json_deep_copy(meta) if isinstance(meta, dict) else {}
            copied_meta["cache_hit"] = True
            copied_meta["cache_age_ms"] = age_ms
            copied_meta["cache_ttl_sec"] = float(self.config.llm_semantic_cache_ttl_sec)
            copied_meta["cache_key"] = key[:16]
            return copied_plan, copied_meta

    def _semantic_plan_cache_put(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
        strict_llm_mode: bool,
        dialogue_history: list[dict[str, Any]] | None,
        plan: dict[str, Any],
        llm_meta: dict[str, Any] | None,
    ) -> None:
        if not bool(self.config.llm_semantic_cache_enabled):
            return
        if not isinstance(plan, dict):
            return
        actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
        has_side_effect = any(
            bool(row.get("side_effect", False))
            for row in actions
            if isinstance(row, dict)
        )
        if has_side_effect and (not bool(self.config.llm_semantic_cache_side_effect_enabled)):
            return
        key = self._semantic_plan_cache_key(
            query=query,
            detector=detector,
            max_actions=max_actions,
            strict_llm_mode=strict_llm_mode,
            dialogue_history=dialogue_history,
        )
        if not key:
            return
        mode = _safe_text((llm_meta or {}).get("mode"), limit=16).lower()
        if mode not in ("action", "chat"):
            mode = "action" if actions else "chat"
        if mode != "action":
            return
        reply = self._normalize_feedback_text(_safe_text((llm_meta or {}).get("reply"), limit=220))
        meta = {
            "ok": True,
            "status": int((llm_meta or {}).get("status") or 200),
            "mode": mode,
            "reply": reply,
            "planned_actions": len(actions),
            "source": "llm_semantic_cache",
        }
        row = {
            "ts": time.time(),
            "plan": self._json_deep_copy(plan),
            "meta": meta,
        }
        with self._semantic_plan_cache_lock:
            self._semantic_plan_cache[key] = row
            self._semantic_plan_cache_puts += 1
            max_items = int(self.config.llm_semantic_cache_max_items)
            if len(self._semantic_plan_cache) <= max_items:
                return
            stale = sorted(
                self._semantic_plan_cache.items(),
                key=lambda item: float((item[1] or {}).get("ts") or 0.0),
            )
            drop = max(1, len(self._semantic_plan_cache) - max_items)
            for cache_key, _row in stale[:drop]:
                self._semantic_plan_cache.pop(cache_key, None)

    def _semantic_plan_cache_snapshot(self) -> dict[str, Any]:
        with self._semantic_plan_cache_lock:
            size = len(self._semantic_plan_cache)
            hits = int(self._semantic_plan_cache_hits)
            misses = int(self._semantic_plan_cache_misses)
            puts = int(self._semantic_plan_cache_puts)
        total = hits + misses
        hit_rate = (float(hits) / float(total)) if total > 0 else 0.0
        return {
            "enabled": bool(self.config.llm_semantic_cache_enabled),
            "size": size,
            "max_items": int(self.config.llm_semantic_cache_max_items),
            "ttl_sec": float(self.config.llm_semantic_cache_ttl_sec),
            "side_effect_enabled": bool(self.config.llm_semantic_cache_side_effect_enabled),
            "hits": hits,
            "misses": misses,
            "puts": puts,
            "hit_rate": round(hit_rate, 4),
        }

    def _maybe_sync_camera_capabilities(self, *, trace_ctx: TraceContext | None, force: bool = False) -> None:
        now = time.monotonic()
        with self._camera_capability_sync_lock:
            if not force and (now - self._camera_capability_sync_last_ts) < self._camera_capability_sync_interval_sec:
                return
            self._camera_capability_sync_last_ts = now

        profile = self.vision_adapter.profile_status()
        readable = isinstance(profile, dict) and ("enabled" in profile or "current" in profile)
        if not readable:
            if trace_ctx is not None:
                TraceStore.step(
                    trace_ctx,
                    name="vision.capability.sync",
                    ok=False,
                    detail=_safe_text(profile.get("error") if isinstance(profile, dict) else "profile status failed", limit=220),
                )
            return

        sync_meta = _refresh_camera_capability_state(profile)
        if not bool(sync_meta.get("ok", False)):
            if trace_ctx is not None:
                TraceStore.step(
                    trace_ctx,
                    name="vision.capability.sync",
                    ok=False,
                    detail=_safe_text(sync_meta.get("error") or "capability refresh failed", limit=220),
                )
            return

        fingerprint = _safe_text(sync_meta.get("fingerprint"), limit=1200)
        with self._camera_capability_sync_lock:
            changed = bool(fingerprint and fingerprint != self._camera_capability_sync_last_fingerprint)
            self._camera_capability_sync_last_fingerprint = fingerprint

        if trace_ctx is not None:
            detail = (
                f"count={int(sync_meta.get('capability_count') or 0)}, "
                f"terms={int(sync_meta.get('term_count') or 0)}, changed={changed}"
            )
            TraceStore.step(
                trace_ctx,
                name="vision.capability.sync",
                ok=True,
                detail=detail,
            )

    def _maybe_sync_camera_alias_terms(self, *, trace_ctx: TraceContext | None, force: bool = False) -> None:
        now = time.monotonic()
        with self._camera_alias_sync_lock:
            if not force and (now - self._camera_alias_sync_last_ts) < self._camera_alias_sync_interval_sec:
                return
            self._camera_alias_sync_last_ts = now

        vocab = self.vision_adapter.yolo_world_vocab_status()
        if not bool(vocab.get("ok", False)):
            if trace_ctx is not None:
                TraceStore.step(
                    trace_ctx,
                    name="vision.vocab.sync",
                    ok=False,
                    detail=_safe_text(vocab.get("error") or "vocab status failed", limit=220),
                )
            return

        assets = vocab.get("assets") if isinstance(vocab.get("assets"), dict) else {}
        active_vocab = _safe_text(vocab.get("active_vocab"), limit=80)
        labels_path = _safe_text(assets.get("labels_path"), limit=600)
        aliases_path = _safe_text(assets.get("aliases_path"), limit=600)

        with self._camera_alias_sync_lock:
            unchanged = (
                bool(active_vocab)
                and active_vocab == self._camera_alias_sync_last_active_vocab
                and labels_path == self._camera_alias_sync_last_labels_path
                and aliases_path == self._camera_alias_sync_last_aliases_path
            )
        if unchanged and not force:
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, name="vision.vocab.sync", ok=True, detail=f"unchanged: {active_vocab}")
            return

        sync_meta = _refresh_camera_alias_state(labels_path=labels_path, aliases_path=aliases_path)
        if bool(sync_meta.get("ok", False)):
            with self._camera_alias_sync_lock:
                self._camera_alias_sync_last_active_vocab = active_vocab
                self._camera_alias_sync_last_labels_path = labels_path
                self._camera_alias_sync_last_aliases_path = aliases_path
            if trace_ctx is not None:
                TraceStore.step(
                    trace_ctx,
                    name="vision.vocab.sync",
                    ok=True,
                    detail=(
                        f"active={active_vocab or 'unknown'}, labels={int(sync_meta.get('labels_count') or 0)}, "
                        f"aliases={int(sync_meta.get('alias_count') or 0)}"
                    ),
                )
            return

        if trace_ctx is not None:
            TraceStore.step(
                trace_ctx,
                name="vision.vocab.sync",
                ok=False,
                detail=_safe_text(sync_meta.get("error") or "refresh failed", limit=220),
            )

    def resolve_route(self, path: str) -> RouteSpec | None:
        for route in self.routes:
            if route.path_regex.match(path):
                return route
        return None

    def is_owned_path(self, path: str) -> bool:
        return self.resolve_route(path) is not None

    def owned_route_patterns(self) -> list[str]:
        return [route.path_regex.pattern for route in self.routes]

    @staticmethod
    def _client_id(headers: dict[str, str], remote_ip: str) -> str:
        xff = _safe_text(headers.get("X-Forwarded-For"), limit=220)
        if xff:
            first = _safe_text(xff.split(",", 1)[0], limit=96)
            if first:
                return first
        return _safe_text(remote_ip, limit=96) or "local"

    @staticmethod
    def _extract_llm_text(llm_payload: dict[str, Any], *, allow_assistant_feedback: bool = True) -> str:
        direct = _safe_text(llm_payload.get("llm_text"), limit=4000)
        if direct:
            return direct
        raw = llm_payload.get("llm_response")
        if isinstance(raw, dict):
            choices = raw.get("choices")
            if isinstance(choices, list):
                for item in choices:
                    if not isinstance(item, dict):
                        continue
                    msg = item.get("message")
                    if isinstance(msg, dict):
                        text = _safe_text(msg.get("content"), limit=4000)
                        if text:
                            return text
                    text = _safe_text(item.get("text"), limit=4000)
                    if text:
                        return text
            for key in ("text", "output_text", "response", "result"):
                text = _safe_text(raw.get(key), limit=4000)
                if text:
                    return text
        if allow_assistant_feedback:
            return _safe_text(llm_payload.get("assistant_feedback"), limit=4000)
        return ""

    @staticmethod
    def _extract_first_json_object(text: str) -> str:
        raw = str(text or "")
        start = raw.find("{")
        if start < 0:
            return ""
        depth = 0
        in_str = False
        escape = False
        for idx in range(start, len(raw)):
            ch = raw[idx]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return raw[start: idx + 1]
        return ""

    @staticmethod
    def _dialogue_history_prompt_load(
        dialogue_history: list[dict[str, Any]] | None,
        *,
        max_rows: int = 20,
    ) -> tuple[int, int]:
        rows = [
            row for row in list(dialogue_history or [])[-max(1, int(max_rows)) :]
            if isinstance(row, dict)
        ]
        if not rows:
            return 0, 0
        chars = 0
        for row in rows:
            text = str(row.get("text") or row.get("content") or "")
            chars += len(text)
            tools = row.get("tools") if isinstance(row.get("tools"), list) else []
            if tools:
                chars += sum(len(str(v or "")) for v in tools[:6])
            actions = row.get("actions") if isinstance(row.get("actions"), list) else []
            for action in actions[:4]:
                if not isinstance(action, dict):
                    continue
                chars += len(str(action.get("tool") or ""))
                args = action.get("arguments")
                if isinstance(args, dict):
                    for key, value in list(args.items())[:8]:
                        chars += len(str(key or "")) + len(str(value or ""))
        return len(rows), min(5000, chars)

    @classmethod
    def _adaptive_max_tokens(
        cls,
        *,
        task: str,
        query: str = "",
        dialogue_history: list[dict[str, Any]] | None = None,
        max_actions: int = 0,
        prefer_chinese: bool = False,
        min_tokens: int = 32,
        max_tokens: int = 256,
    ) -> int:
        task_name = str(task or "").strip().lower()
        query_chars = len(str(query or "").strip())
        hist_rows, hist_chars = cls._dialogue_history_prompt_load(dialogue_history, max_rows=20)

        if task_name == "tool_plan":
            complexity = 0
            if query_chars > 24:
                complexity += 1
            if query_chars > 80:
                complexity += 1
            if query_chars > 180:
                complexity += 1
            if (hist_rows >= 6) or (hist_chars > 480):
                complexity += 1
            if (hist_rows >= 12) or (hist_chars > 1200):
                complexity += 1
            tier_budgets = [34, 38, 42, 46, 50, 54]
            tier_idx = max(0, min(len(tier_budgets) - 1, int(complexity)))
            budget = int(tier_budgets[tier_idx]) + min(4, max(0, int(max_actions) - 1))
            return _clamp_int(
                budget,
                default=44,
                min_value=max(34, int(min_tokens)),
                max_value=min(96, int(max_tokens)),
            )

        if task_name == "chat_rewrite":
            budget = (
                (136 if prefer_chinese else 120)
                + min(80, (query_chars // 24) * 8)
                + min(96, (hist_chars // 240) * 8)
            )
            return _clamp_int(
                budget,
                default=(152 if prefer_chinese else 136),
                min_value=max(96, int(min_tokens)),
                max_value=min(320, int(max_tokens)),
            )

        if task_name == "tool_plan_repair":
            budget = 96 + min(64, (query_chars // 48) * 8)
            return _clamp_int(
                budget,
                default=96,
                min_value=max(64, int(min_tokens)),
                max_value=min(224, int(max_tokens)),
            )

        if task_name == "command_gate":
            # Gate only needs a 0/1 classification token; keep budget tight to avoid timeout tails.
            budget = 8 + min(6, (query_chars // 72) * 2)
            if (hist_rows >= 6) or (hist_chars > 480):
                budget += 2
            lo = max(4, int(min_tokens))
            hi = max(lo, min(16, int(max_tokens)))
            default_budget = max(lo, min(8, hi))
            return _clamp_int(
                budget,
                default=default_budget,
                min_value=lo,
                max_value=hi,
            )

        if task_name == "need_action_verify":
            budget = 20 + min(20, (query_chars // 40) * 5)
            return _clamp_int(
                budget,
                default=28,
                min_value=max(18, int(min_tokens)),
                max_value=min(56, int(max_tokens)),
            )

        if task_name in ("polish_execution", "polish_general"):
            budget = 34 + min(26, (query_chars // 38) * 6)
            return _clamp_int(
                budget,
                default=42,
                min_value=max(28, int(min_tokens)),
                max_value=min(80, int(max_tokens)),
            )

        return _clamp_int(96, default=96, min_value=max(32, int(min_tokens)), max_value=max(96, int(max_tokens)))

    @staticmethod
    def _extract_text_terms(text: str, *, max_terms: int = 36) -> set[str]:
        raw = _safe_text(text or "", limit=1200).lower()
        if not raw:
            return set()
        terms: set[str] = set()
        for token in re.findall(r"[a-z0-9._:/-]{2,}|[\u4e00-\u9fff]{1,8}", raw):
            norm = token.strip("._:/-")
            if not norm:
                continue
            terms.add(norm)
            if norm.isascii() and any(ch in norm for ch in "._:/-"):
                for part in re.split(r"[._:/-]+", norm):
                    part_norm = part.strip()
                    if len(part_norm) >= 2:
                        terms.add(part_norm)
        if len(terms) <= max_terms:
            return terms
        ranked = sorted(terms, key=lambda item: (len(item), item), reverse=True)
        return set(ranked[: max(1, int(max_terms))])

    @classmethod
    def _adaptive_timeout_sec(
        cls,
        *,
        task: str,
        base_timeout_sec: float,
        query: str = "",
        dialogue_history: list[dict[str, Any]] | None = None,
        max_actions: int = 0,
        min_sec: float = 1.0,
        max_sec: float = 20.0,
    ) -> float:
        try:
            base_timeout = float(base_timeout_sec)
        except (TypeError, ValueError):
            base_timeout = float(min_sec)
        base_timeout = max(float(min_sec), min(float(max_sec), base_timeout))

        query_chars = len(str(query or "").strip())
        hist_rows, hist_chars = cls._dialogue_history_prompt_load(dialogue_history, max_rows=20)
        complexity = 0
        if query_chars > 24:
            complexity += 1
        if query_chars > 90:
            complexity += 1
        if query_chars > 220:
            complexity += 1
        if (hist_rows >= 6) or (hist_chars > 520):
            complexity += 1
        if (hist_rows >= 14) or (hist_chars > 1500):
            complexity += 1
        if int(max_actions) > 1:
            complexity += 1
        scale = max(0.0, min(1.0, float(complexity) / 6.0))

        task_name = str(task or "").strip().lower()
        if task_name == "tool_plan":
            low = max(float(min_sec), min(base_timeout, 16.5))
            high = max(low, min(base_timeout, 25.0))
        elif task_name == "chat_rewrite":
            low = max(float(min_sec), min(base_timeout, 8.0))
            high = max(low, min(base_timeout, 14.0))
        elif task_name == "tool_plan_repair":
            low = max(float(min_sec), min(base_timeout, 1.6))
            high = max(low, min(base_timeout, 3.0))
        elif task_name == "command_gate":
            low = max(float(min_sec), min(base_timeout, 14.0))
            high = max(low, min(base_timeout, 20.0))
        elif task_name == "need_action_verify":
            low = max(float(min_sec), min(base_timeout, 1.0))
            high = max(low, min(base_timeout, 2.6))
        elif task_name in ("polish_execution", "polish_general"):
            low = max(float(min_sec), min(base_timeout, 2.0))
            high = max(low, min(base_timeout, 5.2))
        else:
            low = max(float(min_sec), min(base_timeout, 2.0))
            high = max(low, base_timeout)

        timeout = low + (high - low) * scale
        return round(max(float(min_sec), min(float(max_sec), timeout)), 2)

    def _select_tool_candidates(
        self,
        *,
        query: str,
        detector: str,
        dialogue_history: list[dict[str, Any]] | None,
        include_side_effect: bool,
        max_candidates: int,
        min_candidates: int = 10,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        specs_all = self.tool_registry.list_dict()
        if not specs_all:
            return [], {"total": 0, "selected": 0, "weak_signal": True}

        max_keep = _clamp_int(max_candidates, default=18, min_value=6, max_value=48)
        min_keep = _clamp_int(min_candidates, default=10, min_value=4, max_value=max_keep)

        query_text = str(query or "")
        query_terms = self._extract_text_terms(query_text, max_terms=42)
        history_facts = _extract_dialogue_action_facts(list(dialogue_history or []), max_rows=16, max_facts=16)
        history_tools = {
            _safe_text(item.get("tool"), limit=80).lower()
            for item in history_facts
            if isinstance(item, dict) and _safe_text(item.get("tool"), limit=80)
        }
        history_domains = {
            tool.split(".", 1)[0]
            for tool in history_tools
            if "." in tool
        }

        def _spec_terms(spec: dict[str, Any]) -> set[str]:
            name = _safe_text(spec.get("name"), limit=80).lower()
            desc = _safe_text(spec.get("description"), limit=240).lower()
            args = spec.get("arguments") if isinstance(spec.get("arguments"), dict) else {}
            chunks = [name, desc]
            if args:
                arg_bits: list[str] = []
                for key, value in list(args.items())[:10]:
                    arg_bits.append(str(key or ""))
                    if isinstance(value, str):
                        arg_bits.append(value[:60])
                    elif isinstance(value, list):
                        arg_bits.extend([str(v)[:24] for v in value[:6]])
                if arg_bits:
                    chunks.append(" ".join(arg_bits))
            terms = self._extract_text_terms(" ".join(chunks), max_terms=40)
            prefix = name.split(".", 1)[0] if "." in name else name
            if prefix:
                terms.add(prefix)
            return terms

        scored: list[tuple[float, dict[str, Any], set[str]]] = []
        for spec in specs_all:
            if not isinstance(spec, dict):
                continue
            side_effect = bool(spec.get("side_effect", False))
            if (not include_side_effect) and side_effect:
                continue
            name = _safe_text(spec.get("name"), limit=80).lower()
            if not name:
                continue
            prefix = name.split(".", 1)[0] if "." in name else name
            terms = _spec_terms(spec)
            overlap = len(query_terms & terms) if query_terms else 0
            score = 0.0
            if overlap > 0:
                score += float(overlap) * 1.75
            if name and (name in query_text.lower()):
                score += 5.0
            if prefix and (prefix in query_terms):
                score += 1.2
            if name in history_tools:
                score += 1.8
            if prefix in history_domains:
                score += 0.9
            if detector and detector != "none" and name.startswith("vision."):
                score += 0.4
            if not side_effect:
                score += 0.2
            scored.append((score, spec, terms))

        if not scored:
            return [], {"total": len(specs_all), "selected": 0, "weak_signal": True}

        scored.sort(
            key=lambda row: (
                -float(row[0]),
                bool((row[1] or {}).get("side_effect", False)),
                _safe_text((row[1] or {}).get("name"), limit=80),
            )
        )

        strongest = float(scored[0][0])
        weak_signal = bool(query_terms) and strongest < 1.2
        dynamic_keep = max_keep
        if weak_signal:
            dynamic_keep = min(22, max(dynamic_keep, 16))

        selected: list[dict[str, Any]] = [dict(row[1]) for row in scored[:dynamic_keep]]
        selected_names = {_safe_text(row.get("name"), limit=80) for row in selected if isinstance(row, dict)}

        # Ensure low-risk read coverage across domains while still pruning overall volume.
        domain_read_anchor: dict[str, str] = {}
        for spec in specs_all:
            if not isinstance(spec, dict):
                continue
            if bool(spec.get("side_effect", False)):
                continue
            name = _safe_text(spec.get("name"), limit=80)
            if not name or "." not in name:
                continue
            domain = name.split(".", 1)[0]
            domain_read_anchor.setdefault(domain, name)
        for _domain, anchor in domain_read_anchor.items():
            if anchor in selected_names:
                continue
            spec = self.tool_registry.get(anchor)
            if isinstance(spec, dict):
                selected.append(dict(spec))
                selected_names.add(anchor)

        if len(selected) < min_keep:
            for _score, spec, _terms in scored:
                name = _safe_text(spec.get("name"), limit=80)
                if not name or name in selected_names:
                    continue
                selected.append(dict(spec))
                selected_names.add(name)
                if len(selected) >= min_keep:
                    break

        if len(selected) > 48:
            selected = selected[:48]
        return selected, {
            "total": len(specs_all),
            "selected": len(selected),
            "weak_signal": weak_signal,
            "query_terms": len(query_terms),
            "history_tools": len(history_tools),
        }

    @staticmethod
    def _tool_schema_type_from_hint(hint: str) -> str:
        text = _safe_text(hint, limit=200).lower()
        if not text:
            return "string"
        if "true|false" in text or "bool" in text or "boolean" in text:
            return "boolean"
        if "int" in text or "float" in text or re.search(r"\d+\s*(\.\.|-)\s*\d+", text):
            return "number"
        return "string"

    @classmethod
    def _build_native_function_tools(
        cls,
        specs: list[dict[str, Any]],
        *,
        max_tools: int = 12,
    ) -> list[dict[str, Any]]:
        tools: list[dict[str, Any]] = []
        for spec in list(specs or [])[: max(1, int(max_tools))]:
            if not isinstance(spec, dict):
                continue
            name = _safe_text(spec.get("name"), limit=80)
            if not name:
                continue
            description = _safe_text(spec.get("description"), limit=220) or name
            args_obj = spec.get("arguments") if isinstance(spec.get("arguments"), dict) else {}
            properties: dict[str, Any] = {}
            for raw_key, raw_hint in list(args_obj.items())[:16]:
                key = _safe_text(raw_key, limit=48)
                if not key:
                    continue
                field: dict[str, Any] = {}
                if isinstance(raw_hint, list):
                    field = {"type": "array", "items": {"type": "string"}}
                    if raw_hint:
                        field["description"] = _safe_text(json.dumps(raw_hint, ensure_ascii=False), limit=180)
                elif isinstance(raw_hint, dict):
                    field = {"type": "object"}
                    field["description"] = _safe_text(json.dumps(raw_hint, ensure_ascii=False), limit=180)
                else:
                    hint = _safe_text(raw_hint, limit=180)
                    field_type = cls._tool_schema_type_from_hint(hint)
                    field = {"type": field_type}
                    if hint:
                        field["description"] = hint
                    enum_vals: list[Any] = []
                    if field_type == "string":
                        tokens = [seg.strip() for seg in hint.split("|") if seg.strip()]
                        if (
                            2 <= len(tokens) <= 10
                            and all(re.fullmatch(r"[A-Za-z0-9._-]{1,24}", token or "") for token in tokens)
                        ):
                            enum_vals = tokens
                    elif field_type == "boolean" and "true|false" in hint.lower():
                        enum_vals = [True, False]
                    if enum_vals:
                        field["enum"] = enum_vals
                properties[key] = field
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": name,
                        "description": description,
                        "parameters": {
                            "type": "object",
                            "properties": properties,
                            "required": [],
                        },
                    },
                }
            )
        return tools

    @classmethod
    def _extract_native_tool_call_actions(
        cls,
        llm_text: str,
        *,
        max_actions: int,
    ) -> list[dict[str, Any]]:
        text = str(llm_text or "")
        if not text:
            return []
        matches = re.findall(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", text, flags=re.DOTALL)
        actions: list[dict[str, Any]] = []
        for raw in matches:
            if len(actions) >= max(1, int(max_actions)):
                break
            try:
                payload = json.loads(raw)
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            name = _safe_text(payload.get("name") or payload.get("tool"), limit=80)
            args = payload.get("arguments")
            if isinstance(args, str):
                parsed_args = {}
                try:
                    maybe = json.loads(args)
                    if isinstance(maybe, dict):
                        parsed_args = dict(maybe)
                except Exception:
                    parsed_args = {}
                args = parsed_args
            if not isinstance(args, dict):
                args = {}
            if not name:
                continue
            actions.append(
                {
                    "tool": name,
                    "arguments": dict(args),
                    "reason": "llm native tool_call",
                }
            )
        return actions

    @classmethod
    def _parse_llm_tool_actions(
        cls,
        llm_text: str,
        *,
        max_actions: int,
    ) -> tuple[list[dict[str, Any]], str, str, str]:
        text = str(llm_text or "").strip()
        if not text:
            return [], "empty llm text", "", ""
        native_actions = cls._extract_native_tool_call_actions(text, max_actions=max_actions)
        if native_actions:
            return native_actions, "", "", "action"

        def _recover_from_partial(raw: str) -> tuple[list[dict[str, Any]], str, str, str]:
            blob = str(raw or "")
            mode_match = re.search(r'"mode"\s*:\s*"?(action|chat)', blob, flags=re.IGNORECASE)
            mode = (mode_match.group(1).lower() if mode_match else "")
            if mode == "chat":
                reply_match = re.search(r'"reply"\s*:\s*"([^"\r\n}]*)', blob, flags=re.IGNORECASE)
                reply = _safe_text(reply_match.group(1) if reply_match else "", limit=320).strip()
                if reply:
                    return [], "", reply, "chat"
                return [], "llm partial chat output without reply", "", "chat"
            if mode == "action":
                tool_match = re.search(r'"tool"\s*:\s*"([a-zA-Z0-9._-]{2,80})', blob, flags=re.IGNORECASE)
                if tool_match:
                    tool = _safe_text(tool_match.group(1), limit=80)
                    if tool:
                        return [{"tool": tool, "arguments": {}, "reason": "llm partial tool planner"}], "", "", "action"
                return [], "llm partial action output without tool", "", "action"
            reply_match = re.search(r'"reply"\s*:\s*"([^"\r\n}]*)', blob, flags=re.IGNORECASE)
            reply = _safe_text(reply_match.group(1) if reply_match else "", limit=320).strip()
            if reply:
                return [], "", reply, "chat"
            return [], "no json object found in llm output", "", ""

        parsed_obj: Any = None
        try:
            parsed_obj = json.loads(text)
        except Exception:
            obj_text = cls._extract_first_json_object(text)
            if not obj_text:
                return _recover_from_partial(text)
            try:
                parsed_obj = json.loads(obj_text)
            except Exception:
                recovered = _recover_from_partial(text)
                if not recovered[1]:
                    return recovered
                return [], "llm json parse failed", "", ""

        actions_raw: list[Any] = []
        explicit_actions_schema = False
        non_action_reply = ""
        declared_mode = ""
        if isinstance(parsed_obj, dict):
            if isinstance(parsed_obj.get("actions"), list):
                actions_raw = list(parsed_obj.get("actions") or [])
                explicit_actions_schema = True
            elif isinstance(parsed_obj.get("plan"), dict):
                plan_obj = parsed_obj.get("plan") if isinstance(parsed_obj.get("plan"), dict) else {}
                if isinstance(plan_obj.get("actions"), list):
                    actions_raw = list(plan_obj.get("actions") or [])
                    explicit_actions_schema = True
            non_action_reply = _safe_text(
                parsed_obj.get("reply")
                or parsed_obj.get("assistant_feedback")
                or parsed_obj.get("response")
                or parsed_obj.get("answer"),
                limit=320,
            )
            non_action_reply = re.sub(r"^\s*<[^>]{1,32}>\s*", "", non_action_reply).strip()
            if non_action_reply.lower() in (
                "非执行请求时给用户的简短中文回复",
                "<short_cn_reply>",
                "short reply",
                "reply",
            ):
                non_action_reply = ""
            if ("短中文回复" in non_action_reply) or ("short_cn_reply" in non_action_reply.lower()):
                non_action_reply = ""
            mode = _safe_text(
                parsed_obj.get("mode")
                or parsed_obj.get("intent")
                or parsed_obj.get("route")
                or parsed_obj.get("type"),
                limit=24,
            ).lower()
            if mode in ("action", "execute", "command", "tool"):
                declared_mode = "action"
            elif mode in ("chat", "talk", "conversation", "non_action", "reply"):
                declared_mode = "chat"
            else:
                need_action = _coerce_enabled(parsed_obj.get("need_action"))
                if need_action is not None:
                    declared_mode = "action" if bool(need_action) else "chat"
            if (not actions_raw):
                single_tool = _safe_text(parsed_obj.get("tool") or parsed_obj.get("name"), limit=80)
                if single_tool:
                    single_args = (
                        parsed_obj.get("arguments")
                        if isinstance(parsed_obj.get("arguments"), dict)
                        else {}
                    )
                    single_reason = _safe_text(parsed_obj.get("reason") or "llm tool planner", limit=120)
                    actions_raw = [{"tool": single_tool, "arguments": dict(single_args), "reason": single_reason}]
                    explicit_actions_schema = True
                    if not declared_mode:
                        declared_mode = "action"
            if (not actions_raw) and isinstance(parsed_obj.get("function_call"), dict):
                function_call = parsed_obj.get("function_call") if isinstance(parsed_obj.get("function_call"), dict) else {}
                single_tool = _safe_text(function_call.get("name"), limit=80)
                single_args_raw = function_call.get("arguments")
                if isinstance(single_args_raw, str):
                    try:
                        parsed_args = json.loads(single_args_raw)
                    except Exception:
                        parsed_args = {}
                    single_args_raw = parsed_args
                single_args = single_args_raw if isinstance(single_args_raw, dict) else {}
                if single_tool:
                    actions_raw = [
                        {
                            "tool": single_tool,
                            "arguments": dict(single_args),
                            "reason": "llm function_call",
                        }
                    ]
                    explicit_actions_schema = True
                    if not declared_mode:
                        declared_mode = "action"
        elif isinstance(parsed_obj, list):
            actions_raw = list(parsed_obj)
            explicit_actions_schema = True
            declared_mode = "action"

        if declared_mode == "chat":
            # Single-call CM: explicit mode=chat is authoritative for non-action flow.
            if not non_action_reply:
                return [], "llm tool plan mode=chat but reply empty", "", "chat"
            return [], "", non_action_reply, "chat"
        if declared_mode == "action" and (not actions_raw):
            return [], "llm tool plan mode=action but actions empty", non_action_reply, "action"

        if (not actions_raw) and explicit_actions_schema:
            # LLM explicitly decided this is a non-executable request.
            return [], "", non_action_reply, "chat"
        if (not actions_raw) and non_action_reply:
            # Accept reply-only JSON as non-action chat output.
            return [], "", non_action_reply, (declared_mode or "chat")
        if not actions_raw:
            return [], "llm tool plan has no actions", "", ""

        proposals: list[dict[str, Any]] = []
        keep = _clamp_int(max_actions, default=4, min_value=1, max_value=8)
        for item in actions_raw:
            if len(proposals) >= keep:
                break
            if isinstance(item, str):
                tool = _safe_text(item, limit=80)
                if not tool:
                    continue
                proposals.append({"tool": tool, "arguments": {}, "reason": "llm tool planner"})
                continue
            if not isinstance(item, dict):
                continue
            tool = _safe_text(item.get("tool") or item.get("name"), limit=80)
            if not tool:
                continue
            args = item.get("arguments") if isinstance(item.get("arguments"), dict) else {}
            reason = _safe_text(item.get("reason") or "llm tool planner", limit=120)
            proposals.append({"tool": tool, "arguments": dict(args), "reason": reason})

        if not proposals:
            return [], "llm tool plan has no valid action entries", non_action_reply, (declared_mode or "action")
        return proposals, "", non_action_reply, (declared_mode or "action")

    @classmethod
    def _should_try_llm_tool_planner(cls, query: str) -> bool:
        # Lexical/keyword pre-routing is intentionally disabled.
        # LLM-first mode should rely on semantic gate instead of token enumeration.
        _ = query
        return False

    @classmethod
    def _parse_llm_command_gate_output(cls, llm_text: str) -> tuple[bool | None, str, str]:
        text = str(llm_text or "").strip()
        if not text:
            return None, "", "empty llm text"
        parsed_obj: Any = None
        try:
            parsed_obj = json.loads(text)
        except Exception:
            obj_text = cls._extract_first_json_object(text)
            if not obj_text:
                low = text.lower()
                if "<tool_call>" in low:
                    return True, "", ""
                if re.search(r"\bneed_action\s*[:=]\s*1\b", low) or re.search(r"\brequires_action\s*[:=]\s*1\b", low):
                    return True, "", ""
                if re.search(r"\bneed_action\s*[:=]\s*0\b", low) or re.search(r"\brequires_action\s*[:=]\s*0\b", low):
                    return False, "", ""
                if re.fullmatch(r"\s*1\s*", low) or re.match(r"^\s*1(\D|$)", low):
                    return True, "", ""
                if re.fullmatch(r"\s*0\s*", low) or re.match(r"^\s*0(\D|$)", low):
                    return False, "", ""
                if re.search(r"\b(action|execute|command|tool)\b", low):
                    return True, "", ""
                if re.search(r"\b(chat|talk|conversation|non_action|reply)\b", low):
                    return False, "", ""
                if any(token in text for token in ("需要调用工具", "需要工具", "要调用", "执行命令")):
                    return True, "", ""
                if any(token in text for token in ("闲聊", "纯聊天", "不需要工具", "无需工具")):
                    return False, "", ""
                return None, "", "no json object found in llm output"
            try:
                parsed_obj = json.loads(obj_text)
            except Exception:
                return None, "", "llm json parse failed"
        if isinstance(parsed_obj, bool):
            return bool(parsed_obj), "", ""
        if isinstance(parsed_obj, (int, float)):
            num = int(parsed_obj)
            if num in (0, 1):
                return bool(num), "", ""
        if isinstance(parsed_obj, str):
            low_val = parsed_obj.strip().lower()
            if low_val in ("0", "1"):
                return bool(int(low_val)), "", ""
            if low_val in ("action", "execute", "command", "tool"):
                return True, "", ""
            if low_val in ("chat", "talk", "conversation", "non_action", "reply"):
                return False, "", ""
        if not isinstance(parsed_obj, dict):
            return None, "", "llm command gate expects JSON object"

        reply = _safe_text(
            parsed_obj.get("reply")
            or parsed_obj.get("assistant_feedback")
            or parsed_obj.get("response")
            or parsed_obj.get("answer"),
            limit=320,
        )
        reply = re.sub(r"^\s*<[^>]{1,32}>\s*", "", reply).strip()
        if reply.lower() in (
            "非执行请求时给用户的简短中文回复",
            "<short_cn_reply>",
            "short reply",
            "reply",
        ):
            reply = ""
        if ("短中文回复" in reply) or ("short_cn_reply" in reply.lower()):
            reply = ""

        mode = _safe_text(
            parsed_obj.get("mode")
            or parsed_obj.get("intent")
            or parsed_obj.get("route")
            or parsed_obj.get("type"),
            limit=24,
        ).lower()
        need_action = _coerce_enabled(
            parsed_obj.get("need_action")
            if ("need_action" in parsed_obj)
            else parsed_obj.get("requires_action")
        )
        if need_action is not None:
            return bool(need_action), reply, ""
        if mode in ("action", "execute", "command", "tool"):
            return True, reply, ""
        if mode in ("chat", "talk", "conversation", "non_action", "reply"):
            return False, reply, ""
        return None, reply, "llm command gate missing mode/need_action"

    def _fallback_llm_command_gate(
        self,
        *,
        query: str,
        detector: str,
        dialogue_history: list[dict[str, Any]] | None,
        trace_ctx: TraceContext,
    ) -> tuple[bool | None, dict[str, Any]]:
        base_timeout = max(1.0, min(20.0, float(self.config.llm_command_gate_timeout_sec)))
        timeout_sec = self._adaptive_timeout_sec(
            task="command_gate",
            base_timeout_sec=base_timeout,
            query=query,
            dialogue_history=dialogue_history,
            min_sec=1.0,
            max_sec=20.0,
        )
        timeout_sec = round(min(20.0, max(16.0, float(timeout_sec))), 2)
        candidate_specs, candidate_meta = self._select_tool_candidates(
            query=query,
            detector=detector,
            dialogue_history=dialogue_history,
            include_side_effect=False,
            max_candidates=6,
            min_candidates=4,
        )
        read_tool_names: list[str] = []
        for spec in candidate_specs:
            name = _safe_text(spec.get("name"), limit=80)
            if name:
                read_tool_names.append(name)
        prompt_obj = {
            "query": _safe_text(query, limit=220),
            "read_tools": read_tool_names[:8],
        }
        history_rows = list(dialogue_history or [])
        if history_rows:
            prompt_obj["dialogue_history"] = history_rows[-6:]
        prompt = (
            "只输出一个字符：0 或 1，不要任何其他文本。\n"
            "任务：判断 query 是否必须先调用设备工具。\n"
            "规则：读取实时状态/观察画面/执行设备动作 => 1；"
            "问候/身份/解释/回顾等纯对话 => 0；"
            "不确定时输出 1。\n"
            "输入:"
            + json.dumps(prompt_obj, ensure_ascii=False, separators=(",", ":"))
        )
        llm_payload: dict[str, Any] = {
            "task": "command_gate",
            "message": prompt,
            "include_llm_text": True,
            "fast_mode": True,
            "timeout_sec": timeout_sec,
            "enable_thinking": False,
            "temperature": 0.0,
            "top_p": 0.3,
            "top_k": 1,
            "max_tokens": self._adaptive_max_tokens(
                task="command_gate",
                query=query,
                dialogue_history=dialogue_history,
                min_tokens=2,
                max_tokens=4,
            ),
            "max_retries": 0,
            "busy_retries": 0,
            "busy_retry_delay_sec": 0.12,
            "keep_history": False,
            "clear_history": True,
        }
        started = time.perf_counter()
        status, body, err, slot_wait_ms = self._llm_agent_task_request(
            payload=llm_payload,
            timeout_sec=max(2.0, timeout_sec + 0.8),
            use_planner_slot=True,
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        if not base_ok:
            detail = _safe_text(
                err
                or body_obj.get("error")
                or f"status={status or 0}",
                limit=220,
            )
            TraceStore.step(
                trace_ctx,
                name="llm.command_gate",
                ok=False,
                detail=detail,
                duration_ms=(time.perf_counter() - started) * 1000.0,
                status=(status if status > 0 else None),
            )
            return None, {
                "ok": False,
                "status": status,
                "detail": detail,
                "upstream": self.config.llm_api_base,
                "latency_ms": round((time.perf_counter() - started) * 1000.0, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(llm_payload.get("max_tokens") or 0),
                "candidate_tools": int(candidate_meta.get("selected") or len(read_tool_names)),
                "slot_wait_ms": float(slot_wait_ms),
            }
        gate_action, gate_reply, parse_err = self._parse_llm_command_gate_output(llm_text)
        if parse_err:
            raw_preview = _safe_text(llm_text, limit=200)
            TraceStore.step(
                trace_ctx,
                name="llm.command_gate",
                ok=False,
                detail=(f"{parse_err}: {raw_preview}" if raw_preview else parse_err),
                duration_ms=(time.perf_counter() - started) * 1000.0,
                status=(status if status > 0 else None),
            )
            return None, {
                "ok": False,
                "status": status,
                "detail": parse_err,
                "raw_preview": raw_preview,
                "upstream": self.config.llm_api_base,
                "latency_ms": round((time.perf_counter() - started) * 1000.0, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(llm_payload.get("max_tokens") or 0),
                "candidate_tools": int(candidate_meta.get("selected") or len(read_tool_names)),
                "slot_wait_ms": float(slot_wait_ms),
            }
        parsed_obj: dict[str, Any] = {}
        try:
            raw_obj = json.loads(llm_text)
            if isinstance(raw_obj, dict):
                parsed_obj = raw_obj
        except Exception:
            obj_text = self._extract_first_json_object(llm_text)
            if obj_text:
                try:
                    raw_obj = json.loads(obj_text)
                    if isinstance(raw_obj, dict):
                        parsed_obj = raw_obj
                except Exception:
                    parsed_obj = {}

        plan: dict[str, Any] | None = None
        warnings: list[str] = []
        mode = "action" if gate_action else "chat"
        plan_actions = plan.get("actions") if isinstance(plan, dict) and isinstance(plan.get("actions"), list) else []
        detail = f"mode={mode}, actions={len(plan_actions)}"
        detail = (
            f"{detail}, budget={int(llm_payload.get('max_tokens') or 0)}, "
            f"tools={int(candidate_meta.get('selected') or len(read_tool_names))}"
        )
        detail = f"{detail}, slot_wait_ms={round(float(slot_wait_ms), 2)}"
        TraceStore.step(
            trace_ctx,
            name="llm.command_gate",
            ok=True,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        return gate_action, {
            "ok": True,
            "status": status,
            "detail": detail,
            "mode": mode,
            "reply": gate_reply,
            "upstream": self.config.llm_api_base,
            "latency_ms": round((time.perf_counter() - started) * 1000.0, 2),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(llm_payload.get("max_tokens") or 0),
            "candidate_tools": int(candidate_meta.get("selected") or len(read_tool_names)),
            "slot_wait_ms": float(slot_wait_ms),
            "plan": plan if isinstance(plan, dict) else None,
            "plan_warnings": warnings[:4],
        }

    def _fallback_llm_need_action_verify(
        self,
        *,
        query: str,
        dialogue_history: list[dict[str, Any]] | None,
        trace_ctx: TraceContext,
    ) -> tuple[bool | None, dict[str, Any]]:
        base_timeout = max(1.0, min(4.5, float(self.config.llm_command_gate_timeout_sec)))
        timeout_sec = self._adaptive_timeout_sec(
            task="need_action_verify",
            base_timeout_sec=base_timeout,
            query=query,
            dialogue_history=dialogue_history,
            min_sec=1.0,
            max_sec=4.5,
        )
        prompt_obj: dict[str, Any] = {"query": _safe_text(query, limit=220)}
        prompt = (
            "只输出JSON: {\"need_action\":0|1}\n"
            "判定标准: 需要读取当前设备状态(温度/CPU/内存/时间/外设/画面)或执行设备控制 => 1；"
            "普通聊天/身份介绍/寒暄/回顾对话 => 0；不确定 => 1。\n"
            "输入:"
            + json.dumps(prompt_obj, ensure_ascii=False, separators=(",", ":"))
        )
        llm_payload: dict[str, Any] = {
            "task": "need_action_verify",
            "message": prompt,
            "include_llm_text": True,
            "fast_mode": True,
            "timeout_sec": timeout_sec,
            "enable_thinking": False,
            "temperature": 0.2,
            "top_p": 0.9,
            "top_k": 8,
            "max_tokens": self._adaptive_max_tokens(
                task="need_action_verify",
                query=query,
                dialogue_history=dialogue_history,
                min_tokens=20,
                max_tokens=56,
            ),
            "max_retries": 0,
            "busy_retries": 1,
            "busy_retry_delay_sec": 0.08,
        }
        started = time.perf_counter()
        status, body, err, slot_wait_ms = self._llm_agent_task_request(
            payload=llm_payload,
            timeout_sec=max(2.0, timeout_sec + 0.8),
            use_planner_slot=True,
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        if not base_ok:
            detail = _safe_text(
                err or body_obj.get("error") or f"status={status or 0}",
                limit=220,
            )
            TraceStore.step(
                trace_ctx,
                name="llm.need_action.verify",
                ok=False,
                detail=detail,
                duration_ms=(time.perf_counter() - started) * 1000.0,
                status=(status if status > 0 else None),
            )
            return None, {
                "ok": False,
                "status": status,
                "detail": detail,
                "upstream": self.config.llm_api_base,
                "latency_ms": round((time.perf_counter() - started) * 1000.0, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(llm_payload.get("max_tokens") or 0),
                "slot_wait_ms": float(slot_wait_ms),
            }

        parsed_obj: dict[str, Any] = {}
        try:
            raw_obj = json.loads(llm_text)
            if isinstance(raw_obj, dict):
                parsed_obj = raw_obj
        except Exception:
            obj_text = self._extract_first_json_object(llm_text)
            if obj_text:
                try:
                    raw_obj = json.loads(obj_text)
                    if isinstance(raw_obj, dict):
                        parsed_obj = raw_obj
                except Exception:
                    parsed_obj = {}

        need_action = _coerce_enabled(parsed_obj.get("need_action"))
        mode = _safe_text(parsed_obj.get("mode"), limit=16).lower()
        if need_action is None:
            if mode in ("action", "execute", "command", "tool"):
                need_action = True
            elif mode in ("chat", "conversation", "reply"):
                need_action = False
        ok = need_action is not None
        detail = f"need_action={int(bool(need_action))}" if ok else "missing need_action"
        detail = (
            f"{detail}, budget={int(llm_payload.get('max_tokens') or 0)}, "
            f"slot_wait_ms={round(float(slot_wait_ms), 2)}"
        )
        TraceStore.step(
            trace_ctx,
            name="llm.need_action.verify",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        return need_action, {
            "ok": ok,
            "status": status,
            "detail": detail,
            "upstream": self.config.llm_api_base,
            "latency_ms": round((time.perf_counter() - started) * 1000.0, 2),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(llm_payload.get("max_tokens") or 0),
            "slot_wait_ms": float(slot_wait_ms),
        }

    def _repair_llm_tool_plan_json(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
        tool_specs: list[dict[str, Any]],
        raw_llm_text: str,
        trace_ctx: TraceContext,
    ) -> tuple[str, dict[str, Any]]:
        if (not self.config.llm_tool_plan_repair_enabled) or (not raw_llm_text.strip()):
            return "", {
                "ok": False,
                "status": 0,
                "detail": "repair disabled or empty llm text",
                "upstream": self.config.llm_api_base,
                "latency_ms": 0.0,
            }
        base_timeout = max(1.0, min(8.0, float(self.config.llm_tool_plan_repair_timeout_sec)))
        timeout_sec = self._adaptive_timeout_sec(
            task="tool_plan_repair",
            base_timeout_sec=base_timeout,
            query=query,
            min_sec=1.0,
            max_sec=8.0,
            max_actions=max_actions,
        )
        max_tokens = self._adaptive_max_tokens(
            task="tool_plan_repair",
            query=query,
            min_tokens=80,
            max_tokens=192,
        )
        prompt_obj = {
            "query": _safe_text(query, limit=320),
            "detector_hint": _safe_text(detector, limit=24) or "none",
            "max_actions": _clamp_int(max_actions, default=4, min_value=1, max_value=8),
            "available_tools": tool_specs[:48],
            "llm_output": _safe_text(raw_llm_text, limit=1200),
        }
        prompt = (
            "你是 Agent tool_plan JSON 修复器。\n"
            "任务：把 llm_output 修复为一个且仅一个合法 JSON 对象。\n"
            "只能输出 JSON 对象本体，禁止 markdown、代码块、解释、前后缀文本。\n"
            "schema:\n"
            "{\n"
            '  "mode":"action|chat",\n'
            '  "reason":"short",\n'
            '  "actions":[{"tool":"tool.name","arguments":{},"reason":"short"}],\n'
            '  "reply":"<short_cn_reply>"\n'
            "}\n"
            "约束：tool 只能来自 available_tools.name；actions 数量 <= max_actions；"
            "mode=action 时 actions 非空且 reply 置空；"
            "mode=chat 时 actions 为空且 reply 必填（简体中文，<=120字）。\n"
            "语义约束：仅当 query 需要外部工具读取实时状态/视觉观察/设备控制时使用 mode=action；"
            "其余对话类请求使用 mode=chat。\n"
            "问候/身份/能力/运行位置/闲聊类请求必须修复为 mode=chat。\n"
            "对话回顾/总结类请求必须修复为 mode=chat，并直接依据 dialogue_history* 回答；"
            "除非用户明确要求管理记忆，否则禁止修复为 memory.* 动作。\n"
            "禁止编造工具、参数、执行结果或实时数值。\n"
            "输入:\n"
            + json.dumps(prompt_obj, ensure_ascii=False)
        )
        llm_payload: dict[str, Any] = {
            "task": "tool_plan_repair",
            "message": prompt,
            "include_llm_text": True,
            "fast_mode": True,
            "timeout_sec": timeout_sec,
            "enable_thinking": False,
            "temperature": 0.0,
            "top_p": 0.9,
            "max_tokens": max_tokens,
            "max_retries": 0,
            "busy_retries": 0,
            "busy_retry_delay_sec": 0.1,
        }
        started = time.perf_counter()
        status, body, err, slot_wait_ms = self._llm_agent_task_request(
            payload=llm_payload,
            timeout_sec=max(1.2, timeout_sec + 0.6),
            use_planner_slot=True,
        )
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        if not base_ok:
            detail = _safe_text(
                err
                or body_obj.get("error")
                or body_obj.get("llm_text")
                or f"status={status or 0}",
                limit=220,
            )
            TraceStore.step(
                trace_ctx,
                name="llm.tool_plan.repair",
                ok=False,
                detail=detail,
                duration_ms=elapsed_ms,
                status=(status if status > 0 else None),
            )
            return "", {
                "ok": False,
                "status": status,
                "detail": detail,
                "upstream": self.config.llm_api_base,
                "latency_ms": round(elapsed_ms, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(max_tokens),
                "slot_wait_ms": float(slot_wait_ms),
            }
        if not llm_text:
            detail = "repair produced empty output"
            TraceStore.step(
                trace_ctx,
                name="llm.tool_plan.repair",
                ok=False,
                detail=detail,
                duration_ms=elapsed_ms,
                status=(status if status > 0 else None),
            )
            return "", {
                "ok": False,
                "status": status,
                "detail": detail,
                "upstream": self.config.llm_api_base,
                "latency_ms": round(elapsed_ms, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(max_tokens),
                "slot_wait_ms": float(slot_wait_ms),
            }
        TraceStore.step(
            trace_ctx,
            name="llm.tool_plan.repair",
            ok=True,
            detail=f"repaired=1,budget={int(max_tokens)}",
            duration_ms=elapsed_ms,
            status=(status if status > 0 else None),
        )
        return llm_text, {
            "ok": True,
            "status": status,
            "detail": "repaired=1",
            "upstream": self.config.llm_api_base,
            "latency_ms": round(elapsed_ms, 2),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(max_tokens),
            "slot_wait_ms": float(slot_wait_ms),
        }

    def _fallback_llm_command_only_tool_plan(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
        dialogue_history: list[dict[str, Any]] | None,
        llm_session_id: str = "",
        llm_keep_history: bool = False,
        llm_clear_history: bool = False,
        trace_ctx: TraceContext,
    ) -> tuple[dict[str, Any] | None, list[str], dict[str, Any]]:
        if not self.config.llm_tool_planner_enabled:
            TraceStore.step(
                trace_ctx,
                name="llm.command_manual.tool_plan",
                ok=False,
                detail="disabled by AGENT_LLM_TOOL_PLANNER=0",
            )
            return None, [], {
                "ok": False,
                "status": 0,
                "detail": "disabled by AGENT_LLM_TOOL_PLANNER=0",
                "upstream": self.config.llm_api_base,
                "planned_actions": 0,
                "non_action": False,
                "mode": "",
                "reply": "",
                "latency_ms": 0.0,
                "timeout_sec": 0.0,
                "max_tokens": 0,
                "candidate_tools": 0,
                "parse_fail": False,
                "repair_attempted": False,
                "repair_success": False,
                "slot_wait_ms": 0.0,
                "cache_hit": False,
            }

        keep = _clamp_int(max_actions, default=4, min_value=1, max_value=8)
        history_rows = list(dialogue_history or [])
        query_low = str(query or "").lower()
        explicit_memory_request = _is_explicit_agent_memory_request(query, query_low)
        gimbal_motion_hint = bool(
            re.search(
                r"(云台|gimbal|yaw|pitch|镜头|向左|向右|向上|向下|左转|右转|回中|中间|居中|停止|别动|抬头|低头)",
                query_low,
                flags=re.IGNORECASE,
            )
        )
        cpu_hint = bool(
            re.search(r"(cpu|处理器|负载|cpu占用|cpu使用率|cpu usage|cpu utilization)", query_low, flags=re.IGNORECASE)
        )
        npu_hint = bool(
            re.search(r"(npu|rknpu|tops|ai core|神经网络处理器|npu usage|npu占用)", query_low, flags=re.IGNORECASE)
        )
        mem_hint = bool(
            re.search(r"(内存|ram|memory|mem|内存占用|内存使用率)", query_low, flags=re.IGNORECASE)
        )
        observe_hint = bool(
            re.search(
                r"(观察|画面|看一下|看看|识别|检测|snapshot|observe|detect|camera)",
                query_low,
                flags=re.IGNORECASE,
            )
        )
        time_hint = bool(
            re.search(r"(时间|几点|日期|星期|time|date|clock)", query_low, flags=re.IGNORECASE)
        )
        candidate_specs_raw, candidate_meta = self._select_tool_candidates(
            query=query,
            detector=detector,
            dialogue_history=history_rows,
            include_side_effect=True,
            max_candidates=max(8, min(14, keep * 4)),
            min_candidates=max(6, keep + 2),
        )
        candidate_specs: list[dict[str, Any]] = []
        for spec in candidate_specs_raw:
            if not isinstance(spec, dict):
                continue
            name = _safe_text(spec.get("name"), limit=80)
            if (not name) or (not self.tool_registry.has(name)):
                continue
            if (not explicit_memory_request) and name.startswith("memory."):
                continue
            candidate_specs.append(dict(spec))
        if gimbal_motion_hint:
            candidate_specs.sort(
                key=lambda row: (
                    0
                    if _safe_text(row.get("name"), limit=80).startswith("vision.gimbal.")
                    else (1 if _safe_text(row.get("name"), limit=80) == "vision.observe" else 2)
                )
            )
        elif time_hint:
            candidate_specs.sort(
                key=lambda row: (0 if _safe_text(row.get("name"), limit=80) == "system.time" else 1)
            )
        elif mem_hint and (not explicit_memory_request):
            candidate_specs.sort(
                key=lambda row: (
                    0 if _safe_text(row.get("name"), limit=80) == "system.mem" else 1
                )
            )
        elif observe_hint:
            candidate_specs.sort(
                key=lambda row: (0 if _safe_text(row.get("name"), limit=80) == "vision.observe" else 1)
            )
        candidate_specs = candidate_specs[:12]
        candidate_count = int(
            _clamp_int(
                (candidate_meta or {}).get("selected")
                or len(candidate_specs),
                default=len(candidate_specs),
                min_value=0,
                max_value=64,
            )
        )
        if not candidate_specs:
            TraceStore.step(
                trace_ctx,
                name="llm.command_manual.tool_plan",
                ok=False,
                detail="no candidate tools",
            )
            return None, [], {
                "ok": False,
                "status": 0,
                "detail": "no candidate tools",
                "upstream": self.config.llm_api_base,
                "planned_actions": 0,
                "non_action": False,
                "mode": "",
                "reply": "",
                "latency_ms": 0.0,
                "timeout_sec": 0.0,
                "max_tokens": 0,
                "candidate_tools": int(candidate_count),
                "parse_fail": False,
                "repair_attempted": False,
                "repair_success": False,
                "slot_wait_ms": 0.0,
                "cache_hit": False,
            }

        prompt_tool_specs: list[dict[str, Any]] = []
        tool_specs: list[dict[str, Any]] = []
        for spec in candidate_specs:
            name = _safe_text(spec.get("name"), limit=80)
            if not name:
                continue
            row: dict[str, Any] = {"name": name}
            desc = _safe_text(spec.get("description"), limit=64)
            if desc:
                row["description"] = desc
            args_obj = spec.get("arguments") if isinstance(spec.get("arguments"), dict) else {}
            if args_obj:
                args_out: list[str] = []
                for raw_key, _raw_hint in list(args_obj.items())[:8]:
                    key = _safe_text(raw_key, limit=40)
                    if not key:
                        continue
                    args_out.append(key)
                if args_out:
                    row["arguments"] = args_out
            prompt_tool_specs.append(row)
            tool_specs.append({"name": name})

        prompt_obj: dict[str, Any] = {
            "query": _safe_text(query, limit=320),
            "detector_hint": _safe_text(detector, limit=20) or "none",
            "max_actions": keep,
            "tools": prompt_tool_specs,
            "intent_hints": {
                "memory_allowed": bool(explicit_memory_request),
                "gimbal_motion_hint": bool(gimbal_motion_hint),
                "observe_hint": bool(observe_hint),
                "time_hint": bool(time_hint),
            },
        }
        history_text = _format_dialogue_history_for_prompt(history_rows, max_rows=8, max_chars=520)
        if history_text:
            prompt_obj["dialogue_history_text"] = history_text
        action_facts = _extract_dialogue_action_facts(history_rows, max_rows=8, max_facts=8)
        if action_facts:
            prompt_obj["dialogue_action_facts"] = action_facts

        prompt = (
            "你是 command_manual 的工具规划器。仅输出一个 JSON 对象，不要其它文本。\n"
            "schema:{\"mode\":\"action|chat\",\"actions\":[{\"tool\":\"tool.name\",\"arguments\":{},\"reason\":\"short\"}],\"reply\":\"\"}\n"
            "规则:\n"
            "1) tool 只能来自 tools；arguments 只能使用该工具允许的参数键。\n"
            "2) 命令请求优先 mode=action；mode=action 时 actions 必须 1..max_actions 且 reply 为空。\n"
            "3) 仅在无法映射命令时用 mode=chat；actions 为空；reply 一句澄清。\n"
            "4) 提到内存/memory/mem/ram 默认指 system.mem；只有明确要求记忆管理时才允许 memory.*。\n"
            "5) 云台方向/回中/停止优先 vision.gimbal.command；时间查询优先 system.time；画面观察优先 vision.observe。\n"
            "6) 禁止编造执行结果或状态值。\n"
            "输入:\n"
            + json.dumps(prompt_obj, ensure_ascii=False)
        )

        base_timeout = max(10.0, min(22.0, float(self.config.llm_tool_planner_timeout_sec)))
        timeout_sec = self._adaptive_timeout_sec(
            task="tool_plan",
            base_timeout_sec=base_timeout,
            query=query,
            dialogue_history=history_rows,
            max_actions=keep,
            min_sec=10.0,
            max_sec=22.0,
        )
        timeout_sec = round(min(22.0, max(10.0, float(timeout_sec))), 2)
        max_tokens = self._adaptive_max_tokens(
            task="tool_plan",
            query=query,
            dialogue_history=history_rows,
            max_actions=keep,
            min_tokens=72,
            max_tokens=128,
        )
        native_history_enabled = bool(self.config.llm_tool_plan_native_history_enabled)
        upstream_keep_history = bool(llm_session_id and native_history_enabled and llm_keep_history)
        upstream_clear_history = bool(llm_clear_history or (not upstream_keep_history))
        llm_payload: dict[str, Any] = {
            "task": "command_manual_tool_plan",
            "message": prompt,
            "include_llm_text": True,
            "fast_mode": True,
            "timeout_sec": float(timeout_sec),
            "enable_thinking": False,
            "tools": [],
            "temperature": 0.0,
            "top_p": 0.2,
            "top_k": 1,
            "max_tokens": int(max_tokens),
            "max_retries": 1,
            "busy_retries": 2,
            "busy_retry_delay_sec": 0.12,
            "keep_history": upstream_keep_history,
            "clear_history": upstream_clear_history,
        }
        if llm_session_id and native_history_enabled:
            llm_payload["session_id"] = llm_session_id

        started = time.perf_counter()
        status, body, err, slot_wait_ms = self._llm_agent_task_request(
            payload=llm_payload,
            timeout_sec=max(2.0, float(timeout_sec) + 0.8),
            use_planner_slot=True,
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        if not base_ok:
            detail = _safe_text(
                err or body_obj.get("error") or f"status={status or 0}",
                limit=220,
            )
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            TraceStore.step(
                trace_ctx,
                name="llm.command_manual.tool_plan",
                ok=False,
                detail=detail,
                duration_ms=elapsed_ms,
                status=(status if status > 0 else None),
            )
            return None, [], {
                "ok": False,
                "status": int(status or 0),
                "detail": detail,
                "upstream": self.config.llm_api_base,
                "planned_actions": 0,
                "non_action": False,
                "mode": "",
                "reply": "",
                "latency_ms": round(elapsed_ms, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(max_tokens),
                "candidate_tools": int(candidate_count),
                "parse_fail": False,
                "repair_attempted": False,
                "repair_success": False,
                "slot_wait_ms": float(slot_wait_ms),
                "cache_hit": False,
            }

        parse_fail = False
        repair_attempted = False
        repair_success = False
        proposals, parse_err, non_action_reply, parsed_mode = self._parse_llm_tool_actions(
            llm_text,
            max_actions=keep,
        )
        if (not parse_err) and proposals:
            has_partial = any(
                _safe_text(item.get("reason"), limit=60).lower().startswith("llm partial")
                for item in proposals
                if isinstance(item, dict)
            )
            if has_partial:
                parse_err = "partial llm output"
        if parse_err:
            parse_fail = True
            repair_attempted = True
            repaired_text, repair_meta = self._repair_llm_tool_plan_json(
                query=query,
                detector=detector,
                max_actions=keep,
                tool_specs=tool_specs,
                raw_llm_text=llm_text,
                trace_ctx=trace_ctx,
            )
            if bool(repair_meta.get("ok", False)) and repaired_text:
                proposals, parse_err, non_action_reply, parsed_mode = self._parse_llm_tool_actions(
                    repaired_text,
                    max_actions=keep,
                )
                if not parse_err:
                    repair_success = True
        if parse_err:
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            TraceStore.step(
                trace_ctx,
                name="llm.command_manual.tool_plan",
                ok=False,
                detail=parse_err,
                duration_ms=elapsed_ms,
                status=(status if status > 0 else None),
            )
            return None, [], {
                "ok": False,
                "status": int(status or 0),
                "detail": parse_err,
                "upstream": self.config.llm_api_base,
                "planned_actions": 0,
                "non_action": False,
                "mode": "",
                "reply": "",
                "latency_ms": round(elapsed_ms, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(max_tokens),
                "candidate_tools": int(candidate_count),
                "parse_fail": bool(parse_fail),
                "repair_attempted": bool(repair_attempted),
                "repair_success": bool(repair_success),
                "slot_wait_ms": float(slot_wait_ms),
                "cache_hit": False,
            }

        non_action_reply = self._normalize_feedback_text(non_action_reply)
        allowed_args_by_tool: dict[str, set[str]] = {}
        for spec in candidate_specs:
            if not isinstance(spec, dict):
                continue
            name = _safe_text(spec.get("name"), limit=80)
            if not name:
                continue
            args_obj = spec.get("arguments") if isinstance(spec.get("arguments"), dict) else {}
            allowed_args_by_tool[name] = {str(k).strip() for k in args_obj.keys() if str(k).strip()}
        sanitized_proposals: list[dict[str, Any]] = []
        for item in proposals:
            if not isinstance(item, dict):
                continue
            tool = _safe_text(item.get("tool"), limit=80)
            if not tool:
                continue
            if (not explicit_memory_request) and tool.startswith("memory."):
                continue
            args = item.get("arguments") if isinstance(item.get("arguments"), dict) else {}
            allowed_keys = allowed_args_by_tool.get(tool, set())
            if allowed_keys:
                args = {k: v for k, v in args.items() if str(k) in allowed_keys}
            else:
                args = {}
            sanitized_proposals.append(
                {
                    "tool": tool,
                    "arguments": dict(args),
                    "reason": _safe_text(item.get("reason"), limit=120) or "llm tool planner",
                }
            )
        if mem_hint and (not cpu_hint):
            sanitized_proposals = [
                row
                for row in sanitized_proposals
                if _safe_text(row.get("tool"), limit=80) != "system.cpu"
            ]
        if mem_hint and (not npu_hint):
            sanitized_proposals = [
                row
                for row in sanitized_proposals
                if _safe_text(row.get("tool"), limit=80) != "system.npu"
            ]
        proposals = sanitized_proposals
        warnings: list[str] = []
        time_part = IntentRegistry._infer_time_query_part(query, query_low) if time_hint else "datetime"
        if time_hint:
            for row in proposals:
                if not isinstance(row, dict):
                    continue
                if _safe_text(row.get("tool"), limit=80) != "system.time":
                    continue
                args = row.get("arguments") if isinstance(row.get("arguments"), dict) else {}
                current_part = _safe_text(args.get("part"), limit=24).lower()
                if time_part in ("weekday", "date", "time", "date_weekday"):
                    args["part"] = time_part
                else:
                    args["part"] = (
                        current_part
                        if current_part in ("datetime", "date", "time", "weekday", "date_weekday")
                        else "datetime"
                    )
                row["arguments"] = args
        if gimbal_motion_hint and (
            not any(_safe_text(item.get("tool"), limit=80) == "vision.gimbal.command" for item in proposals)
        ):
            corrected = self.planner.intent_registry._gimbal_semantic_actions(query, query_low)
            corrected = [row for row in corrected if _safe_text(row.get("tool"), limit=80) == "vision.gimbal.command"]
            if corrected:
                proposals = corrected[:keep]
                warnings.append("command_manual_llm: corrected_to_gimbal_command")
        if time_hint and (
            not any(_safe_text(item.get("tool"), limit=80) == "system.time" for item in proposals)
        ):
            proposals = [
                {
                    "tool": "system.time",
                    "arguments": {"part": time_part},
                    "reason": "time query fallback",
                }
            ]
            warnings.append("command_manual_llm: corrected_to_system_time")
        if observe_hint and (not gimbal_motion_hint) and (
            not any(_safe_text(item.get("tool"), limit=80) == "vision.observe" for item in proposals)
        ):
            proposals = [
                {
                    "tool": "vision.observe",
                    "arguments": {"detector": detector if detector != "none" else "yolo_world"},
                    "reason": "observe query fallback",
                }
            ]
            warnings.append("command_manual_llm: corrected_to_vision_observe")
        if proposals:
            plan, plan_warnings = self.planner.build_plan_from_proposals(
                proposals,
                query=query,
                detector=detector,
                max_actions=keep,
                source="llm_command_manual",
            )
            warnings.extend(plan_warnings)
        else:
            plan = {
                "summary": _safe_text(query or "tool command", limit=220),
                "actions": [],
                "source": "llm_command_manual",
                "needs_clarification": False,
                "clarification_question": "",
                "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                "needs_confirmation": False,
            }
        actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
        mode = parsed_mode if parsed_mode in ("action", "chat") else ("action" if actions else "chat")
        if (mode == "action") and (not actions):
            mode = "chat"
        detail = (
            f"mode={mode}, actions={len(actions)}, proposals={len(proposals)}, "
            f"budget={int(max_tokens)}, tools={int(candidate_count)}, "
            f"slot_wait_ms={round(float(slot_wait_ms), 2)}"
        )
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        TraceStore.step(
            trace_ctx,
            name="llm.command_manual.tool_plan",
            ok=True,
            detail=detail,
            duration_ms=elapsed_ms,
            status=(status if status > 0 else None),
        )
        return plan, warnings, {
            "ok": True,
            "status": int(status or 0),
            "detail": detail,
            "upstream": self.config.llm_api_base,
            "planned_actions": int(len(actions)),
            "non_action": bool(mode == "chat"),
            "mode": mode,
            "reply": non_action_reply,
            "latency_ms": round(elapsed_ms, 2),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(max_tokens),
            "candidate_tools": int(candidate_count),
            "parse_fail": bool(parse_fail),
            "repair_attempted": bool(repair_attempted),
            "repair_success": bool(repair_success),
            "slot_wait_ms": float(slot_wait_ms),
            "cache_hit": False,
        }

    def _fallback_llm_tool_plan(
        self,
        *,
        query: str,
        detector: str,
        max_actions: int,
        dialogue_history: list[dict[str, Any]] | None,
        llm_session_id: str = "",
        llm_keep_history: bool = False,
        llm_clear_history: bool = False,
        trace_ctx: TraceContext,
    ) -> tuple[dict[str, Any] | None, list[str], dict[str, Any]]:
        if not self.config.llm_tool_planner_enabled:
            TraceStore.step(
                trace_ctx,
                name="llm.tool_plan",
                ok=False,
                detail="disabled by AGENT_LLM_TOOL_PLANNER=0",
            )
            return None, [], {
                "ok": False,
                "status": 0,
                "detail": "disabled by AGENT_LLM_TOOL_PLANNER=0",
                "upstream": self.config.llm_api_base,
                "latency_ms": 0.0,
                "timeout_sec": 0.0,
                "max_tokens": 0,
                "candidate_tools": 0,
                "parse_fail": False,
                "repair_attempted": False,
                "repair_success": False,
                "native_tools": False,
                "native_tool_count": 0,
            }

        keep = _clamp_int(max_actions, default=4, min_value=1, max_value=8)
        candidate_specs, candidate_meta = self._select_tool_candidates(
            query=query,
            detector=detector,
            dialogue_history=dialogue_history,
            include_side_effect=True,
            max_candidates=max(6, min(10, keep * 2)),
            min_candidates=max(4, keep + 1),
        )
        query_text = str(query or "").strip()
        query_low = query_text.lower()
        explicit_memory_request = _is_explicit_agent_memory_request(query_text, query_low)
        cpu_hint = bool(
            re.search(r"(cpu|处理器|负载|cpu占用|cpu使用率|cpu usage|cpu utilization)", query_low, flags=re.IGNORECASE)
        )
        npu_hint = bool(
            re.search(r"(npu|rknpu|tops|ai core|神经网络处理器|npu usage|npu占用)", query_low, flags=re.IGNORECASE)
        )
        mem_hint = bool(
            re.search(r"(内存|ram|memory|mem|内存占用|内存使用率)", query_low, flags=re.IGNORECASE)
        )
        filtered_candidate_specs: list[dict[str, Any]] = []
        for spec in candidate_specs:
            if not isinstance(spec, dict):
                continue
            name = _safe_text(spec.get("name"), limit=80)
            if (not name) or ((not explicit_memory_request) and name.startswith("memory.")):
                continue
            filtered_candidate_specs.append(spec)
        candidate_specs = filtered_candidate_specs
        if mem_hint and (not explicit_memory_request):
            candidate_specs.sort(
                key=lambda row: (
                    0 if _safe_text(row.get("name"), limit=80) == "system.mem" else 1
                )
            )
        prompt_candidate_cap = _clamp_int(max(10, keep * 2), default=10, min_value=8, max_value=10)
        if len(candidate_specs) > prompt_candidate_cap:
            candidate_specs = list(candidate_specs[:prompt_candidate_cap])
        if isinstance(candidate_meta, dict):
            candidate_meta = dict(candidate_meta)
            candidate_meta["selected_prompt"] = len(candidate_specs)
        tool_semantic_hint_map: dict[str, list[str]] = {
            "system.time": ["时间", "当前时间", "clock", "time"],
            "system.cpu": ["CPU", "处理器", "占用", "usage"],
            "system.mem": ["内存", "memory", "RAM", "占用"],
            "system.npu": ["NPU", "推理加速", "占用", "usage"],
            "system.thermal": ["温度", "热", "thermal", "temperature"],
            "vision.observe": ["画面", "摄像头", "观察", "detect"],
        }
        tool_names: list[str] = []
        prompt_tool_specs: list[dict[str, Any]] = []
        for spec in candidate_specs:
            name = _safe_text(spec.get("name"), limit=80)
            if name:
                tool_names.append(name)
                prompt_row: dict[str, Any] = {"name": name}
                desc = _safe_text(spec.get("description"), limit=36)
                if desc:
                    prompt_row["description"] = desc
                hint_vals = tool_semantic_hint_map.get(name, [])
                if hint_vals:
                    prompt_row["semantic_hint"] = hint_vals[:4]
                args_obj = spec.get("arguments") if isinstance(spec.get("arguments"), dict) else {}
                if args_obj:
                    arg_names: list[str] = []
                    for raw_key, _raw_value in list(args_obj.items())[:4]:
                        key = _safe_text(raw_key, limit=40)
                        if not key:
                            continue
                        arg_names.append(key)
                    if arg_names:
                        prompt_row["argument_keys"] = arg_names
                if bool(spec.get("side_effect", False)):
                    prompt_row["side_effect"] = True
                prompt_tool_specs.append(prompt_row)
        tool_specs = [{"name": _safe_text(row.get("name"), limit=80)} for row in candidate_specs if _safe_text(row.get("name"), limit=80)]
        candidate_count = int(
            _clamp_int(
                (candidate_meta or {}).get("selected_prompt")
                or (candidate_meta or {}).get("selected")
                or len(tool_names),
                default=len(tool_names),
                min_value=0,
                max_value=64,
            )
        )
        native_tools_enabled = bool(self.config.llm_tool_plan_native_tools_enabled)
        native_function_tools = (
            self._build_native_function_tools(candidate_specs, max_tools=max(6, min(20, candidate_count)))
            if native_tools_enabled
            else []
        )
        native_tool_count = len(native_function_tools)

        native_history_enabled = bool(self.config.llm_tool_plan_native_history_enabled)
        native_history_active = bool(
            native_history_enabled
            and llm_session_id
            and llm_keep_history
            and (not llm_clear_history)
        )

        read_tool_names: list[str] = []
        for spec in candidate_specs:
            if not isinstance(spec, dict):
                continue
            name = _safe_text(spec.get("name"), limit=80)
            if not name:
                continue
            side_effect = bool(spec.get("side_effect", False))
            if (not side_effect) and (len(read_tool_names) < 10):
                read_tool_names.append(name)

        history_rows_full = list(dialogue_history or [])
        history_rows = list(history_rows_full)
        if native_history_active:
            # When RKLLM native KV history is enabled, avoid duplicating long dialogue context in prompt.
            history_rows = history_rows[-6:]
        history_sensitive = bool(
            re.search(
                r"(回顾|第一句|上一句|刚刚|刚才|本次|命令|参数|记住|代号|first message|last message|what did i just|remember)",
                query_low,
                flags=re.IGNORECASE,
            )
        )
        detail_requested = bool(
            re.search(
                r"(详细|分条|逐条|完整|不要省略|详细说明|展开|具体一点|explain|detailed|in\\s*depth|step\\s*by\\s*step|with\\s*details)",
                query_low,
                flags=re.IGNORECASE,
            )
        )
        question_mark_count = len(re.findall(r"[？?]", query_text))
        question_cue_count = len(
            re.findall(
                r"(谁|哪[里儿]?|在哪|什么|如何|怎么|为何|为什么|能否|可否|可以|who|what|where|how|why|can\\s+you)",
                query_low,
                flags=re.IGNORECASE,
            )
        )
        clause_count = len(
            [
                seg
                for seg in re.split(r"[？?；;。!\n]+", query_text)
                if _safe_text(seg, limit=120)
            ]
        )
        has_coordination = bool(
            re.search(r"(并且|而且|以及|同时|还有|另外|分别|分条|逐条| and | also )", query_low, flags=re.IGNORECASE)
        )
        need_identity = bool(
            re.search(r"(你是谁|谁是你|你的身份|身份|who\\s+are\\s+you|who\\s+r\\s+u)", query_low, flags=re.IGNORECASE)
        )
        need_deployment = bool(
            re.search(r"(你在(哪|哪里)|运行在|运行于|部署在|where\\s+are\\s+you|run\\s+on)", query_low, flags=re.IGNORECASE)
        )
        need_capability = bool(
            re.search(r"(能做什么|可以做什么|干什么|能力|能干什么|what\\s+can\\s+you\\s+do|capabilit)", query_low, flags=re.IGNORECASE)
        )
        required_dimensions: list[str] = []
        if need_identity:
            required_dimensions.append("identity")
        if need_deployment:
            required_dimensions.append("deployment")
        if need_capability:
            required_dimensions.append("capability")
        if required_dimensions:
            native_function_tools = []
            native_tool_count = 0
        chat_only_hint = bool(
            re.search(r"(你好|你好吗|嗨|hello|hi|thanks|谢谢|在吗|还在吗|how are you)", query_low, flags=re.IGNORECASE)
        )
        status_or_action_hint = bool(
            re.search(
                r"(时间|温度|内存|cpu|npu|状态|画面|摄像头|观察|检测|执行|命令|开启|关闭|锁定|跟随|time|temp|status|camera|observe|run|command|start|stop|track)",
                query_low,
                flags=re.IGNORECASE,
            )
        )
        if chat_only_hint and (not status_or_action_hint):
            native_function_tools = []
            native_tool_count = 0
        expected_points = max(question_mark_count, min(4, question_cue_count), min(4, clause_count))
        if required_dimensions:
            expected_points = max(expected_points, len(required_dimensions))
        if (expected_points < 2) and has_coordination and question_cue_count >= 2:
            expected_points = 2
        multi_part_query = bool(expected_points >= 2)

        user_texts: list[str] = []
        history_rows_user_only: list[dict[str, Any]] = []
        if history_sensitive:
            for row in history_rows_full[-36:]:
                if not isinstance(row, dict):
                    continue
                role = _safe_text(row.get("role"), limit=20).lower()
                text = _safe_text(row.get("text") or row.get("content"), limit=120)
                if not text:
                    continue
                if role == "user":
                    user_texts.append(text)
            for row in history_rows:
                if not isinstance(row, dict):
                    continue
                role = _safe_text(row.get("role"), limit=20).lower()
                if role != "user":
                    continue
                history_rows_user_only.append(row)
        dialogue_recall: dict[str, Any] = {}
        if user_texts:
            dialogue_recall["first_user_message"] = user_texts[0]
            dialogue_recall["last_user_message"] = user_texts[-1]

        response_language = "zh-CN" if _contains_cjk(query) else "same_as_user"
        chat_reply_char_limit = 120 if detail_requested else (180 if multi_part_query else 60)
        prompt_obj = {
            "query": _safe_text(query, limit=320),
            "max_actions": keep,
            "available_tools": tool_names[:24],
            "available_tool_specs": prompt_tool_specs[:6],
            "runtime_context": {
                "agent_role": "你的本地助手",
                "deployment": "本地设备环境",
                "response_language": response_language,
                "chat_reply_char_limit": int(chat_reply_char_limit),
                "expected_points": int(max(1, min(4, expected_points))),
                "required_dimensions": required_dimensions,
                "tool_access_policy": "只能通过 available_tool_specs 中工具读取实时信息或执行动作",
                "fact_policy": "实时状态/设备状态/画面状态结论必须来自工具返回，禁止猜测或编造",
                "read_tools": read_tool_names[:8],
                "camera_capabilities": list(_camera_capability_names())[:6],
            },
            "dialogue_recall": dialogue_recall,
        }
        query_chars = len(str(query or "").strip())
        history_row_cap = 3 if query_chars > 120 else 4
        history_char_cap = 260 if query_chars > 120 else 360
        fact_cap = 4 if query_chars > 120 else 5
        history_text = _format_dialogue_history_for_prompt(
            history_rows_user_only if history_sensitive else [],
            max_rows=history_row_cap,
            max_chars=history_char_cap,
        )
        action_facts = _extract_dialogue_action_facts(
            history_rows if history_sensitive else [],
            max_rows=history_row_cap,
            max_facts=fact_cap,
        )
        if history_text:
            prompt_obj["dialogue_history_text"] = history_text
        if action_facts:
            prompt_obj["dialogue_action_facts"] = action_facts
        use_compact_prompt = bool(native_history_active)
        if use_compact_prompt:
            compact_obj: dict[str, Any] = {
                "query": _safe_text(query, limit=320),
                "max_actions": keep,
                "available_tools": tool_names[:16],
                "available_tool_specs": prompt_tool_specs[:4],
                "runtime_context": {
                    "agent_role": "你的本地助手",
                    "deployment": "本地设备环境",
                    "response_language": response_language,
                    "chat_reply_char_limit": int(chat_reply_char_limit),
                    "expected_points": int(max(1, min(4, expected_points))),
                    "required_dimensions": required_dimensions,
                    "tool_access_policy": "只能通过 available_tool_specs 的工具读取实时信息或执行动作",
                    "fact_policy": "实时信息必须基于工具返回，禁止猜测",
                    "read_tools": read_tool_names[:6],
                    "camera_capabilities": list(_camera_capability_names())[:4],
                },
                "dialogue_recall": dialogue_recall,
            }
            if history_text:
                compact_obj["dialogue_history_text"] = _safe_text(history_text, limit=420)
            if action_facts:
                compact_obj["dialogue_action_facts"] = action_facts[:8]
            prompt = (
                "继续沿用本会话既定的 tool_plan JSON 规范，只输出一个 JSON 对象。\n"
                "schema:{\"mode\":\"action|chat\",\"actions\":[{\"tool\":\"tool.name\",\"arguments\":{},\"reason\":\"short\"}],\"reply\":\"\"}\n"
                "你现在在做“任务规划”（不是闲聊）：先判断是否需要工具，再给最小可执行动作链。\n"
                "你能做什么只由 available_tool_specs 决定；未列出的能力一律视为不存在。\n"
                "请在内部按三步决策（不要输出思考过程）：目标识别 -> 是否依赖实时事实 -> 最小工具链。\n"
                "启发示例（仅作风格参考）：\n"
                "- 用户: “先看看镜头里有没有人” => mode=action，actions应包含视觉设置+观察。\n"
                "- 用户: “你是谁/你能做什么” => mode=chat，actions为空。\n"
                "要求:\n"
                "1) 若答案依赖实时状态/视觉观察/设备控制，且有可用读取工具，则 mode=action。\n"
                "2) mode=action 时 actions 必须非空且不得输出 reply；mode=chat 时 actions 必须为空且 reply 使用 runtime_context.response_language，且长度<=runtime_context.chat_reply_char_limit。\n"
                "3) 回顾问题优先依据 dialogue_history_text / dialogue_action_facts / dialogue_recall；非回顾问题忽略 dialogue_recall。\n"
                "4) 若用户问“第一句/上一句/刚刚说了什么”，优先直接复述 dialogue_recall 中对应 user 原文。\n"
                "5) 若 runtime_context.expected_points>1，mode=chat 必须按 1.2.3. 分点覆盖每个子问题，每点一句完整句。\n"
                "6) 若 runtime_context.required_dimensions 非空，reply 必须逐项覆盖这些维度，不得遗漏。\n"
                "7) mode=chat 回复宁可更短，也必须是完整句，禁止输出半句或未完结片段。\n"
                "8) 禁止编造工具、参数、执行结果、实时数值。\n"
                "输入:\n"
                + json.dumps(compact_obj, ensure_ascii=False)
            )
        else:
            prompt = (
                "你是Agent，只输出一个JSON对象。\n"
                "schema:{\"mode\":\"action|chat\",\"actions\":[{\"tool\":\"tool.name\",\"arguments\":{},\"reason\":\"short\"}],\"reply\":\"\"}\n"
                "你现在在做“任务规划”（不是闲聊）：先判断是否需要工具，再给最小可执行动作链。\n"
                "你能做什么只由 available_tool_specs 决定；未列出的能力一律视为不存在。\n"
                "请在内部按三步决策（不要输出思考过程）：目标识别 -> 是否依赖实时事实 -> 最小工具链。\n"
                "启发示例（仅作风格参考）：\n"
                "- “先看看镜头里有没有人” => mode=action，优先视觉工具，不要闲聊回复。\n"
                "- “帮我检查画面是否有手机” => mode=action。\n"
                "- “你是谁/你能做什么” => mode=chat。\n"
                "规则:\n"
                "1) 若答案依赖实时状态/视觉观察/设备控制，并且 available_tool_specs 中存在可用读取工具，则用 mode=action。\n"
                "2) 其余请求用 mode=chat（含问候、身份、能力、位置、闲聊、回顾）。\n"
                "3) mode=action: actions非空, 数量<=max_actions, tool必须在available_tools, reply必须为空。\n"
                "4) mode=chat: actions必须为空, reply必填, reply语言遵循 runtime_context.response_language, 长度<=runtime_context.chat_reply_char_limit。\n"
                "5) 回顾类问题依据 dialogue_history_text / dialogue_action_facts / dialogue_recall；非回顾问题忽略 dialogue_recall；无事实则明确“无法确认/未记录”。\n"
                "6) 若用户问“第一句/上一句/刚刚说了什么”，优先直接复述 dialogue_recall 中对应 user 原文。\n"
                "7) 若 runtime_context.expected_points>1，mode=chat 必须按 1.2.3. 分点覆盖每个子问题，每点一句完整句。\n"
                "8) 若 runtime_context.required_dimensions 非空，reply 必须逐项覆盖这些维度，不得遗漏。\n"
                "9) mode=chat 回复宁可更短，也必须是完整句，禁止输出半句或未完结片段。\n"
                "10) 提到内存/memory/mem/ram 默认指 system.mem；只有明确要求记忆管理时才允许 memory.*。\n"
                "11) 对任何“当前/实时”信息，若存在可用读取工具，禁止回复“未知/无法获取”而不调用工具。\n"
                "12) 回答身份/运行位置/能力时，必须基于 runtime_context 与 available_tool_specs，不要自称云端通用助手。\n"
                "13) 禁止编造工具、参数、执行结果或实时数值。\n"
                "输入:\n"
                + json.dumps(prompt_obj, ensure_ascii=False)
            )

        base_timeout = max(2.5, min(20.0, float(self.config.llm_tool_planner_timeout_sec)))
        timeout_sec = self._adaptive_timeout_sec(
            task="tool_plan",
            base_timeout_sec=base_timeout,
            query=query,
            dialogue_history=history_rows,
            max_actions=keep,
            min_sec=5.0,
            max_sec=24.0,
        )
        if detail_requested:
            timeout_sec = round(min(24.0, max(4.0, float(timeout_sec) + 3.0)), 2)
        elif multi_part_query:
            timeout_sec = round(min(22.0, max(4.0, float(timeout_sec) + 1.5)), 2)
        max_tokens = self._adaptive_max_tokens(
            task="tool_plan",
            query=query,
            dialogue_history=history_rows,
            max_actions=keep,
            min_tokens=(48 if (detail_requested or multi_part_query) else 36),
            max_tokens=96,
        )
        llm_payload: dict[str, Any] = {
            "task": "tool_plan",
            "message": prompt,
            "include_llm_text": True,
            "fast_mode": True,
            "timeout_sec": timeout_sec,
            "enable_thinking": False,
            "temperature": 0.0,
            "top_p": 0.3,
            "top_k": 1,
            "max_tokens": max_tokens,
            "max_retries": 1,
            "busy_retries": 3,
            "busy_retry_delay_sec": 0.2,
        }
        if native_function_tools:
            llm_payload["tools"] = native_function_tools
        if llm_session_id and bool(self.config.llm_tool_plan_native_history_enabled):
            llm_payload["session_id"] = llm_session_id
            llm_payload["keep_history"] = bool(llm_keep_history)
            if llm_clear_history:
                llm_payload["clear_history"] = True

        started = time.perf_counter()
        status, body, err, slot_wait_ms = self._llm_agent_task_request(
            payload=llm_payload,
            timeout_sec=max(2.0, timeout_sec + 0.8),
            use_planner_slot=True,
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        if not base_ok:
            upstream_status = _clamp_int(body_obj.get("llm_status", status), default=status or 0, min_value=0, max_value=999)
            upstream_text = _safe_text(body_obj.get("llm_text"), limit=120)
            llm_resp = body_obj.get("llm_response") if isinstance(body_obj.get("llm_response"), dict) else {}
            if (not upstream_text) and isinstance(llm_resp, dict):
                upstream_text = _safe_text(llm_resp.get("error") or llm_resp.get("message"), limit=120)
            detail = _safe_text(
                err
                or body_obj.get("error")
                or upstream_text
                or f"status={status or 0}, llm_status={upstream_status}",
                limit=220,
            )
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            TraceStore.step(
                trace_ctx,
                name="llm.tool_plan",
                ok=False,
                detail=detail,
                duration_ms=elapsed_ms,
                status=(status if status > 0 else None),
            )
            return None, [], {
                "ok": False,
                "status": status,
                "detail": detail,
                "upstream": self.config.llm_api_base,
                "latency_ms": round(elapsed_ms, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(max_tokens),
                "candidate_tools": int(candidate_count),
                "parse_fail": False,
                "repair_attempted": False,
                "repair_success": False,
                "slot_wait_ms": float(slot_wait_ms),
                "native_tools": bool(native_tool_count > 0),
                "native_tool_count": int(native_tool_count),
            }

        parse_fail = False
        repair_attempted = False
        repair_success = False
        proposals, parse_err, non_action_reply, parsed_mode = self._parse_llm_tool_actions(
            llm_text,
            max_actions=keep,
        )
        if parse_err:
            parse_fail = True
            repair_attempted = True
            repaired_text, repair_meta = self._repair_llm_tool_plan_json(
                query=query,
                detector=detector,
                max_actions=keep,
                tool_specs=tool_specs,
                raw_llm_text=llm_text,
                trace_ctx=trace_ctx,
            )
            if bool(repair_meta.get("ok", False)) and repaired_text:
                proposals, parse_err, non_action_reply, parsed_mode = self._parse_llm_tool_actions(
                    repaired_text,
                    max_actions=keep,
                )
                if not parse_err:
                    repair_success = True
        if parse_err:
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            TraceStore.step(
                trace_ctx,
                name="llm.tool_plan",
                ok=False,
                detail=parse_err,
                duration_ms=elapsed_ms,
                status=(status if status > 0 else None),
            )
            return None, [], {
                "ok": False,
                "status": status,
                "detail": parse_err,
                "llm_text_excerpt": _safe_text(llm_text, limit=240),
                "upstream": self.config.llm_api_base,
                "latency_ms": round(elapsed_ms, 2),
                "timeout_sec": float(timeout_sec),
                "max_tokens": int(max_tokens),
                "candidate_tools": int(candidate_count),
                "parse_fail": bool(parse_fail),
                "repair_attempted": bool(repair_attempted),
                "repair_success": bool(repair_success),
                "slot_wait_ms": float(slot_wait_ms),
                "native_tools": bool(native_tool_count > 0),
                "native_tool_count": int(native_tool_count),
            }
        non_action_reply = self._normalize_feedback_text(non_action_reply)
        if non_action_reply and required_dimensions:
            non_action_reply = self._enrich_chat_reply_required_dimensions(
                reply=non_action_reply,
                required_dimensions=required_dimensions,
                read_tool_names=read_tool_names,
            )
            non_action_reply = self._normalize_feedback_text(non_action_reply)
        if non_action_reply and _contains_cjk(query) and (not _contains_cjk(non_action_reply)):
            non_action_reply = ""
        if mem_hint and (not cpu_hint):
            proposals = [
                row
                for row in proposals
                if _safe_text((row or {}).get("tool"), limit=80) != "system.cpu"
            ]
        if mem_hint and (not npu_hint):
            proposals = [
                row
                for row in proposals
                if _safe_text((row or {}).get("tool"), limit=80) != "system.npu"
            ]

        warnings: list[str] = []
        if proposals:
            plan, warnings = self.planner.build_plan_from_proposals(
                proposals,
                query=query,
                detector=detector,
                max_actions=keep,
                source="llm_tool_planner",
            )
        else:
            plan = {
                "summary": _safe_text(query or "tool command", limit=220),
                "actions": [],
                "source": "llm_tool_planner",
                "needs_clarification": False,
                "clarification_question": "",
                "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                "needs_confirmation": False,
            }
        actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
        mode = parsed_mode if parsed_mode in ("action", "chat") else ("action" if actions else "chat")
        detail = f"actions={len(actions)}, proposals={len(proposals)}, mode={mode}"
        if mode == "chat":
            if non_action_reply:
                detail = f"{detail}, reply=1"
        if repair_attempted:
            detail = f"{detail}, repair={'1' if repair_success else '0'}"
        if warnings:
            detail = f"{detail}, warnings={len(warnings)}"
        detail = (
            f"{detail}, budget={int(max_tokens)}, tools={int(candidate_count)}, "
            f"native_tools={int(native_tool_count > 0)}"
        )
        detail = f"{detail}, slot_wait_ms={round(float(slot_wait_ms), 2)}"
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        TraceStore.step(
            trace_ctx,
            name="llm.tool_plan",
            ok=True,
            detail=detail,
            duration_ms=elapsed_ms,
            status=(status if status > 0 else None),
        )
        return plan, warnings, {
            "ok": True,
            "status": status,
            "detail": detail,
            "upstream": self.config.llm_api_base,
            "planned_actions": len(actions),
            "non_action": bool(mode == "chat"),
            "mode": mode,
            "reply": non_action_reply,
            "latency_ms": round(elapsed_ms, 2),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(max_tokens),
            "candidate_tools": int(candidate_count),
            "parse_fail": bool(parse_fail),
            "repair_attempted": bool(repair_attempted),
            "repair_success": bool(repair_success),
            "slot_wait_ms": float(slot_wait_ms),
            "native_tools": bool(native_tool_count > 0),
            "native_tool_count": int(native_tool_count),
        }

    def _next_feedback_style_hint(self) -> tuple[str, int]:
        with self._feedback_style_lock:
            idx = int(self._feedback_style_seq % len(EXEC_FEEDBACK_STYLE_HINTS))
            self._feedback_style_seq += 1
        return EXEC_FEEDBACK_STYLE_HINTS[idx], idx

    @staticmethod
    def _compact_action_results_for_feedback(action_results: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for item in action_results[:4]:
            if not isinstance(item, dict):
                continue
            tool = _safe_text(item.get("tool"), limit=80)
            ok = bool(item.get("ok", False))
            result = item.get("result") if isinstance(item.get("result"), dict) else {}
            brief = _brief_tool_result_summary(tool, result, ok)
            rows.append(
                {
                    "tool": tool,
                    "ok": ok,
                    "summary": (_safe_text(brief, limit=180) if ok else ""),
                    "error": (_safe_text(brief, limit=180) if not ok else ""),
                }
            )
        return rows

    @staticmethod
    def _is_tolerable_observe_failure(row: dict[str, Any]) -> bool:
        if not isinstance(row, dict):
            return False
        if bool(row.get("ok", False)):
            return False
        if _safe_text(row.get("tool"), limit=80) != "vision.observe":
            return False
        if bool(row.get("side_effect", False)):
            return False
        result = row.get("result") if isinstance(row.get("result"), dict) else {}
        err = _safe_text(result.get("error") or row.get("error"), limit=220).lower()
        if not err:
            return False
        tolerated_tokens = (
            "frame unavailable",
            "stale frame",
            "camera read failed",
            "cannot open camera",
            "vision disabled",
        )
        return any(token in err for token in tolerated_tokens)

    @staticmethod
    def _trim_dangling_feedback_fragment(text: str) -> str:
        raw = str(text or "").strip()
        if not raw:
            return ""
        parts = [seg.strip() for seg in re.findall(r"[^。！？!?]+[。！？!?]?", raw) if seg.strip()]
        if len(parts) < 2:
            return raw
        tail = parts[-1]
        # If the last segment does not end with sentence punctuation, treat it as a dangling fragment.
        if not re.search(r"[。！？!?]\s*$", tail):
            return "".join(parts[:-1]).strip()
        tail_core = re.sub(r"[。！？!?]+$", "", tail).strip()
        # Extremely short last sentence is usually a broken fragment after truncation.
        if len(tail_core) <= 2:
            return "".join(parts[:-1]).strip()
        return raw

    @staticmethod
    def _chat_capability_sentence_from_tools(read_tool_names: list[str] | None) -> str:
        names = list(read_tool_names or [])
        has_system = any(_safe_text(name, limit=80).startswith("system.") for name in names[:12])
        has_vision = any(_safe_text(name, limit=80).startswith("vision.") for name in names[:12])
        if has_system and has_vision:
            return "可以在你需要时帮你看设备和画面状态，也能执行设备相关操作"
        if has_vision:
            return "可以在你需要时帮你看画面和设备状态，也能执行设备相关操作"
        if has_system:
            return "可以在你需要时帮你看设备状态，也能执行设备相关操作"
        return "可以按你的需求提供对话协助，并在需要时执行设备相关操作"

    @classmethod
    def _enrich_chat_reply_required_dimensions(
        cls,
        *,
        reply: str,
        required_dimensions: list[str] | None,
        read_tool_names: list[str] | None = None,
    ) -> str:
        text = str(reply or "").strip()
        dims_raw = list(required_dimensions or [])
        dims: list[str] = []
        for raw in dims_raw:
            dim = _safe_text(raw, limit=24).lower()
            if dim in ("identity", "deployment", "capability") and dim not in dims:
                dims.append(dim)
        if (not text) or (not dims):
            return text

        low = text.lower()

        def _covered(dim: str) -> bool:
            if dim == "identity":
                return bool(re.search(r"(我是|本地代理|设备控制链路|agent|assistant)", text, flags=re.IGNORECASE))
            if dim == "deployment":
                return bool(re.search(r"(运行在|本机|本地|边缘设备|edge)", text, flags=re.IGNORECASE))
            if dim == "capability":
                return bool(
                    re.search(
                        r"((可以|可|能够|能|支持|会|擅长)[^。！？!?]{0,14}(执行|处理|回答|协助|查看|查询|控制|观察|操作|识别|检测|分析))|(能做什么|可以做什么|可做什么)",
                        text,
                        flags=re.IGNORECASE,
                    )
                )
            return True

        missing = [dim for dim in dims if not _covered(dim)]
        if not missing:
            return text

        addition_map = {
            "identity": "我是你的本地助手",
            "deployment": "我运行在这台本地设备上",
            "capability": cls._chat_capability_sentence_from_tools(read_tool_names),
        }
        additions: list[str] = []
        for dim in dims:
            if dim in missing:
                sentence = _safe_text(addition_map.get(dim, ""), limit=120)
                if sentence:
                    additions.append(sentence)

        if not additions:
            return text
        base = re.sub(r"[。！？!?]+$", "", text).strip()
        if additions and re.fullmatch(r"(?i)(ok|okay|好的|收到|明白|了解|在|我在)", base or ""):
            base = ""
        rows = [base] if base else []
        rows.extend(additions)
        merged = "；".join([row for row in rows if row]).strip()
        if not merged:
            return text
        return f"{merged}。"

    @staticmethod
    def _normalize_feedback_text(text: str) -> str:
        raw = str(text or "").replace("\r", "\n").strip()
        if not raw:
            return ""
        raw = re.sub(r"</?think[^>]*>", "", raw, flags=re.IGNORECASE).strip()
        lines = [seg.strip() for seg in raw.split("\n") if seg.strip()]
        uniq: list[str] = []
        for line in lines:
            if line not in uniq:
                uniq.append(line)
        merged = " ".join(uniq)
        merged = re.sub(r"\s+", " ", merged).strip()
        merged = AgentServiceApp._trim_dangling_feedback_fragment(merged)
        merged = re.sub(r"[、，,:：;；/\\-]+$", "", merged).strip()
        if merged and (not merged.endswith(("。", "！", "？", ".", "!", "?"))):
            merged = f"{merged}。"
        return _safe_text(merged, limit=320)

    @staticmethod
    def _accept_non_cjk_chat_reply(query: str, text: str) -> bool:
        raw = str(text or "").strip()
        if not raw:
            return False
        if _contains_cjk(raw):
            return True
        compact = re.sub(r"\s+", "", raw).strip("。.!?！？")
        if re.fullmatch(r"(?i)(ok|okay|yes|no|true|false|done|ready)", compact or ""):
            query_lower = str(query or "").lower()
            query_raw = str(query or "")
            return bool(
                ("ok" in query_lower)
                or ("english" in query_lower)
                or ("英文" in query_raw)
                or ("字母" in query_raw)
            )
        return False

    @staticmethod
    def _looks_like_llm_chat_report(text: str) -> bool:
        raw = str(text or "").strip()
        if not raw:
            return False
        hit = 0
        for token in ("已接收任务：", "执行：", "任务完成：摘要=", "模型返回为空"):
            if token in raw:
                hit += 1
        return hit >= 2

    @staticmethod
    def _query_wants_technical_detail(query: str) -> bool:
        text = str(query or "").strip().lower()
        if not text:
            return False
        tokens = (
            "置信度",
            "坐标",
            "面积",
            "bbox",
            "score",
            "confidence",
            "细节",
            "详细",
            "参数",
        )
        return any(token in text for token in tokens)

    @classmethod
    def _strip_technical_detail_if_needed(cls, query: str, text: str) -> str:
        out = str(text or "").strip()
        if not out or cls._query_wants_technical_detail(query):
            return out
        out = re.sub(r"(置信度|confidence)\s*[:：=]?\s*\d+(\.\d+)?", "", out, flags=re.IGNORECASE)
        out = re.sub(r"(坐标|coordinate[s]?)\s*[:：=]?\s*\([^)]*\)", "", out, flags=re.IGNORECASE)
        out = re.sub(r"(面积|area)\s*[:：=]?\s*\d+(\.\d+)?", "", out, flags=re.IGNORECASE)
        out = re.sub(r"(score)\s*[:：=]?\s*\d+(\.\d+)?", "", out, flags=re.IGNORECASE)
        out = re.sub(r"(数字|number)\s*[:：=]\s*\d+", "", out, flags=re.IGNORECASE)
        out = re.sub(r"[;；,，]\s*$", "", out).strip()
        out = re.sub(r"\s{2,}", " ", out).strip()
        return _safe_text(out, limit=320)

    @staticmethod
    def _extract_canon_labels_from_text(text: str) -> set[str]:
        raw = str(text or "")
        if not raw:
            return set()
        low = raw.lower()
        found: set[str] = set()
        for term in CAMERA_ALIAS_NON_ASCII_TERMS:
            token = str(term or "").strip().lower()
            if len(token) < 2:
                continue
            if token and token in low:
                canon = CAMERA_ALIAS_CANON_BY_TERM.get(token, token)
                if canon in CAMERA_CANON_LABEL_SET:
                    found.add(canon)
        for term in CAMERA_ALIAS_ASCII_TERMS:
            token = str(term or "").strip().lower()
            if len(token) < 3:
                continue
            if not re.search(rf"\b{re.escape(token)}\b", low):
                continue
            canon = CAMERA_ALIAS_CANON_BY_TERM.get(token, token)
            if canon in CAMERA_CANON_LABEL_SET:
                found.add(canon)
        return found

    @classmethod
    def _extract_observed_labels(cls, action_results: list[dict[str, Any]]) -> set[str]:
        labels: set[str] = set()
        for row in action_results:
            if not isinstance(row, dict):
                continue
            if _safe_text(row.get("tool"), limit=80) != "vision.observe":
                continue
            if not bool(row.get("ok", False)):
                continue
            result = row.get("result") if isinstance(row.get("result"), dict) else {}
            objs = result.get("objects") if isinstance(result.get("objects"), list) else []
            for obj in objs:
                if not isinstance(obj, dict):
                    continue
                name = _safe_text(obj.get("class_name") or obj.get("class_id"), limit=48).lower()
                if not name:
                    continue
                canon = CAMERA_ALIAS_CANON_BY_TERM.get(name, name)
                if canon in CAMERA_CANON_LABEL_SET:
                    labels.add(canon)
            best = result.get("best_target") if isinstance(result.get("best_target"), dict) else {}
            best_name = _safe_text(best.get("class_name") or best.get("class_id"), limit=48).lower()
            if best_name:
                canon = CAMERA_ALIAS_CANON_BY_TERM.get(best_name, best_name)
                if canon in CAMERA_CANON_LABEL_SET:
                    labels.add(canon)
        return labels

    @staticmethod
    def _is_polished_feedback_safe(context: str, text: str) -> bool:
        raw = str(text or "").strip().lower()
        if not raw:
            return False
        if context in ("confirm_pending", "confirm_preview"):
            forbidden = (
                "已执行",
                "执行完成",
                "已经执行",
                "执行成功",
                "completed",
                "executed",
                "done",
            )
            return not any(token in raw for token in forbidden)
        return True

    @staticmethod
    def _is_execution_polish_safe(query: str, base_feedback: str, action_results: list[dict[str, Any]], text: str) -> bool:
        raw = str(text or "").strip().lower()
        base = str(base_feedback or "").strip().lower()
        if not raw:
            return False
        # When tool summary says no target, polished text must preserve that meaning.
        if "no target" in base or "未检测到" in base or "未发现" in base:
            keep_tokens = ("no target", "未检测到", "未发现", "没有")
            if not any(token in raw for token in keep_tokens):
                return False
        query_text = str(query or "").strip()
        query_lower = query_text.lower()
        if query_text:
            has_prompt_set = any(
                isinstance(item, dict)
                and _safe_text(item.get("tool"), limit=80) == "vision.yolo_world.prompt.set"
                and bool(item.get("ok", False))
                for item in action_results
            )
            has_camera_domain = IntentRegistry._contains_any(
                query_text,
                query_lower,
                ("摄像头", "相机", "镜头", "画面", "监控", "camera", "vision", "yolo"),
            )
            question_like = bool(re.search(r"(有没有|有无|是否有|有吗|is there|are there)", query_lower))
            if has_camera_domain and question_like and not has_prompt_set:
                positive_tokens = ("检测到", "识别到", "发现", "detected", "found", "there is", "exists", "有")
                negative_tokens = ("没有", "未检测到", "未发现", "not found", "no target", "no ")
                if any(token in raw for token in positive_tokens) and not any(token in raw for token in negative_tokens):
                    return False
        has_observe = any(
            isinstance(item, dict)
            and _safe_text(item.get("tool"), limit=80) == "vision.observe"
            and bool(item.get("ok", False))
            for item in action_results
        )
        if has_observe:
            observed = AgentServiceApp._extract_observed_labels(action_results)
            base_labels = AgentServiceApp._extract_canon_labels_from_text(base_feedback)
            polished_labels = AgentServiceApp._extract_canon_labels_from_text(text)
            query_labels = AgentServiceApp._extract_canon_labels_from_text(query)
            positive_tokens = ("检测到", "识别到", "发现", "detect", "found", "看到")
            negative_tokens = ("没有", "未检测到", "未发现", "not found", "no target")
            has_positive = any(token in raw for token in positive_tokens)
            has_negative = any(token in raw for token in negative_tokens)

            if polished_labels:
                allow_labels = observed or base_labels
                if not allow_labels:
                    if has_positive and not has_negative:
                        return False
                else:
                    extra = polished_labels - allow_labels
                    if extra and has_positive and not has_negative:
                        return False
            # Guard against contradictory wording for the asked label set (e.g. "没看到人，但检测到两人").
            if has_positive and has_negative and query_labels and polished_labels.intersection(query_labels):
                return False
            if "person" in query_labels:
                person_neg = re.search(r"(没看到|未看到|看不到).{0,4}(人|person)", raw)
                person_pos = re.search(r"(检测|识别|发现).{0,4}(人|person)", raw)
                if person_neg and person_pos:
                    return False
        return True

    @staticmethod
    def _should_skip_exec_polish(query: str, action_results: list[dict[str, Any]]) -> bool:
        _ = (query, action_results)
        return False

    @staticmethod
    def _looks_like_user_correction(query: str) -> bool:
        text = str(query or "").strip()
        if not text:
            return False
        lower = text.lower()
        zh_tokens = (
            "你错了",
            "你说错了",
            "这不对",
            "不对吧",
            "现象不对",
            "怎么搞的",
            "这对吗",
            "明显不对",
            "回答错了",
            "你搞错了",
            "你又错了",
        )
        en_tokens = (
            "you are wrong",
            "you're wrong",
            "this is wrong",
            "not correct",
            "incorrect",
            "you got it wrong",
        )
        return any(token in text for token in zh_tokens) or any(token in lower for token in en_tokens)

    @staticmethod
    def _looks_like_pure_user_correction(query: str) -> bool:
        text = str(query or "").strip()
        if not AgentServiceApp._looks_like_user_correction(text):
            return False
        lower = text.lower()
        action_tokens_zh = ("查", "看", "打开", "关闭", "设置", "执行", "启动", "停止", "锁定", "观察", "搜索")
        action_tokens_en = ("check", "show", "set", "run", "start", "stop", "open", "close", "observe", "search")
        if any(token in text for token in action_tokens_zh):
            return False
        if any(token in lower for token in action_tokens_en):
            return False
        return True

    def _capture_user_correction(self, *, query: str, trace_ctx: TraceContext) -> dict[str, Any]:
        clean = _safe_text(query, limit=600)
        if not clean:
            result = {"ok": False, "error": "empty correction query"}
            TraceStore.step(trace_ctx, "memory.user_correction.capture", False, "empty correction query")
            return result
        if not bool(self.config.memory_enabled):
            result = {"ok": False, "error": "memory disabled"}
            TraceStore.step(trace_ctx, "memory.user_correction.capture", False, "memory disabled")
            return result
        meta = {
            "kind": "user_correction",
            "version": 1,
            "query": clean,
            "route": _safe_text(trace_ctx.trace.get("route"), limit=120),
            "trace_id": _safe_text(trace_ctx.trace.get("trace_id"), limit=32),
            "captured_at": _ts_now(),
        }
        result = self.memory_store.add(
            text=f"user_correction={clean}",
            tags=["feedback", "correction", "user"],
            source="user_feedback",
            role="user",
            meta=meta,
        )
        TraceStore.step(
            trace_ctx,
            "memory.user_correction.capture",
            bool(result.get("ok", False)),
            _safe_text(result.get("summary") or result.get("error"), limit=220),
        )
        return result

    def _build_feedback_memory_context(
        self,
        *,
        query: str,
        trace_ctx: TraceContext | None = None,
        limit: int = 8,
    ) -> dict[str, Any]:
        text = _safe_text(query, limit=220)
        if not text or not bool(self.config.memory_enabled):
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "memory.feedback.context", True, "skip (memory disabled or empty query)")
            return {
                "hits": 0,
                "ok_hits": 0,
                "failed_hits": 0,
                "correction_hits": 0,
                "correction_recent_count": 0,
                "recent_corrections": [],
                "guidance": "",
            }

        keep = _clamp_int(limit, default=8, min_value=2, max_value=20)
        items = self.memory_store.search(query=text, limit=keep)
        if not isinstance(items, list):
            items = []

        ok_hits = 0
        failed_hits = 0
        correction_hits = 0
        tool_counter: dict[str, int] = {}
        failure_counter: dict[str, int] = {}
        recent_examples: list[dict[str, Any]] = []
        correction_recent_count = 0
        recent_corrections: list[str] = []

        recent_rows = self.memory_store.list(limit=60)
        for row in recent_rows:
            if not isinstance(row, dict):
                continue
            meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
            if _safe_text(meta.get("kind"), limit=24).lower() != "user_correction":
                continue
            correction_recent_count += 1
            corr = _safe_text(meta.get("query") or row.get("text"), limit=120)
            if corr and corr not in recent_corrections:
                recent_corrections.append(corr)

        for row in items:
            if not isinstance(row, dict):
                continue
            meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
            kind = _safe_text(meta.get("kind"), limit=24).lower()
            if kind == "user_correction":
                correction_hits += 1
                corr = _safe_text(meta.get("query") or row.get("text"), limit=120)
                if corr and corr not in recent_corrections:
                    recent_corrections.append(corr)
                continue
            if kind and kind != "auto_turn":
                continue

            row_ok = bool(meta.get("ok", True))
            if row_ok:
                ok_hits += 1
            else:
                failed_hits += 1

            plan_tools = meta.get("plan_tools") if isinstance(meta.get("plan_tools"), list) else []
            compact_tools: list[str] = []
            for tool in plan_tools[:4]:
                name = _safe_text(tool, limit=80)
                if not name:
                    continue
                compact_tools.append(name)
                tool_counter[name] = int(tool_counter.get(name, 0)) + 1

            action_results = meta.get("action_results") if isinstance(meta.get("action_results"), list) else []
            for result in action_results[:4]:
                if not isinstance(result, dict):
                    continue
                if bool(result.get("ok", False)):
                    continue
                reason = _safe_text(result.get("error") or result.get("summary"), limit=120)
                if not reason:
                    continue
                failure_counter[reason] = int(failure_counter.get(reason, 0)) + 1

            recent_examples.append(
                {
                    "ok": row_ok,
                    "query": _safe_text(meta.get("query") or row.get("text"), limit=120),
                    "tools": compact_tools[:3],
                    "feedback": _safe_text(meta.get("assistant_feedback"), limit=120),
                }
            )

        top_tools = [
            name
            for name, _count in sorted(
                tool_counter.items(),
                key=lambda pair: (-int(pair[1]), pair[0]),
            )[:3]
        ]
        top_failures = [
            reason
            for reason, _count in sorted(
                failure_counter.items(),
                key=lambda pair: (-int(pair[1]), pair[0]),
            )[:2]
        ]

        guidance = ""
        if correction_hits > 0 or correction_recent_count > 0:
            guidance = "用户近期有纠错反馈，回复先给事实，避免过度自信。"
        elif failed_hits > ok_hits and failed_hits > 0:
            guidance = "同类请求近期失败较多，先说明限制和失败点，再给结论。"
        elif ok_hits > 0:
            guidance = "同类请求近期可执行，回复保持先结论后细节并简洁。"

        result = {
            "hits": int(ok_hits + failed_hits),
            "ok_hits": int(ok_hits),
            "failed_hits": int(failed_hits),
            "correction_hits": int(correction_hits),
            "correction_recent_count": int(correction_recent_count),
            "top_tools": top_tools,
            "top_failures": top_failures,
            "guidance": guidance,
            "recent_examples": recent_examples[-2:],
            "recent_corrections": recent_corrections[-2:],
        }
        if trace_ctx is not None:
            TraceStore.step(
                trace_ctx,
                "memory.feedback.context",
                True,
                (
                    f"hits={result['hits']}, ok={ok_hits}, fail={failed_hits}, "
                    f"corrections={int(correction_hits)}, recent_corrections={int(correction_recent_count)}"
                ),
            )
        return result

    def _build_clarification_feedback(self, *, query: str, trace_ctx: TraceContext | None = None) -> str:
        text = _safe_text(query, limit=120)
        if not text or not _looks_like_clarification_query(text):
            return ""
        if not bool(self.config.memory_enabled):
            return ""
        try:
            rows = self.memory_store.list(limit=12)
        except Exception:
            rows = []
        current_key = text.strip().lower()
        for row in reversed(rows):
            if not isinstance(row, dict):
                continue
            meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
            if _safe_text(meta.get("kind"), limit=24).lower() != "auto_turn":
                continue
            prev_query = _safe_text(meta.get("query"), limit=120)
            prev_feedback = _safe_text(meta.get("assistant_feedback"), limit=260)
            if not prev_feedback or not prev_query:
                continue
            if prev_query.strip().lower() == current_key:
                continue
            if _looks_like_clarification_query(prev_query):
                continue
            action_rows = meta.get("action_results") if isinstance(meta.get("action_results"), list) else []
            detail_steps: list[str] = []
            for row_action in action_rows[:3]:
                if not isinstance(row_action, dict):
                    continue
                tool = _safe_text(row_action.get("tool"), limit=80)
                ok = bool(row_action.get("ok", False))
                summary = _safe_text(row_action.get("summary") or row_action.get("error"), limit=140)
                low = summary.lower()
                if tool == "vision.yolo_world.prompt.set":
                    if ok:
                        detail_steps.append("先更新了检测目标。")
                    else:
                        detail_steps.append("更新检测目标失败。")
                    continue
                if tool == "vision.observe":
                    if "no target" in low or "未检测到" in summary or "未发现" in summary:
                        detail_steps.append("随后重新观察画面，未检测到目标。")
                    elif summary:
                        detail_steps.append(f"随后重新观察画面，结果：{summary}")
                    else:
                        detail_steps.append("随后重新观察画面。")
                    continue
                if summary:
                    detail_steps.append(summary if summary.endswith(("。", "！", "？")) else f"{summary}。")

            if detail_steps:
                detail_text = "".join(detail_steps)[:220]
                feedback = (
                    f"详细解释：上一条在处理“{_safe_text(prev_query, limit=36)}”时，"
                    f"{detail_text}结论是：{_safe_text(prev_feedback, limit=120)}"
                )
            else:
                feedback = f"上一条的意思是：{prev_feedback}"
            detail = f"hit query={_safe_text(prev_query, limit=80)}"
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "context.clarification.reply", True, detail)
            return _safe_text(feedback, limit=320)
        if trace_ctx is not None:
            TraceStore.step(trace_ctx, "context.clarification.reply", False, "no suitable recent feedback")
        return ""

    def _build_chat_profile_context(
        self,
        *,
        query: str = "",
        trace_ctx: TraceContext | None = None,
        marker: str = "[assistant_profile]",
        limit: int = 80,
        max_chars: int = 2200,
    ) -> str:
        if not bool(self.config.memory_enabled):
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "memory.chat_profile.context", True, "skip (memory disabled)")
            return ""
        keep = _clamp_int(limit, default=80, min_value=1, max_value=200)
        query_text = _safe_text(query, limit=160)
        try:
            query_rows = self.memory_store.search(query=query_text, limit=min(24, keep)) if query_text else []
            marker_rows = self.memory_store.search(query=marker, limit=keep)
        except Exception as exc:
            if trace_ctx is not None:
                TraceStore.step(
                    trace_ctx,
                    "memory.chat_profile.context",
                    False,
                    _safe_text(str(exc), limit=180) or "memory search failed",
                )
            return ""

        def _normalize_row(row: dict[str, Any]) -> tuple[str, int]:
            text = _safe_text(row.get("text"), limit=4000)
            if not text:
                return "", 0
            meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
            kind = _safe_text(meta.get("kind"), limit=40).lower()
            marker_low = marker.lower()
            has_marker_prefix = text.lower().lstrip().startswith(marker_low)
            if (not has_marker_prefix) and kind != "assistant_profile":
                return "", 0
            clean = re.sub(
                r"^\s*\[assistant_profile\](?:\[[^\]]+\])*\s*",
                "",
                text,
                flags=re.IGNORECASE,
            ).strip()
            clean = _safe_text(clean, limit=4000)
            if not clean:
                return "", 0
            chunk_idx = 0
            m = re.search(r"\[chunk\s*(\d+)\s*/\s*(\d+)\]", text, flags=re.IGNORECASE)
            if m:
                try:
                    chunk_idx = int(m.group(1))
                except Exception:
                    chunk_idx = 0
            elif isinstance(meta.get("chunk_index"), (int, float)):
                try:
                    chunk_idx = int(meta.get("chunk_index"))
                except Exception:
                    chunk_idx = 0
            return clean, chunk_idx

        relevant_pairs: list[tuple[int, str]] = []
        base_pairs: list[tuple[int, str]] = []
        seen: set[str] = set()

        for row in query_rows:
            if not isinstance(row, dict):
                continue
            clean, chunk_idx = _normalize_row(row)
            if not clean or clean in seen:
                continue
            seen.add(clean)
            relevant_pairs.append((chunk_idx, clean))

        for row in marker_rows:
            if not isinstance(row, dict):
                continue
            clean, chunk_idx = _normalize_row(row)
            if not clean or clean in seen:
                continue
            seen.add(clean)
            base_pairs.append((chunk_idx, clean))

        base_pairs.sort(key=lambda item: (item[0] <= 0, item[0]))
        ordered_chunks = [text for _idx, text in relevant_pairs] + [text for _idx, text in base_pairs]

        if not ordered_chunks:
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "memory.chat_profile.context", True, "hits=0")
            return ""

        merged = "\n".join(ordered_chunks)
        clipped = _safe_text(merged, limit=max(200, min(6000, int(max_chars))))
        if trace_ctx is not None:
            TraceStore.step(
                trace_ctx,
                "memory.chat_profile.context",
                True,
                f"hits={len(ordered_chunks)}, query_hits={len(relevant_pairs)}, chars={len(clipped)}",
            )
        return clipped

    @staticmethod
    def _extract_project_query_keywords(query: str) -> list[str]:
        text = _safe_text(query, limit=220).lower()
        keyword_pool = (
            "智渔灵枢",
            "rk3588",
            "养殖",
            "智慧养殖",
            "边缘",
            "边缘ai",
            "门禁",
            "生物安全",
            "入口",
            "人脸",
            "跟踪",
            "跟随",
            "锁控",
            "多模态",
            "环境",
            "传感器",
            "水温",
            "ph",
            "浊度",
            "水位",
            "池面",
            "异常",
            "漂浮",
            "识别",
            "定位",
            "执行",
            "龙门",
            "末端",
            "自动处置",
            "llm",
            "大语言模型",
            "平台",
            "app",
            "html",
            "打卡",
            "演示",
            "展示",
            "评委",
            "体验",
            "亮点",
            "闭环",
            "原理",
            "实现",
            "答辩",
            "问答",
            "版本",
            "边界",
            "judge",
            "judges",
            "demo",
            "introduction",
            "introduce",
            "principle",
            "implement",
            "implementation",
            "multimodal",
            "perception",
            "executor",
            "tracking",
            "access control",
            "platform",
        )
        hits: list[str] = []
        for keyword in keyword_pool:
            if keyword.lower() in text and keyword not in hits:
                hits.append(keyword)
        return hits[:12]

    @staticmethod
    def _infer_project_knowledge_layer(query: str) -> str:
        text = _safe_text(query, limit=220).lower()
        intro_tokens = (
            "介绍",
            "是什么",
            "做什么",
            "简介",
            "亮点",
            "价值",
            "演示",
            "展示",
            "体验",
            "评委",
            "参观",
            "一分钟",
            "为什么有价值",
            "introduce",
            "introduction",
            "judge",
            "judges",
            "demo",
            "what is",
            "why",
        )
        principle_tokens = (
            "原理",
            "实现",
            "怎么做",
            "为什么这样设计",
            "架构",
            "系统架构",
            "数据流",
            "部署",
            "部署关系",
            "工程拆分",
            "模块",
            "算法",
            "识别",
            "定位",
            "执行端",
            "龙门",
            "llm",
            "平台",
            "边界",
            "多模态",
            "门禁",
            "答辩",
            "principle",
            "implement",
            "implementation",
            "architecture",
            "data flow",
            "deployment",
            "module",
            "multimodal",
            "perception",
            "executor",
            "tracking",
            "access control",
        )
        intro_score = sum(1 for token in intro_tokens if token in text)
        principle_score = sum(1 for token in principle_tokens if token in text)
        if principle_score > intro_score:
            return "principle"
        if intro_score > 0:
            return "intro"
        return "intro"

    def _load_project_knowledge_docs(self) -> list[dict[str, Any]]:
        if not bool(self.config.knowledge_base_enabled):
            return []
        root = Path(self.config.knowledge_base_path).expanduser()
        if not root.exists() or (not root.is_dir()):
            return []
        files = sorted(
            path for path in root.rglob("*.md") if path.is_file() and path.name.lower() != "readme.md"
        )
        signature = tuple(
            (str(path.resolve()), int(path.stat().st_mtime_ns), int(path.stat().st_size))
            for path in files
        )
        with self._knowledge_docs_lock:
            if signature == self._knowledge_docs_signature and self._knowledge_docs_cache:
                return [dict(row) for row in self._knowledge_docs_cache]
            docs: list[dict[str, Any]] = []
            for path in files:
                try:
                    text = path.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
                clean = _safe_text(text.strip(), limit=12000)
                if not clean:
                    continue
                rel_path = str(path.relative_to(root)).replace("\\", "/")
                layer = "principle" if rel_path.startswith("01_operation_and_principle_layer/") else "intro"
                title = ""
                for line in clean.splitlines():
                    striped = line.strip()
                    if striped.startswith("#"):
                        title = striped.lstrip("#").strip()
                        break
                docs.append(
                    {
                        "path": rel_path,
                        "layer": layer,
                        "title": title or path.stem,
                        "text": clean,
                    }
                )
            self._knowledge_docs_signature = signature
            self._knowledge_docs_cache = [dict(row) for row in docs]
            return docs

    def _build_project_knowledge_context(
        self,
        *,
        query: str,
        trace_ctx: TraceContext | None = None,
    ) -> str:
        if not bool(self.config.knowledge_base_enabled):
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "knowledge.project.context", True, "disabled")
            return ""
        docs = self._load_project_knowledge_docs()
        if not docs:
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "knowledge.project.context", True, "hits=0")
            return ""

        preferred_layer = self._infer_project_knowledge_layer(query)
        keywords = self._extract_project_query_keywords(query)
        scored: list[tuple[int, dict[str, Any]]] = []
        for doc in docs:
            score = 0
            if _safe_text(doc.get("layer"), limit=20) == preferred_layer:
                score += 20
            text = str(doc.get("text") or "")
            path = _safe_text(doc.get("path"), limit=200).lower()
            title = _safe_text(doc.get("title"), limit=120)
            for keyword in keywords:
                if keyword.lower() in text.lower():
                    score += 6
                if keyword.lower() in path:
                    score += 4
                if keyword.lower() in title.lower():
                    score += 4
            if preferred_layer == "intro" and "问答" in title:
                score += 5
            if preferred_layer == "principle" and ("原理" in title or "边界" in title):
                score += 5
            if score > 0:
                scored.append((score, doc))

        if not scored:
            fallback_docs = [doc for doc in docs if _safe_text(doc.get("layer"), limit=20) == preferred_layer]
            scored = [(1, doc) for doc in fallback_docs[: int(self.config.knowledge_base_max_hits)]]

        scored.sort(
            key=lambda item: (
                -int(item[0]),
                _safe_text(item[1].get("path"), limit=200),
            )
        )
        max_hits = int(self.config.knowledge_base_max_hits)
        max_chars = int(self.config.knowledge_base_max_chars)
        snippets: list[str] = []
        used_chars = 0
        for _score, doc in scored[:max(1, max_hits * 2)]:
            title = _safe_text(doc.get("title"), limit=120)
            layer = "介绍层" if _safe_text(doc.get("layer"), limit=20) == "intro" else "原理层"
            text = _safe_text(doc.get("text"), limit=2400)
            if not text:
                continue
            snippet_budget = min(110, max(80, max_chars - used_chars))
            snippet_text = _safe_text(text, limit=snippet_budget)
            block = f"[{layer}] {title}\n{snippet_text}"
            projected = used_chars + len(block) + 2
            if snippets and projected > max_chars:
                continue
            snippets.append(block)
            used_chars = projected
            if len(snippets) >= max_hits or used_chars >= max_chars:
                break

        if not snippets:
            if trace_ctx is not None:
                TraceStore.step(trace_ctx, "knowledge.project.context", True, "hits=0")
            return ""

        intro = "项目身份：你是“智渔灵枢”专属助手。"
        strategy = "规则：项目问题优先依据知识回答，先总结，不长段照抄。"
        layer_hint = "当前建议回答层：介绍层。" if preferred_layer == "intro" else "当前建议回答层：操作和实现原理层。"
        context = "\n".join([intro, strategy, layer_hint, "相关知识：", "\n\n".join(snippets)])
        context = _safe_text(context, limit=max_chars + 80)
        if trace_ctx is not None:
            TraceStore.step(
                trace_ctx,
                "knowledge.project.context",
                True,
                f"layer={preferred_layer}, keywords={len(keywords)}, hits={len(snippets)}, chars={len(context)}",
            )
        return context

    def _compose_chat_manual_message(
        self,
        *,
        query: str,
        dialogue_history: list[dict[str, Any]] | None,
        prefer_chinese: bool,
        project_context: str,
    ) -> str:
        history_rows = list(dialogue_history or [])
        history_text = _format_dialogue_history_for_prompt(history_rows, max_rows=8, max_chars=520)
        style_lines = [
            "你是“智渔灵枢”项目助手。",
            "项目相关问题优先依据提供的项目知识回答。",
            "只输出最终答复，不要输出分析、JSON、流程日志。",
            "用自然口语回答；除非用户明确要求分点，否则不要列清单。",
            "不要长段照抄知识；不确定就直接说明。",
        ]
        if prefer_chinese:
            style_lines.append("必须使用简体中文，通常 1-4 句。")
        else:
            style_lines.append("Use the user's language in natural spoken style.")
        style_prompt = "\n".join(style_lines)
        parts = [style_prompt]
        if project_context:
            parts.append("以下是项目身份与相关知识，仅在相关时使用：\n" + project_context)
        if history_text:
            parts.append("以下是最近对话，仅用于保持上下文一致：\n" + history_text)
        parts.append("用户当前问题：" + query)
        parts.append("请直接输出最终答复。")
        return _safe_text("\n".join(parts), limit=4200)

    def _build_project_knowledge_fallback_reply(self, *, query: str) -> str:
        text = _safe_text(query, limit=260).lower()
        preferred_layer = self._infer_project_knowledge_layer(query)
        intro_reply = (
            "智渔灵枢是一套面向小型智慧养殖场景的边缘人工智能闭环系统。"
            "它从园区入口的智能生物安全门禁开始，延伸到园区内部的多模态环境感知、池面异常识别、自动化处置以及平台与大语言模型交互，形成门禁防闭、环境感知、视觉识别、智能交互、自动处置五位一体的完整链路。"
            "如果从项目主线看，它不是单点功能展示，而是把人、环境、设备、执行和平台串成了一条完整闭环。"
        )
        principle_parts: list[str] = []
        if any(token in text for token in ("多模态", "multimodal", "perception", "感知", "传感")):
            principle_parts.append(
                "这套系统的多模态感知，核心是把池面图像和水温、pH、浊度、水位等传感器参数协同起来，不只看画面，也不只看单一环境数值，而是一起判断养殖现场状态。"
            )
        if any(token in text for token in ("架构", "architecture", "系统架构", "模块", "module")):
            principle_parts.append(
                "从系统架构上看，它可以分成入口安全层、园区感知层、异常识别与定位层、执行与处置层，以及平台和 LLM 交互层。前面负责采集和判断，中间负责识别和定位，后面负责执行动作和结果展示。"
            )
        if any(token in text for token in ("数据流", "data flow", "流程", "链路", "闭环")):
            principle_parts.append(
                "从数据流上看，门禁视频会进入人脸识别与锁控链路，池面图像会进入异常识别与定位链路，传感器参数会进入多模态状态判断链路，最后这些结果都会汇总到平台和语言交互层，形成可解释、可展示、可继续执行的闭环。"
            )
        if any(token in text for token in ("执行", "executor", "龙门", "处置")):
            principle_parts.append(
                "执行端采用 XY 龙门机构和轻量末端执行器，视觉模块先识别并定位异常目标，再把位置信息交给执行端完成自动化物理处置，这样就把感知结果真正接到了动作层。"
            )
        if any(token in text for token in ("门禁", "access control", "人脸", "锁控")):
            principle_parts.append(
                "入口门禁部分通过动态人脸识别、人员跟踪和智能锁控建立第一道生物安全防线，先从源头管住谁可以进入园区。"
            )
        if any(token in text for token in ("部署", "deployment", "部署关系", "rk3588", "板端", "下位机")):
            principle_parts.append(
                "从部署关系看，RK3588 板端是核心边缘节点，主要承载视觉推理、LLM 代理、Agent 服务和 HTML 页面；下位机负责部分传感器采集与执行机构协同；这样形成边缘主节点加硬件执行节点的协同结构。"
            )
        if any(token in text for token in ("app", "html", "flutter", "前端", "平台", "后台")):
            principle_parts.append(
                "从工程拆分看，系统并不是一个单文件程序，而是由视觉与门禁工程、执行端与下位机工程、HTML 后台、Flutter App，以及 LLM 智能交互工程共同组成。HTML 更适合展示和管理，App 更适合移动端登录、打卡和状态查看。"
            )
        if any(token in text for token in ("llm", "大语言模型", "平台", "app", "html")):
            principle_parts.append(
                "大语言模型和平台层主要负责把门禁记录、环境参数、识别结果和设备状态转成更容易理解和查询的自然语言说明。"
            )
        if preferred_layer == "principle":
            if not principle_parts:
                principle_parts.append(
                    "从实现原理上看，这套系统是把入口门禁、多模态感知、异常识别、执行端和平台交互串成闭环，而不是做成互相独立的几个模块。"
                )
            return "".join(principle_parts)[:720]
        return intro_reply[:420]

    def _fallback_llm_chat_rewrite(
        self,
        *,
        query: str,
        profile_context: str,
        dialogue_history: list[dict[str, Any]] | None,
        prefer_chinese: bool,
        timeout_sec: float,
        llm_session_id: str = "",
        llm_keep_history: bool = False,
        llm_clear_history: bool = False,
        trace_ctx: TraceContext,
    ) -> tuple[bool, str, dict[str, Any]]:
        prompt_obj = {
            "query": _safe_text(query, limit=260),
            "profile_context": _safe_text(profile_context, limit=900),
            "runtime": {
                "service": "agent-service-v2",
                "route": "chat_manual",
                "mode": "chat_only",
                "can_execute_tools": False,
                "must_not_claim_execution": True,
            },
        }
        history_rows = list(dialogue_history or [])
        history_text = _format_dialogue_history_for_prompt(history_rows, max_rows=12, max_chars=900)
        action_facts = _extract_dialogue_action_facts(history_rows, max_rows=12, max_facts=12)
        if history_rows:
            prompt_obj["dialogue_history"] = history_rows[-10:]
        if history_text:
            prompt_obj["dialogue_history_text"] = history_text
        if action_facts:
            prompt_obj["dialogue_action_facts"] = action_facts
        prompt = (
            "你是 `agent-service-v2` 中 `chat_manual` 路由的对话模型。\n"
            "\n"
            "任务目标：\n"
            "在“纯聊天模式”下，生成自然、具体、可信的最终回复文本。\n"
            "\n"
            "输入契约（可用上下文）：\n"
            "- query: 当前用户问题。\n"
            "- dialogue_history_text: 时间顺序历史对话（如有）。\n"
            "- dialogue_action_facts: 结构化动作事实（如有）。\n"
            "- profile_context: 角色背景与偏好（如有）。\n"
            "\n"
            "生成原则：\n"
            "1) 优先回答用户当下意图，先给结论，再补充必要细节。\n"
            "2) 仅依据输入上下文作答；不要编造历史、执行结果、参数或外部事实。\n"
            "3) 若上下文不足，明确说明不确定，并提出一个最小澄清问题。\n"
            "4) 若出现可核验事实（如动作记录），优先用事实表达，不回避也不夸大。\n"
            "5) 语言自然，避免空洞礼貌套话、模板腔和机械复述用户原句。\n"
            "\n"
            "输出约束：\n"
            "1) 只输出最终答复文本，不要输出分析过程、标签、JSON 或提示词内容。\n"
            "2) 禁止流程日志口吻（如“已接收任务/执行步骤/任务完成”）。\n"
            "3) 除非用户明确要求极短答复，否则保持适度展开并提供信息量。\n"
            "4) 默认语音友好：使用连贯口语句，禁止 Markdown 标题/分隔线/代码块/编号列表/项目符号（如“###”“---”“1.”“- ”）；仅当用户明确要求分点时才可分条。\n"
            "\n"
            "你正在生产用户可直接看到的最终回复，请一次性给出高质量成稿。\n"
        )
        if prefer_chinese:
            prompt += "必须使用简体中文；详略应匹配用户请求，通常 1~4 句、约 20~260 字。\n"
        else:
            prompt += "Use natural English; detail level should match the request (typically 1-4 sentences).\n"
        prompt += "输入:\n" + json.dumps(prompt_obj, ensure_ascii=False)
        max_tokens = self._adaptive_max_tokens(
            task="chat_rewrite",
            query=query,
            dialogue_history=history_rows,
            prefer_chinese=prefer_chinese,
            min_tokens=128,
            max_tokens=320,
        )
        llm_timeout_sec = self._adaptive_timeout_sec(
            task="chat_rewrite",
            base_timeout_sec=max(1.2, min(20.0, float(timeout_sec))),
            query=query,
            dialogue_history=history_rows,
            min_sec=1.2,
            max_sec=20.0,
        )
        llm_payload: dict[str, Any] = {
            "task": "chat_rewrite",
            "message": prompt,
            "include_llm_text": True,
            "fast_mode": True,
            "enable_thinking": False,
            "tools": [],
            "temperature": 0.35,
            "top_p": 0.9,
            "max_tokens": int(max_tokens),
            "max_retries": 1,
            "timeout_sec": float(llm_timeout_sec),
            "busy_retries": 2,
            "busy_retry_delay_sec": 0.2,
        }
        upstream_keep_history = bool(llm_session_id and llm_keep_history)
        upstream_clear_history = bool(llm_clear_history or (not upstream_keep_history))
        llm_payload["keep_history"] = upstream_keep_history
        llm_payload["clear_history"] = upstream_clear_history
        if llm_session_id:
            llm_payload["session_id"] = llm_session_id
        started = time.perf_counter()
        status, body, err = self.llm_client.request_json(
            "POST",
            "/api/llm/agent_task",
            payload=llm_payload,
            timeout_sec=max(2.0, float(llm_payload["timeout_sec"]) + 0.8),
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        text = self._normalize_feedback_text(
            self._extract_llm_text(body_obj, allow_assistant_feedback=False) if base_ok else ""
        )
        ok = base_ok and bool(text)
        if ok and prefer_chinese and (not self._accept_non_cjk_chat_reply(query, text)):
            ok = False
        detail = (
            "ok"
            if ok
            else _safe_text(
                err
                or body_obj.get("error")
                or ("empty llm text" if base_ok else f"status={status or 0}"),
                limit=220,
            )
        )
        TraceStore.step(
            trace_ctx,
            name="llm.chat.rewrite",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        return ok, text, {
            "status": status,
            "detail": detail,
            "timeout_sec": float(llm_timeout_sec),
            "max_tokens": int(max_tokens),
        }

    @staticmethod
    def _extract_chat_direct_text(body_obj: dict[str, Any]) -> str:
        llm_text = AgentServiceApp._extract_llm_text(body_obj, allow_assistant_feedback=True)
        normalized = AgentServiceApp._normalize_feedback_text(llm_text)
        if normalized and (not AgentServiceApp._looks_like_llm_chat_report(normalized)):
            return normalized

        assistant_feedback = _safe_text(body_obj.get("assistant_feedback"), limit=4000)
        if assistant_feedback:
            m = re.search(r"任务完成：摘要=([^\n\r]+)", assistant_feedback)
            if m:
                return AgentServiceApp._normalize_feedback_text(m.group(1))
            m = re.search(r"(?:summary|摘要)\s*=\s*([^\n\r]+)", assistant_feedback, flags=re.IGNORECASE)
            if m:
                return AgentServiceApp._normalize_feedback_text(m.group(1))
            if not AgentServiceApp._looks_like_llm_chat_report(assistant_feedback):
                return AgentServiceApp._normalize_feedback_text(assistant_feedback)
        return ""

    def _fallback_llm_chat_direct(
        self,
        *,
        query: str,
        prefer_chinese: bool,
        timeout_sec: float,
        llm_session_id: str = "",
        llm_keep_history: bool = False,
        llm_clear_history: bool = False,
        trace_ctx: TraceContext,
    ) -> tuple[bool, str, dict[str, Any]]:
        direct_timeout = self._adaptive_timeout_sec(
            task="chat_direct",
            # Keep direct-chat budget above observed upstream p95 to avoid
            # agent-side early timeout while upstream is still running.
            base_timeout_sec=max(45.0, min(60.0, float(timeout_sec) + 15.0)),
            query=query,
            min_sec=45.0,
            max_sec=60.0,
        )
        llm_payload: dict[str, Any] = {
            "message": _safe_text(query, limit=600),
            "attach_vision": False,
            "tools": [],
            "timeout_sec": float(direct_timeout),
            # Do not stack retries here; retries can double tail latency.
            "max_retries": 0,
        }
        upstream_keep_history = bool(llm_session_id and llm_keep_history)
        upstream_clear_history = bool(llm_clear_history or (not upstream_keep_history))
        llm_payload["keep_history"] = upstream_keep_history
        llm_payload["clear_history"] = upstream_clear_history
        if llm_session_id:
            llm_payload["session_id"] = llm_session_id

        started = time.perf_counter()
        status, body, err = self.llm_client.request_json(
            "POST",
            "/api/llm/chat",
            payload=llm_payload,
            # Ensure client timeout always covers upstream budget with margin.
            timeout_sec=max(66.0, float(direct_timeout) + 4.0),
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        text = self._extract_chat_direct_text(body_obj) if base_ok else ""
        ok = bool(text)
        if ok and prefer_chinese and (not self._accept_non_cjk_chat_reply(query, text)):
            ok = False

        detail = (
            "ok"
            if ok
            else _safe_text(
                err
                or body_obj.get("error")
                or ("empty llm text" if base_ok else f"status={status or 0}"),
                limit=220,
            )
        )
        TraceStore.step(
            trace_ctx,
            name="llm.chat.direct",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        return ok, text, {
            "status": status,
            "detail": detail,
            "timeout_sec": float(direct_timeout),
        }

    def _fallback_llm_chat(
        self,
        *,
        query: str,
        payload: dict[str, Any],
        dialogue_history: list[dict[str, Any]] | None = None,
        allow_local_fallback: bool = True,
        trace_ctx: TraceContext,
    ) -> tuple[bool, str, dict[str, Any]]:
        if not self.config.llm_chat_fallback_enabled:
            TraceStore.step(
                trace_ctx,
                name="llm.chat.fallback",
                ok=False,
                detail="disabled by AGENT_LLM_CHAT_FALLBACK=0",
            )
            return False, "", {
                "status": 0,
                "detail": "disabled by AGENT_LLM_CHAT_FALLBACK=0",
            }

        _ = allow_local_fallback
        timeout_sec = self.config.llm_chat_timeout_sec
        try:
            timeout_sec = float(payload.get("llm_timeout_sec", timeout_sec))
        except (TypeError, ValueError):
            timeout_sec = self.config.llm_chat_timeout_sec
        timeout_sec = max(2.0, min(12.0, timeout_sec))

        prefer_chinese = _contains_cjk(query)
        llm_session_id = _safe_text(payload.get("llm_session_id"), limit=64)
        if not llm_session_id:
            llm_session_id = _safe_text(payload.get("session_id"), limit=64)
        llm_keep_history_flag = _coerce_enabled(payload.get("llm_keep_history"))
        llm_clear_history_flag = _coerce_enabled(payload.get("llm_clear_history"))
        llm_keep_history = (
            bool(llm_keep_history_flag)
            if llm_keep_history_flag is not None
            else bool(llm_session_id)
        )
        llm_clear_history = bool(llm_clear_history_flag) if llm_clear_history_flag is not None else False
        history_rows = list(dialogue_history or [])
        project_context = self._build_project_knowledge_context(query=query, trace_ctx=trace_ctx)
        message_text = self._compose_chat_manual_message(
            query=query,
            dialogue_history=history_rows,
            prefer_chinese=prefer_chinese,
            project_context=project_context,
        )

        llm_payload: dict[str, Any] = {
            "message": message_text,
            "attach_vision": bool(payload.get("attach_vision", False)),
            "include_llm_text": True,
            "fast_mode": True,
            "timeout_sec": float(timeout_sec),
            "max_retries": 0,
            # Keep chat output concise for latency stability.
            "max_tokens": int(
                _clamp_int(
                    payload.get("llm_max_tokens", 64),
                    default=64,
                    min_value=24,
                    max_value=128,
                )
            ),
        }
        if "enable_thinking" in payload:
            llm_payload["enable_thinking"] = bool(payload.get("enable_thinking"))
        if "temperature" in payload:
            llm_payload["temperature"] = payload.get("temperature")
        if "top_p" in payload:
            llm_payload["top_p"] = payload.get("top_p")
        if "top_k" in payload:
            llm_payload["top_k"] = payload.get("top_k")
        if "tools" in payload:
            llm_payload["tools"] = payload.get("tools")
        llm_payload["keep_history"] = bool(llm_session_id and llm_keep_history)
        llm_payload["clear_history"] = bool(llm_clear_history or (not llm_payload["keep_history"]))
        if llm_session_id:
            llm_payload["session_id"] = llm_session_id

        started = time.perf_counter()
        status, body, err = self.llm_client.request_json(
            "POST",
            "/api/llm/chat",
            payload=llm_payload,
            timeout_sec=max(4.0, float(timeout_sec) + 1.6),
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_chat_direct_text(body_obj) if base_ok else ""
        llm_text = self._normalize_feedback_text(llm_text)
        ok = base_ok and bool(llm_text)
        if ok and prefer_chinese and (not self._accept_non_cjk_chat_reply(query, llm_text)):
            ok = False

        detail = (
            "ok"
            if ok
            else _safe_text(
                err
                or body_obj.get("error")
                or ("empty llm text" if base_ok else f"status={status or 0}"),
                limit=220,
            )
        )
        TraceStore.step(
            trace_ctx,
            name="llm.chat.direct",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        if ok:
            detail = "direct llm chat fallback"
        TraceStore.step(
            trace_ctx,
            name="llm.chat.fallback",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        if (not ok) and project_context:
            fallback_text = self._build_project_knowledge_fallback_reply(query=query)
            fallback_text = self._normalize_feedback_text(fallback_text)
            if fallback_text:
                TraceStore.step(
                    trace_ctx,
                    name="knowledge.project.fallback",
                    ok=True,
                    detail="project knowledge fallback",
                )
                return True, fallback_text, {
                    "status": int(status or 0),
                    "detail": "project knowledge fallback",
                }
        return ok, llm_text, {
            "status": int(status or 0),
            "detail": detail,
        }

    def _polish_execution_feedback(
        self,
        *,
        query: str,
        base_feedback: str,
        plan: dict[str, Any],
        action_results: list[dict[str, Any]],
        all_ok: bool,
        trace_ctx: TraceContext,
        memory_context: dict[str, Any] | None = None,
    ) -> tuple[bool, str, dict[str, Any]]:
        if not self.config.llm_exec_feedback_enabled:
            TraceStore.step(
                trace_ctx,
                name="llm.feedback.polish",
                ok=False,
                detail="disabled by AGENT_LLM_EXEC_FEEDBACK=0",
            )
            return False, "", {
                "status": 0,
                "detail": "disabled by AGENT_LLM_EXEC_FEEDBACK=0",
                "source": "tool_summary",
            }

        style_hint, style_id = self._next_feedback_style_hint()
        # Keep polish fast: short prompt + short output budget.
        timeout_sec = self._adaptive_timeout_sec(
            task="polish_execution",
            base_timeout_sec=max(2.5, min(6.0, float(self.config.llm_exec_feedback_timeout_sec))),
            query=query,
            min_sec=2.0,
            max_sec=6.0,
        )
        max_tokens = self._adaptive_max_tokens(
            task="polish_execution",
            query=query,
            min_tokens=32,
            max_tokens=72,
        )
        compact_results = self._compact_action_results_for_feedback(action_results)
        fact_chunks: list[str] = []
        for row in compact_results[:3]:
            tool = _safe_text(row.get("tool"), limit=48) or "tool"
            state = "ok" if bool(row.get("ok", False)) else "fail"
            detail = _safe_text(row.get("summary") or row.get("error"), limit=88)
            fact_chunks.append(f"{tool}:{state}:{detail or '-'}")
        memory_guidance = ""
        if isinstance(memory_context, dict):
            memory_guidance = _safe_text(memory_context.get("guidance"), limit=88)
        prompt_lines = [
            "你是执行结果润色器。把事实改写成1句自然中文，最多28字。",
            "只用给定事实，禁止编造；有失败就明确失败点；默认不输出置信度/坐标/面积；只输出最终句子。",
            f"风格:{_safe_text(style_hint, limit=36)}",
            f"问题:{_safe_text(query, limit=140)}",
            f"基础结论:{_safe_text(base_feedback, limit=180)}",
            f"事实:{' | '.join(fact_chunks) if fact_chunks else '-'}",
        ]
        if memory_guidance:
            prompt_lines.append(f"提示:{memory_guidance}")
        prompt = "\n".join(prompt_lines)
        llm_payload: dict[str, Any] = {
            "task": "polish_execution",
            "message": prompt,
            "include_llm_text": True,
            "timeout_sec": timeout_sec,
            "fast_mode": True,
            # Polish only needs a short deterministic rewrite; disable reasoning path for latency.
            "enable_thinking": False,
            "temperature": min(0.3, float(self.config.llm_exec_feedback_temperature)),
            "top_p": 0.8,
            "max_tokens": int(max_tokens),
            "max_retries": 0,
            "busy_retries": 2,
            "busy_retry_delay_sec": 0.1,
        }
        started = time.perf_counter()
        status, body, err = self.llm_client.request_json(
            "POST",
            "/api/llm/agent_task",
            payload=llm_payload,
            timeout_sec=max(timeout_sec + 0.8, 5.0),
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        polished = self._normalize_feedback_text(llm_text)
        polished = self._strip_technical_detail_if_needed(query, polished)
        safe = self._is_execution_polish_safe(query, base_feedback, action_results, polished)
        ok = base_ok and bool(polished) and bool(safe)
        detail = (
            "ok"
            if ok
            else _safe_text(
                ("unsafe polish content: no-target mismatch" if (base_ok and polished and not safe) else "")
                or
                err
                or body_obj.get("error")
                or ("empty llm text" if base_ok else f"status={status or 0}"),
                limit=220,
            )
        )
        TraceStore.step(
            trace_ctx,
            name="llm.feedback.polish",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        return ok, polished, {
            "status": status,
            "detail": detail,
            "style_id": style_id,
            "source": ("llm_polish" if ok else "tool_summary"),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(max_tokens),
        }

    def _polish_general_feedback(
        self,
        *,
        query: str,
        base_feedback: str,
        context: str,
        trace_ctx: TraceContext,
        memory_context: dict[str, Any] | None = None,
    ) -> tuple[bool, str, dict[str, Any]]:
        if not self.config.llm_exec_feedback_enabled:
            TraceStore.step(
                trace_ctx,
                name="llm.feedback.general",
                ok=False,
                detail="disabled by AGENT_LLM_EXEC_FEEDBACK=0",
            )
            return False, "", {
                "status": 0,
                "detail": "disabled by AGENT_LLM_EXEC_FEEDBACK=0",
                "source": "template",
            }

        style_hint, style_id = self._next_feedback_style_hint()
        timeout_sec = self._adaptive_timeout_sec(
            task="polish_general",
            base_timeout_sec=max(2.5, min(6.0, float(self.config.llm_exec_feedback_timeout_sec))),
            query=query,
            min_sec=2.0,
            max_sec=6.0,
        )
        max_tokens = self._adaptive_max_tokens(
            task="polish_general",
            query=query,
            min_tokens=30,
            max_tokens=72,
        )
        expected_state = {
            "confirm_preview": "executed=false, awaiting_confirmation=true",
            "confirm_pending": "executed=false, awaiting_confirmation=true",
            "no_action": "executed=false, awaiting_confirmation=false",
        }.get(context, "executed=unknown")
        memory_guidance = ""
        if isinstance(memory_context, dict):
            memory_guidance = _safe_text(memory_context.get("guidance"), limit=88)
        prompt_lines = [
            "你是回复润色器。把给定信息改写成1句自然中文，最多28字。",
            "不要编造，不要改状态，不要Markdown，只输出最终句子。",
            f"风格:{_safe_text(style_hint, limit=36)}",
            f"上下文:{_safe_text(context, limit=32)}",
            f"状态:{expected_state}",
            f"问题:{_safe_text(query, limit=140)}",
            f"基础结论:{_safe_text(base_feedback, limit=180)}",
        ]
        if memory_guidance:
            prompt_lines.append(f"提示:{memory_guidance}")
        prompt = "\n".join(prompt_lines)
        busy_retries = 8 if context == "no_action" else 2
        llm_payload: dict[str, Any] = {
            "task": "polish_general",
            "message": prompt,
            "include_llm_text": True,
            "timeout_sec": timeout_sec,
            "fast_mode": True,
            # General polish is also a short rewrite task; keep fast/non-reasoning path.
            "enable_thinking": False,
            "temperature": min(0.3, float(self.config.llm_exec_feedback_temperature)),
            "top_p": 0.8,
            "max_tokens": int(max_tokens),
            "max_retries": 0,
            "busy_retries": busy_retries,
            "busy_retry_delay_sec": 0.12,
        }
        started = time.perf_counter()
        status, body, err = self.llm_client.request_json(
            "POST",
            "/api/llm/agent_task",
            payload=llm_payload,
            timeout_sec=max(timeout_sec + 0.8, 5.0),
        )
        body_obj = body if isinstance(body, dict) else {}
        base_ok = 200 <= status < 300 and bool(body_obj.get("ok", False))
        llm_text = self._extract_llm_text(body_obj) if base_ok else ""
        polished = self._normalize_feedback_text(llm_text)
        polished = self._strip_technical_detail_if_needed(query, polished)
        safe = self._is_polished_feedback_safe(context, polished)
        ok = base_ok and bool(polished) and bool(safe)
        detail = (
            "ok"
            if ok
            else _safe_text(
                ("unsafe polish content: state mismatch" if (base_ok and polished and not safe) else "")
                or
                err
                or body_obj.get("error")
                or ("empty llm text" if base_ok else f"status={status or 0}"),
                limit=220,
            )
        )
        TraceStore.step(
            trace_ctx,
            name="llm.feedback.general",
            ok=ok,
            detail=detail,
            duration_ms=(time.perf_counter() - started) * 1000.0,
            status=(status if status > 0 else None),
        )
        return ok, polished, {
            "status": status,
            "detail": detail,
            "style_id": style_id,
            "source": ("llm_polish" if ok else "template"),
            "timeout_sec": float(timeout_sec),
            "max_tokens": int(max_tokens),
        }

    def health_payload(self) -> tuple[int, dict[str, Any]]:
        vision = self.vision_adapter.health(timeout_sec=2.0)
        llm_status, llm_body, llm_err = self.llm_client.request_json(
            "GET",
            "/api/llm/health",
            timeout_sec=2.0,
        )
        llm_ok = 200 <= llm_status < 300 and bool((llm_body or {}).get("ok", False))
        llm_detail = (
            "status=200"
            if llm_ok
            else _safe_text(
                llm_err or (llm_body or {}).get("error") or f"status={llm_status or 0}",
                limit=180,
            )
        )
        required_flags: list[bool] = []
        if self.config.require_vision:
            required_flags.append(bool(vision.get("up")))
        ok = all(required_flags) if required_flags else True
        payload = {
            "ok": ok,
            "timestamp": _ts_now(),
            "service": "agent-service-v2",
            "listen": f"{self.config.host}:{self.config.port}",
            "runtime": {
                "tool_runtime": self.config.tool_runtime,
                "rgb_backend": self.config.rgb_backend,
                "memory_enabled": bool(self.config.memory_enabled),
                "memory_persist_enabled": bool(self.config.memory_persist_enabled),
                "memory_persist_path": self.config.memory_persist_path or None,
                "memory_auto_capture_enabled": bool(self.memory_auto_capture_enabled),
                "memory_auto_capture_on_failure": bool(self.memory_auto_capture_on_failure),
                "require_vision": bool(self.config.require_vision),
                "llm_chat_fallback_enabled": bool(self.config.llm_chat_fallback_enabled),
                "llm_fast_chat_route_enabled": bool(self.config.llm_fast_chat_route_enabled),
                "llm_semantic_cache_enabled": bool(self.config.llm_semantic_cache_enabled),
                "llm_semantic_cache_ttl_sec": float(self.config.llm_semantic_cache_ttl_sec),
                "llm_semantic_cache_max_items": int(self.config.llm_semantic_cache_max_items),
                "llm_semantic_cache_side_effect_enabled": bool(
                    self.config.llm_semantic_cache_side_effect_enabled
                ),
                "command_embed_router_enabled": bool(self.config.command_embed_router_enabled),
                "command_embed_router_model": _safe_text(self.config.command_embed_router_model, limit=180),
                "command_embed_router_min_score": float(self.config.command_embed_router_min_score),
                "command_embed_router_min_margin": float(self.config.command_embed_router_min_margin),
                "command_embed_router_use_npu": bool(self.config.command_embed_router_use_npu),
                "command_embed_router_local_files_only": bool(
                    self.config.command_embed_router_local_files_only
                ),
                "command_embed_router_prewarm": bool(self.config.command_embed_router_prewarm),
                "command_embed_classifier_enabled": bool(self.config.command_embed_classifier_enabled),
                "command_embed_classifier_path": _safe_text(
                    self.config.command_embed_classifier_path,
                    limit=220,
                ),
                "command_embed_classifier_min_prob": float(self.config.command_embed_classifier_min_prob),
                "command_embed_model_only": bool(self.config.command_embed_model_only),
                "llm_command_gate_timeout_sec": float(self.config.llm_command_gate_timeout_sec),
                "llm_strict_mode": bool(self.config.llm_strict_mode),
                "llm_tool_planner_enabled": bool(self.config.llm_tool_planner_enabled),
                "llm_tool_planner_timeout_sec": float(self.config.llm_tool_planner_timeout_sec),
                "llm_planner_concurrency": int(self._llm_planner_concurrency),
                "llm_planner_slot_wait_sec": float(self._llm_planner_slot_wait_sec),
                "llm_tool_plan_native_history_enabled": bool(
                    self.config.llm_tool_plan_native_history_enabled
                ),
                "llm_tool_plan_native_tools_enabled": bool(
                    self.config.llm_tool_plan_native_tools_enabled
                ),
                "llm_tool_plan_repair_enabled": bool(self.config.llm_tool_plan_repair_enabled),
                "llm_tool_plan_repair_timeout_sec": float(self.config.llm_tool_plan_repair_timeout_sec),
                "llm_exec_feedback_enabled": bool(self.config.llm_exec_feedback_enabled),
                "llm_exec_feedback_timeout_sec": float(self.config.llm_exec_feedback_timeout_sec),
                "llm_exec_feedback_temperature": float(self.config.llm_exec_feedback_temperature),
                "llm_fast_chat_cache_enabled": bool(self._fast_chat_cache_enabled),
                "exec_read_parallelism": int(self.config.exec_read_parallelism),
                "camera_observe_capabilities": _camera_capability_state_snapshot(),
            },
            "upstream": {
                "vision": self.config.vision_api_base,
                "llm": self.config.llm_api_base,
            },
            "owned_routes": self.owned_route_patterns(),
            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
            "counters": {
                "pending_confirmations": self.confirm_store.count(),
                "trace_cached": self.trace_store.count(),
                "llm_planner": self._llm_planner_metrics_snapshot(),
                "llm_semantic_cache": self._semantic_plan_cache_snapshot(),
                "command_embed_router": self.semantic_intent_router.snapshot(),
            },
            "deps": {
                "vision": vision,
                "llm": {
                    "up": llm_ok,
                    "status": llm_status,
                    "detail": llm_detail,
                    "probe": "/api/llm/health",
                },
            },
        }
        return (200 if ok else 503), payload

    @staticmethod
    def _compact_objects_for_memory(objects: list[Any], limit: int = 6) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        if not isinstance(objects, list):
            return out
        for obj in objects[: max(1, int(limit))]:
            if not isinstance(obj, dict):
                continue
            out.append(
                {
                    "class_name": _safe_text(obj.get("class_name"), limit=48) or None,
                    "class_id": obj.get("class_id"),
                    "score": round(float(obj.get("score") or 0.0), 4),
                    "cx": round(float(obj.get("cx") or 0.0), 2),
                    "cy": round(float(obj.get("cy") or 0.0), 2),
                }
            )
        return out

    def _compact_tool_result_for_memory(
        self,
        *,
        tool: str,
        action_ok: bool,
        result: dict[str, Any],
    ) -> tuple[dict[str, Any], set[str]]:
        item: dict[str, Any] = {
            "tool": _safe_text(tool, limit=80),
            "ok": bool(action_ok),
            "summary": _safe_text(result.get("summary"), limit=220),
            "error": _safe_text(result.get("error"), limit=220),
        }
        modalities: set[str] = {"text"}
        if tool == "vision.observe":
            modalities.add("vision")
            frame = result.get("frame") if isinstance(result.get("frame"), dict) else {}
            best = result.get("best_target") if isinstance(result.get("best_target"), dict) else {}
            api_meta = result.get("api") if isinstance(result.get("api"), dict) else {}
            vision_meta: dict[str, Any] = {
                "detector": _safe_text(result.get("detector") or api_meta.get("detector"), limit=24),
                "frame": {
                    "width": int(frame.get("width") or 0),
                    "height": int(frame.get("height") or 0),
                },
                "best": {
                    "class_name": _safe_text(best.get("class_name"), limit=48) or None,
                    "class_id": best.get("class_id"),
                    "score": round(float(best.get("score") or 0.0), 4),
                    "cx": round(float(best.get("cx") or 0.0), 2),
                    "cy": round(float(best.get("cy") or 0.0), 2),
                }
                if best
                else None,
                "objects": self._compact_objects_for_memory(result.get("objects") if isinstance(result.get("objects"), list) else [], limit=6),
            }
            wear = result.get("wear_glasses") if isinstance(result.get("wear_glasses"), dict) else {}
            emotion = result.get("emotion") if isinstance(result.get("emotion"), dict) else {}
            if wear:
                vision_meta["wear_glasses"] = {
                    "ok": bool(wear.get("ok", False)),
                    "wear_glasses_count": int(wear.get("wear_glasses_count") or 0),
                }
            if emotion:
                vision_meta["emotion"] = {
                    "ok": bool(emotion.get("ok", False)),
                    "emotion_count": int(emotion.get("emotion_count") or 0),
                }
            item["vision"] = vision_meta
        elif tool.startswith("vision.gimbal"):
            modalities.add("control")
            item["gimbal"] = {
                "status": _safe_text(result.get("status"), limit=48),
                "connected": bool(result.get("connected", False)),
                "active": bool(result.get("active", False)),
                "locked": bool(result.get("locked", False)),
                "message": _safe_text(result.get("message"), limit=160),
            }
            cmd = result.get("command") if isinstance(result.get("command"), dict) else {}
            if cmd:
                item["gimbal"]["command"] = {
                    "yaw_rpm": round(float(cmd.get("yaw_rpm") or 0.0), 3),
                    "pitch_rpm": round(float(cmd.get("pitch_rpm") or 0.0), 3),
                    "laser_enabled": cmd.get("laser_enabled"),
                    "auto_stop_ms": cmd.get("auto_stop_ms"),
                }
        elif tool.startswith("system."):
            item["system"] = {
                "cpu": result.get("cpu"),
                "memory": result.get("memory"),
                "npu": result.get("npu"),
                "max_temp_c": result.get("max_temp_c"),
            }
        return item, modalities

    def _maybe_auto_capture_memory(
        self,
        *,
        trace_ctx: TraceContext,
        status: int,
        ok: bool,
        body: dict[str, Any],
    ) -> None:
        route = _safe_text(trace_ctx.trace.get("route"), limit=120)
        if route not in ("/api/agent/command", "/api/agent/command_llm_first", "/api/agent/command_manual"):
            return
        if not self.memory_auto_capture_enabled:
            return
        if not bool(self.config.memory_enabled):
            return
        response_ok = bool(body.get("ok", ok))
        if not response_ok and not self.memory_auto_capture_on_failure:
            return
        query = _safe_text(body.get("query") or trace_ctx.trace.get("raw_input"), limit=600)
        if not query:
            return

        plan = body.get("plan") if isinstance(body.get("plan"), dict) else {}
        plan_actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
        plan_tools: list[str] = []
        for row in plan_actions:
            if not isinstance(row, dict):
                continue
            tool = _safe_text(row.get("tool"), limit=80)
            if tool:
                plan_tools.append(tool)
        if plan_tools and all(tool.startswith("memory.") for tool in plan_tools):
            TraceStore.step(trace_ctx, "memory.auto.capture", True, "skip memory-only plan")
            return

        action_results = body.get("action_results") if isinstance(body.get("action_results"), list) else []
        compact_results: list[dict[str, Any]] = []
        modalities: set[str] = {"text"}
        for row in action_results[:4]:
            if not isinstance(row, dict):
                continue
            tool = _safe_text(row.get("tool"), limit=80)
            result = row.get("result") if isinstance(row.get("result"), dict) else {}
            compact, mods = self._compact_tool_result_for_memory(
                tool=tool,
                action_ok=bool(row.get("ok", False)),
                result=result,
            )
            if compact:
                compact_results.append(compact)
            modalities.update(mods)

        executed = bool(body.get("executed", False))
        awaiting = bool(body.get("awaiting_confirmation", False))
        assistant_feedback = _safe_text(body.get("assistant_feedback"), limit=240)
        turn_mode = "executed" if executed else ("awaiting_confirmation" if awaiting else "planned")
        tool_tokens = plan_tools[:4] if plan_tools else []
        text_parts = [
            f"query={query}",
            f"mode={turn_mode}",
            f"ok={int(response_ok)}",
        ]
        if tool_tokens:
            text_parts.append("plan_tools=" + ",".join(tool_tokens))
        if assistant_feedback:
            text_parts.append(f"feedback={assistant_feedback}")
        memory_text = " | ".join(text_parts)
        trace_id = _safe_text(trace_ctx.trace.get("trace_id"), limit=32)
        meta: dict[str, Any] = {
            "kind": "auto_turn",
            "version": 1,
            "status_code": int(status),
            "query": query,
            "executed": executed,
            "awaiting_confirmation": awaiting,
            "ok": response_ok,
            "route": route,
            "trace_id": trace_id,
            "plan_tools": plan_tools[:8],
            "action_results": compact_results,
            "assistant_feedback": assistant_feedback,
            "modalities": sorted(modalities),
            "response_mode": _safe_text(body.get("response_mode"), limit=32),
            "captured_at": _ts_now(),
        }
        tags = ["auto", "turn", turn_mode, "ok" if response_ok else "failed"] + sorted(modalities)
        memory_result = self.memory_store.add(
            memory_text,
            tags=tags[:8],
            source="auto_capture",
            role="system",
            meta=meta,
        )
        TraceStore.step(
            trace_ctx,
            "memory.auto.capture",
            bool(memory_result.get("ok", False)),
            _safe_text(memory_result.get("summary") or memory_result.get("error"), limit=220),
        )

    def _response_with_trace(
        self,
        *,
        status: int,
        ok: bool,
        trace_ctx: TraceContext,
        body: dict[str, Any],
    ) -> tuple[int, dict[str, Any]]:
        output = dict(body)
        output["speech_output"] = self._build_speech_output(output)
        self._maybe_auto_capture_memory(
            trace_ctx=trace_ctx,
            status=status,
            ok=ok,
            body=output,
        )
        execution_trace = self.trace_store.finalize(trace_ctx, ok=ok)
        output["execution_trace"] = execution_trace
        return status, output

    @staticmethod
    def _extract_speech_reply_from_json_text(text: str) -> str:
        raw = str(text or "").strip()
        if not raw:
            return ""
        parsed: Any = None
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = None
            obj_text = AgentServiceApp._extract_first_json_object(raw)
            if obj_text:
                try:
                    parsed = json.loads(obj_text)
                except Exception:
                    parsed = None
        if isinstance(parsed, dict):
            for key in ("reply", "assistant_feedback", "text", "message"):
                value = _safe_text(parsed.get(key), limit=800)
                if value:
                    return value
        elif isinstance(parsed, str):
            return _safe_text(parsed, limit=800)
        return ""

    @classmethod
    def _to_speech_text(cls, text: str) -> str:
        raw = str(text or "").strip()
        if not raw:
            return ""
        reply = cls._extract_speech_reply_from_json_text(raw)
        if reply:
            raw = reply
        raw = re.sub(r"```[\s\S]*?```", " ", raw)
        raw = raw.replace("`", " ")
        raw = re.sub(r"<[^>]+>", " ", raw)
        raw = re.sub(r"\s+", " ", raw).strip()
        normalized = cls._normalize_feedback_text(raw)
        return _safe_text(normalized, limit=480)

    @classmethod
    def _build_speech_output(cls, body: dict[str, Any]) -> dict[str, Any]:
        source = "none"
        candidate = ""
        assistant_feedback = _safe_text(body.get("assistant_feedback"), limit=1200)
        if assistant_feedback:
            source = "assistant_feedback"
            candidate = assistant_feedback
        else:
            error_detail = _safe_text(body.get("error_detail"), limit=600)
            if error_detail:
                source = "error_detail"
                candidate = error_detail
            else:
                err = _safe_text(body.get("error"), limit=220)
                if err:
                    source = "error"
                    candidate = err
        speech_text = cls._to_speech_text(candidate)
        lang = "zh-CN" if _contains_cjk(speech_text) else "en-US"
        return {
            "ready": bool(speech_text),
            "text": speech_text,
            "lang": lang,
            "source": source,
            "format": "plain_text_v1",
        }

    @staticmethod
    def _is_gimbal_lock_tool(tool: str) -> bool:
        key = _safe_text(tool, limit=80).lower()
        return key in ("vision.gimbal.lock.status", "vision.gimbal.lock.start", "vision.gimbal.lock.stop")

    def _maybe_preempt_running_gimbal_lock(
        self,
        *,
        query: str,
        detector: str,
        allow_execute: bool,
        plan: dict[str, Any],
        actions: list[dict[str, Any]],
        max_actions: int,
        trace_ctx: TraceContext,
    ) -> tuple[dict[str, Any], list[dict[str, Any]], list[str]]:
        if not allow_execute or not actions:
            return plan, actions, []
        if any(self._is_gimbal_lock_tool(str(row.get("tool") or "")) for row in actions):
            return plan, actions, []
        if not any(bool(row.get("side_effect", False)) for row in actions):
            return plan, actions, []

        lock_status = self.vision_adapter.gimbal_lock_status()
        lock_active = bool(lock_status.get("active", False) or lock_status.get("thread_alive", False))
        if not lock_active:
            return plan, actions, []

        raw_actions: list[dict[str, Any]] = [
            {
                "tool": "vision.gimbal.lock.stop",
                "arguments": {"wait": False, "reason": "preempt-next-command"},
                "reason": "auto stop previous lock",
            }
        ]
        for row in actions:
            if not isinstance(row, dict):
                continue
            raw_actions.append(
                {
                    "tool": row.get("tool"),
                    "arguments": row.get("arguments") if isinstance(row.get("arguments"), dict) else {},
                    "reason": row.get("reason") or "intent-rule",
                    "group": row.get("group"),
                    "depends_on": row.get("depends_on"),
                }
            )

        rebuilt_plan, warnings = self.planner.build_plan_from_proposals(
            raw_actions,
            query=query,
            detector=detector,
            max_actions=max(1, min(8, max(int(max_actions), len(raw_actions)))),
            source=_safe_text(plan.get("source"), limit=32) or "intent_registry",
        )
        rebuilt_actions = rebuilt_plan.get("actions") if isinstance(rebuilt_plan.get("actions"), list) else []
        TraceStore.step(
            trace_ctx,
            name="plan.gimbal_lock.preempt",
            ok=True,
            detail=f"lock active -> prepend stop, actions={len(rebuilt_actions)}",
        )
        return rebuilt_plan, rebuilt_actions, warnings

    def handle_agent_chat_manual(
        self,
        payload: dict[str, Any],
        client_id: str,
    ) -> tuple[int, dict[str, Any]]:
        query = _safe_text(payload.get("query") or payload.get("message"), limit=600)
        if not query:
            return 400, {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "query (or message) is required",
            }

        dialogue_history = _normalize_dialogue_history(payload.get("dialogue_history"))
        chat_payload = dict(payload)
        _ = client_id
        if "llm_skip_rewrite" not in chat_payload:
            chat_payload["llm_skip_rewrite"] = True
        if "llm_timeout_sec" not in chat_payload:
            chat_payload["llm_timeout_sec"] = 10.0
        if "llm_keep_history" not in chat_payload:
            chat_payload["llm_keep_history"] = False
        if "llm_clear_history" not in chat_payload:
            chat_payload["llm_clear_history"] = True

        trace_ctx = self.trace_store.start(
            route="/api/agent/chat_manual",
            payload=chat_payload,
            raw_input=query,
        )
        TraceStore.step(
            trace_ctx,
            name="request.parse",
            ok=True,
            detail=f"mode=chat_manual, dialogue_turns={len(dialogue_history)}",
        )
        if dialogue_history:
            TraceStore.step(
                trace_ctx,
                name="context.dialogue_history",
                ok=True,
                detail=f"turns={len(dialogue_history)}",
            )

        chat_ok, chat_text, chat_meta = self._fallback_llm_chat(
            query=query,
            payload=chat_payload,
            dialogue_history=dialogue_history,
            allow_local_fallback=True,
            trace_ctx=trace_ctx,
        )
        chat_meta = chat_meta if isinstance(chat_meta, dict) else {}

        if chat_ok and chat_text:
            body = {
                "ok": True,
                "timestamp": _ts_now(),
                "query": query,
                "executed": False,
                "awaiting_confirmation": False,
                "response_mode": "chat_manual",
                "plan": {
                    "summary": _safe_text(query, limit=220),
                    "actions": [],
                    "source": "chat_manual",
                    "needs_clarification": False,
                    "clarification_question": "",
                    "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                    "needs_confirmation": False,
                },
                "assistant_feedback_source": "llm_chat",
                "assistant_feedback": chat_text,
                "llm_chat": {
                    "status": int(chat_meta.get("status") or 0),
                    "detail": _safe_text(chat_meta.get("detail"), limit=220),
                },
            }
            return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)

        detail = _safe_text(chat_meta.get("detail"), limit=220) or "chat fallback unavailable"
        body = {
            "ok": False,
            "timestamp": _ts_now(),
            "query": query,
            "executed": False,
            "awaiting_confirmation": False,
            "response_mode": "chat_manual_failed",
            "error": "chat_manual_failed",
            "error_detail": detail,
            "plan": {
                "summary": _safe_text(query, limit=220),
                "actions": [],
                "source": "chat_manual",
                "needs_clarification": False,
                "clarification_question": "",
                "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                "needs_confirmation": False,
            },
            "assistant_feedback_source": "policy",
            "assistant_feedback": detail,
            "llm_chat": {
                "status": int(chat_meta.get("status") or 0),
                "detail": detail,
            },
        }
        return self._response_with_trace(status=503, ok=False, trace_ctx=trace_ctx, body=body)

    @staticmethod
    def _route_only_sensor_prefill_plan(query: str) -> dict[str, Any] | None:
        text = str(query or "")
        if not text:
            return None
        low = text.lower()
        threshold_hint = any(token in text for token in ("阈值", "上限", "下限", "改成", "设置"))
        has_sensor_term = bool(
            ("传感器" in text)
            or ("水温" in text)
            or ("浊度" in text)
            or ("酸碱" in text)
            or ("pH" in text)
            or re.search(r"\bph\b", low)
            or (("温度" in text) and (("水" in text) or ("传感器" in text)))
        )
        if not has_sensor_term:
            return None
        # Prevent explicit actuator intents from being downgraded into a sensor query.
        if any(token in text for token in ("激光", "云台", "锁定", "跟踪", "点头", "右转", "左转")):
            return None
        if threshold_hint:
            threshold_args: dict[str, Any] = {}
            segments = [seg.strip() for seg in re.split(r"[，,；;。]", text) if seg.strip()]
            for seg in segments:
                seg_low = seg.lower()
                nums = [float(item) for item in re.findall(r"[0-9]+(?:\.[0-9]+)?", seg)]
                if not nums:
                    continue
                is_temp = ("温度" in seg) or ("水温" in seg)
                is_ph = ("pH" in seg) or ("PH" in seg) or ("ph" in seg_low) or ("酸碱度" in seg)
                is_turbidity = ("浊度" in seg) or ("turbidity" in seg_low) or ("ntu" in seg_low)
                if is_temp:
                    if "上限" in seg and nums:
                        threshold_args["temperature_max"] = nums[0]
                    elif "下限" in seg and nums:
                        threshold_args["temperature_min"] = nums[0]
                    elif len(nums) >= 2:
                        threshold_args["temperature_min"] = nums[0]
                        threshold_args["temperature_max"] = nums[1]
                if is_ph:
                    if "上限" in seg and nums:
                        threshold_args["ph_max"] = nums[0]
                    elif "下限" in seg and nums:
                        threshold_args["ph_min"] = nums[0]
                    elif len(nums) >= 2:
                        threshold_args["ph_min"] = nums[0]
                        threshold_args["ph_max"] = nums[1]
                if is_turbidity:
                    if "上限" in seg and nums:
                        threshold_args["turbidity_max"] = nums[0]
                    elif "下限" in seg and nums:
                        threshold_args["turbidity_min"] = nums[0]
                    elif len(nums) >= 2:
                        threshold_args["turbidity_min"] = nums[0]
                        threshold_args["turbidity_max"] = nums[1]

            if threshold_args:
                return {
                    "summary": _safe_text(query, limit=220),
                    "actions": [
                        {
                            "tool": "vision.sensors.thresholds.set",
                            "arguments": threshold_args,
                            "reason": "sensor threshold keyword override",
                            "side_effect": True,
                            "risk_level": "low",
                            "requires_confirmation": False,
                            "group": "sensor.config.1",
                            "depends_on": [],
                        }
                    ],
                    "source": "command_route_only_sensor_threshold_keyword",
                    "needs_clarification": False,
                    "clarification_question": "",
                    "confirm_policy": {"min_risk": "high"},
                    "needs_confirmation": False,
                }
        return {
            "summary": _safe_text(query, limit=220),
            "actions": [
                {
                    "tool": "vision.sensors.get",
                    "arguments": {},
                    "reason": "sensor keyword override",
                    "side_effect": False,
                    "risk_level": "low",
                    "requires_confirmation": False,
                    "group": "sensor.read.1",
                    "depends_on": [],
                }
            ],
            "source": "command_route_only_sensor_keyword",
            "needs_clarification": False,
            "clarification_question": "",
            "confirm_policy": {"min_risk": "high"},
            "needs_confirmation": False,
        }

    def handle_agent_command(
        self,
        payload: dict[str, Any],
        client_id: str,
        *,
        llm_first: bool = False,
        route_path_override: str = "",
    ) -> tuple[int, dict[str, Any]]:
        query = _safe_text(payload.get("query") or payload.get("message"), limit=600)
        confirm_token = _safe_text(payload.get("confirm_token"), limit=80)
        if not query and not confirm_token:
            return 400, {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "query (or message) is required unless confirm_token is provided",
            }

        allow_execute_flag = _coerce_enabled(payload.get("allow_execute"))
        allow_execute = bool(allow_execute_flag) if allow_execute_flag is not None else False
        force_llm_flag = _coerce_enabled(payload.get("force_llm"))
        force_llm = bool(force_llm_flag) if force_llm_flag is not None else False
        strict_llm_flag = _coerce_enabled(payload.get("strict_llm_mode"))
        strict_llm_mode = (
            bool(strict_llm_flag)
            if strict_llm_flag is not None
            else bool(self.config.llm_strict_mode)
        )

        detector, det_err = _normalize_detector(payload.get("detector", "none"), default="none")
        if detector is None:
            return 400, {"ok": False, "timestamp": _ts_now(), "error": det_err}

        max_actions = _clamp_int(
            payload.get("max_actions", self.config.command_max_actions),
            default=self.config.command_max_actions,
            min_value=1,
            max_value=8,
        )
        dialogue_history = _normalize_dialogue_history(payload.get("dialogue_history"))
        llm_session_id = _safe_text(payload.get("llm_session_id"), limit=64)
        if not llm_session_id:
            llm_session_id = _safe_text(payload.get("session_id"), limit=64)
        if not llm_session_id:
            fallback_client = re.sub(r"[^0-9A-Za-z._:-]", "", _safe_text(client_id, limit=48))
            if fallback_client:
                llm_session_id = _safe_text(f"agent-{fallback_client}", limit=64)
        llm_keep_history_flag = _coerce_enabled(payload.get("llm_keep_history"))
        llm_clear_history_flag = _coerce_enabled(payload.get("llm_clear_history"))
        llm_keep_history = (
            bool(llm_keep_history_flag)
            if llm_keep_history_flag is not None
            else bool(llm_session_id)
        )
        llm_clear_history = bool(llm_clear_history_flag) if llm_clear_history_flag is not None else False
        include_parse_warning = bool(payload.get("include_parse_warning", False))
        llm_gate_classify_only_flag = _coerce_enabled(payload.get("llm_gate_classify_only"))
        llm_gate_classify_only = (
            bool(llm_gate_classify_only_flag)
            if llm_gate_classify_only_flag is not None
            else False
        )
        feedback_with_llm_flag = _coerce_enabled(payload.get("feedback_with_llm"))
        force_vocab_sync_flag = _coerce_enabled(payload.get("force_vocab_sync"))
        force_vocab_sync = bool(force_vocab_sync_flag) if force_vocab_sync_flag is not None else False
        force_capability_sync_flag = _coerce_enabled(payload.get("force_capability_sync"))
        force_capability_sync = (
            bool(force_capability_sync_flag)
            if force_capability_sync_flag is not None
            else force_vocab_sync
        )

        route_path = route_path_override or ("/api/agent/command_llm_first" if llm_first else "/api/agent/command")
        # command_manual is an execute-oriented route; if caller omits allow_execute,
        # default to execute to avoid accidental preview-only responses.
        if allow_execute_flag is None and route_path == "/api/agent/command_manual":
            allow_execute = True
        command_route_only_flag = _coerce_enabled(payload.get("command_route_only"))
        command_route_only = (
            bool(command_route_only_flag)
            if command_route_only_flag is not None
            else (route_path == "/api/agent/command_manual")
        )
        command_llm_only_flag = _coerce_enabled(payload.get("command_llm_only"))
        command_llm_only = (
            bool(command_llm_only_flag)
            if command_llm_only_flag is not None
            else False
        )
        feedback_with_llm_default = bool(
            self.config.llm_exec_feedback_enabled and (not command_route_only)
        )
        if feedback_with_llm_flag is None:
            feedback_with_llm = feedback_with_llm_default
        else:
            feedback_with_llm = bool(
                self.config.llm_exec_feedback_enabled and bool(feedback_with_llm_flag)
            )
        trace_ctx = self.trace_store.start(
            route=route_path,
            payload=payload,
            raw_input=query or f"confirm:{confirm_token}",
        )
        TraceStore.step(
            trace_ctx,
            name="request.parse",
            ok=True,
            detail=(
                f"allow_execute={allow_execute}, force_llm={force_llm}, "
                f"llm_first={llm_first}, strict_llm_mode={int(strict_llm_mode)}, "
                f"llm_gate_classify_only={int(llm_gate_classify_only)}, "
                f"command_route_only={int(command_route_only)}, "
                f"command_llm_only={int(command_llm_only)}, "
                f"max_actions={max_actions}, feedback_with_llm={feedback_with_llm}, "
                f"force_vocab_sync={force_vocab_sync}, "
                f"force_capability_sync={force_capability_sync}, "
                f"confirm_token={'yes' if confirm_token else 'no'}"
            ),
        )
        if dialogue_history:
            TraceStore.step(
                trace_ctx,
                name="context.dialogue_history",
                ok=True,
                detail=f"turns={len(dialogue_history)}",
            )
        self._maybe_sync_camera_capabilities(trace_ctx=trace_ctx, force=force_capability_sync)
        self._maybe_sync_camera_alias_terms(trace_ctx=trace_ctx, force=force_vocab_sync)

        parse_warnings: list[str] = []
        llm_tool_plan_meta: dict[str, Any] | None = None
        llm_command_gate_meta: dict[str, Any] | None = None
        llm_semantic_cache_meta: dict[str, Any] | None = None
        llm_semantic_cache_candidate: dict[str, Any] | None = None
        llm_gate_wants_action: bool | None = None
        llm_non_action_reply = ""
        llm_plan_attempted = False
        llm_metrics_recorded = False
        llm_fast_chat_action_hint = bool(
            re.search(
                r"(时间|温度|内存|cpu|mem|memory|npu|状态|画面|摄像头|相机|观察|检测|执行|命令|"
                r"开启|关闭|锁定|跟随|云台|电机|追踪|"
                r"time|temp|status|camera|observe|detect|run|command|start|stop|track|gimbal|motor)",
                str(query or "").lower(),
                flags=re.IGNORECASE,
            )
        )
        llm_fast_chat_query = bool(
            query
            and self._is_fast_chat_cacheable_query(query)
            and (not llm_fast_chat_action_hint)
        )
        if command_route_only:
            llm_fast_chat_action_hint = False
            llm_fast_chat_query = False
        llm_skip_tool_plan_due_fast_chat = False
        route_only_plan_prefill: dict[str, Any] | None = None
        route_only_prefill_actions_count = 0
        correction_detected = bool(query and self._looks_like_user_correction(query))
        correction_pure = bool(query and self._looks_like_pure_user_correction(query))
        if correction_detected and query:
            TraceStore.step(
                trace_ctx,
                name="command.user_correction.detected",
                ok=True,
                detail=f"pure={int(correction_pure)}",
            )
            correction_result = self._capture_user_correction(query=query, trace_ctx=trace_ctx)
            if correction_pure and not confirm_token:
                body = {
                    "ok": True,
                    "timestamp": _ts_now(),
                    "query": query,
                    "executed": False,
                    "awaiting_confirmation": False,
                    "response_mode": "user_correction",
                    "correction_recorded": bool(correction_result.get("ok", False)),
                    "plan": {
                        "summary": _safe_text(query, limit=220),
                        "actions": [],
                        "source": "user_correction",
                        "needs_clarification": False,
                        "clarification_question": "",
                        "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                        "needs_confirmation": False,
                    },
                    "assistant_feedback_source": "policy",
                    "assistant_feedback": (
                        "已收到你的纠错反馈并写入记忆。后续我会优先按工具事实给结论，"
                        "不确定时会明确说明。"
                    ),
                }
                item = correction_result.get("item") if isinstance(correction_result.get("item"), dict) else {}
                if item:
                    body["correction_memory"] = {
                        "id": item.get("id"),
                        "timestamp": item.get("timestamp"),
                        "storage": correction_result.get("storage"),
                        "persistent": bool(correction_result.get("persistent", False)),
                    }
                return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)

        if command_route_only and query and (not confirm_token):
            sensor_prefill = self._route_only_sensor_prefill_plan(query)
            if isinstance(sensor_prefill, dict):
                route_only_plan_prefill = sensor_prefill
                route_only_prefill_actions_count = len(sensor_prefill.get("actions") or [])
                parse_warnings.append("command_route_only_precheck: sensor_keyword_override")
                TraceStore.step(
                    trace_ctx,
                    name="command.route_only.precheck.keyword_override",
                    ok=True,
                    detail=f"sensor_actions={route_only_prefill_actions_count}",
                )
            elif command_llm_only:
                llm_plan, llm_plan_warnings, llm_meta = self._fallback_llm_command_only_tool_plan(
                    query=query,
                    detector=detector,
                    max_actions=max_actions,
                    dialogue_history=dialogue_history,
                    llm_session_id=llm_session_id,
                    llm_keep_history=llm_keep_history,
                    llm_clear_history=llm_clear_history,
                    trace_ctx=trace_ctx,
                )
                parse_warnings.extend(llm_plan_warnings)
                llm_tool_plan_meta = llm_meta if isinstance(llm_meta, dict) else None
                llm_plan_attempted = True
                llm_non_action_reply = _safe_text((llm_meta or {}).get("reply"), limit=320)
                llm_actions = (
                    llm_plan.get("actions")
                    if isinstance(llm_plan, dict) and isinstance(llm_plan.get("actions"), list)
                    else []
                )
                if llm_actions:
                    route_only_plan_prefill = llm_plan
                    route_only_prefill_actions_count = len(llm_actions)
                    TraceStore.step(
                        trace_ctx,
                        name="command.route_only.precheck",
                        ok=True,
                        detail=f"llm_actions={route_only_prefill_actions_count}",
                    )
                else:
                    fallback_selected = False
                    fallback_from_semantic = False
                    fallback_non_action = False
                    fallback_proposals: list[dict[str, Any]] = []
                    semantic_actions, semantic_meta = self.semantic_intent_router.route(
                        query=query,
                        detector=detector,
                        max_actions=max_actions,
                    )
                    semantic_non_action = bool((semantic_meta or {}).get("ok", False)) and bool(
                        (semantic_meta or {}).get("non_action", False)
                    )
                    if semantic_non_action:
                        fallback_non_action = True
                        semantic_intent = _safe_text((semantic_meta or {}).get("intent"), limit=80)
                        semantic_score = float((semantic_meta or {}).get("score") or 0.0)
                        semantic_margin = float((semantic_meta or {}).get("margin") or 0.0)
                        parse_warnings.append(
                            "command_manual_llm: "
                            f"semantic_non_action={semantic_intent},score={semantic_score:.4f},"
                            f"margin={semantic_margin:.4f}"
                        )
                        TraceStore.step(
                            trace_ctx,
                            name="command.route_only.precheck.semantic_intent",
                            ok=True,
                            detail=(
                                f"intent={semantic_intent},score={semantic_score:.4f},"
                                f"margin={semantic_margin:.4f},non_action=1"
                            ),
                        )
                    elif semantic_actions:
                        fallback_proposals = list(semantic_actions)
                        fallback_from_semantic = True
                        semantic_intent = _safe_text((semantic_meta or {}).get("intent"), limit=80)
                        semantic_score = float((semantic_meta or {}).get("score") or 0.0)
                        semantic_margin = float((semantic_meta or {}).get("margin") or 0.0)
                        semantic_source = _safe_text((semantic_meta or {}).get("source"), limit=24) or "prototype"
                        parse_warnings.append(
                            "command_manual_llm: "
                            f"semantic_intent={semantic_intent},score={semantic_score:.4f},"
                            f"margin={semantic_margin:.4f},source={semantic_source}"
                        )
                        TraceStore.step(
                            trace_ctx,
                            name="command.route_only.precheck.semantic_intent",
                            ok=True,
                            detail=(
                                f"intent={semantic_intent},score={semantic_score:.4f},"
                                f"margin={semantic_margin:.4f},source={semantic_source},actions={len(fallback_proposals)}"
                            ),
                        )
                    else:
                        semantic_detail = _safe_text((semantic_meta or {}).get("detail"), limit=120)
                        if semantic_detail:
                            parse_warnings.append(f"command_manual_llm: semantic_miss={semantic_detail}")
                        if not self.config.command_embed_model_only:
                            fallback_actions, fallback_warnings = self.planner.intent_registry.plan(
                                query=query,
                                detector=detector,
                                max_actions=max_actions,
                            )
                            if fallback_warnings:
                                parse_warnings.extend(fallback_warnings)
                            fallback_proposals = list(fallback_actions or [])
                    low_query = str(query or "").lower()
                    if (
                        (not self.config.command_embed_model_only)
                        and (not fallback_non_action)
                        and (not fallback_proposals)
                        and re.search(
                        r"(原图|原始画面|原始图|原始帧|raw(?:\\s*frame)?|no\\s*detect|不检测|仅画面)",
                        low_query,
                        flags=re.IGNORECASE,
                        )
                    ):
                        fallback_proposals = [
                            {
                                "tool": "vision.observe",
                                "arguments": {"detector": "none"},
                                "reason": "raw frame request fallback",
                            }
                        ]
                        parse_warnings.append("command_manual_llm: fallback_to_raw_frame_observe")
                    if fallback_proposals:
                        fallback_plan, fallback_plan_warnings = self.planner.build_plan_from_proposals(
                            fallback_proposals,
                            query=query,
                            detector=detector,
                            max_actions=max_actions,
                            source="command_route_only_llm_fallback",
                        )
                        if fallback_plan_warnings:
                            parse_warnings.extend(fallback_plan_warnings)
                        fallback_plan_actions = (
                            fallback_plan.get("actions")
                            if isinstance(fallback_plan, dict) and isinstance(fallback_plan.get("actions"), list)
                            else []
                        )
                        if fallback_plan_actions:
                            route_only_plan_prefill = fallback_plan
                            route_only_prefill_actions_count = len(fallback_plan_actions)
                            TraceStore.step(
                                trace_ctx,
                                name="command.route_only.precheck",
                                ok=True,
                                detail=f"llm_actions=0,fallback_actions={route_only_prefill_actions_count}",
                            )
                            if isinstance(llm_tool_plan_meta, dict):
                                llm_tool_plan_meta["fallback_actions"] = int(route_only_prefill_actions_count)
                                llm_tool_plan_meta["fallback_semantic_used"] = bool(fallback_from_semantic)
                                llm_tool_plan_meta["fallback_rule_used"] = bool(not fallback_from_semantic)
                            fallback_selected = True
                    if not fallback_selected:
                        llm_ok = bool((llm_meta or {}).get("ok", False))
                        llm_non_action = bool((llm_meta or {}).get("non_action", False))
                        no_action_detail = (
                            "semantic non-action intent in command-only route"
                            if fallback_non_action
                            else (
                                _safe_text((llm_meta or {}).get("detail"), limit=180)
                                or (
                                    "llm command parser produced non-action"
                                    if llm_non_action
                                    else "llm command parser returned no executable actions"
                                )
                            )
                        )
                        no_action_feedback = (
                            (
                                "这是聊天类问题。此接口仅用于命令执行；"
                                "请改用 /api/agent/chat_manual。"
                            )
                            if fallback_non_action
                            else (
                                llm_non_action_reply
                                or "未识别到可执行命令。请直接描述你要执行的设备操作。"
                            )
                        )
                        TraceStore.step(
                            trace_ctx,
                            name="command.route_only.precheck",
                            ok=False,
                            detail=no_action_detail,
                        )
                        body = {
                            "ok": False,
                            "timestamp": _ts_now(),
                            "query": query,
                            "executed": False,
                            "awaiting_confirmation": False,
                            "response_mode": "command_no_action",
                            "error": "command_no_action",
                            "error_detail": no_action_detail,
                            "plan": {
                                "summary": _safe_text(query, limit=220),
                                "actions": [],
                                "source": "llm_command_manual",
                                "needs_clarification": False,
                                "clarification_question": "",
                                "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                                "needs_confirmation": False,
                            },
                            "assistant_feedback_source": "policy",
                            "assistant_feedback": no_action_feedback,
                        }
                        if llm_tool_plan_meta is not None:
                            body["llm_tool_plan"] = llm_tool_plan_meta
                        if parse_warnings and include_parse_warning:
                            body["parse_warning"] = "; ".join(parse_warnings)[:320]
                        status_code = 422 if (llm_ok or fallback_non_action) else 503
                        return self._response_with_trace(
                            status=status_code,
                            ok=False,
                            trace_ctx=trace_ctx,
                            body=body,
                        )
            else:
                pre_actions: list[dict[str, Any]] = []
                semantic_actions, semantic_meta = self.semantic_intent_router.route(
                    query=query,
                    detector=detector,
                    max_actions=max_actions,
                )
                semantic_non_action = bool((semantic_meta or {}).get("ok", False)) and bool(
                    (semantic_meta or {}).get("non_action", False)
                )
                if semantic_actions:
                    pre_actions = semantic_actions
                    semantic_intent = _safe_text((semantic_meta or {}).get("intent"), limit=80)
                    semantic_score = float((semantic_meta or {}).get("score") or 0.0)
                    semantic_margin = float((semantic_meta or {}).get("margin") or 0.0)
                    semantic_source = _safe_text((semantic_meta or {}).get("source"), limit=24) or "prototype"
                    parse_warnings.append(
                        "command_route_only_precheck: "
                        f"semantic_intent={semantic_intent},score={semantic_score:.4f},"
                        f"margin={semantic_margin:.4f},source={semantic_source}"
                    )
                    TraceStore.step(
                        trace_ctx,
                        name="command.route_only.precheck.semantic_intent",
                        ok=True,
                        detail=(
                            f"intent={semantic_intent},score={semantic_score:.4f},"
                            f"margin={semantic_margin:.4f},source={semantic_source},actions={len(pre_actions)}"
                        ),
                    )
                elif semantic_non_action:
                    semantic_intent = _safe_text((semantic_meta or {}).get("intent"), limit=80)
                    semantic_score = float((semantic_meta or {}).get("score") or 0.0)
                    semantic_margin = float((semantic_meta or {}).get("margin") or 0.0)
                    semantic_source = _safe_text((semantic_meta or {}).get("source"), limit=24) or "prototype"
                    no_action_detail = "semantic non-action intent in command-only route"
                    no_action_feedback = (
                        "这是聊天类问题。此接口仅用于命令执行；"
                        "请改用 /api/agent/chat_manual。"
                    )
                    parse_warnings.append(
                        "command_route_only_precheck: "
                        f"semantic_non_action={semantic_intent},score={semantic_score:.4f},"
                        f"margin={semantic_margin:.4f},source={semantic_source}"
                    )
                    TraceStore.step(
                        trace_ctx,
                        name="command.route_only.precheck.semantic_intent",
                        ok=True,
                        detail=(
                            f"intent={semantic_intent},score={semantic_score:.4f},"
                            f"margin={semantic_margin:.4f},source={semantic_source},non_action=1"
                        ),
                    )
                    TraceStore.step(
                        trace_ctx,
                        name="command.route_only.precheck",
                        ok=False,
                        detail=no_action_detail,
                    )
                    body = {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "query": query,
                        "executed": False,
                        "awaiting_confirmation": False,
                        "response_mode": "command_no_action",
                        "error": "command_no_action",
                        "error_detail": no_action_detail,
                        "plan": {
                            "summary": _safe_text(query, limit=220),
                            "actions": [],
                            "source": "command_route_only_precheck",
                            "needs_clarification": False,
                            "clarification_question": "",
                            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                            "needs_confirmation": False,
                        },
                        "assistant_feedback_source": "policy",
                        "assistant_feedback": no_action_feedback,
                    }
                    if parse_warnings and include_parse_warning:
                        body["parse_warning"] = "; ".join(parse_warnings)[:320]
                    return self._response_with_trace(status=422, ok=False, trace_ctx=trace_ctx, body=body)
                else:
                    semantic_detail = _safe_text((semantic_meta or {}).get("detail"), limit=120)
                    if semantic_detail:
                        parse_warnings.append(
                            f"command_route_only_precheck: semantic_miss={semantic_detail}"
                        )

                if (not pre_actions) and (not self.config.command_embed_model_only):
                    pre_actions, pre_warnings = self.planner.intent_registry.plan(
                        query=query,
                        detector=detector,
                        max_actions=max_actions,
                    )
                    if pre_warnings:
                        parse_warnings.extend(pre_warnings)
                if (not pre_actions) and (not self.config.command_embed_model_only):
                    low_query = str(query or "").lower()
                    if re.search(
                        r"(原图|原始画面|原始图|原始帧|raw(?:\\s*frame)?|no\\s*detect|不检测|仅画面)",
                        low_query,
                        flags=re.IGNORECASE,
                    ):
                        pre_actions = [
                            {
                                "tool": "vision.observe",
                                "arguments": {"detector": "none"},
                                "reason": "raw frame request fallback",
                            }
                        ]
                        parse_warnings.append("command_route_only_precheck: fallback_to_raw_frame_observe")
                if not pre_actions:
                    no_action_detail = "no executable command intent"
                    no_action_feedback = (
                        "未识别到可执行命令。此接口仅用于命令执行；"
                        "聊天请改用 /api/agent/chat_manual。"
                    )
                    TraceStore.step(
                        trace_ctx,
                        name="command.route_only.precheck",
                        ok=False,
                        detail=no_action_detail,
                    )
                    body = {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "query": query,
                        "executed": False,
                        "awaiting_confirmation": False,
                        "response_mode": "command_no_action",
                        "error": "command_no_action",
                        "error_detail": no_action_detail,
                        "plan": {
                            "summary": _safe_text(query, limit=220),
                            "actions": [],
                            "source": "command_route_only_precheck",
                            "needs_clarification": False,
                            "clarification_question": "",
                            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                            "needs_confirmation": False,
                        },
                        "assistant_feedback_source": "policy",
                        "assistant_feedback": no_action_feedback,
                    }
                    if parse_warnings and include_parse_warning:
                        body["parse_warning"] = "; ".join(parse_warnings)[:320]
                    return self._response_with_trace(status=422, ok=False, trace_ctx=trace_ctx, body=body)
                route_only_plan_prefill, pre_plan_warnings = self.planner.build_plan_from_proposals(
                    pre_actions,
                    query=query,
                    detector=detector,
                    max_actions=max_actions,
                    source="command_route_only_precheck",
                )
                if pre_plan_warnings:
                    parse_warnings.extend(pre_plan_warnings)
                route_only_prefill_actions_count = (
                    len(route_only_plan_prefill.get("actions") or [])
                    if isinstance(route_only_plan_prefill, dict)
                    else 0
                )
                if route_only_prefill_actions_count <= 0:
                    no_action_detail = "no executable command actions after normalize"
                    no_action_feedback = (
                        "未识别到可执行命令。此接口仅用于命令执行；"
                        "聊天请改用 /api/agent/chat_manual。"
                    )
                    TraceStore.step(
                        trace_ctx,
                        name="command.route_only.precheck",
                        ok=False,
                        detail=no_action_detail,
                    )
                    body = {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "query": query,
                        "executed": False,
                        "awaiting_confirmation": False,
                        "response_mode": "command_no_action",
                        "error": "command_no_action",
                        "error_detail": no_action_detail,
                        "plan": {
                            "summary": _safe_text(query, limit=220),
                            "actions": [],
                            "source": "command_route_only_precheck",
                            "needs_clarification": False,
                            "clarification_question": "",
                            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                            "needs_confirmation": False,
                        },
                        "assistant_feedback_source": "policy",
                        "assistant_feedback": no_action_feedback,
                    }
                    if parse_warnings and include_parse_warning:
                        body["parse_warning"] = "; ".join(parse_warnings)[:320]
                    return self._response_with_trace(status=422, ok=False, trace_ctx=trace_ctx, body=body)
                TraceStore.step(
                    trace_ctx,
                    name="command.route_only.precheck",
                    ok=True,
                    detail=f"actions={route_only_prefill_actions_count}",
                )

        if confirm_token:
            pending, pending_err = self.confirm_store.take(
                token=confirm_token,
                client_id=client_id,
                consume=allow_execute,
            )
            TraceStore.step(
                trace_ctx,
                name="command.confirm.lookup",
                ok=pending is not None,
                detail=pending_err or "confirm token accepted",
            )
            if pending is None:
                return self._response_with_trace(
                    status=404,
                    ok=False,
                    trace_ctx=trace_ctx,
                    body={
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": pending_err,
                        "awaiting_confirmation": False,
                    },
                )

            pending_plan = pending.get("plan") if isinstance(pending.get("plan"), dict) else {}
            pending_query = _safe_text(pending.get("query"), limit=600)
            rebuilt_plan, rebuilt_warn = self.planner.rebuild_plan(
                pending_plan,
                query=pending_query or query,
                detector=detector,
                max_actions=max_actions,
            )
            parse_warnings.extend(rebuilt_warn)
            if not allow_execute:
                pending_count = sum(
                    1 for row in rebuilt_plan.get("actions", []) if row.get("requires_confirmation")
                )
                assistant_feedback = self.feedback.compose_pending(pending_count)
                feedback_source = "template"
                feedback_meta: dict[str, Any] | None = None
                if (pending_query or query) and feedback_with_llm:
                    feedback_memory_context = self._build_feedback_memory_context(
                        query=pending_query or query,
                        trace_ctx=trace_ctx,
                    )
                    polish_ok, polished_text, polish_meta = self._polish_general_feedback(
                        query=pending_query or query,
                        base_feedback=assistant_feedback,
                        context="confirm_preview",
                        trace_ctx=trace_ctx,
                        memory_context=feedback_memory_context,
                    )
                    feedback_meta = {
                        "ok": bool(polish_ok),
                        "status": int(polish_meta.get("status") or 0),
                        "detail": _safe_text(polish_meta.get("detail"), limit=220),
                        "style_id": int(polish_meta.get("style_id") or 0),
                        "source": _safe_text(polish_meta.get("source"), limit=24) or "template",
                        "memory_hits": int(feedback_memory_context.get("hits") or 0),
                        "memory_correction_hits": int(feedback_memory_context.get("correction_hits") or 0),
                        "memory_correction_recent_count": int(
                            feedback_memory_context.get("correction_recent_count") or 0
                        ),
                        "upstream": self.config.llm_api_base,
                    }
                    if polish_ok and polished_text:
                        assistant_feedback = polished_text
                        feedback_source = "llm_polish"
                body = {
                    "ok": True,
                    "timestamp": _ts_now(),
                    "query": pending_query or query,
                    "executed": False,
                    "awaiting_confirmation": True,
                    "confirm_token": confirm_token,
                    "confirm_expires_at": pending.get("expires_at"),
                    "plan": rebuilt_plan,
                    "assistant_feedback_source": feedback_source,
                    "assistant_feedback": assistant_feedback,
                }
                if feedback_meta is not None:
                    body["assistant_feedback_meta"] = feedback_meta
                return self._response_with_trace(
                    status=200,
                    ok=True,
                    trace_ctx=trace_ctx,
                    body=body,
                )
            if not query:
                query = pending_query
            plan = rebuilt_plan
            TraceStore.step(trace_ctx, name="command.confirm.consume", ok=True, detail=f"token={confirm_token}")
        else:
            llm_plan_selected = False
            if command_route_only and isinstance(route_only_plan_prefill, dict):
                plan = route_only_plan_prefill
                llm_plan_selected = True
                llm_plan_attempted = True
                if not isinstance(llm_tool_plan_meta, dict):
                    llm_tool_plan_meta = {
                        "ok": True,
                        "status": 200,
                        "detail": f"command_route_only_precheck actions={route_only_prefill_actions_count}",
                        "upstream": self.config.llm_api_base,
                        "planned_actions": int(route_only_prefill_actions_count),
                        "non_action": False,
                        "mode": "action",
                        "reply": "",
                        "latency_ms": 0.0,
                        "timeout_sec": 0.0,
                        "max_tokens": 0,
                        "candidate_tools": int(route_only_prefill_actions_count),
                        "parse_fail": False,
                        "repair_attempted": False,
                        "repair_success": False,
                        "cache_hit": False,
                    }
                TraceStore.step(
                    trace_ctx,
                    name="plan.command.route_only.precheck",
                    ok=True,
                    detail=f"actions={route_only_prefill_actions_count}",
                )
            if llm_first and query:
                llm_semantic_cache_meta = {"hit": False}
                if (not strict_llm_mode) and llm_fast_chat_query:
                    cached_chat_reply = self._fast_chat_cache_get(query)
                    if cached_chat_reply:
                        TraceStore.step(
                            trace_ctx,
                            name="plan.llm_fast_chat_cache",
                            ok=True,
                            detail="query cache hit",
                        )
                        plan = {
                            "summary": _safe_text(query, limit=220),
                            "actions": [],
                            "source": "llm_fast_chat_cache",
                            "needs_clarification": False,
                            "clarification_question": "",
                            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                            "needs_confirmation": False,
                        }
                        body = {
                            "ok": True,
                            "timestamp": _ts_now(),
                            "query": query,
                            "executed": False,
                            "awaiting_confirmation": False,
                            "response_mode": "llm_fast_chat_cache",
                            "plan": plan,
                            "assistant_feedback_source": "llm_fast_chat_cache",
                            "assistant_feedback": cached_chat_reply,
                        }
                        if llm_semantic_cache_meta is not None:
                            body["llm_semantic_cache"] = llm_semantic_cache_meta
                        if parse_warnings and include_parse_warning:
                            body["parse_warning"] = "; ".join(parse_warnings)[:320]
                        return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)
                cached_plan, cached_meta = None, None
                if not strict_llm_mode:
                    cached_plan, cached_meta = self._semantic_plan_cache_get(
                        query=query,
                        detector=detector,
                        max_actions=max_actions,
                        strict_llm_mode=strict_llm_mode,
                        dialogue_history=dialogue_history,
                    )
                if cached_plan is not None and isinstance(cached_plan.get("actions"), list):
                    cached_mode = _safe_text((cached_meta or {}).get("mode"), limit=16).lower()
                    cached_actions_raw = cached_plan.get("actions") if isinstance(cached_plan.get("actions"), list) else []
                    if cached_mode not in ("action", "chat"):
                        cached_mode = "action" if cached_actions_raw else "chat"
                    if cached_mode == "action" and cached_actions_raw:
                        rebuilt_cached_plan, cached_warnings = self.planner.rebuild_plan(
                            cached_plan,
                            query=query,
                            detector=detector,
                            max_actions=max_actions,
                        )
                        parse_warnings.extend(cached_warnings)
                        plan = rebuilt_cached_plan
                    else:
                        plan = {
                            "summary": _safe_text(query, limit=220),
                            "actions": [],
                            "source": "llm_semantic_cache",
                            "needs_clarification": False,
                            "clarification_question": "",
                            "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                            "needs_confirmation": False,
                        }
                    llm_plan_selected = True
                    llm_plan_attempted = True
                    cached_actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
                    llm_gate_wants_action = bool(cached_mode == "action")
                    llm_non_action_reply = _safe_text((cached_meta or {}).get("reply"), limit=320)
                    llm_semantic_cache_meta = {
                        "hit": True,
                        "age_ms": float((cached_meta or {}).get("cache_age_ms") or 0.0),
                        "ttl_sec": float((cached_meta or {}).get("cache_ttl_sec") or 0.0),
                        "key": _safe_text((cached_meta or {}).get("cache_key"), limit=24),
                        "mode": cached_mode,
                        "planned_actions": len(cached_actions),
                    }
                    llm_tool_plan_meta = {
                        "ok": True,
                        "status": int((cached_meta or {}).get("status") or 200),
                        "detail": (
                            f"semantic_cache_hit, mode={cached_mode}, "
                            f"actions={len(cached_actions)}, age_ms={int(float((cached_meta or {}).get('cache_age_ms') or 0.0))}"
                        ),
                        "upstream": self.config.llm_api_base,
                        "planned_actions": len(cached_actions),
                        "non_action": bool(cached_mode == "chat"),
                        "mode": cached_mode,
                        "reply": llm_non_action_reply,
                        "latency_ms": 0.0,
                        "timeout_sec": 0.0,
                        "max_tokens": 0,
                        "candidate_tools": 0,
                        "parse_fail": False,
                        "repair_attempted": False,
                        "repair_success": False,
                        "cache_hit": True,
                    }
                    TraceStore.step(
                        trace_ctx,
                        name="plan.llm_semantic_cache",
                        ok=True,
                        detail=(
                            f"mode={cached_mode}, actions={len(cached_actions)}, "
                            f"age_ms={int(float((cached_meta or {}).get('cache_age_ms') or 0.0))}"
                        ),
                    )
                    self._record_llm_planner_metrics(
                        pure_llm_hit=True,
                        latency_ms=0.0,
                    )
                    llm_metrics_recorded = True
                fast_chat_route_flag = _coerce_enabled(payload.get("llm_fast_chat_route"))
                command_gate_attempted = False
                use_command_gate = bool(
                    (not llm_plan_selected)
                    and (not command_route_only)
                    and (
                        strict_llm_mode
                        or (
                            self.config.llm_fast_chat_route_enabled
                            and (fast_chat_route_flag is not False)
                        )
                    )
                )
                if use_command_gate:
                    command_gate_attempted = True
                    llm_gate_wants_action, gate_meta = self._fallback_llm_command_gate(
                        query=query,
                        detector=detector,
                        dialogue_history=dialogue_history,
                        trace_ctx=trace_ctx,
                    )
                    llm_command_gate_meta = {
                        "ok": bool(gate_meta.get("ok", False)),
                        "status": int(gate_meta.get("status") or 0),
                        "detail": _safe_text(gate_meta.get("detail"), limit=180),
                        "raw_preview": _safe_text(gate_meta.get("raw_preview"), limit=200),
                        "mode": _safe_text(gate_meta.get("mode"), limit=16),
                        "upstream": self.config.llm_api_base,
                        "latency_ms": gate_meta.get("latency_ms"),
                        "timeout_sec": gate_meta.get("timeout_sec"),
                        "max_tokens": gate_meta.get("max_tokens"),
                        "candidate_tools": gate_meta.get("candidate_tools"),
                    }
                    gate_plan = gate_meta.get("plan") if isinstance(gate_meta.get("plan"), dict) else None
                    gate_plan_actions = (
                        gate_plan.get("actions")
                        if isinstance(gate_plan, dict) and isinstance(gate_plan.get("actions"), list)
                        else []
                    )
                    gate_plan_warnings = (
                        gate_meta.get("plan_warnings")
                        if isinstance(gate_meta.get("plan_warnings"), list)
                        else []
                    )
                    parse_warnings.extend(
                        [_safe_text(v, limit=160) for v in gate_plan_warnings if _safe_text(v, limit=160)]
                    )
                    llm_command_gate_meta["planned_actions"] = len(gate_plan_actions)
                    if llm_gate_wants_action is True and gate_plan_actions:
                        plan = gate_plan
                        llm_plan_selected = True
                        llm_plan_attempted = True
                        if not strict_llm_mode:
                            llm_tool_plan_meta = {
                                "ok": True,
                                "status": int(gate_meta.get("status") or 0),
                                "detail": _safe_text(gate_meta.get("detail"), limit=180) or "single_call_cm via llm.command_gate",
                                "upstream": self.config.llm_api_base,
                                "planned_actions": len(gate_plan_actions),
                                "non_action": False,
                                "mode": "action",
                                "reply": "",
                                "latency_ms": gate_meta.get("latency_ms"),
                                "parse_fail": False,
                                "repair_attempted": False,
                                "repair_success": False,
                            }
                        TraceStore.step(
                            trace_ctx,
                            name="plan.llm_command_gate",
                            ok=True,
                            detail=f"actions={len(gate_plan_actions)}",
                        )
                        self._record_llm_planner_metrics(
                            pure_llm_hit=True,
                            latency_ms=gate_meta.get("latency_ms"),
                        )
                        llm_metrics_recorded = True
                    if llm_gate_wants_action is True and (not gate_plan_actions) and llm_gate_classify_only:
                        bridge_plan, bridge_warn = self.planner.build_plan(
                            query=query,
                            detector=detector,
                            max_actions=max_actions,
                            force_llm=force_llm,
                        )
                        bridge_actions = (
                            bridge_plan.get("actions")
                            if isinstance(bridge_plan, dict) and isinstance(bridge_plan.get("actions"), list)
                            else []
                        )
                        parse_warnings.extend(bridge_warn)
                        if bridge_actions:
                            bridge_plan = dict(bridge_plan)
                            bridge_plan["source"] = "llm_gate_intent_bridge"
                            plan = bridge_plan
                            llm_plan_selected = True
                            llm_plan_attempted = True
                            TraceStore.step(
                                trace_ctx,
                                name="plan.llm_command_gate.intent_bridge",
                                ok=True,
                                detail=f"actions={len(bridge_actions)}",
                            )
                            self._record_llm_planner_metrics(
                                pure_llm_hit=True,
                                fallback_used=True,
                                latency_ms=gate_meta.get("latency_ms"),
                            )
                            llm_metrics_recorded = True
                        else:
                            low_query = str(query or "").lower()
                            if re.search(
                                r"(原图|原始画面|原始帧|raw(?:\\s*frame)?|no\\s*detect|不检测|仅画面)",
                                low_query,
                                flags=re.IGNORECASE,
                            ):
                                raw_plan, raw_warn = self.planner.build_plan_from_proposals(
                                    [
                                        {
                                            "tool": "vision.observe",
                                            "arguments": {"detector": "none"},
                                            "reason": "raw frame request",
                                        }
                                    ],
                                    query=query,
                                    detector=detector,
                                    max_actions=max_actions,
                                    source="llm_gate_intent_bridge",
                                )
                                raw_actions = (
                                    raw_plan.get("actions")
                                    if isinstance(raw_plan, dict) and isinstance(raw_plan.get("actions"), list)
                                    else []
                                )
                                parse_warnings.extend(raw_warn)
                                if raw_actions:
                                    plan = raw_plan
                                    llm_plan_selected = True
                                    llm_plan_attempted = True
                                    TraceStore.step(
                                        trace_ctx,
                                        name="plan.llm_command_gate.intent_bridge.raw_frame",
                                        ok=True,
                                        detail=f"actions={len(raw_actions)}",
                                    )
                                    self._record_llm_planner_metrics(
                                        pure_llm_hit=True,
                                        fallback_used=True,
                                        latency_ms=gate_meta.get("latency_ms"),
                                    )
                                    llm_metrics_recorded = True
                                else:
                                    parse_warnings.append(
                                        "llm_command_gate: classify-only need_action=1 but no intent actions"
                                    )
                            else:
                                parse_warnings.append(
                                    "llm_command_gate: classify-only need_action=1 but no intent actions"
                                )
                    if llm_gate_wants_action is False and llm_gate_classify_only and (not llm_plan_selected):
                        bridge_plan, bridge_warn = self.planner.build_plan(
                            query=query,
                            detector=detector,
                            max_actions=max_actions,
                            force_llm=force_llm,
                        )
                        bridge_actions = (
                            bridge_plan.get("actions")
                            if isinstance(bridge_plan, dict) and isinstance(bridge_plan.get("actions"), list)
                            else []
                        )
                        parse_warnings.extend(bridge_warn)
                        if bridge_actions:
                            bridge_plan = dict(bridge_plan)
                            bridge_plan["source"] = "llm_gate_intent_bridge"
                            plan = bridge_plan
                            llm_plan_selected = True
                            llm_plan_attempted = True
                            TraceStore.step(
                                trace_ctx,
                                name="plan.llm_command_gate.intent_bridge.override_chat",
                                ok=True,
                                detail=f"actions={len(bridge_actions)}",
                            )
                            self._record_llm_planner_metrics(
                                pure_llm_hit=True,
                                fallback_used=True,
                                latency_ms=gate_meta.get("latency_ms"),
                            )
                            llm_metrics_recorded = True
                    if llm_gate_wants_action is None:
                        cached_reply = self._fast_chat_cache_get(query)
                        if cached_reply:
                            plan = {
                                "summary": _safe_text(query, limit=220),
                                "actions": [],
                                "source": "llm_command_gate_cache",
                                "needs_clarification": False,
                                "clarification_question": "",
                                "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                                "needs_confirmation": False,
                            }
                            body = {
                                "ok": True,
                                "timestamp": _ts_now(),
                                "query": query,
                                "executed": False,
                                "awaiting_confirmation": False,
                                "response_mode": "llm_fast_chat_cache",
                                "plan": plan,
                                "assistant_feedback_source": "llm_command_gate_cache",
                                "assistant_feedback": cached_reply,
                            }
                            if llm_command_gate_meta is not None:
                                body["llm_command_gate"] = llm_command_gate_meta
                            if llm_semantic_cache_meta is not None:
                                body["llm_semantic_cache"] = llm_semantic_cache_meta
                            if parse_warnings and include_parse_warning:
                                body["parse_warning"] = "; ".join(parse_warnings)[:320]
                            return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)
                        llm_skip_tool_plan_due_fast_chat = True
                        parse_warnings.append("llm_command_gate: undecided -> skip tool_plan")
                    if (llm_gate_wants_action is False) and (not llm_plan_selected):
                        fast_chat_reply = self._normalize_feedback_text(
                            _safe_text((gate_meta or {}).get("reply"), limit=120)
                        )
                        if not fast_chat_reply:
                            cached_reply = self._fast_chat_cache_get(query)
                            if cached_reply:
                                fast_chat_reply = cached_reply
                            else:
                                llm_skip_tool_plan_due_fast_chat = True
                                parse_warnings.append("llm_command_gate: empty chat reply -> skip tool_plan")
                        if fast_chat_reply:
                            self._fast_chat_cache_put(query, fast_chat_reply)
                            plan = {
                                "summary": _safe_text(query, limit=220),
                                "actions": [],
                                "source": "llm_command_gate",
                                "needs_clarification": False,
                                "clarification_question": "",
                                "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                                "needs_confirmation": False,
                            }
                            body = {
                                "ok": True,
                                "timestamp": _ts_now(),
                                "query": query,
                                "executed": False,
                                "awaiting_confirmation": False,
                                "response_mode": "llm_fast_chat",
                                "plan": plan,
                                "assistant_feedback_source": "llm_command_gate",
                                "assistant_feedback": fast_chat_reply,
                            }
                            if llm_command_gate_meta is not None:
                                body["llm_command_gate"] = llm_command_gate_meta
                            if llm_semantic_cache_meta is not None:
                                body["llm_semantic_cache"] = llm_semantic_cache_meta
                            if parse_warnings and include_parse_warning:
                                body["parse_warning"] = "; ".join(parse_warnings)[:320]
                            return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)
                if (
                    strict_llm_mode
                    and command_gate_attempted
                    and (not llm_plan_selected)
                    and (not llm_skip_tool_plan_due_fast_chat)
                ):
                    llm_skip_tool_plan_due_fast_chat = True
                    parse_warnings.append("llm_command_gate: strict mode -> skip tool_plan")
                if llm_skip_tool_plan_due_fast_chat and (llm_tool_plan_meta is None):
                    if not (strict_llm_mode and command_gate_attempted):
                        gate_mode = _safe_text((llm_command_gate_meta or {}).get("mode"), limit=16).lower()
                        llm_tool_plan_meta = {
                            "ok": False,
                            "status": int((llm_command_gate_meta or {}).get("status") or 0),
                            "detail": (
                                _safe_text((llm_command_gate_meta or {}).get("detail"), limit=180)
                                or "llm command gate unavailable"
                            ),
                            "upstream": self.config.llm_api_base,
                            "planned_actions": 0,
                            "non_action": bool(gate_mode == "chat"),
                            "mode": gate_mode or "chat",
                            "reply": "",
                            "latency_ms": (llm_command_gate_meta or {}).get("latency_ms"),
                            "timeout_sec": float((llm_command_gate_meta or {}).get("timeout_sec") or 0.0),
                            "max_tokens": int((llm_command_gate_meta or {}).get("max_tokens") or 0),
                            "candidate_tools": int((llm_command_gate_meta or {}).get("candidate_tools") or 0),
                            "parse_fail": False,
                            "repair_attempted": False,
                            "repair_success": False,
                        }
                if (not llm_plan_selected) and llm_skip_tool_plan_due_fast_chat:
                    llm_plan_attempted = True
                    TraceStore.step(
                        trace_ctx,
                        name=(
                            "plan.llm.command_gate_only"
                            if (strict_llm_mode and command_gate_attempted)
                            else "plan.llm_tool_planner.skip_fast_chat"
                        ),
                        ok=True,
                        detail=(
                            "skip after command_gate (strict)"
                            if strict_llm_mode
                            else "skip after command_gate"
                        ),
                    )
                if not llm_plan_selected and (not llm_skip_tool_plan_due_fast_chat):
                    # Single-call CM: one LLM call does both classification and action planning.
                    llm_plan_attempted = True
                    llm_plan, llm_plan_warnings, llm_meta = self._fallback_llm_tool_plan(
                        query=query,
                        detector=detector,
                        max_actions=max_actions,
                        dialogue_history=dialogue_history,
                        llm_session_id=llm_session_id,
                        llm_keep_history=llm_keep_history,
                        llm_clear_history=llm_clear_history,
                        trace_ctx=trace_ctx,
                    )
                    llm_tool_plan_meta = llm_meta
                    llm_non_action_reply = _safe_text(llm_meta.get("reply"), limit=320)
                    parse_warnings.extend(llm_plan_warnings)
                    llm_parse_fail = bool(llm_meta.get("parse_fail", False))
                    llm_repair_success = bool(llm_meta.get("repair_success", False))
                    llm_latency_ms = llm_meta.get("latency_ms")
                    if llm_plan is not None and isinstance(llm_plan.get("actions"), list):
                        llm_actions = list(llm_plan.get("actions") or [])
                        llm_mode = _safe_text(llm_meta.get("mode"), limit=16).lower()
                        if llm_mode not in ("action", "chat"):
                            llm_mode = "action" if llm_actions else "chat"
                        plan = llm_plan
                        llm_plan_selected = True
                        llm_gate_wants_action = bool(llm_mode == "action")
                        TraceStore.step(
                            trace_ctx,
                            name="plan.llm_tool_planner",
                            ok=True,
                            detail=f"actions={len(llm_actions)}",
                        )
                        self._record_llm_planner_metrics(
                            pure_llm_hit=True,
                            parse_fail=llm_parse_fail,
                            repair_success=llm_repair_success,
                            latency_ms=llm_latency_ms,
                        )
                        llm_semantic_cache_candidate = {
                            "query": query,
                            "detector": detector,
                            "max_actions": max_actions,
                            "strict_llm_mode": strict_llm_mode,
                            "dialogue_history": dialogue_history,
                            "plan": llm_plan,
                            "llm_meta": llm_meta,
                        }
                        llm_metrics_recorded = True
                    else:
                        if strict_llm_mode:
                            detail = _safe_text(llm_meta.get("detail"), limit=160) or "llm tool plan unavailable"
                            TraceStore.step(
                                trace_ctx,
                                name="plan.llm_tool_planner.strict_fail",
                                ok=False,
                                detail=detail,
                            )
                            self._record_llm_planner_metrics(
                                parse_fail=llm_parse_fail,
                                repair_success=llm_repair_success,
                                strict_fail=True,
                                latency_ms=llm_latency_ms,
                            )
                            llm_metrics_recorded = True
                            body = {
                                "ok": False,
                                "timestamp": _ts_now(),
                                "query": query,
                                "executed": False,
                                "awaiting_confirmation": False,
                                "response_mode": "llm_plan_failed",
                                "error": "llm_plan_failed",
                                "error_detail": detail,
                                "plan": {
                                    "summary": _safe_text(query, limit=220),
                                    "actions": [],
                                    "source": "llm_tool_planner",
                                    "needs_clarification": False,
                                    "clarification_question": "",
                                    "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                                    "needs_confirmation": False,
                                },
                                "assistant_feedback_source": "policy",
                                "assistant_feedback": "LLM 规划失败（strict_llm_mode=1），未回退规则路径。",
                            }
                            if llm_tool_plan_meta is not None:
                                body["llm_tool_plan"] = llm_tool_plan_meta
                            if llm_command_gate_meta is not None:
                                body["llm_command_gate"] = llm_command_gate_meta
                            if llm_semantic_cache_meta is not None:
                                body["llm_semantic_cache"] = llm_semantic_cache_meta
                            if parse_warnings and include_parse_warning:
                                body["parse_warning"] = "; ".join(parse_warnings)[:320]
                            return self._response_with_trace(status=503, ok=False, trace_ctx=trace_ctx, body=body)

            if llm_first and strict_llm_mode and (not llm_plan_selected) and llm_plan_attempted:
                strict_detail = (
                    _safe_text((llm_tool_plan_meta or {}).get("detail"), limit=160)
                    or _safe_text((llm_command_gate_meta or {}).get("detail"), limit=160)
                    or "llm planner unavailable in strict mode"
                )
                TraceStore.step(
                    trace_ctx,
                    name="plan.llm.strict_no_fallback",
                    ok=False,
                    detail=strict_detail,
                )
                if not llm_metrics_recorded:
                    self._record_llm_planner_metrics(
                        parse_fail=bool((llm_tool_plan_meta or {}).get("parse_fail", False)),
                        repair_success=bool((llm_tool_plan_meta or {}).get("repair_success", False)),
                        strict_fail=True,
                        latency_ms=(
                            (llm_tool_plan_meta or {}).get("latency_ms")
                            if isinstance(llm_tool_plan_meta, dict)
                            else (llm_command_gate_meta or {}).get("latency_ms")
                        ),
                    )
                    llm_metrics_recorded = True
                strict_source = (
                    _safe_text((llm_tool_plan_meta or {}).get("mode"), limit=24)
                    or _safe_text((llm_command_gate_meta or {}).get("mode"), limit=24)
                    or "llm_tool_planner"
                )
                body = {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "query": query,
                    "executed": False,
                    "awaiting_confirmation": False,
                    "response_mode": "llm_plan_failed",
                    "error": "llm_plan_failed",
                    "error_detail": strict_detail,
                    "plan": {
                        "summary": _safe_text(query, limit=220),
                        "actions": [],
                        "source": strict_source,
                        "needs_clarification": False,
                        "clarification_question": "",
                        "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                        "needs_confirmation": False,
                    },
                    "assistant_feedback_source": "policy",
                    "assistant_feedback": "LLM 规划失败（strict_llm_mode=1），未回退规则路径。",
                }
                if llm_tool_plan_meta is not None:
                    body["llm_tool_plan"] = llm_tool_plan_meta
                if llm_command_gate_meta is not None:
                    body["llm_command_gate"] = llm_command_gate_meta
                if llm_semantic_cache_meta is not None:
                    body["llm_semantic_cache"] = llm_semantic_cache_meta
                if parse_warnings and include_parse_warning:
                    body["parse_warning"] = "; ".join(parse_warnings)[:320]
                return self._response_with_trace(status=503, ok=False, trace_ctx=trace_ctx, body=body)

            if not llm_plan_selected:
                plan, plan_warn = self.planner.build_plan(
                    query=query,
                    detector=detector,
                    max_actions=max_actions,
                    force_llm=force_llm,
                )
                parse_warnings.extend(plan_warn)
                TraceStore.step(
                    trace_ctx,
                    name="plan.intent_registry",
                    ok=True,
                    detail=f"actions={len(plan.get('actions') or [])}",
                )
                fallback_actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
                if (
                    llm_first
                    and query
                    and fallback_actions
                    and isinstance(llm_tool_plan_meta, dict)
                    and (not bool(llm_tool_plan_meta.get("ok", False)))
                ):
                    llm_semantic_cache_candidate = {
                        "query": query,
                        "detector": detector,
                        "max_actions": max_actions,
                        "strict_llm_mode": strict_llm_mode,
                        "dialogue_history": dialogue_history,
                        "plan": plan,
                        "llm_meta": {
                            "ok": True,
                            "status": int(llm_tool_plan_meta.get("status") or 200),
                            "detail": "intent_fallback_cached",
                            "upstream": self.config.llm_api_base,
                            "planned_actions": len(fallback_actions),
                            "non_action": False,
                            "mode": "action",
                            "reply": "",
                            "latency_ms": float(llm_tool_plan_meta.get("latency_ms") or 0.0),
                            "parse_fail": bool(llm_tool_plan_meta.get("parse_fail", False)),
                            "repair_attempted": bool(llm_tool_plan_meta.get("repair_attempted", False)),
                            "repair_success": bool(llm_tool_plan_meta.get("repair_success", False)),
                        },
                    }
                if llm_first and (not llm_metrics_recorded):
                    self._record_llm_planner_metrics(
                        parse_fail=bool((llm_tool_plan_meta or {}).get("parse_fail", False)),
                        repair_success=bool((llm_tool_plan_meta or {}).get("repair_success", False)),
                        fallback_used=True,
                        latency_ms=(llm_tool_plan_meta or {}).get("latency_ms"),
                    )
                    llm_metrics_recorded = True

        actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
        if (not llm_plan_attempted) and not actions and query and (
            force_llm or bool(llm_gate_wants_action) or self._should_try_llm_tool_planner(query)
        ):
            llm_plan, llm_plan_warnings, llm_meta = self._fallback_llm_tool_plan(
                query=query,
                detector=detector,
                max_actions=max_actions,
                dialogue_history=dialogue_history,
                llm_session_id=llm_session_id,
                llm_keep_history=llm_keep_history,
                llm_clear_history=llm_clear_history,
                trace_ctx=trace_ctx,
            )
            llm_tool_plan_meta = llm_meta
            llm_non_action_reply = _safe_text(llm_meta.get("reply"), limit=320)
            parse_warnings.extend(llm_plan_warnings)
            if llm_plan is not None and isinstance(llm_plan.get("actions"), list):
                llm_actions = llm_plan.get("actions") or []
                if llm_actions:
                    plan = llm_plan
                    actions = llm_actions
                    llm_semantic_cache_candidate = {
                        "query": query,
                        "detector": detector,
                        "max_actions": max_actions,
                        "strict_llm_mode": strict_llm_mode,
                        "dialogue_history": dialogue_history,
                        "plan": llm_plan,
                        "llm_meta": llm_meta,
                    }
                    TraceStore.step(
                        trace_ctx,
                        name="plan.llm_tool_planner",
                        ok=True,
                        detail=f"actions={len(actions)}",
                    )

        if actions:
            plan, actions, preempt_warnings = self._maybe_preempt_running_gimbal_lock(
                query=query,
                detector=detector,
                allow_execute=allow_execute,
                plan=plan,
                actions=actions,
                max_actions=max_actions,
                trace_ctx=trace_ctx,
            )
            parse_warnings.extend(preempt_warnings)

        if not actions:
            if command_route_only:
                no_action_detail = "no executable command parsed"
                no_action_feedback = (
                    "未解析到可执行命令。此接口仅用于命令执行；"
                    "聊天请改用 /api/agent/chat_manual。"
                )
                TraceStore.step(
                    trace_ctx,
                    name="command.route_only.no_action",
                    ok=False,
                    detail=no_action_detail,
                )
                body = {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "query": query,
                    "executed": False,
                    "awaiting_confirmation": False,
                    "response_mode": "command_no_action",
                    "error": "command_no_action",
                    "error_detail": no_action_detail,
                    "plan": plan,
                    "assistant_feedback_source": "policy",
                    "assistant_feedback": no_action_feedback,
                }
                if llm_tool_plan_meta is not None:
                    body["llm_tool_plan"] = llm_tool_plan_meta
                if llm_command_gate_meta is not None:
                    body["llm_command_gate"] = llm_command_gate_meta
                if llm_semantic_cache_meta is not None:
                    body["llm_semantic_cache"] = llm_semantic_cache_meta
                if parse_warnings and include_parse_warning:
                    body["parse_warning"] = "; ".join(parse_warnings)[:320]
                return self._response_with_trace(status=422, ok=False, trace_ctx=trace_ctx, body=body)

            clarification_feedback = self._build_clarification_feedback(query=query, trace_ctx=trace_ctx) if query else ""
            llm_first_mode = bool(llm_first)
            llm_planner_non_action = bool(
                isinstance(llm_tool_plan_meta, dict)
                and bool(llm_tool_plan_meta.get("non_action", False))
            )
            llm_tool_plan_failed = bool(
                llm_first_mode
                and isinstance(llm_tool_plan_meta, dict)
                and (not bool(llm_tool_plan_meta.get("ok", False)))
            )
            llm_tool_plan_fail_detail = _safe_text(
                (llm_tool_plan_meta or {}).get("detail") if isinstance(llm_tool_plan_meta, dict) else "",
                limit=160,
            ).lower()
            llm_tool_plan_busy_or_timeout = bool(
                llm_tool_plan_failed
                and (
                    ("busy" in llm_tool_plan_fail_detail)
                    or ("timeout" in llm_tool_plan_fail_detail)
                    or ("timed out" in llm_tool_plan_fail_detail)
                )
            )
            if llm_first_mode and llm_planner_non_action and llm_non_action_reply and (not clarification_feedback):
                if llm_fast_chat_query:
                    self._fast_chat_cache_put(query, llm_non_action_reply)
                body = {
                    "ok": True,
                    "timestamp": _ts_now(),
                    "query": query,
                    "executed": False,
                    "awaiting_confirmation": False,
                    "response_mode": "llm_first_non_action",
                    "plan": plan,
                    "assistant_feedback_source": "llm_tool_planner",
                    "assistant_feedback": llm_non_action_reply,
                }
                if llm_tool_plan_meta is not None:
                    body["llm_tool_plan"] = llm_tool_plan_meta
                if llm_command_gate_meta is not None:
                    body["llm_command_gate"] = llm_command_gate_meta
                if llm_semantic_cache_meta is not None:
                    body["llm_semantic_cache"] = llm_semantic_cache_meta
                if parse_warnings and include_parse_warning:
                    body["parse_warning"] = "; ".join(parse_warnings)[:320]
                return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)
            if llm_first_mode and llm_planner_non_action and (not llm_non_action_reply) and (not clarification_feedback):
                parse_warnings.append("llm_first_non_action: empty reply (no local fallback)")
            allow_llm_chat_fallback = bool(
                query
                and self.config.llm_chat_fallback_enabled
                and (
                    llm_first_mode
                    or (
                        (not feedback_with_llm)
                        and (not self._should_try_llm_tool_planner(query))
                    )
                )
            )
            llm_fallback_meta: dict[str, Any] | None = None
            if llm_tool_plan_failed:
                if llm_tool_plan_busy_or_timeout:
                    parse_warnings.append("llm_tool_plan busy/timeout -> try local chat fallback")
                else:
                    parse_warnings.append("llm_tool_plan failed -> try llm_chat_fallback")
            if query and allow_llm_chat_fallback and (not clarification_feedback):
                chat_payload = payload
                if llm_first_mode and ("llm_timeout_sec" not in payload):
                    chat_payload = dict(payload)
                    chat_payload["llm_timeout_sec"] = max(8.0, float(self.config.llm_chat_timeout_sec))
                allow_local_chat_fallback = bool((not llm_first_mode) or llm_fast_chat_query)
                if llm_first_mode and llm_tool_plan_busy_or_timeout and (not allow_local_chat_fallback):
                    parse_warnings.append("llm_first: local fallback disabled on busy/timeout")
                if llm_first_mode and llm_tool_plan_busy_or_timeout and llm_fast_chat_query:
                    if chat_payload is payload:
                        chat_payload = dict(payload)
                    chat_payload["llm_skip_rewrite"] = True
                llm_ok, llm_feedback, llm_meta = self._fallback_llm_chat(
                    query=query,
                    payload=chat_payload,
                    dialogue_history=dialogue_history,
                    allow_local_fallback=allow_local_chat_fallback,
                    trace_ctx=trace_ctx,
                )
                llm_fallback_meta = {
                    "ok": llm_ok,
                    "status": int(llm_meta.get("status") or 0),
                    "detail": _safe_text(llm_meta.get("detail"), limit=220),
                    "max_tokens": int(llm_meta.get("max_tokens") or 0),
                    "timeout_sec": float(llm_meta.get("timeout_sec") or 0.0),
                    "upstream": self.config.llm_api_base,
                }
                if llm_ok and llm_feedback:
                    if llm_first_mode and llm_fast_chat_query:
                        self._fast_chat_cache_put(query, llm_feedback)
                    body = {
                        "ok": True,
                        "timestamp": _ts_now(),
                        "query": query,
                        "executed": False,
                        "awaiting_confirmation": False,
                        "response_mode": "llm_fallback",
                        "plan": plan,
                        "llm_fallback": llm_fallback_meta,
                        "assistant_feedback_source": "llm_fallback",
                        "assistant_feedback": llm_feedback,
                    }
                    if parse_warnings and include_parse_warning:
                        body["parse_warning"] = "; ".join(parse_warnings)[:320]
                    if llm_tool_plan_meta is not None:
                        body["llm_tool_plan"] = llm_tool_plan_meta
                    if llm_command_gate_meta is not None:
                        body["llm_command_gate"] = llm_command_gate_meta
                    if llm_semantic_cache_meta is not None:
                        body["llm_semantic_cache"] = llm_semantic_cache_meta
                    return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)
                parse_warnings.append(f"llm_fallback: {llm_fallback_meta.get('detail') or 'unavailable'}")
            if llm_first_mode:
                fail_detail = ""
                if isinstance(llm_fallback_meta, dict) and (not bool(llm_fallback_meta.get("ok", False))):
                    fail_detail = _safe_text(llm_fallback_meta.get("detail"), limit=180)
                if not fail_detail and llm_tool_plan_failed:
                    fail_detail = _safe_text((llm_tool_plan_meta or {}).get("detail"), limit=180)
                if not fail_detail and llm_planner_non_action and (not llm_non_action_reply):
                    fail_detail = "llm non-action reply empty"
                if not fail_detail:
                    fail_detail = "llm non-action unavailable"
                TraceStore.step(
                    trace_ctx,
                    name="llm.feedback.general",
                    ok=False,
                    detail=fail_detail,
                )
                body = {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "query": query,
                    "executed": False,
                    "awaiting_confirmation": False,
                    "response_mode": "llm_plan_failed",
                    "error": "llm_plan_failed",
                    "error_detail": fail_detail,
                    "plan": {
                        "summary": _safe_text(query, limit=220),
                        "actions": [],
                        "source": "llm_tool_planner",
                        "needs_clarification": False,
                        "clarification_question": "",
                        "confirm_policy": {"min_risk": self.risk_policy.confirm_min_risk},
                        "needs_confirmation": False,
                    },
                    "assistant_feedback_source": "policy",
                    "assistant_feedback": "LLM 对话不可用，请稍后重试。",
                }
                if llm_fallback_meta is not None:
                    body["llm_fallback"] = llm_fallback_meta
                if llm_tool_plan_meta is not None:
                    body["llm_tool_plan"] = llm_tool_plan_meta
                if llm_command_gate_meta is not None:
                    body["llm_command_gate"] = llm_command_gate_meta
                if llm_semantic_cache_meta is not None:
                    body["llm_semantic_cache"] = llm_semantic_cache_meta
                if parse_warnings and include_parse_warning:
                    body["parse_warning"] = "; ".join(parse_warnings)[:320]
                return self._response_with_trace(status=503, ok=False, trace_ctx=trace_ctx, body=body)

            assistant_feedback = self.feedback.compose_no_action(
                query=query,
                force_llm=force_llm,
                llm_fallback_enabled=allow_llm_chat_fallback,
            )
            feedback_source = "template"
            if clarification_feedback:
                assistant_feedback = clarification_feedback
                feedback_source = "policy"
            feedback_meta = None
            if query and feedback_with_llm and not clarification_feedback:
                feedback_memory_context = self._build_feedback_memory_context(
                    query=query,
                    trace_ctx=trace_ctx,
                )
                polish_ok, polished_text, polish_meta = self._polish_general_feedback(
                    query=query,
                    base_feedback=assistant_feedback,
                    context="no_action",
                    trace_ctx=trace_ctx,
                    memory_context=feedback_memory_context,
                )
                feedback_meta = {
                    "ok": bool(polish_ok),
                    "status": int(polish_meta.get("status") or 0),
                    "detail": _safe_text(polish_meta.get("detail"), limit=220),
                    "style_id": int(polish_meta.get("style_id") or 0),
                    "source": _safe_text(polish_meta.get("source"), limit=24) or "template",
                    "memory_hits": int(feedback_memory_context.get("hits") or 0),
                    "memory_correction_hits": int(feedback_memory_context.get("correction_hits") or 0),
                    "memory_correction_recent_count": int(
                        feedback_memory_context.get("correction_recent_count") or 0
                    ),
                    "upstream": self.config.llm_api_base,
                }
                if polish_ok and polished_text:
                    assistant_feedback = polished_text
                    feedback_source = "llm_polish"
            body = {
                "ok": True,
                "timestamp": _ts_now(),
                "query": query,
                "executed": False,
                "awaiting_confirmation": False,
                "response_mode": "no_action",
                "plan": plan,
                "assistant_feedback_source": feedback_source,
                "assistant_feedback": assistant_feedback,
            }
            if llm_fallback_meta is not None:
                body["llm_fallback"] = llm_fallback_meta
            if llm_tool_plan_meta is not None:
                body["llm_tool_plan"] = llm_tool_plan_meta
            if llm_command_gate_meta is not None:
                body["llm_command_gate"] = llm_command_gate_meta
            if llm_semantic_cache_meta is not None:
                body["llm_semantic_cache"] = llm_semantic_cache_meta
            if feedback_meta is not None:
                body["assistant_feedback_meta"] = feedback_meta
            if parse_warnings and include_parse_warning:
                body["parse_warning"] = "; ".join(parse_warnings)[:320]
            return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)

        confirm_actions = [row for row in actions if bool(row.get("requires_confirmation", False))]
        if confirm_actions and not allow_execute:
            token_meta = self.confirm_store.create(client_id=client_id, query=query, plan=plan)
            TraceStore.step(
                trace_ctx,
                name="command.confirm.pending",
                ok=True,
                detail=f"token={token_meta.get('token')}, ttl={token_meta.get('ttl_sec')}s",
            )
            assistant_feedback = self.feedback.compose_pending(len(confirm_actions))
            feedback_source = "template"
            feedback_meta = None
            if query and feedback_with_llm:
                feedback_memory_context = self._build_feedback_memory_context(
                    query=query,
                    trace_ctx=trace_ctx,
                )
                polish_ok, polished_text, polish_meta = self._polish_general_feedback(
                    query=query,
                    base_feedback=assistant_feedback,
                    context="confirm_pending",
                    trace_ctx=trace_ctx,
                    memory_context=feedback_memory_context,
                )
                feedback_meta = {
                    "ok": bool(polish_ok),
                    "status": int(polish_meta.get("status") or 0),
                    "detail": _safe_text(polish_meta.get("detail"), limit=220),
                    "style_id": int(polish_meta.get("style_id") or 0),
                    "source": _safe_text(polish_meta.get("source"), limit=24) or "template",
                    "memory_hits": int(feedback_memory_context.get("hits") or 0),
                    "memory_correction_hits": int(feedback_memory_context.get("correction_hits") or 0),
                    "memory_correction_recent_count": int(
                        feedback_memory_context.get("correction_recent_count") or 0
                    ),
                    "upstream": self.config.llm_api_base,
                }
                if polish_ok and polished_text:
                    assistant_feedback = polished_text
                    feedback_source = "llm_polish"
            body = {
                "ok": True,
                "timestamp": _ts_now(),
                "query": query,
                "executed": False,
                "awaiting_confirmation": True,
                "confirm_token": token_meta.get("token"),
                "confirm_expires_at": token_meta.get("expires_at"),
                "confirm_ttl_sec": token_meta.get("ttl_sec"),
                "plan": plan,
                "assistant_feedback_source": feedback_source,
                "assistant_feedback": assistant_feedback,
            }
            if feedback_meta is not None:
                body["assistant_feedback_meta"] = feedback_meta
            if llm_tool_plan_meta is not None:
                body["llm_tool_plan"] = llm_tool_plan_meta
            if llm_command_gate_meta is not None:
                body["llm_command_gate"] = llm_command_gate_meta
            if llm_semantic_cache_meta is not None:
                body["llm_semantic_cache"] = llm_semantic_cache_meta
            if parse_warnings and include_parse_warning:
                body["parse_warning"] = "; ".join(parse_warnings)[:320]
            return self._response_with_trace(status=202, ok=True, trace_ctx=trace_ctx, body=body)

        side_effect_actions = [row for row in actions if bool(row.get("side_effect", False))]
        if side_effect_actions and not allow_execute:
            TraceStore.step(
                trace_ctx,
                name="command.execute.blocked",
                ok=True,
                detail=f"allow_execute=false, side_effect_actions={len(side_effect_actions)}",
            )
            body = {
                "ok": True,
                "timestamp": _ts_now(),
                "query": query,
                "executed": False,
                "awaiting_confirmation": False,
                "plan": plan,
                "assistant_feedback_source": "policy",
                "assistant_feedback": self.feedback.compose_plan_only(len(side_effect_actions)),
            }
            if llm_tool_plan_meta is not None:
                body["llm_tool_plan"] = llm_tool_plan_meta
            if llm_command_gate_meta is not None:
                body["llm_command_gate"] = llm_command_gate_meta
            if llm_semantic_cache_meta is not None:
                body["llm_semantic_cache"] = llm_semantic_cache_meta
            if parse_warnings and include_parse_warning:
                body["parse_warning"] = "; ".join(parse_warnings)[:320]
            return self._response_with_trace(status=200, ok=True, trace_ctx=trace_ctx, body=body)

        TraceStore.step(trace_ctx, name="executor.batch.start", ok=True, detail=f"actions={len(actions)}")
        action_results = self.executor.execute_actions(actions, trace_ctx=trace_ctx, trace_store=self.trace_store)
        tolerated_failures = 0
        for row in action_results:
            if self._is_tolerable_observe_failure(row):
                tolerated_failures += 1
                if isinstance(row, dict):
                    row["tolerated_failure"] = True
        all_ok = (
            len(action_results) == len(actions)
            and all(bool(row.get("ok", False)) or self._is_tolerable_observe_failure(row) for row in action_results)
        )
        if all_ok and isinstance(llm_semantic_cache_candidate, dict):
            self._semantic_plan_cache_put(
                query=_safe_text(llm_semantic_cache_candidate.get("query"), limit=600),
                detector=_safe_text(llm_semantic_cache_candidate.get("detector"), limit=20) or detector,
                max_actions=_clamp_int(
                    llm_semantic_cache_candidate.get("max_actions"),
                    default=max_actions,
                    min_value=1,
                    max_value=8,
                ),
                strict_llm_mode=bool(llm_semantic_cache_candidate.get("strict_llm_mode", False)),
                dialogue_history=(
                    llm_semantic_cache_candidate.get("dialogue_history")
                    if isinstance(llm_semantic_cache_candidate.get("dialogue_history"), list)
                    else dialogue_history
                ),
                plan=(
                    llm_semantic_cache_candidate.get("plan")
                    if isinstance(llm_semantic_cache_candidate.get("plan"), dict)
                    else plan
                ),
                llm_meta=(
                    llm_semantic_cache_candidate.get("llm_meta")
                    if isinstance(llm_semantic_cache_candidate.get("llm_meta"), dict)
                    else llm_tool_plan_meta
                ),
            )
        TraceStore.step(
            trace_ctx,
            name="executor.batch.finish",
            ok=all_ok,
            detail=(
                f"executed={len(action_results)}/{len(actions)}"
                + (f", tolerated={tolerated_failures}" if tolerated_failures > 0 else "")
            ),
        )

        assistant_feedback = self.feedback.compose_execution(action_results, all_ok=all_ok)
        feedback_source = "tool_summary"
        feedback_meta: dict[str, Any] | None = None
        skip_exec_polish = self._should_skip_exec_polish(query=query, action_results=action_results)
        if query and feedback_with_llm and skip_exec_polish:
            TraceStore.step(
                trace_ctx,
                name="llm.feedback.polish",
                ok=False,
                detail="skipped by status-tool policy",
            )
        elif query and feedback_with_llm:
            feedback_memory_context = self._build_feedback_memory_context(
                query=query,
                trace_ctx=trace_ctx,
            )
            polish_ok, polished_text, polish_meta = self._polish_execution_feedback(
                query=query,
                base_feedback=assistant_feedback,
                plan=plan,
                action_results=action_results,
                all_ok=all_ok,
                trace_ctx=trace_ctx,
                memory_context=feedback_memory_context,
            )
            feedback_meta = {
                "ok": bool(polish_ok),
                "status": int(polish_meta.get("status") or 0),
                "detail": _safe_text(polish_meta.get("detail"), limit=220),
                "style_id": int(polish_meta.get("style_id") or 0),
                "source": _safe_text(polish_meta.get("source"), limit=24) or "tool_summary",
                "memory_hits": int(feedback_memory_context.get("hits") or 0),
                "memory_correction_hits": int(feedback_memory_context.get("correction_hits") or 0),
                "memory_correction_recent_count": int(
                    feedback_memory_context.get("correction_recent_count") or 0
                ),
                "upstream": self.config.llm_api_base,
            }
            if polish_ok and polished_text:
                assistant_feedback = polished_text
                feedback_source = "llm_polish"
        body = {
            "ok": all_ok,
            "timestamp": _ts_now(),
            "query": query,
            "executed": True,
            "awaiting_confirmation": False,
            "response_mode": "executed_action",
            "plan": plan,
            "action_results": action_results,
            "tool_results": action_results,
            "assistant_feedback_source": feedback_source,
            "assistant_feedback": assistant_feedback,
        }
        if tolerated_failures > 0:
            body["tolerated_failures"] = int(tolerated_failures)
        if feedback_meta is not None:
            body["assistant_feedback_meta"] = feedback_meta
        if llm_tool_plan_meta is not None:
            body["llm_tool_plan"] = llm_tool_plan_meta
        if llm_command_gate_meta is not None:
            body["llm_command_gate"] = llm_command_gate_meta
        if llm_semantic_cache_meta is not None:
            body["llm_semantic_cache"] = llm_semantic_cache_meta
        if parse_warnings and include_parse_warning:
            body["parse_warning"] = "; ".join(parse_warnings)[:320]
        return self._response_with_trace(
            status=200 if all_ok else 503,
            ok=all_ok,
            trace_ctx=trace_ctx,
            body=body,
        )

    def handle_trigger_evaluate(
        self,
        *,
        method: str,
        query_params: dict[str, list[str]],
        payload: dict[str, Any] | None,
    ) -> tuple[int, dict[str, Any]]:
        dry_run_flag = None
        if method == "GET":
            raw = _safe_text((query_params.get("dry_run") or ["1"])[0], limit=16)
            dry_run_flag = _coerce_enabled(raw)
        else:
            obj = payload if isinstance(payload, dict) else {}
            dry_run_flag = _coerce_enabled(obj.get("dry_run"))
        dry_run = bool(dry_run_flag) if dry_run_flag is not None else True

        trace_ctx = self.trace_store.start(
            route="/api/agent/triggers/evaluate",
            payload=payload if isinstance(payload, dict) else {"dry_run": dry_run},
            raw_input=f"dry_run={dry_run}",
        )
        TraceStore.step(trace_ctx, "trigger.request.parse", True, f"dry_run={dry_run}")

        report = self.trigger_engine.evaluate(
            dry_run=dry_run,
            executor=self.executor,
            trace_ctx=trace_ctx,
            trace_store=self.trace_store,
        )
        actions = report.get("actions") if isinstance(report.get("actions"), list) else []
        sensors = report.get("sensors") if isinstance(report.get("sensors"), dict) else {}
        assistant_feedback = (
            f"Trigger evaluation complete: dry_run={dry_run}; "
            f"actions={len(actions)}, max_temp={sensors.get('max_temp_c')}, "
            f"mem={sensors.get('mem_used_percent')}%."
        )

        return self._response_with_trace(
            status=200,
            ok=True,
            trace_ctx=trace_ctx,
            body={
                "ok": True,
                "timestamp": _ts_now(),
                "assistant_feedback": assistant_feedback,
                "report": report,
            },
        )

    def handle_trace_query(self, path: str, query_params: dict[str, list[str]]) -> tuple[int, dict[str, Any]]:
        trace_id = ""
        if path.startswith("/api/agent/trace/"):
            trace_id = _safe_text(path.rsplit("/", 1)[-1], limit=64)
        if not trace_id:
            trace_id = _safe_text((query_params.get("trace_id") or [""])[0], limit=64)

        if trace_id:
            trace = self.trace_store.get(trace_id)
            if trace is None:
                return 404, {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "trace not found",
                    "trace_id": trace_id,
                }
            return 200, {
                "ok": True,
                "timestamp": _ts_now(),
                "trace": trace,
            }

        limit = _clamp_int((query_params.get("limit") or ["20"])[0], default=20, min_value=1, max_value=200)
        traces = self.trace_store.recent(limit=limit)
        return 200, {
            "ok": True,
            "timestamp": _ts_now(),
            "traces": traces,
            "count": len(traces),
        }

    def dispatch_agent_route(
        self,
        *,
        route: RouteSpec,
        method: str,
        path: str,
        query_params: dict[str, list[str]],
        payload: dict[str, Any] | None,
        headers: dict[str, str],
        remote_ip: str,
    ) -> tuple[int, dict[str, Any]]:
        client_id = self._client_id(headers, remote_ip)
        if route.key == "agent.health":
            return self.health_payload()
        if route.key == "agent.command":
            return self.handle_agent_command(payload if isinstance(payload, dict) else {}, client_id=client_id)
        if route.key == "agent.command.llm_first":
            return self.handle_agent_command(
                payload if isinstance(payload, dict) else {},
                client_id=client_id,
                llm_first=True,
            )
        if route.key == "agent.chat.manual":
            return self.handle_agent_chat_manual(payload if isinstance(payload, dict) else {}, client_id=client_id)
        if route.key == "agent.command.manual":
            command_payload = dict(payload) if isinstance(payload, dict) else {}
            # Command-only route: parse/execute commands, do not downgrade to chat.
            command_payload["command_route_only"] = True
            if "strict_llm_mode" not in command_payload:
                command_payload["strict_llm_mode"] = False
            command_payload["llm_gate_classify_only"] = False
            command_payload["llm_fast_chat_route"] = False
            return self.handle_agent_command(
                command_payload,
                client_id=client_id,
                llm_first=True,
                route_path_override="/api/agent/command_manual",
            )
        if route.key == "agent.triggers.evaluate":
            return self.handle_trigger_evaluate(method=method, query_params=query_params, payload=payload)
        if route.key in ("agent.trace.collection", "agent.trace.item"):
            return self.handle_trace_query(path, query_params)
        return 404, {
            "ok": False,
            "timestamp": _ts_now(),
            "error": f"unsupported route key: {route.key}",
        }


CONFIG = AgentConfig.from_env()
APP = AgentServiceApp(CONFIG)


class AgentServiceHandler(BaseHTTPRequestHandler):
    server_version = "agent-service-v2"

    def _send_json(self, payload: dict[str, Any], status: int = 200, *, head_only: bool = False) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-Request-Id, X-Trace-Id",
        )
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if head_only:
            return
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            return

    def _send_sse_headers(self, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-Request-Id, X-Trace-Id",
        )
        self.end_headers()

    def _write_sse_event(self, event: str, data: dict[str, Any]) -> bool:
        payload = f"event: {str(event or 'message').strip()}\n"
        payload += "data: " + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n\n"
        try:
            self.wfile.write(payload.encode("utf-8"))
            self.wfile.flush()
            return True
        except BrokenPipeError:
            return False
        except Exception:
            return False

    def _handle_chat_manual_stream(self, payload: dict[str, Any]) -> None:
        query = _safe_text(payload.get("query") or payload.get("message"), limit=600)
        if not query:
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "query (or message) is required",
                },
                status=400,
                head_only=False,
            )
            return

        trace_ctx = APP.trace_store.start(
            route="/api/agent/chat_manual",
            payload=payload,
            raw_input=query,
        )
        TraceStore.step(trace_ctx, "request.parse", True, "mode=chat_manual_stream")

        timeout_sec = 10.0
        try:
            timeout_sec = float(payload.get("llm_timeout_sec", timeout_sec))
        except (TypeError, ValueError):
            timeout_sec = 10.0
        timeout_sec = max(2.0, min(12.0, timeout_sec))

        llm_session_id = _safe_text(payload.get("llm_session_id"), limit=64)
        if not llm_session_id:
            llm_session_id = _safe_text(payload.get("session_id"), limit=64)
        llm_keep_history_flag = _coerce_enabled(payload.get("llm_keep_history"))
        llm_clear_history_flag = _coerce_enabled(payload.get("llm_clear_history"))
        llm_keep_history = (
            bool(llm_keep_history_flag)
            if llm_keep_history_flag is not None
            else bool(llm_session_id)
        )
        llm_clear_history = bool(llm_clear_history_flag) if llm_clear_history_flag is not None else False

        dialogue_history = _normalize_dialogue_history(payload.get("dialogue_history"))
        history_rows = list(dialogue_history)
        if history_rows:
            last = history_rows[-1] if isinstance(history_rows[-1], dict) else {}
            last_role = _safe_text(last.get("role"), limit=16).lower()
            last_text = _safe_text(last.get("text") or last.get("content"), limit=600)
            if (last_role == "user") and (last_text == query):
                history_rows = history_rows[:-1]

        prefer_chinese = _contains_cjk(query)
        project_context = APP._build_project_knowledge_context(query=query, trace_ctx=trace_ctx)
        message_text = APP._compose_chat_manual_message(
            query=query,
            dialogue_history=history_rows,
            prefer_chinese=prefer_chinese,
            project_context=project_context,
        )

        llm_payload: dict[str, Any] = {
            "message": message_text,
            "stream": True,
            "attach_vision": bool(payload.get("attach_vision", False)),
            "timeout_sec": float(timeout_sec),
            "max_retries": 0,
            "fast_mode": True,
            "max_tokens": int(
                _clamp_int(
                    payload.get("llm_max_tokens", 64),
                    default=64,
                    min_value=24,
                    max_value=128,
                )
            ),
            "include_llm_text": False,
        }
        if "enable_thinking" in payload:
            llm_payload["enable_thinking"] = bool(payload.get("enable_thinking"))
        if "temperature" in payload:
            llm_payload["temperature"] = payload.get("temperature")
        if "top_p" in payload:
            llm_payload["top_p"] = payload.get("top_p")
        if "top_k" in payload:
            llm_payload["top_k"] = payload.get("top_k")
        if "tools" in payload:
            llm_payload["tools"] = payload.get("tools")
        llm_payload["keep_history"] = bool(llm_session_id and llm_keep_history)
        llm_payload["clear_history"] = bool(llm_clear_history or (not llm_payload["keep_history"]))
        if llm_session_id:
            llm_payload["session_id"] = llm_session_id

        target = parse_base_target(APP.config.llm_api_base)
        if not target.is_unix and not target.host:
            TraceStore.step(trace_ctx, "llm.chat.stream.proxy", False, "invalid llm base url")
            APP.trace_store.finalize(trace_ctx, False)
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "invalid llm base url",
                },
                status=502,
                head_only=False,
            )
            return
        req_path = "/api/llm/chat"
        req_path = compose_request_path(APP.config.llm_api_base, req_path)

        upstream_conn: http.client.HTTPConnection | http.client.HTTPSConnection | None = None
        upstream_resp: http.client.HTTPResponse | None = None
        started = time.perf_counter()
        stream_started = False
        try:
            body = json.dumps(llm_payload, ensure_ascii=False).encode("utf-8")
            headers = {
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "text/event-stream",
                "User-Agent": "agent-service-v2",
                "Connection": "close",
                "Content-Length": str(len(body)),
            }
            upstream_conn, _ = open_connection(
                APP.config.llm_api_base,
                timeout_sec=max(30.0, timeout_sec + 20.0),
            )
            upstream_conn.request("POST", req_path, body=body, headers=headers)
            upstream_resp = upstream_conn.getresponse()
            upstream_status = int(getattr(upstream_resp, "status", 0) or 0)
            if not (200 <= upstream_status < 300):
                raw = upstream_resp.read()
                text = raw.decode("utf-8", errors="replace") if raw else ""
                err_detail = _safe_text(text or f"upstream status={upstream_status}", limit=260)
                TraceStore.step(
                    trace_ctx,
                    "llm.chat.stream.proxy",
                    False,
                    err_detail,
                    duration_ms=(time.perf_counter() - started) * 1000.0,
                    status=upstream_status,
                )
                APP.trace_store.finalize(trace_ctx, False)
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "chat stream upstream failed",
                        "detail": err_detail,
                        "llm_status": upstream_status,
                    },
                    status=502,
                    head_only=False,
                )
                return

            self._send_sse_headers(status=200)
            stream_started = True
            if not self._write_sse_event(
                "agent_meta",
                {
                    "ok": True,
                    "timestamp": _ts_now(),
                    "route": "/api/agent/chat_manual",
                    "trace_id": trace_ctx.trace.get("trace_id"),
                },
            ):
                TraceStore.step(trace_ctx, "llm.chat.stream.proxy", False, "client disconnected before stream")
                APP.trace_store.finalize(trace_ctx, False)
                return

            relayed_bytes = 0
            while True:
                line = upstream_resp.readline()
                if not line:
                    break
                relayed_bytes += len(line)
                try:
                    self.wfile.write(line)
                    self.wfile.flush()
                except BrokenPipeError:
                    TraceStore.step(trace_ctx, "llm.chat.stream.proxy", False, "client disconnected during stream")
                    APP.trace_store.finalize(trace_ctx, False)
                    return
            TraceStore.step(
                trace_ctx,
                "llm.chat.stream.proxy",
                True,
                f"relayed_bytes={relayed_bytes}",
                duration_ms=(time.perf_counter() - started) * 1000.0,
                status=upstream_status,
            )
            APP.trace_store.finalize(trace_ctx, True)
            self.close_connection = True
        except Exception as exc:
            TraceStore.step(
                trace_ctx,
                "llm.chat.stream.proxy",
                False,
                _safe_text(str(exc), limit=220) or "stream proxy failed",
                duration_ms=(time.perf_counter() - started) * 1000.0,
            )
            APP.trace_store.finalize(trace_ctx, False)
            if not stream_started:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": _safe_text(str(exc), limit=220) or "stream proxy failed",
                    },
                    status=502,
                    head_only=False,
                )
        finally:
            try:
                if upstream_resp is not None:
                    upstream_resp.close()
            except Exception:
                pass
            try:
                if upstream_conn is not None:
                    upstream_conn.close()
            except Exception:
                pass

    def _send_no_content(self, allow_methods: str) -> None:
        self.send_response(204)
        self.send_header("Allow", allow_methods)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", allow_methods)
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-Request-Id, X-Trace-Id",
        )
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _read_json_body(self) -> tuple[dict[str, Any] | None, str]:
        raw_len = _safe_text(self.headers.get("Content-Length"), limit=20)
        if not raw_len:
            return {}, ""
        try:
            body_len = int(raw_len)
        except ValueError:
            return None, "invalid Content-Length"
        if body_len < 0:
            return None, "invalid Content-Length"
        if body_len > APP.config.body_limit_bytes:
            return None, "request body too large"
        if body_len == 0:
            return {}, ""
        try:
            raw = self.rfile.read(body_len)
        except Exception:
            return None, "failed to read request body"
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception:
            return None, "invalid JSON body"
        if not isinstance(payload, dict):
            return None, "JSON body must be an object"
        return payload, ""

    def _owned_allow_methods(self, route: RouteSpec) -> set[str]:
        allow = set(route.methods)
        allow.add("OPTIONS")
        if "GET" in allow:
            allow.add("HEAD")
        return allow

    def do_OPTIONS(self) -> None:
        parts = urlsplit(self.path)
        path = parts.path
        if path == "/health":
            self._send_no_content("GET,HEAD,OPTIONS")
            return
        route = APP.resolve_route(path)
        if route is not None:
            allow = ",".join(sorted(self._owned_allow_methods(route)))
            self._send_no_content(allow)
            return
        if path.startswith("/api/agent/"):
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"agent route not owned by agent service: {path}",
                },
                status=404,
            )
            return
        self._send_json(
            {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"not found: {path}",
            },
            status=404,
        )

    def do_HEAD(self) -> None:
        self._dispatch(head_only=True)

    def do_GET(self) -> None:
        self._dispatch(head_only=False)

    def do_POST(self) -> None:
        self._dispatch(head_only=False)

    def do_PUT(self) -> None:
        self._dispatch(head_only=False)

    def do_PATCH(self) -> None:
        self._dispatch(head_only=False)

    def do_DELETE(self) -> None:
        self._dispatch(head_only=False)

    def do_TRACE(self) -> None:
        self._dispatch(head_only=False)

    def do_CONNECT(self) -> None:
        self._dispatch(head_only=False)

    def _dispatch(self, head_only: bool) -> None:
        parts = urlsplit(self.path)
        path = parts.path
        query_params = parse_qs(parts.query or "", keep_blank_values=True)

        if path == "/health":
            status, payload = APP.health_payload()
            self._send_json(payload, status=status, head_only=head_only)
            return

        route = APP.resolve_route(path)
        if route is None:
            if path.startswith("/api/agent/"):
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"agent route not owned by agent service: {path}",
                    },
                    status=404,
                    head_only=head_only,
                )
                return
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"not found: {path}",
                },
                status=404,
                head_only=head_only,
            )
            return

        effective_method = "GET" if self.command == "HEAD" else self.command
        if effective_method not in route.methods:
            allow = sorted(self._owned_allow_methods(route))
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"method not allowed: {self.command}",
                    "route": path,
                    "allow": allow,
                },
                status=405,
                head_only=head_only,
            )
            return

        payload: dict[str, Any] | None = None
        if effective_method == "POST":
            payload, err = self._read_json_body()
            if payload is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400, head_only=head_only)
                return

        if (
            (not head_only)
            and effective_method == "POST"
            and route.key == "agent.chat.manual"
            and isinstance(payload, dict)
            and bool(payload.get("stream", False))
        ):
            self._handle_chat_manual_stream(payload)
            return

        headers = {key: str(value) for key, value in self.headers.items()}
        remote_ip = self.client_address[0] if isinstance(self.client_address, tuple) else "local"
        status, response = APP.dispatch_agent_route(
            route=route,
            method=effective_method,
            path=path,
            query_params=query_params,
            payload=payload,
            headers=headers,
            remote_ip=remote_ip,
        )
        self._send_json(response, status=status, head_only=head_only)

    def log_message(self, fmt: str, *args: Any) -> None:
        message = fmt % args if args else fmt
        remote = "local"
        port = 0
        if isinstance(self.client_address, tuple):
            remote = str(self.client_address[0])
            if len(self.client_address) > 1:
                try:
                    port = int(self.client_address[1])
                except Exception:
                    port = 0
        print(
            f"{_ts_now()} "
            f"agent-service {remote}:{port} {message}"
        )


def main() -> None:
    server = bind_server(CONFIG.host, CONFIG.port, AgentServiceHandler, unix_socket_path=CONFIG.unix_socket_path)
    print(
        "agent service v2 listening on "
        f"{('unix://' + CONFIG.unix_socket_path) if CONFIG.unix_socket_path else ('http://' + CONFIG.host + ':' + str(CONFIG.port))} "
        f"(runtime={CONFIG.tool_runtime}, vision={CONFIG.vision_api_base}, "
        f"llm={CONFIG.llm_api_base}, llm_fallback={int(CONFIG.llm_chat_fallback_enabled)}, "
        f"llm_fast_chat_route={int(CONFIG.llm_fast_chat_route_enabled)}, "
        f"llm_semantic_cache={int(CONFIG.llm_semantic_cache_enabled)}, "
        f"llm_tool_planner={int(CONFIG.llm_tool_planner_enabled)}, "
        f"llm_native_tools={int(CONFIG.llm_tool_plan_native_tools_enabled)}, "
        f"llm_exec_feedback={int(CONFIG.llm_exec_feedback_enabled)})"
    )
    server.serve_forever()


if __name__ == "__main__":
    main()
