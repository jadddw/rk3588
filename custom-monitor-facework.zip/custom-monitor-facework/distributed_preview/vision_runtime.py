#!/usr/bin/env python3
from __future__ import annotations

import base64
import binascii
import json
import logging
import os
import re
import select
import secrets
import subprocess
import threading
import time
import urllib.request
import hashlib
import hmac
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np

# Keep BASE_DIR at project root so model default paths remain identical to server.py
BASE_DIR = Path(__file__).resolve().parents[1]

VISION_ENABLED = os.environ.get("VISION_ENABLED", "1") not in ("0", "false", "False")
VISION_CAMERA_RAW = os.environ.get("VISION_CAMERA", "0").strip()
VISION_BACKEND = os.environ.get("VISION_BACKEND", "v4l2").lower()
VISION_PIPELINE = os.environ.get("VISION_PIPELINE", "opencv").strip().lower()
VISION_FFMPEG_BIN = os.environ.get("VISION_FFMPEG_BIN", "ffmpeg").strip() or "ffmpeg"
VISION_FFMPEG_LOGLEVEL = os.environ.get("VISION_FFMPEG_LOGLEVEL", "quiet").strip() or "quiet"
VISION_FFMPEG_READ_TIMEOUT_MS = max(
    50.0, float(os.environ.get("VISION_FFMPEG_READ_TIMEOUT_MS", "700"))
)
VISION_FFMPEG_PROBESIZE = max(32, int(os.environ.get("VISION_FFMPEG_PROBESIZE", "32")))
VISION_FFMPEG_ANALYZEDURATION_US = max(
    0, int(os.environ.get("VISION_FFMPEG_ANALYZEDURATION_US", "0"))
)
VISION_WIDTH = int(os.environ.get("VISION_WIDTH", "640"))
VISION_HEIGHT = int(os.environ.get("VISION_HEIGHT", "480"))
VISION_FPS = float(os.environ.get("VISION_FPS", "30"))
VISION_FOURCC = os.environ.get("VISION_FOURCC", "MJPG").upper()
VISION_STREAM_ENABLED = os.environ.get("VISION_STREAM_ENABLED", "1") not in (
    "0",
    "false",
    "False",
)
VISION_STREAM_MAX_FPS = float(os.environ.get("VISION_STREAM_MAX_FPS", "120"))
VISION_FLIP = int(os.environ.get("VISION_FLIP", "-1"))
_VISION_ROTATE_RAW = os.environ.get("VISION_ROTATE", "0").strip().lower()
_VISION_ROTATE_MAP = {
    "ccw90": 90,
    "left": 90,
    "cw90": 270,
    "right": 270,
    "180": 180,
    "270": 270,
}
try:
    VISION_ROTATE = int(_VISION_ROTATE_RAW)
except ValueError:
    VISION_ROTATE = _VISION_ROTATE_MAP.get(_VISION_ROTATE_RAW, 0)
VISION_ROTATE = VISION_ROTATE % 360
if VISION_ROTATE not in (0, 90, 180, 270):
    VISION_ROTATE = 0
VISION_JPEG_QUALITY = int(os.environ.get("VISION_JPEG_QUALITY", "85"))
try:
    VISION_STREAM_WIDTH = int(os.environ.get("VISION_STREAM_WIDTH", "0"))
except ValueError:
    VISION_STREAM_WIDTH = 0
try:
    VISION_STREAM_HEIGHT = int(os.environ.get("VISION_STREAM_HEIGHT", "0"))
except ValueError:
    VISION_STREAM_HEIGHT = 0
VISION_STREAM_WIDTH = max(0, VISION_STREAM_WIDTH)
VISION_STREAM_HEIGHT = max(0, VISION_STREAM_HEIGHT)
VISION_MIN_AREA_RATIO = float(os.environ.get("VISION_MIN_AREA_RATIO", "0.005"))
VISION_MAX_AREA_RATIO = float(os.environ.get("VISION_MAX_AREA_RATIO", "0.5"))
VISION_REOPEN_FAILS = int(os.environ.get("VISION_REOPEN_FAILS", "2"))
VISION_REOPEN_DELAY = float(os.environ.get("VISION_REOPEN_DELAY", "0.3"))
VISION_FAIL_COOLDOWN = float(os.environ.get("VISION_FAIL_COOLDOWN", "1.0"))
VISION_MAX_FRAME_AGE_MS = float(os.environ.get("VISION_MAX_FRAME_AGE_MS", "1000"))
VISION_OBSERVE_RETRY_MS = max(
    0.0, min(2000.0, float(os.environ.get("VISION_OBSERVE_RETRY_MS", "350")))
)
VISION_OBSERVE_RETRY_INTERVAL_MS = max(
    10.0,
    min(500.0, float(os.environ.get("VISION_OBSERVE_RETRY_INTERVAL_MS", "35"))),
)
VISION_STREAM_FPS_STALE_SEC = float(os.environ.get("VISION_STREAM_FPS_STALE_SEC", "2.0"))
VISION_PROFILE = os.environ.get("VISION_PROFILE", "fullhd30").strip().lower()
VISION_YOLO_MODEL = os.environ.get("VISION_YOLO_MODEL", "").strip()
VISION_YOLO_BACKEND = os.environ.get("VISION_YOLO_BACKEND", "auto").strip().lower()
VISION_YOLO_RKNN_MODEL = os.environ.get("VISION_YOLO_RKNN_MODEL", "").strip()
VISION_YOLO_RKNN_TARGET = os.environ.get("VISION_YOLO_RKNN_TARGET", "rk3588").strip().lower()
VISION_YOLO_RKNN_CORE = os.environ.get("VISION_YOLO_RKNN_CORE", "auto").strip().lower()
VISION_YOLO_ANCHORS = os.environ.get("VISION_YOLO_ANCHORS", "").strip()
VISION_YOLO_INPUT = int(os.environ.get("VISION_YOLO_INPUT", "320"))
VISION_YOLO_CONF = float(os.environ.get("VISION_YOLO_CONF", "0.35"))
VISION_YOLO_NMS = float(os.environ.get("VISION_YOLO_NMS", "0.45"))
VISION_YOLO_CLASSES = os.environ.get("VISION_YOLO_CLASSES", "").strip()
VISION_YOLO_MAX_OBJECTS = max(1, int(os.environ.get("VISION_YOLO_MAX_OBJECTS", "40")))
VISION_YOLO_ADAPTIVE_TRIGGER = max(
    4, int(os.environ.get("VISION_YOLO_ADAPTIVE_TRIGGER", "16"))
)
VISION_YOLO_ADAPTIVE_CONF = max(
    0.05, min(1.0, float(os.environ.get("VISION_YOLO_ADAPTIVE_CONF", "0.45")))
)
VISION_YOLO_SPIKE_COUNT = max(6, int(os.environ.get("VISION_YOLO_SPIKE_COUNT", "20")))
VISION_YOLO_SPIKE_FACTOR = max(
    1.5, float(os.environ.get("VISION_YOLO_SPIKE_FACTOR", "3.0"))
)
VISION_YOLO_SPIKE_CONFIRM = max(
    1, int(os.environ.get("VISION_YOLO_SPIKE_CONFIRM", "3"))
)
VISION_YOLO_WORLD_MODEL = os.environ.get(
    "VISION_YOLO_WORLD_MODEL", str(BASE_DIR / "models/yolo_world_v2s.rknn")
).strip()
VISION_YOLO_WORLD_ENABLED = os.environ.get("VISION_YOLO_WORLD_ENABLED", "0") not in (
    "0",
    "false",
    "False",
)
VISION_YOLO_WORLD_TEXT = os.environ.get(
    "VISION_YOLO_WORLD_TEXT", str(BASE_DIR / "models/coco_text_outp.npy")
).strip()
VISION_YOLO_WORLD_LABELS = os.environ.get(
    "VISION_YOLO_WORLD_LABELS", str(BASE_DIR / "models/detect_classes.txt")
).strip()
VISION_YOLO_WORLD_INPUT = int(os.environ.get("VISION_YOLO_WORLD_INPUT", "640"))
VISION_YOLO_WORLD_CONF = float(os.environ.get("VISION_YOLO_WORLD_CONF", "0.25"))
VISION_YOLO_WORLD_NMS = float(os.environ.get("VISION_YOLO_WORLD_NMS", "0.45"))
VISION_YOLO_WORLD_MAX_OBJECTS = max(
    1, int(os.environ.get("VISION_YOLO_WORLD_MAX_OBJECTS", "80"))
)
VISION_YOLO_WORLD_ADAPTIVE_TRIGGER = max(
    4, int(os.environ.get("VISION_YOLO_WORLD_ADAPTIVE_TRIGGER", "12"))
)
VISION_YOLO_WORLD_ADAPTIVE_CONF = max(
    0.05, min(1.0, float(os.environ.get("VISION_YOLO_WORLD_ADAPTIVE_CONF", "0.40")))
)
VISION_YOLO_WORLD_SPIKE_COUNT = max(
    6, int(os.environ.get("VISION_YOLO_WORLD_SPIKE_COUNT", "12"))
)
VISION_YOLO_WORLD_SPIKE_FACTOR = max(
    1.5, float(os.environ.get("VISION_YOLO_WORLD_SPIKE_FACTOR", "3.0"))
)
VISION_YOLO_WORLD_SPIKE_CONFIRM = max(
    1, int(os.environ.get("VISION_YOLO_WORLD_SPIKE_CONFIRM", "3"))
)
VISION_YOLO_WORLD_PRE_NMS_CAP = max(
    16, int(os.environ.get("VISION_YOLO_WORLD_PRE_NMS_CAP", "60"))
)
VISION_YOLO_WORLD_RKNN_CORE = os.environ.get(
    "VISION_YOLO_WORLD_RKNN_CORE", VISION_YOLO_RKNN_CORE
).strip().lower()
VISION_YOLO_WORLD_SINGLE_FLIGHT = os.environ.get("VISION_YOLO_WORLD_SINGLE_FLIGHT", "1") not in (
    "0",
    "false",
    "False",
)
VISION_YOLO_WORLD_ASYNC = os.environ.get("VISION_YOLO_WORLD_ASYNC", "1") not in (
    "0",
    "false",
    "False",
)
VISION_YOLO_WORLD_ASYNC_FPS = max(
    1.0, min(60.0, float(os.environ.get("VISION_YOLO_WORLD_ASYNC_FPS", "12")))
)
VISION_YOLO_WORLD_CACHE_TTL_MS = max(
    0.0, float(os.environ.get("VISION_YOLO_WORLD_CACHE_TTL_MS", "120"))
)
VISION_YOLO_WORLD_ALIASES = os.environ.get(
    "VISION_YOLO_WORLD_ALIASES", str(BASE_DIR / "models/yolo_world_aliases.json")
).strip()
VISION_YOLO_WORLD_PROMPT_MAX_TERMS = max(
    1, min(32, int(os.environ.get("VISION_YOLO_WORLD_PROMPT_MAX_TERMS", "12")))
)
VISION_YOLO_WORLD_PROMPT_STRICT_DEFAULT = os.environ.get(
    "VISION_YOLO_WORLD_PROMPT_STRICT_DEFAULT", "0"
) not in ("0", "false", "False")
VISION_YOLO_WORLD_VOCAB_DIR = os.environ.get(
    "VISION_YOLO_WORLD_VOCAB_DIR", str(BASE_DIR / "models/yolo_world_vocab")
).strip()
VISION_YOLO_WORLD_VOCAB_SAFE_DEFAULT = os.environ.get(
    "VISION_YOLO_WORLD_VOCAB_SAFE_DEFAULT", "1"
) not in ("0", "false", "False")
VISION_YOLO_WORLD_VOCAB_SAFE_MIN_OVERLAP = max(
    1, int(os.environ.get("VISION_YOLO_WORLD_VOCAB_SAFE_MIN_OVERLAP", "20"))
)
VISION_YOLO_WORLD_VOCAB_SAFE_MIN_MEAN_COS = max(
    0.0,
    min(1.0, float(os.environ.get("VISION_YOLO_WORLD_VOCAB_SAFE_MIN_MEAN_COS", "0.97"))),
)
VISION_YOLO_WORLD_VOCAB_SAFE_MIN_ANCHOR_COS = max(
    0.0,
    min(1.0, float(os.environ.get("VISION_YOLO_WORLD_VOCAB_SAFE_MIN_ANCHOR_COS", "0.90"))),
)
VISION_YOLO_WORLD_VOCAB_SAFE_ANCHORS = [
    item.strip()
    for item in os.environ.get(
        "VISION_YOLO_WORLD_VOCAB_SAFE_ANCHORS",
        "person,car,dog,cat,bottle,cell phone",
    ).split(",")
    if item.strip()
]
VISION_WEAR_GLASSES_ENABLED = os.environ.get("VISION_WEAR_GLASSES_ENABLED", "1") not in (
    "0",
    "false",
    "False",
)
VISION_WEAR_GLASSES_AUTO = os.environ.get("VISION_WEAR_GLASSES_AUTO", "0") not in (
    "0",
    "false",
    "False",
)
VISION_WEAR_GLASSES_CLIP_MODEL = os.environ.get(
    "VISION_WEAR_GLASSES_CLIP_MODEL", "ViT-B/32"
).strip()
VISION_WEAR_GLASSES_DEVICE = os.environ.get("VISION_WEAR_GLASSES_DEVICE", "auto").strip().lower()
VISION_WEAR_GLASSES_MAX_PERSONS = max(
    1, min(8, int(os.environ.get("VISION_WEAR_GLASSES_MAX_PERSONS", "4")))
)
VISION_WEAR_GLASSES_MIN_MARGIN = max(
    -1.0, min(1.0, float(os.environ.get("VISION_WEAR_GLASSES_MIN_MARGIN", "-0.005")))
)
VISION_WEAR_GLASSES_HEAD_RATIO = max(
    0.35, min(0.9, float(os.environ.get("VISION_WEAR_GLASSES_HEAD_RATIO", "0.62")))
)
VISION_WEAR_GLASSES_HEAD_WIDTH_RATIO = max(
    0.4, min(1.0, float(os.environ.get("VISION_WEAR_GLASSES_HEAD_WIDTH_RATIO", "0.72")))
)
VISION_WEAR_GLASSES_UPDATE_INTERVAL_MS = max(
    0.0,
    min(10000.0, float(os.environ.get("VISION_WEAR_GLASSES_UPDATE_INTERVAL_MS", "1200"))),
)
VISION_WEAR_GLASSES_CACHE_TTL_MS = max(
    250.0, min(15000.0, float(os.environ.get("VISION_WEAR_GLASSES_CACHE_TTL_MS", "3000")))
)
VISION_WEAR_GLASSES_CACHE_MATCH_IOU = max(
    0.05, min(0.95, float(os.environ.get("VISION_WEAR_GLASSES_CACHE_MATCH_IOU", "0.45")))
)
VISION_WEAR_GLASSES_CACHE_MAX_CENTER_DIST = max(
    0.05,
    min(
        1.5,
        float(os.environ.get("VISION_WEAR_GLASSES_CACHE_MAX_CENTER_DIST", "0.40")),
    ),
)
VISION_EMOTION_ENABLED = os.environ.get("VISION_EMOTION_ENABLED", "1") not in (
    "0",
    "false",
    "False",
)
VISION_EMOTION_AUTO = os.environ.get("VISION_EMOTION_AUTO", "0") not in (
    "0",
    "false",
    "False",
)
VISION_EMOTION_ENGINE = os.environ.get("VISION_EMOTION_ENGINE", "onnx").strip().lower()
VISION_EMOTION_MODEL = os.environ.get("VISION_EMOTION_MODEL", "enet_b0_8_best_vgaf").strip()
VISION_EMOTION_RKNN_MODEL = os.environ.get("VISION_EMOTION_RKNN_MODEL", "").strip()
VISION_EMOTION_RKNN_INPUT = max(
    64, min(512, int(os.environ.get("VISION_EMOTION_RKNN_INPUT", "224")))
)
VISION_EMOTION_RKNN_CORE = os.environ.get(
    "VISION_EMOTION_RKNN_CORE", VISION_YOLO_RKNN_CORE
).strip().lower()
VISION_EMOTION_RKNN_LAYOUT = os.environ.get("VISION_EMOTION_RKNN_LAYOUT", "nhwc").strip().lower()
VISION_EMOTION_RKNN_DTYPE = os.environ.get(
    "VISION_EMOTION_RKNN_DTYPE", "float32"
).strip().lower()
VISION_EMOTION_RKNN_COLOR = os.environ.get(
    "VISION_EMOTION_RKNN_COLOR", "rgb"
).strip().lower()
VISION_EMOTION_RKNN_LABELS = os.environ.get("VISION_EMOTION_RKNN_LABELS", "").strip()
VISION_EMOTION_RKNN_LABELS_FILE = os.environ.get(
    "VISION_EMOTION_RKNN_LABELS_FILE", ""
).strip()
VISION_EMOTION_RKNN_MEAN = os.environ.get(
    "VISION_EMOTION_RKNN_MEAN", "0.485,0.456,0.406"
).strip()
VISION_EMOTION_RKNN_STD = os.environ.get(
    "VISION_EMOTION_RKNN_STD", "0.229,0.224,0.225"
).strip()
VISION_EMOTION_RKNN_SOFTMAX = os.environ.get("VISION_EMOTION_RKNN_SOFTMAX", "1") not in (
    "0",
    "false",
    "False",
)
VISION_EMOTION_MAX_PERSONS = max(
    1, min(8, int(os.environ.get("VISION_EMOTION_MAX_PERSONS", "3")))
)
VISION_EMOTION_MIN_CONFIDENCE = max(
    0.0, min(1.0, float(os.environ.get("VISION_EMOTION_MIN_CONFIDENCE", "0.45")))
)
VISION_EMOTION_HEAD_RATIO = max(
    0.35, min(0.9, float(os.environ.get("VISION_EMOTION_HEAD_RATIO", "0.58")))
)
VISION_EMOTION_HEAD_WIDTH_RATIO = max(
    0.4, min(1.0, float(os.environ.get("VISION_EMOTION_HEAD_WIDTH_RATIO", "0.62")))
)
VISION_EMOTION_UPDATE_INTERVAL_MS = max(
    0.0, min(10000.0, float(os.environ.get("VISION_EMOTION_UPDATE_INTERVAL_MS", "900")))
)
VISION_EMOTION_CACHE_TTL_MS = max(
    250.0, min(15000.0, float(os.environ.get("VISION_EMOTION_CACHE_TTL_MS", "3000")))
)
VISION_EMOTION_CACHE_MATCH_IOU = max(
    0.05, min(0.95, float(os.environ.get("VISION_EMOTION_CACHE_MATCH_IOU", "0.45")))
)
VISION_EMOTION_CACHE_MAX_CENTER_DIST = max(
    0.05,
    min(
        1.5,
        float(os.environ.get("VISION_EMOTION_CACHE_MAX_CENTER_DIST", "0.40")),
    ),
)
VISION_EMOTION_REQUIRE_FACE = os.environ.get("VISION_EMOTION_REQUIRE_FACE", "1") not in (
    "0",
    "false",
    "False",
)
VISION_EMOTION_FACE_DETECTOR = os.environ.get("VISION_EMOTION_FACE_DETECTOR", "yunet").strip().lower()
VISION_FACE_DETECTOR = os.environ.get("VISION_FACE_DETECTOR", "").strip().lower()
VISION_EMOTION_FACE_MODEL = os.environ.get(
    "VISION_EMOTION_FACE_MODEL", str(BASE_DIR / "models/face_detection_yunet_2023mar.onnx")
).strip()
VISION_EMOTION_FACE_INPUT_SIZE = max(
    128, min(1280, int(os.environ.get("VISION_EMOTION_FACE_INPUT_SIZE", "640")))
)
VISION_EMOTION_FACE_SCORE = max(
    0.05, min(1.0, float(os.environ.get("VISION_EMOTION_FACE_SCORE", "0.35")))
)
VISION_EMOTION_FACE_NMS = max(
    0.05, min(1.0, float(os.environ.get("VISION_EMOTION_FACE_NMS", "0.30")))
)
VISION_EMOTION_FACE_TOPK = max(1, min(256, int(os.environ.get("VISION_EMOTION_FACE_TOPK", "20"))))
VISION_EMOTION_FACE_EXPAND = max(
    1.0, min(2.0, float(os.environ.get("VISION_EMOTION_FACE_EXPAND", "1.20")))
)
VISION_EMOTION_FACE_MIN_SIZE = max(
    16, min(512, int(os.environ.get("VISION_EMOTION_FACE_MIN_SIZE", "28")))
)
VISION_FACE_RKNN_MODEL = os.environ.get(
    "VISION_FACE_RKNN_MODEL", str(BASE_DIR / "models/face_detection_yunet_2023mar_int8.rknn")
).strip()
VISION_FACE_RKNN_INPUT = max(
    128, min(1280, int(os.environ.get("VISION_FACE_RKNN_INPUT", "640")))
)
VISION_FACE_RKNN_CONF = max(
    0.01, min(1.0, float(os.environ.get("VISION_FACE_RKNN_CONF", "0.30")))
)
VISION_FACE_RKNN_NMS = max(
    0.05, min(1.0, float(os.environ.get("VISION_FACE_RKNN_NMS", "0.45")))
)
VISION_FACE_RKNN_CLASS_ID = int(os.environ.get("VISION_FACE_RKNN_CLASS_ID", "0"))
VISION_FACE_RKNN_CORE = os.environ.get(
    "VISION_FACE_RKNN_CORE", VISION_YOLO_RKNN_CORE
).strip().lower()
VISION_FACE_RKNN_TYPE = os.environ.get("VISION_FACE_RKNN_TYPE", "auto").strip().lower()
VISION_PERSON_HEAD_BOX_TOP_RATIO = max(
    0.20, min(0.80, float(os.environ.get("VISION_PERSON_HEAD_BOX_TOP_RATIO", "0.40")))
)
VISION_PERSON_HEAD_BOX_WIDTH_RATIO = max(
    0.20, min(1.00, float(os.environ.get("VISION_PERSON_HEAD_BOX_WIDTH_RATIO", "0.52")))
)
VISION_PERSON_HEAD_FACE_DETECT_LIVE = os.environ.get(
    "VISION_PERSON_HEAD_FACE_DETECT_LIVE", "0"
) not in (
    "0",
    "false",
    "False",
)
VISION_FACE_ONLY = os.environ.get("VISION_FACE_ONLY", "0") not in (
    "0",
    "false",
    "False",
)
VISION_FACE_ONLY_USE_YOLO_WORLD = os.environ.get(
    "VISION_FACE_ONLY_USE_YOLO_WORLD", "1"
) not in (
    "0",
    "false",
    "False",
)
VISION_FACE_ONLY_WORLD_STRICT = os.environ.get(
    "VISION_FACE_ONLY_WORLD_STRICT", "0"
) not in (
    "0",
    "false",
    "False",
)
VISION_FACE_DETECT_MAX_SIDE = max(
    0, min(1920, int(os.environ.get("VISION_FACE_DETECT_MAX_SIDE", "960")))
)
VISION_FACE_UPDATE_INTERVAL_MS = max(
    0.0, min(5000.0, float(os.environ.get("VISION_FACE_UPDATE_INTERVAL_MS", "120")))
)
VISION_FACE_ATTR_EXPAND = max(
    1.0, min(2.0, float(os.environ.get("VISION_FACE_ATTR_EXPAND", "1.20")))
)
VISION_FACE_MAX_OBJECTS = max(1, min(4, int(os.environ.get("VISION_FACE_MAX_OBJECTS", "1"))))
VISION_FACE_MAX_AREA_RATIO = max(
    0.05, min(0.95, float(os.environ.get("VISION_FACE_MAX_AREA_RATIO", "0.55")))
)
VISION_FACE_MIN_ASPECT_RATIO = max(
    0.20, min(2.50, float(os.environ.get("VISION_FACE_MIN_ASPECT_RATIO", "0.45")))
)
VISION_FACE_MAX_ASPECT_RATIO = max(
    0.30, min(3.50, float(os.environ.get("VISION_FACE_MAX_ASPECT_RATIO", "1.70")))
)
VISION_FACE_MIN_SCORE = max(0.05, min(0.99, float(os.environ.get("VISION_FACE_MIN_SCORE", "0.40"))))
VISION_FACE_RECOGNITION_ENABLED = os.environ.get("VISION_FACE_RECOGNITION_ENABLED", "0") not in (
    "0",
    "false",
    "False",
)
VISION_FACE_RECOGNITION_AUTO = os.environ.get("VISION_FACE_RECOGNITION_AUTO", "1") not in (
    "0",
    "false",
    "False",
)
VISION_FACE_RECOGNITION_MODEL = os.environ.get(
    "VISION_FACE_RECOGNITION_MODEL", str(BASE_DIR / "models/face_recognition_sface_2021dec.onnx")
).strip()
VISION_FACE_RECOGNITION_BACKEND = os.environ.get(
    "VISION_FACE_RECOGNITION_BACKEND", "auto"
).strip().lower()
VISION_FACE_RECOGNITION_TARGET = os.environ.get(
    "VISION_FACE_RECOGNITION_TARGET", "auto"
).strip().lower()
VISION_FACE_RECOGNITION_GALLERY_DIR = os.environ.get(
    "VISION_FACE_RECOGNITION_GALLERY_DIR", str(BASE_DIR / "runtime/face_gallery")
).strip()
VISION_ACCOUNT_STORE_DIR = os.environ.get(
    "VISION_ACCOUNT_STORE_DIR", str(BASE_DIR / "runtime/account_store")
).strip()
VISION_ATTENDANCE_RECHECK_INTERVAL_MINUTES = max(
    1,
    min(10080, int(os.environ.get("VISION_ATTENDANCE_RECHECK_INTERVAL_MINUTES", "1440"))),
)
VISION_FACE_RECOGNITION_THRESHOLD = max(
    0.0, min(1.0, float(os.environ.get("VISION_FACE_RECOGNITION_THRESHOLD", "0.58")))
)
VISION_FACE_RECOGNITION_PEAK_THRESHOLD = max(
    0.0, min(1.0, float(os.environ.get("VISION_FACE_RECOGNITION_PEAK_THRESHOLD", "0.68")))
)
VISION_FACE_RECOGNITION_SUPPORT_THRESHOLD = max(
    0.0,
    min(1.0, float(os.environ.get("VISION_FACE_RECOGNITION_SUPPORT_THRESHOLD", "0.52"))),
)
VISION_FACE_RECOGNITION_MIN_SUPPORT = max(
    1, min(16, int(os.environ.get("VISION_FACE_RECOGNITION_MIN_SUPPORT", "3")))
)
VISION_FACE_RECOGNITION_TOPK = max(
    1, min(8, int(os.environ.get("VISION_FACE_RECOGNITION_TOPK", "3")))
)
VISION_FACE_RECOGNITION_MIN_FACE_SIZE = max(
    20, min(2048, int(os.environ.get("VISION_FACE_RECOGNITION_MIN_FACE_SIZE", "40")))
)
VISION_FACE_RECOGNITION_MIN_SCORE = max(
    0.0, min(1.0, float(os.environ.get("VISION_FACE_RECOGNITION_MIN_SCORE", "0.55")))
)
VISION_FACE_RECOGNITION_MAX_YAW_DEG = max(
    0.0, min(90.0, float(os.environ.get("VISION_FACE_RECOGNITION_MAX_YAW_DEG", "18"))))
VISION_FACE_RECOGNITION_MAX_PITCH_DEG = max(
    0.0, min(90.0, float(os.environ.get("VISION_FACE_RECOGNITION_MAX_PITCH_DEG", "15"))))
VISION_FACE_RECOGNITION_MAX_ROLL_DEG = max(
    0.0, min(90.0, float(os.environ.get("VISION_FACE_RECOGNITION_MAX_ROLL_DEG", "18"))))
VISION_FACE_RECOGNITION_UNKNOWN_LABEL = (
    os.environ.get("VISION_FACE_RECOGNITION_UNKNOWN_LABEL", "unknown").strip() or "unknown"
)
VISION_AUTO_RECOVER = os.environ.get("VISION_AUTO_RECOVER", "1") not in (
    "0",
    "false",
    "False",
)
VISION_AUTO_RECOVER_FAIL_THRESHOLD = int(
    os.environ.get("VISION_AUTO_RECOVER_FAIL_THRESHOLD", "12")
)
VISION_AUTO_RECOVER_STALE_THRESHOLD_MS = float(
    os.environ.get("VISION_AUTO_RECOVER_STALE_THRESHOLD_MS", "1500")
)
VISION_AUTO_RECOVER_COOLDOWN_SEC = float(
    os.environ.get("VISION_AUTO_RECOVER_COOLDOWN_SEC", "8")
)
VISION_AUTO_RECOVER_SCRIPT = os.environ.get(
    "VISION_AUTO_RECOVER_SCRIPT", "/root/custom-monitor/reset-camera-link.sh"
).strip()
VISION_USB_DEVICE = os.environ.get("VISION_USB_DEVICE", "").strip()
VISION_GIMBAL_SERIAL_PORT = os.environ.get("VISION_GIMBAL_SERIAL_PORT", "").strip()
VISION_GIMBAL_ENABLED = os.environ.get(
    "VISION_GIMBAL_ENABLED",
    "1" if VISION_GIMBAL_SERIAL_PORT else "0",
) not in ("0", "false", "False")
VISION_GIMBAL_SERIAL_BAUD = int(os.environ.get("VISION_GIMBAL_SERIAL_BAUD", "1152000"))
VISION_GIMBAL_SERIAL_TIMEOUT_SEC = max(
    0.0, float(os.environ.get("VISION_GIMBAL_SERIAL_TIMEOUT_SEC", "0.0"))
)
VISION_GIMBAL_RX_MONITOR = os.environ.get("VISION_GIMBAL_RX_MONITOR", "1") not in (
    "0",
    "false",
    "False",
)
VISION_GIMBAL_RX_PREVIEW_BYTES = max(
    16, min(4096, int(os.environ.get("VISION_GIMBAL_RX_PREVIEW_BYTES", "96")))
)
VISION_GIMBAL_RPM_LIMIT = max(
    1.0, min(120.0, float(os.environ.get("VISION_GIMBAL_RPM_LIMIT", "50.0")))
)
VISION_GIMBAL_DEFAULT_LASER_FLAG = int(
    os.environ.get("VISION_GIMBAL_DEFAULT_LASER_FLAG", "2")
)
VISION_GIMBAL_DEFAULT_ENABLED_FLAG = int(
    os.environ.get("VISION_GIMBAL_DEFAULT_ENABLED_FLAG", "1")
)
VISION_GIMBAL_DEFAULT_STABILITY_FLAG = int(
    os.environ.get("VISION_GIMBAL_DEFAULT_STABILITY_FLAG", "2")
)
VISION_GIMBAL_DEFAULT_AUTO_STOP_MS = max(
    0, min(5000, int(os.environ.get("VISION_GIMBAL_DEFAULT_AUTO_STOP_MS", "220")))
)
VISION_GIMBAL_IDLE_YAW_TRIM_RPM = max(
    -1.0, min(1.0, float(os.environ.get("VISION_GIMBAL_IDLE_YAW_TRIM_RPM", "0.0")))
)
VISION_GIMBAL_IDLE_PITCH_TRIM_RPM = max(
    -1.0, min(1.0, float(os.environ.get("VISION_GIMBAL_IDLE_PITCH_TRIM_RPM", "0.0")))
)
VISION_GIMBAL_LOCK_TIMEOUT_MAX_SEC = max(
    60.0, min(86400.0, float(os.environ.get("VISION_GIMBAL_LOCK_TIMEOUT_MAX_SEC", "86400.0")))
)
VISION_GIMBAL_LOCK_TIMEOUT_SEC = max(
    1.0,
    min(
        VISION_GIMBAL_LOCK_TIMEOUT_MAX_SEC,
        float(os.environ.get("VISION_GIMBAL_LOCK_TIMEOUT_SEC", "12.0")),
    ),
)
VISION_GIMBAL_LOCK_LOOP_INTERVAL_SEC = max(
    0.03, min(0.5, float(os.environ.get("VISION_GIMBAL_LOCK_LOOP_INTERVAL_SEC", "0.10")))
)
VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX = max(
    2.0, min(320.0, float(os.environ.get("VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX", "26.0")))
)
VISION_GIMBAL_LOCK_HOLD_TOLERANCE_SCALE = max(
    1.0, min(3.0, float(os.environ.get("VISION_GIMBAL_LOCK_HOLD_TOLERANCE_SCALE", "1.35")))
)
VISION_GIMBAL_LOCK_STABLE_FRAMES = max(
    1, min(60, int(os.environ.get("VISION_GIMBAL_LOCK_STABLE_FRAMES", "10")))
)
VISION_GIMBAL_LOCK_MIN_SCORE = max(
    0.01, min(0.99, float(os.environ.get("VISION_GIMBAL_LOCK_MIN_SCORE", "0.35")))
)
VISION_GIMBAL_LOCK_MAX_RPM = max(
    1.0, min(50.0, float(os.environ.get("VISION_GIMBAL_LOCK_MAX_RPM", "18.0")))
)
VISION_GIMBAL_LOCK_KP_YAW = max(
    0.001, min(1.0, float(os.environ.get("VISION_GIMBAL_LOCK_KP_YAW", "0.035")))
)
VISION_GIMBAL_LOCK_KP_PITCH = max(
    0.001, min(1.0, float(os.environ.get("VISION_GIMBAL_LOCK_KP_PITCH", "0.035")))
)
VISION_GIMBAL_LOCK_ERR_EMA_ALPHA = max(
    0.05, min(1.0, float(os.environ.get("VISION_GIMBAL_LOCK_ERR_EMA_ALPHA", "0.35")))
)
VISION_GIMBAL_LOCK_CMD_MIN_RPM = max(
    0.0, min(3.0, float(os.environ.get("VISION_GIMBAL_LOCK_CMD_MIN_RPM", "0.25")))
)
VISION_GIMBAL_LOCK_BRAKE_ZONE_PX = max(
    4.0, min(640.0, float(os.environ.get("VISION_GIMBAL_LOCK_BRAKE_ZONE_PX", "140.0")))
)
VISION_GIMBAL_LOCK_BRAKE_MIN_SCALE = max(
    0.05, min(1.0, float(os.environ.get("VISION_GIMBAL_LOCK_BRAKE_MIN_SCALE", "0.28")))
)
VISION_GIMBAL_LOCK_CMD_SLEW_RPM_PER_SEC = max(
    0.0, min(400.0, float(os.environ.get("VISION_GIMBAL_LOCK_CMD_SLEW_RPM_PER_SEC", "80.0")))
)
VISION_GIMBAL_LOCK_INVERT_YAW = os.environ.get("VISION_GIMBAL_LOCK_INVERT_YAW", "1") not in (
    "0",
    "false",
    "False",
)
VISION_GIMBAL_LOCK_INVERT_PITCH = os.environ.get("VISION_GIMBAL_LOCK_INVERT_PITCH", "0") not in (
    "0",
    "false",
    "False",
)
VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM = max(
    0.0, min(40.0, float(os.environ.get("VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM", "7.0")))
)
VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS = max(
    0, min(1200, int(os.environ.get("VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS", "180")))
)
VISION_GIMBAL_LOCK_SEARCH_SPIN_DEG = max(
    30.0, min(2160.0, float(os.environ.get("VISION_GIMBAL_LOCK_SEARCH_SPIN_DEG", "360.0")))
)
VISION_GIMBAL_LOCK_SEARCH_SPIN_CLOCKWISE = os.environ.get(
    "VISION_GIMBAL_LOCK_SEARCH_SPIN_CLOCKWISE", "1"
) not in ("0", "false", "False")
VISION_GIMBAL_LOCK_LASER_BLINKS = max(
    0, min(12, int(os.environ.get("VISION_GIMBAL_LOCK_LASER_BLINKS", "3")))
)
VISION_GIMBAL_LOCK_LASER_ON_MS = max(
    40, min(1000, int(os.environ.get("VISION_GIMBAL_LOCK_LASER_ON_MS", "150")))
)
VISION_GIMBAL_LOCK_LASER_OFF_MS = max(
    40, min(1000, int(os.environ.get("VISION_GIMBAL_LOCK_LASER_OFF_MS", "150")))
)
VISION_GIMBAL_LOCK_SINGLE_FACE_TARGET = os.environ.get(
    "VISION_GIMBAL_LOCK_SINGLE_FACE_TARGET", "1"
) not in ("0", "false", "False")
VISION_GIMBAL_LOCK_FACE_KEEP_IOU = max(
    0.0, min(1.0, float(os.environ.get("VISION_GIMBAL_LOCK_FACE_KEEP_IOU", "0.18")))
)
VISION_GIMBAL_LOCK_FACE_KEEP_CENTER_NORM = max(
    0.01,
    min(1.0, float(os.environ.get("VISION_GIMBAL_LOCK_FACE_KEEP_CENTER_NORM", "0.08"))),
)
VISION_GIMBAL_LOCK_FACE_MISS_GRACE_FRAMES = max(
    0, min(120, int(os.environ.get("VISION_GIMBAL_LOCK_FACE_MISS_GRACE_FRAMES", "6")))
)
VISION_GIMBAL_LOCK_FACE_SWITCH_CONFIRM_FRAMES = max(
    1,
    min(60, int(os.environ.get("VISION_GIMBAL_LOCK_FACE_SWITCH_CONFIRM_FRAMES", "4"))),
)

# Human-like targets are routed to face detector in gimbal auto mode.
VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS = {
    "person",
    "human",
    "people",
    "man",
    "woman",
    "boy",
    "girl",
    "face",
    "head",
    "人",
    "人员",
    "行人",
    "人脸",
}
VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM = {
    re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(item or "").strip().lower())
    for item in VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS
    if str(item or "").strip()
}
VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM.discard("")

# Per-detector control presets for single-model lock stability.
VISION_GIMBAL_LOCK_DETECTOR_PRESETS: dict[str, dict[str, float | int]] = {
    "face": {
        "stable_frames": int(max(1, min(60, round(VISION_GIMBAL_LOCK_STABLE_FRAMES * 0.8)))),
        "center_tolerance_px": float(
            max(2.0, min(320.0, VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX * 0.85))
        ),
        "min_score": float(max(0.01, min(0.99, max(VISION_GIMBAL_LOCK_MIN_SCORE, VISION_FACE_MIN_SCORE)))),
        "max_rpm": float(max(1.0, min(50.0, VISION_GIMBAL_LOCK_MAX_RPM * 0.90))),
        "kp_yaw": float(max(0.001, min(1.0, VISION_GIMBAL_LOCK_KP_YAW * 1.10))),
        "kp_pitch": float(max(0.001, min(1.0, VISION_GIMBAL_LOCK_KP_PITCH * 1.10))),
        "search_sweep_rpm": float(max(0.0, min(40.0, VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM * 0.85))),
        "search_sweep_pulse_ms": int(
            max(0, min(1200, round(VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS * 0.9)))
        ),
    },
    "yolo_world": {
        "stable_frames": int(max(1, min(60, VISION_GIMBAL_LOCK_STABLE_FRAMES))),
        "center_tolerance_px": float(
            max(2.0, min(320.0, VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX * 1.10))
        ),
        "min_score": float(
            max(
                0.01,
                min(
                    0.99,
                    max(
                        VISION_YOLO_WORLD_CONF,
                        VISION_GIMBAL_LOCK_MIN_SCORE * 0.80,
                    ),
                ),
            )
        ),
        "max_rpm": float(max(1.0, min(50.0, VISION_GIMBAL_LOCK_MAX_RPM))),
        "kp_yaw": float(max(0.001, min(1.0, VISION_GIMBAL_LOCK_KP_YAW * 0.95))),
        "kp_pitch": float(max(0.001, min(1.0, VISION_GIMBAL_LOCK_KP_PITCH * 0.95))),
        "search_sweep_rpm": float(max(0.0, min(40.0, VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM * 1.10))),
        "search_sweep_pulse_ms": int(
            max(0, min(1200, round(VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS * 1.1)))
        ),
    },
    "yolo": {
        "stable_frames": int(max(1, min(60, VISION_GIMBAL_LOCK_STABLE_FRAMES))),
        "center_tolerance_px": float(
            max(2.0, min(320.0, VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX))
        ),
        "min_score": float(max(0.01, min(0.99, max(VISION_GIMBAL_LOCK_MIN_SCORE, VISION_YOLO_CONF)))),
        "max_rpm": float(max(1.0, min(50.0, VISION_GIMBAL_LOCK_MAX_RPM))),
        "kp_yaw": float(max(0.001, min(1.0, VISION_GIMBAL_LOCK_KP_YAW))),
        "kp_pitch": float(max(0.001, min(1.0, VISION_GIMBAL_LOCK_KP_PITCH))),
        "search_sweep_rpm": float(max(0.0, min(40.0, VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM))),
        "search_sweep_pulse_ms": int(
            max(0, min(1200, VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS))
        ),
    },
}

def _ts_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def read_text(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8").strip()
    except (FileNotFoundError, PermissionError, OSError):
        return ""


def read_int(path: str) -> int | None:
    text = read_text(path)
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        return None


def parse_int_list(text: str) -> list[int]:
    raw = (text or "").replace(",", " ").split()
    out: list[int] = []
    for item in raw:
        try:
            out.append(int(item))
        except ValueError:
            continue
    return out


def parse_float_list(text: str) -> list[float]:
    raw = (text or "").replace(",", " ").split()
    out: list[float] = []
    for item in raw:
        try:
            out.append(float(item))
        except ValueError:
            continue
    return out


def parse_camera_value(raw: str) -> int | str:
    text = (raw or "").strip()
    if not text:
        return 0
    try:
        return int(text)
    except ValueError:
        return text


def camera_to_device(camera: Any) -> str:
    if isinstance(camera, int):
        return f"/dev/video{camera}"
    text = str(camera or "").strip()
    if not text:
        return "/dev/video0"
    if text.startswith("/dev/"):
        return text
    if text.startswith("video"):
        return f"/dev/{text}"
    if text.startswith("v4l/"):
        return f"/dev/{text}"
    return text


def camera_to_label(camera: Any) -> str:
    if isinstance(camera, int):
        return f"index={camera}"
    return camera_to_device(camera)


VISION_CAMERA = parse_camera_value(VISION_CAMERA_RAW)

WEAR_GLASSES_POSITIVE_PROMPTS = [
    "a portrait of a person wearing eyeglasses",
    "a person with glasses on face",
    "a person wearing spectacles",
]
WEAR_GLASSES_NEGATIVE_PROMPTS = [
    "a portrait of a person without eyeglasses",
    "a person without glasses",
    "a person with naked eyes",
]

EMOTION_LABEL_ALIAS = {
    "anger": "anger",
    "contempt": "contempt",
    "disgust": "disgust",
    "fear": "fear",
    "happiness": "happy",
    "neutral": "neutral",
    "sadness": "sad",
    "surprise": "surprise",
}

EMOTION_RKNN_DEFAULT_LABELS = [
    "anger",
    "contempt",
    "disgust",
    "fear",
    "happiness",
    "neutral",
    "sadness",
    "surprise",
]

YUNET_MODEL_URLS = (
    "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/"
    "face_detection_yunet_2023mar.onnx",
    "https://huggingface.co/opencv/face_detection_yunet/resolve/main/"
    "face_detection_yunet_2023mar.onnx",
)
YUNET_MODEL_MIN_BYTES = 100_000


class GimbalSerialBridge:
    RX_STATUS_FRAME_SIZE = 32

    def __init__(
        self,
        *,
        enabled: bool,
        port: str,
        baudrate: int,
        timeout_sec: float,
        rx_monitor: bool,
        rx_preview_bytes: int,
        rpm_limit: float,
        default_laser_flag: int,
        default_enabled_flag: int,
        default_stability_flag: int,
        default_auto_stop_ms: int,
        idle_yaw_trim_rpm: float,
        idle_pitch_trim_rpm: float,
    ) -> None:
        self.enabled = bool(enabled)
        self.port = str(port or "").strip()
        self.baudrate = max(1200, int(baudrate))
        self.timeout_sec = max(0.0, float(timeout_sec))
        self.rx_monitor = bool(rx_monitor)
        self.rx_preview_bytes = max(16, min(4096, int(rx_preview_bytes)))
        self.rpm_limit = max(1.0, float(rpm_limit))
        self.default_laser_flag = self._normalize_flag(default_laser_flag, fallback=2)
        self.default_enabled_flag = self._normalize_flag(default_enabled_flag, fallback=1)
        self.default_stability_flag = self._normalize_flag(default_stability_flag, fallback=2)
        self.default_auto_stop_ms = max(0, min(5000, int(default_auto_stop_ms)))
        self.idle_yaw_trim_rpm = max(-1.0, min(1.0, float(idle_yaw_trim_rpm)))
        self.idle_pitch_trim_rpm = max(-1.0, min(1.0, float(idle_pitch_trim_rpm)))

        self._lock = threading.Lock()
        self._ser: Any | None = None
        self._auto_stop_timer: threading.Timer | None = None
        self._last_error = ""
        self._last_send_ts = 0.0
        self._last_command: dict[str, Any] | None = None
        self._last_packet_hex = ""
        self._last_rx_ts = 0.0
        self._last_rx_hex = ""
        self._last_rx_error = ""
        self._rx_bytes_total = 0
        self._rx_frames_total = 0
        self._rx_valid_frames_total = 0
        self._rx_drop_bytes_total = 0
        self._rx_parse_errors_total = 0
        self._rx_window = bytearray()
        self._rx_sync_locked = False
        self._rx_sync_min_frames = 4
        self._last_feedback: dict[str, Any] | None = None
        self._last_feedback_ts = 0.0

    @staticmethod
    def _normalize_flag(value: Any, fallback: int = 2) -> int:
        try:
            flag = int(value)
        except (TypeError, ValueError):
            flag = int(fallback)
        if flag not in (0, 1, 2):
            flag = int(fallback)
        return flag

    @staticmethod
    def _coerce_flag(value: Any) -> int | None:
        if value is None:
            return None
        if isinstance(value, bool):
            return 1 if value else 0
        if isinstance(value, (int, float)):
            iv = int(value)
            return iv if iv in (0, 1, 2) else None
        text = str(value or "").strip().lower()
        if not text:
            return None
        if text in ("0", "false", "off", "disable", "disabled", "no"):
            return 0
        if text in ("1", "true", "on", "enable", "enabled", "yes"):
            return 1
        if text in ("2", "keep", "noop", "no_action", "none"):
            return 2
        return None

    @staticmethod
    def _checksum_mod_256(payload: bytes) -> int:
        return int(sum(payload) & 0xFF)

    def _build_packet(
        self,
        *,
        yaw_rpm: float,
        pitch_rpm: float,
        laser_flag: int,
        enabled_flag: int,
        stability_flag: int,
    ) -> bytes:
        import struct

        header = struct.pack(
            "<ffBBB",
            float(yaw_rpm),
            float(pitch_rpm),
            int(laser_flag) & 0xFF,
            int(enabled_flag) & 0xFF,
            int(stability_flag) & 0xFF,
        )
        checksum = self._checksum_mod_256(header)
        return header + struct.pack("<B", checksum)

    def _cancel_auto_stop_locked(self) -> None:
        timer = self._auto_stop_timer
        self._auto_stop_timer = None
        if timer is None:
            return
        try:
            timer.cancel()
        except Exception:
            pass

    def _close_locked(self) -> None:
        ser = self._ser
        self._ser = None
        if ser is None:
            return
        try:
            close_fn = getattr(ser, "close", None)
            if callable(close_fn):
                close_fn()
        except Exception:
            pass

    def close(self) -> None:
        with self._lock:
            self._cancel_auto_stop_locked()
            self._close_locked()

    def _ensure_open_locked(self) -> tuple[bool, str]:
        if not self.enabled:
            return False, "gimbal serial disabled by VISION_GIMBAL_ENABLED=0"
        if not self.port:
            return False, "gimbal serial port not configured (VISION_GIMBAL_SERIAL_PORT)"

        ser = self._ser
        if ser is not None:
            try:
                if bool(getattr(ser, "is_open", True)):
                    return True, ""
            except Exception:
                pass
            self._close_locked()

        try:
            import serial  # type: ignore
        except Exception as exc:
            return False, f"pyserial unavailable: {exc}"

        try:
            self._ser = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout_sec,
                write_timeout=max(0.0, self.timeout_sec),
            )
            return True, ""
        except Exception as exc:
            self._close_locked()
            return False, f"serial open failed: {exc}"

    def _drain_rx_locked(self, max_chunks: int = 8) -> None:
        if not self.rx_monitor:
            return
        ser = self._ser
        if ser is None:
            return
        read_fn = getattr(ser, "read", None)
        if not callable(read_fn):
            return
        chunks = max(1, min(64, int(max_chunks)))
        for _ in range(chunks):
            try:
                waiting = int(getattr(ser, "in_waiting", 0) or 0)
            except Exception:
                waiting = 0
            if waiting <= 0:
                break
            read_size = max(1, min(waiting, 4096))
            try:
                raw = read_fn(read_size)
            except Exception as exc:
                self._last_rx_error = f"serial read failed: {exc}"
                break
            data = bytes(raw or b"")
            if not data:
                break
            self._last_rx_ts = time.time()
            self._rx_bytes_total += int(len(data))
            self._rx_frames_total += 1
            self._last_rx_hex = data[-self.rx_preview_bytes :].hex()
            self._last_rx_error = ""
            self._ingest_rx_data_locked(data)

    @staticmethod
    def _decode_rx_status_frame(frame: bytes) -> dict[str, Any]:
        import struct

        vals = struct.unpack("<7f4B", frame)
        return {
            "imu_angles_rad": {
                "yaw": round(float(vals[0]), 6),
                "pitch": round(float(vals[1]), 6),
                "roll": round(float(vals[2]), 6),
            },
            "yaw_imu_angle_rad": round(float(vals[3]), 6),
            "pitch_imu_angle_rad": round(float(vals[4]), 6),
            "yaw_motor_angle_rad": round(float(vals[5]), 6),
            "pitch_motor_angle_rad": round(float(vals[6]), 6),
            "laser_enabled": int(vals[7]),
            "enabled": int(vals[8]),
            "stability_enabled": int(vals[9]),
            "check_sum": int(vals[10]),
        }

    @staticmethod
    def _is_valid_rx_status_frame(frame: bytes) -> bool:
        if len(frame) != int(GimbalSerialBridge.RX_STATUS_FRAME_SIZE):
            return False
        if (sum(frame[:-1]) & 0xFF) != int(frame[-1]):
            return False
        laser = int(frame[28])
        enabled = int(frame[29])
        stability = int(frame[30])
        if laser not in (0, 1) or enabled not in (0, 1) or stability not in (0, 1):
            return False
        return True

    def _find_rx_sync_offset(self, min_frames: int) -> int:
        frame_size = int(self.RX_STATUS_FRAME_SIZE)
        count = max(2, min(12, int(min_frames)))
        need = frame_size * count
        if len(self._rx_window) < need:
            return -1
        limit = len(self._rx_window) - need + 1
        for pos in range(limit):
            ok = True
            for k in range(count):
                start = pos + k * frame_size
                frame = self._rx_window[start : start + frame_size]
                if not self._is_valid_rx_status_frame(frame):
                    ok = False
                    break
            if ok:
                return pos
        return -1

    def _ingest_rx_data_locked(self, data: bytes) -> None:
        if not data:
            return
        frame_size = int(self.RX_STATUS_FRAME_SIZE)
        self._rx_window.extend(data)
        max_window = max(frame_size * 512, 4096)
        if len(self._rx_window) > max_window:
            drop_count = int(len(self._rx_window) - max_window)
            if drop_count > 0:
                del self._rx_window[:drop_count]
                self._rx_drop_bytes_total += drop_count

        while True:
            if not self._rx_sync_locked:
                sync_pos = self._find_rx_sync_offset(self._rx_sync_min_frames)
                if sync_pos < 0:
                    keep_tail = max(frame_size * self._rx_sync_min_frames - 1, frame_size - 1)
                    drop_count = max(0, len(self._rx_window) - keep_tail)
                    if drop_count > 0:
                        del self._rx_window[:drop_count]
                        self._rx_drop_bytes_total += drop_count
                    break
                if sync_pos > 0:
                    del self._rx_window[:sync_pos]
                    self._rx_drop_bytes_total += sync_pos
                self._rx_sync_locked = True

            if len(self._rx_window) < frame_size:
                break

            frame = bytes(self._rx_window[:frame_size])
            if not self._is_valid_rx_status_frame(frame):
                self._rx_sync_locked = False
                self._rx_parse_errors_total += 1
                del self._rx_window[:1]
                self._rx_drop_bytes_total += 1
                continue

            del self._rx_window[:frame_size]
            try:
                decoded = self._decode_rx_status_frame(frame)
            except Exception:
                self._rx_parse_errors_total += 1
                continue
            self._rx_valid_frames_total += 1
            self._last_feedback = decoded
            self._last_feedback_ts = time.time()

    def _schedule_auto_stop(
        self,
        *,
        auto_stop_ms: int,
        laser_flag: int,
        enabled_flag: int,
        stability_flag: int,
    ) -> None:
        delay_sec = max(0.0, float(auto_stop_ms) / 1000.0)
        if delay_sec <= 0:
            return

        def _stop_job() -> None:
            self.send_speed(
                yaw_rpm=0.0,
                pitch_rpm=0.0,
                laser_flag=laser_flag,
                enabled_flag=enabled_flag,
                stability_flag=stability_flag,
                auto_stop_ms=0,
                reason="auto-stop",
            )

        with self._lock:
            self._cancel_auto_stop_locked()
            timer = threading.Timer(delay_sec, _stop_job)
            timer.daemon = True
            self._auto_stop_timer = timer
            timer.start()

    def status(self) -> dict[str, Any]:
        with self._lock:
            # Allow passive telemetry monitoring even when no command has been sent yet.
            if self.enabled and self.port and self._ser is None:
                ok, err = self._ensure_open_locked()
                if not ok and err:
                    self._last_error = err
            self._drain_rx_locked()
            connected = False
            if self._ser is not None:
                try:
                    connected = bool(getattr(self._ser, "is_open", True))
                except Exception:
                    connected = True
            if self.rx_monitor:
                if self._rx_valid_frames_total > 0:
                    feedback_mode = "serial-rx-telemetry"
                else:
                    feedback_mode = "serial-rx-monitor"
            else:
                feedback_mode = "write-only"
            auto_stop_pending = bool(
                self._auto_stop_timer is not None
                and bool(getattr(self._auto_stop_timer, "is_alive", lambda: False)())
            )
            payload = {
                "ok": True,
                "timestamp": _ts_now(),
                "enabled": bool(self.enabled),
                "configured": bool(self.port),
                "port": self.port or None,
                "baudrate": int(self.baudrate),
                "timeout_sec": float(self.timeout_sec),
                "feedback_mode": feedback_mode,
                "rx_monitor": bool(self.rx_monitor),
                "rx_preview_bytes": int(self.rx_preview_bytes),
                "connected": connected,
                "rpm_limit": float(self.rpm_limit),
                "default_flags": {
                    "laser_enabled": int(self.default_laser_flag),
                    "enabled": int(self.default_enabled_flag),
                    "stability_enabled": int(self.default_stability_flag),
                },
                "default_auto_stop_ms": int(self.default_auto_stop_ms),
                "idle_trim_rpm": {
                    "yaw": round(float(self.idle_yaw_trim_rpm), 4),
                    "pitch": round(float(self.idle_pitch_trim_rpm), 4),
                },
                "last_send_at": (
                    datetime.fromtimestamp(self._last_send_ts).isoformat(timespec="seconds")
                    if self._last_send_ts > 0
                    else None
                ),
                "last_command": dict(self._last_command) if isinstance(self._last_command, dict) else None,
                "last_packet_hex": self._last_packet_hex or None,
                "last_rx_at": (
                    datetime.fromtimestamp(self._last_rx_ts).isoformat(timespec="seconds")
                    if self._last_rx_ts > 0
                    else None
                ),
                "last_rx_hex": self._last_rx_hex or None,
                "last_rx_error": self._last_rx_error or None,
                "rx_bytes_total": int(self._rx_bytes_total),
                "rx_frames_total": int(self._rx_frames_total),
                "rx_valid_frames_total": int(self._rx_valid_frames_total),
                "rx_drop_bytes_total": int(self._rx_drop_bytes_total),
                "rx_parse_errors_total": int(self._rx_parse_errors_total),
                "rx_frame_size": int(self.RX_STATUS_FRAME_SIZE),
                "last_feedback_at": (
                    datetime.fromtimestamp(self._last_feedback_ts).isoformat(timespec="seconds")
                    if self._last_feedback_ts > 0
                    else None
                ),
                "last_feedback": (
                    dict(self._last_feedback) if isinstance(self._last_feedback, dict) else None
                ),
                "last_error": self._last_error or None,
                "auto_stop_pending": auto_stop_pending,
            }
            if not self.enabled:
                payload["summary"] = "gimbal serial disabled"
            elif not self.port:
                payload["summary"] = "gimbal serial port not configured"
            elif connected:
                payload["summary"] = "gimbal serial connected"
            else:
                payload["summary"] = "gimbal serial not connected"
            return payload

    def send_speed(
        self,
        *,
        yaw_rpm: float,
        pitch_rpm: float,
        laser_flag: Any = None,
        enabled_flag: Any = None,
        stability_flag: Any = None,
        auto_stop_ms: int | None = None,
        reason: str = "manual",
    ) -> dict[str, Any]:
        yaw = float(max(-self.rpm_limit, min(self.rpm_limit, float(yaw_rpm))))
        pitch = float(max(-self.rpm_limit, min(self.rpm_limit, float(pitch_rpm))))
        tx_yaw = float(yaw)
        tx_pitch = float(pitch)
        idle_trim_applied = False
        laser = self._coerce_flag(laser_flag)
        enabled = self._coerce_flag(enabled_flag)
        stability = self._coerce_flag(stability_flag)
        if laser is None:
            laser = int(self.default_laser_flag)
        if enabled is None:
            enabled = int(self.default_enabled_flag)
        if stability is None:
            stability = int(self.default_stability_flag)
        stop_ms = (
            int(self.default_auto_stop_ms)
            if auto_stop_ms is None
            else max(0, min(5000, int(auto_stop_ms)))
        )
        if abs(tx_yaw) <= 1e-6 and abs(tx_pitch) <= 1e-6:
            trim_yaw = float(max(-self.rpm_limit, min(self.rpm_limit, self.idle_yaw_trim_rpm)))
            trim_pitch = float(max(-self.rpm_limit, min(self.rpm_limit, self.idle_pitch_trim_rpm)))
            if abs(trim_yaw) > 1e-6 or abs(trim_pitch) > 1e-6:
                tx_yaw = trim_yaw
                tx_pitch = trim_pitch
                idle_trim_applied = True
                stop_ms = 0

        send_error = ""
        with self._lock:
            ok, err = self._ensure_open_locked()
            if not ok:
                self._last_error = err
                send_error = err

            if not send_error:
                packet = self._build_packet(
                    yaw_rpm=tx_yaw,
                    pitch_rpm=tx_pitch,
                    laser_flag=laser,
                    enabled_flag=enabled,
                    stability_flag=stability,
                )
                try:
                    write_fn = getattr(self._ser, "write", None)
                    if not callable(write_fn):
                        raise RuntimeError("serial write unavailable")
                    write_fn(packet)
                    flush_fn = getattr(self._ser, "flush", None)
                    if callable(flush_fn):
                        flush_fn()
                except Exception as exc:
                    self._last_error = f"serial write failed: {exc}"
                    send_error = self._last_error
                    self._close_locked()

            if not send_error:
                self._drain_rx_locked(max_chunks=4)
                self._last_send_ts = time.time()
                self._last_packet_hex = packet.hex()
                self._last_command = {
                    "yaw_rpm": round(tx_yaw, 3),
                    "pitch_rpm": round(tx_pitch, 3),
                    "request_yaw_rpm": round(yaw, 3),
                    "request_pitch_rpm": round(pitch, 3),
                    "idle_trim_applied": bool(idle_trim_applied),
                    "laser_enabled": int(laser),
                    "enabled": int(enabled),
                    "stability_enabled": int(stability),
                    "auto_stop_ms": int(stop_ms),
                    "reason": str(reason or "manual")[:80],
                }
                self._last_error = ""

        if send_error:
            payload = self.status()
            payload["ok"] = False
            payload["error"] = send_error
            return payload

        if stop_ms > 0 and (abs(tx_yaw) > 1e-6 or abs(tx_pitch) > 1e-6):
            self._schedule_auto_stop(
                auto_stop_ms=stop_ms,
                laser_flag=laser,
                enabled_flag=enabled,
                stability_flag=stability,
            )
        else:
            with self._lock:
                self._cancel_auto_stop_locked()

        payload = self.status()
        payload["ok"] = True
        payload["command"] = dict(self._last_command) if isinstance(self._last_command, dict) else None
        payload["summary"] = (
            f"gimbal command sent yaw={tx_yaw:.2f}rpm pitch={tx_pitch:.2f}rpm"
            + (f", auto-stop {stop_ms}ms" if stop_ms > 0 else "")
            + (", idle-trim applied" if idle_trim_applied else "")
        )
        return payload


class VisionService:
    def __init__(self) -> None:
        self.enabled = VISION_ENABLED
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.capture_thread: threading.Thread | None = None
        self.wear_glasses_warmup_thread: threading.Thread | None = None
        self.emotion_warmup_thread: threading.Thread | None = None
        self.cap = None
        self.ffmpeg_proc: subprocess.Popen[bytes] | None = None
        self.ffmpeg_frame_bytes = 0
        self.ffmpeg_shape: tuple[int, int, int] | None = None
        self.pipeline_requested = (
            VISION_PIPELINE if VISION_PIPELINE in ("opencv", "ffmpeg", "auto") else "opencv"
        )
        self.pipeline_active = ""
        self.reopen_requested = False
        self.read_fail_count = 0
        self.open_fail_count = 0
        self.last_error = ""
        self.last_fail_ts = 0.0
        self.latest_frame: Any | None = None
        self.latest_frame_ts = 0.0
        self.capture_fps = 0.0
        self.last_frame_jpeg: bytes | None = None
        self.last_jpeg_ts = 0.0
        self.last_jpeg_source_ts = 0.0
        self.stream_clients: dict[str, dict[str, float]] = {}
        self.stream_enabled = VISION_STREAM_ENABLED
        self.stream_output_width = max(0, int(VISION_STREAM_WIDTH))
        self.stream_output_height = max(0, int(VISION_STREAM_HEIGHT))
        self.cv2 = None
        self.model_load_lock = threading.Lock()
        self.profiles = {
            "stable": {"width": 640, "height": 480, "fps": 30.0, "fourcc": "MJPG"},
            "smooth": {"width": 640, "height": 480, "fps": 60.0, "fourcc": "MJPG"},
            "clear": {"width": 1280, "height": 720, "fps": 30.0, "fourcc": "MJPG"},
            "clear60": {"width": 1280, "height": 720, "fps": 60.0, "fourcc": "MJPG"},
            "fullhd30": {"width": 1920, "height": 1080, "fps": 30.0, "fourcc": "MJPG"},
        }
        self.request_cfg = {
            "camera": VISION_CAMERA,
            "backend": VISION_BACKEND,
            "width": VISION_WIDTH,
            "height": VISION_HEIGHT,
            "fps": VISION_FPS,
            "fourcc": VISION_FOURCC,
            "flip": VISION_FLIP,
            "rotate": VISION_ROTATE,
        }
        self.profile_name = "custom"
        self.auto_recover = VISION_AUTO_RECOVER
        self.recover_count = 0
        self.recover_running = False
        self.last_recover_ts = 0.0
        self.last_recover_attempt_ts = 0.0
        self.last_recover_reason = ""
        self.last_recover_ok: bool | None = None
        self.last_recover_msg = ""
        self.yolo_net = None
        self.yolo_rknn = None
        self.yolo_rknn_runtime = None
        self.yolo_ort_session = None
        self.yolo_ort_input_name = ""
        self.yolo_ort_input_dtype = "tensor(float)"
        self.yolo_ort_input_layout = "nchw"
        self.yolo_backend_requested = (
            VISION_YOLO_BACKEND
            if VISION_YOLO_BACKEND in ("auto", "opencv", "onnxruntime", "rknn", "off")
            else "auto"
        )
        self.yolo_backend_active = ""
        self.yolo_error = "YOLO disabled"
        self.yolo_model_path = VISION_YOLO_MODEL
        self.yolo_rknn_model_path = (
            VISION_YOLO_RKNN_MODEL
            if VISION_YOLO_RKNN_MODEL
            else (
                str(Path(VISION_YOLO_MODEL).with_suffix(".rknn"))
                if VISION_YOLO_MODEL
                else ""
            )
        )
        self.yolo_rknn_target = VISION_YOLO_RKNN_TARGET or "rk3588"
        self.yolo_rknn_core = VISION_YOLO_RKNN_CORE or "auto"
        self.yolo_input = max(64, int(VISION_YOLO_INPUT))
        self.yolo_conf = max(0.01, min(1.0, float(VISION_YOLO_CONF)))
        self.yolo_nms = max(0.01, min(0.99, float(VISION_YOLO_NMS)))
        self.yolo_class_filter = parse_int_list(VISION_YOLO_CLASSES)
        self.yolo_anchors = self._resolve_yolo_anchors(VISION_YOLO_ANCHORS)
        self.yolo_max_objects = int(VISION_YOLO_MAX_OBJECTS)
        self.yolo_adaptive_trigger = int(VISION_YOLO_ADAPTIVE_TRIGGER)
        self.yolo_adaptive_conf = float(VISION_YOLO_ADAPTIVE_CONF)
        self.yolo_spike_count = int(VISION_YOLO_SPIKE_COUNT)
        self.yolo_spike_factor = float(VISION_YOLO_SPIKE_FACTOR)
        self.yolo_spike_confirm = int(VISION_YOLO_SPIKE_CONFIRM)
        self.yolo_world_rknn = None
        self.yolo_world_error = "YOLO-World disabled by config"
        self.yolo_world_model_path = VISION_YOLO_WORLD_MODEL
        self.yolo_world_text_path = VISION_YOLO_WORLD_TEXT
        self.yolo_world_labels_path = VISION_YOLO_WORLD_LABELS
        self.yolo_world_input = max(64, int(VISION_YOLO_WORLD_INPUT))
        self.yolo_world_conf = max(0.01, min(1.0, float(VISION_YOLO_WORLD_CONF)))
        self.yolo_world_nms = max(0.01, min(0.99, float(VISION_YOLO_WORLD_NMS)))
        self.yolo_world_max_objects = int(VISION_YOLO_WORLD_MAX_OBJECTS)
        self.yolo_world_adaptive_trigger = int(VISION_YOLO_WORLD_ADAPTIVE_TRIGGER)
        self.yolo_world_adaptive_conf = float(VISION_YOLO_WORLD_ADAPTIVE_CONF)
        self.yolo_world_spike_count = int(VISION_YOLO_WORLD_SPIKE_COUNT)
        self.yolo_world_spike_factor = float(VISION_YOLO_WORLD_SPIKE_FACTOR)
        self.yolo_world_spike_confirm = int(VISION_YOLO_WORLD_SPIKE_CONFIRM)
        self.yolo_world_pre_nms_cap = int(VISION_YOLO_WORLD_PRE_NMS_CAP)
        self.yolo_world_rknn_core = VISION_YOLO_WORLD_RKNN_CORE or "auto"
        self.yolo_world_single_flight = VISION_YOLO_WORLD_SINGLE_FLIGHT
        self.yolo_world_async_enabled = bool(VISION_YOLO_WORLD_ENABLED and VISION_YOLO_WORLD_ASYNC)
        self.yolo_world_async_fps = float(VISION_YOLO_WORLD_ASYNC_FPS)
        self.yolo_world_cache_ttl_ms = float(VISION_YOLO_WORLD_CACHE_TTL_MS)
        self.face_only_mode = bool(VISION_FACE_ONLY)
        self.face_only_world_fusion = bool(VISION_FACE_ONLY_USE_YOLO_WORLD)
        self.face_only_world_strict = bool(VISION_FACE_ONLY_WORLD_STRICT)
        self.face_detect_max_side = int(VISION_FACE_DETECT_MAX_SIDE)
        self.face_update_interval_ms = float(VISION_FACE_UPDATE_INTERVAL_MS)
        self.face_attr_expand = float(VISION_FACE_ATTR_EXPAND)
        self.face_max_objects = int(VISION_FACE_MAX_OBJECTS)
        self.face_max_area_ratio = float(VISION_FACE_MAX_AREA_RATIO)
        self.face_min_aspect_ratio = float(VISION_FACE_MIN_ASPECT_RATIO)
        self.face_max_aspect_ratio = float(
            max(VISION_FACE_MIN_ASPECT_RATIO, VISION_FACE_MAX_ASPECT_RATIO)
        )
        self.face_min_score = float(VISION_FACE_MIN_SCORE)
        self.face_cache_lock = threading.Lock()
        self.face_last_eval_ts = 0.0
        self.face_cache_ts = 0.0
        self.face_cache_source_ts = 0.0
        self.face_cache_objects: list[dict[str, Any]] = []
        self.face_cache_error = ""
        self.wear_glasses_enabled = bool(VISION_WEAR_GLASSES_ENABLED)
        self.wear_glasses_auto = bool(VISION_WEAR_GLASSES_AUTO)
        self.wear_glasses_clip_model_name = (
            str(VISION_WEAR_GLASSES_CLIP_MODEL).strip() or "ViT-B/32"
        )
        self.wear_glasses_device_request = str(VISION_WEAR_GLASSES_DEVICE or "auto").lower()
        self.wear_glasses_max_persons = int(VISION_WEAR_GLASSES_MAX_PERSONS)
        self.wear_glasses_min_margin = float(VISION_WEAR_GLASSES_MIN_MARGIN)
        self.wear_glasses_head_ratio = float(VISION_WEAR_GLASSES_HEAD_RATIO)
        self.wear_glasses_head_width_ratio = float(VISION_WEAR_GLASSES_HEAD_WIDTH_RATIO)
        self.wear_glasses_ready = False
        self.wear_glasses_error = ""
        self.wear_glasses_device_active = ""
        self.wear_glasses_model: Any | None = None
        self.wear_glasses_preprocess: Any | None = None
        self.wear_glasses_torch: Any | None = None
        self.wear_glasses_pil_image: Any | None = None
        self.wear_glasses_text_pos: Any | None = None
        self.wear_glasses_text_neg: Any | None = None
        self.wear_glasses_lock = threading.Lock()
        self.wear_glasses_infer_lock = threading.Lock()
        self.wear_glasses_cache_lock = threading.Lock()
        self.wear_glasses_refresh_lock = threading.Lock()
        self.wear_glasses_refresh_pending = False
        self.wear_glasses_update_interval_ms = float(VISION_WEAR_GLASSES_UPDATE_INTERVAL_MS)
        self.wear_glasses_cache_ttl_ms = float(VISION_WEAR_GLASSES_CACHE_TTL_MS)
        self.wear_glasses_cache_match_iou = float(VISION_WEAR_GLASSES_CACHE_MATCH_IOU)
        self.wear_glasses_cache_max_center_dist = float(
            VISION_WEAR_GLASSES_CACHE_MAX_CENTER_DIST
        )
        self.wear_glasses_last_eval_ts = 0.0
        self.wear_glasses_cache_ts = 0.0
        self.wear_glasses_cache_items: list[dict[str, Any]] = []
        self.emotion_enabled = bool(VISION_EMOTION_ENABLED)
        self.emotion_auto = bool(VISION_EMOTION_AUTO)
        self.emotion_engine = (
            VISION_EMOTION_ENGINE if VISION_EMOTION_ENGINE in ("onnx", "torch", "rknn") else "onnx"
        )
        self.emotion_model_name = str(VISION_EMOTION_MODEL).strip() or "enet_b0_8_best_vgaf"
        default_emotion_rknn = str(BASE_DIR / f"models/{self.emotion_model_name}.rknn")
        self.emotion_rknn_model_path = (
            str(VISION_EMOTION_RKNN_MODEL).strip() or default_emotion_rknn
        )
        self.emotion_rknn_input = int(VISION_EMOTION_RKNN_INPUT)
        self.emotion_rknn_core = str(VISION_EMOTION_RKNN_CORE or "auto").strip().lower()
        layout = str(VISION_EMOTION_RKNN_LAYOUT or "nhwc").strip().lower()
        self.emotion_rknn_layout = layout if layout in ("nchw", "nhwc") else "nhwc"
        dtype_name = str(VISION_EMOTION_RKNN_DTYPE or "float32").strip().lower()
        self.emotion_rknn_dtype = dtype_name if dtype_name in ("float32", "uint8") else "float32"
        color_name = str(VISION_EMOTION_RKNN_COLOR or "rgb").strip().lower()
        self.emotion_rknn_color = color_name if color_name in ("rgb", "bgr") else "rgb"
        self.emotion_rknn_labels_raw = str(VISION_EMOTION_RKNN_LABELS or "").strip()
        self.emotion_rknn_labels_file = str(VISION_EMOTION_RKNN_LABELS_FILE or "").strip()
        mean_vals = parse_float_list(VISION_EMOTION_RKNN_MEAN)
        std_vals = parse_float_list(VISION_EMOTION_RKNN_STD)
        if len(mean_vals) == 1:
            mean_vals = mean_vals * 3
        if len(std_vals) == 1:
            std_vals = std_vals * 3
        if len(mean_vals) != 3:
            mean_vals = [0.485, 0.456, 0.406]
        if len(std_vals) != 3:
            std_vals = [0.229, 0.224, 0.225]
        std_vals = [v if abs(v) > 1e-9 else 1.0 for v in std_vals]
        self.emotion_rknn_mean = np.asarray(mean_vals, dtype=np.float32).reshape(1, 1, 3)
        self.emotion_rknn_std = np.asarray(std_vals, dtype=np.float32).reshape(1, 1, 3)
        self.emotion_rknn_softmax = bool(VISION_EMOTION_RKNN_SOFTMAX)
        self.emotion_max_persons = int(VISION_EMOTION_MAX_PERSONS)
        self.emotion_min_confidence = float(VISION_EMOTION_MIN_CONFIDENCE)
        self.emotion_head_ratio = float(VISION_EMOTION_HEAD_RATIO)
        self.emotion_head_width_ratio = float(VISION_EMOTION_HEAD_WIDTH_RATIO)
        self.emotion_require_face = bool(VISION_EMOTION_REQUIRE_FACE)
        face_detector_requested = str(
            VISION_FACE_DETECTOR or VISION_EMOTION_FACE_DETECTOR or "yunet"
        ).strip().lower()
        if face_detector_requested not in ("auto", "yunet", "haar", "rknn", "none"):
            face_detector_requested = "yunet"
        self.emotion_face_detector_requested = face_detector_requested
        self.emotion_face_detector_active = "none"
        # Keep legacy field for backward compatibility in payloads.
        self.emotion_face_detector = face_detector_requested
        self.emotion_face_model_path = str(VISION_EMOTION_FACE_MODEL).strip()
        self.emotion_face_rknn_model_path = str(VISION_FACE_RKNN_MODEL).strip()
        self.emotion_face_rknn_input = int(VISION_FACE_RKNN_INPUT)
        self.emotion_face_rknn_conf = float(VISION_FACE_RKNN_CONF)
        self.emotion_face_rknn_nms = float(VISION_FACE_RKNN_NMS)
        self.emotion_face_rknn_class_id = int(VISION_FACE_RKNN_CLASS_ID)
        self.emotion_face_rknn_core = str(VISION_FACE_RKNN_CORE or "auto").strip().lower()
        self.emotion_face_rknn_type = str(VISION_FACE_RKNN_TYPE or "auto").strip().lower()
        if self.emotion_face_rknn_type not in ("auto", "yunet", "yolo", "retinaface"):
            self.emotion_face_rknn_type = "auto"
        self.emotion_face_input_size = int(VISION_EMOTION_FACE_INPUT_SIZE)
        self.emotion_face_score = float(VISION_EMOTION_FACE_SCORE)
        self.emotion_face_nms = float(VISION_EMOTION_FACE_NMS)
        self.emotion_face_topk = int(VISION_EMOTION_FACE_TOPK)
        self.emotion_face_expand = float(VISION_EMOTION_FACE_EXPAND)
        self.emotion_face_min_size = int(VISION_EMOTION_FACE_MIN_SIZE)
        self.person_head_box_top_ratio = float(VISION_PERSON_HEAD_BOX_TOP_RATIO)
        self.person_head_box_width_ratio = float(VISION_PERSON_HEAD_BOX_WIDTH_RATIO)
        self.person_head_face_detect_live = bool(VISION_PERSON_HEAD_FACE_DETECT_LIVE)
        if self.face_only_mode:
            self.yolo_backend_requested = "off"
            if not self.face_only_world_fusion:
                self.yolo_world_async_enabled = False
            self.wear_glasses_auto = False
            self.emotion_auto = False
        self.emotion_update_interval_ms = float(VISION_EMOTION_UPDATE_INTERVAL_MS)
        self.emotion_cache_ttl_ms = float(VISION_EMOTION_CACHE_TTL_MS)
        self.emotion_cache_match_iou = float(VISION_EMOTION_CACHE_MATCH_IOU)
        self.emotion_cache_max_center_dist = float(VISION_EMOTION_CACHE_MAX_CENTER_DIST)
        self.emotion_ready = False
        self.emotion_error = ""
        self.emotion_recognizer: Any | None = None
        self.emotion_rknn: Any | None = None
        self.emotion_rknn_labels: list[str] = list(EMOTION_RKNN_DEFAULT_LABELS)
        self.emotion_rknn_labels_error = ""
        self.emotion_face_detector_obj: Any | None = None
        self.emotion_face_rknn: Any | None = None
        self.emotion_face_detector_error = ""
        self.emotion_face_input_cached: tuple[int, int] = (0, 0)
        self.retinaface_priors_cache: dict[int, np.ndarray] = {}
        self.emotion_haar_path = ""
        self.emotion_lock = threading.Lock()
        self.emotion_infer_lock = threading.Lock()
        self.emotion_cache_lock = threading.Lock()
        self.emotion_refresh_lock = threading.Lock()
        self.emotion_refresh_pending = False
        self.emotion_last_eval_ts = 0.0
        self.emotion_cache_ts = 0.0
        self.emotion_cache_items: list[dict[str, Any]] = []
        self.face_recognition_enabled = bool(VISION_FACE_RECOGNITION_ENABLED)
        self.face_recognition_auto = bool(VISION_FACE_RECOGNITION_AUTO)
        self.face_recognition_model_path = str(VISION_FACE_RECOGNITION_MODEL).strip()
        self.face_recognition_backend_requested = (
            str(VISION_FACE_RECOGNITION_BACKEND or "auto").strip().lower()
        )
        self.face_recognition_target_requested = (
            str(VISION_FACE_RECOGNITION_TARGET or "auto").strip().lower()
        )
        self.face_recognition_gallery_dir = str(VISION_FACE_RECOGNITION_GALLERY_DIR).strip()
        self.account_store_dir = (
            str(VISION_ACCOUNT_STORE_DIR).strip() or str(BASE_DIR / "runtime/account_store")
        )
        self.account_store_path = Path(self.account_store_dir).expanduser().resolve() / "accounts.json"
        self.account_gallery_dir = Path(
            self.face_recognition_gallery_dir or str(BASE_DIR / "runtime/face_gallery")
        ).expanduser().resolve()
        self.face_recognition_threshold = float(VISION_FACE_RECOGNITION_THRESHOLD)
        self.face_recognition_peak_threshold = float(VISION_FACE_RECOGNITION_PEAK_THRESHOLD)
        self.face_recognition_support_threshold = float(VISION_FACE_RECOGNITION_SUPPORT_THRESHOLD)
        self.face_recognition_min_support = int(VISION_FACE_RECOGNITION_MIN_SUPPORT)
        self.face_recognition_topk = int(VISION_FACE_RECOGNITION_TOPK)
        self.face_recognition_min_face_size = int(VISION_FACE_RECOGNITION_MIN_FACE_SIZE)
        self.face_recognition_min_score = float(VISION_FACE_RECOGNITION_MIN_SCORE)
        self.face_recognition_max_yaw_deg = float(VISION_FACE_RECOGNITION_MAX_YAW_DEG)
        self.face_recognition_max_pitch_deg = float(VISION_FACE_RECOGNITION_MAX_PITCH_DEG)
        self.face_recognition_max_roll_deg = float(VISION_FACE_RECOGNITION_MAX_ROLL_DEG)
        self.face_recognition_unknown_label = str(
            VISION_FACE_RECOGNITION_UNKNOWN_LABEL or "unknown"
        ).strip() or "unknown"
        self.face_recognition_ready = False
        self.face_recognition_error = ""
        self.face_recognizer: Any | None = None
        self.face_recognition_backend_active = "none"
        self.face_recognition_target_active = "none"
        self.face_gallery_items: list[dict[str, Any]] = []
        self.face_gallery_identity_count = 0
        self.face_gallery_image_count = 0
        self.face_gallery_updated_ts = 0.0
        self.face_gallery_error = ""
        self.face_recognition_lock = threading.Lock()
        self.accounts_lock = threading.Lock()
        self.accounts_db: dict[str, Any] = {
            "version": 1,
            "updated_at": _ts_now(),
            "accounts": {},
        }
        self.account_store_error = ""
        self.yolo_last_stable_objects: list[dict[str, Any]] = []
        self.yolo_spike_streak = 0
        self.yolo_last_suppressed_spike = False
        self.yolo_world_class_filter_ids: set[int] | None = None
        self.yolo_world_class_filter_names: list[str] = []
        self.yolo_world_class_filter_reason = ""
        self.yolo_world_class_filter_updated_ts = 0.0
        self.yolo_world_aliases_path = VISION_YOLO_WORLD_ALIASES
        self.yolo_world_alias_map: dict[str, list[str]] = {}
        self.yolo_world_alias_inline_map: dict[str, list[str]] = {}
        self.yolo_world_alias_error = ""
        self.yolo_world_prompt = ""
        self.yolo_world_prompt_include_terms: list[str] = []
        self.yolo_world_prompt_exclude_terms: list[str] = []
        self.yolo_world_prompt_unknown_terms: list[str] = []
        self.yolo_world_prompt_reason = ""
        self.yolo_world_prompt_strict = bool(VISION_YOLO_WORLD_PROMPT_STRICT_DEFAULT)
        self.yolo_world_prompt_updated_ts = 0.0
        self.yolo_world_vocab_dir = str(Path(VISION_YOLO_WORLD_VOCAB_DIR or "").resolve())
        self.yolo_world_vocab_active = "default"
        self.yolo_world_vocab_manifest = ""
        self.yolo_world_vocab_updated_ts = time.time()
        self.yolo_world_vocab_reason = "startup"
        self.yolo_world_vocab_error = ""
        self.yolo_world_vocab_safe_default = bool(VISION_YOLO_WORLD_VOCAB_SAFE_DEFAULT)
        self.yolo_world_vocab_safe_min_overlap = int(VISION_YOLO_WORLD_VOCAB_SAFE_MIN_OVERLAP)
        self.yolo_world_vocab_safe_min_mean_cos = float(VISION_YOLO_WORLD_VOCAB_SAFE_MIN_MEAN_COS)
        self.yolo_world_vocab_safe_min_anchor_cos = float(
            VISION_YOLO_WORLD_VOCAB_SAFE_MIN_ANCHOR_COS
        )
        self.yolo_world_vocab_safe_anchors = list(VISION_YOLO_WORLD_VOCAB_SAFE_ANCHORS)
        self.yolo_world_vocab_baseline_text_path = str(VISION_YOLO_WORLD_TEXT or "")
        self.yolo_world_vocab_baseline_labels_path = str(VISION_YOLO_WORLD_LABELS or "")
        self.yolo_world_vocab_baseline_embeddings, self.yolo_world_vocab_baseline_error = (
            self._load_yolo_world_text_embeddings_from_path(self.yolo_world_vocab_baseline_text_path)
        )
        self.yolo_world_vocab_baseline_labels = self._load_yolo_world_labels_from_path(
            self.yolo_world_vocab_baseline_labels_path
        )
        self.yolo_world_reconfig_lock = threading.Lock()
        self.yolo_world_infer_lock = threading.Lock()
        self.yolo_world_thread: threading.Thread | None = None
        self.yolo_world_text_embeddings: np.ndarray | None = None
        self.yolo_world_labels: list[str] = []
        self.yolo_world_last_stable_objects: list[dict[str, Any]] = []
        self.yolo_world_spike_streak = 0
        self.yolo_world_drop_streak = 0
        self.yolo_world_last_result_ts = 0.0
        self.yolo_world_last_result_at = 0.0
        self.yolo_world_last_result_objects: list[dict[str, Any]] = []
        self.yolo_world_last_result_err = ""
        self.yolo_world_last_result_metrics: dict[str, Any] = {}
        self.yolo_world_async_result_ts = 0.0
        self.yolo_world_async_result_at = 0.0
        self.yolo_world_async_objects: list[dict[str, Any]] = []
        self.yolo_world_async_err = ""
        self.yolo_world_async_metrics: dict[str, Any] = {}
        self.yolo_world_async_runtime_fps = 0.0
        self.yolo_world_async_last_loop_ts = 0.0
        self.gimbal_serial = GimbalSerialBridge(
            enabled=VISION_GIMBAL_ENABLED,
            port=VISION_GIMBAL_SERIAL_PORT,
            baudrate=VISION_GIMBAL_SERIAL_BAUD,
            timeout_sec=VISION_GIMBAL_SERIAL_TIMEOUT_SEC,
            rx_monitor=VISION_GIMBAL_RX_MONITOR,
            rx_preview_bytes=VISION_GIMBAL_RX_PREVIEW_BYTES,
            rpm_limit=VISION_GIMBAL_RPM_LIMIT,
            default_laser_flag=VISION_GIMBAL_DEFAULT_LASER_FLAG,
            default_enabled_flag=VISION_GIMBAL_DEFAULT_ENABLED_FLAG,
            default_stability_flag=VISION_GIMBAL_DEFAULT_STABILITY_FLAG,
            default_auto_stop_ms=VISION_GIMBAL_DEFAULT_AUTO_STOP_MS,
            idle_yaw_trim_rpm=VISION_GIMBAL_IDLE_YAW_TRIM_RPM,
            idle_pitch_trim_rpm=VISION_GIMBAL_IDLE_PITCH_TRIM_RPM,
        )
        self.gimbal_laser_blink_lock = threading.Lock()
        self.gimbal_lock_state_lock = threading.Lock()
        self.gimbal_lock_stop_event = threading.Event()
        self.gimbal_lock_thread: threading.Thread | None = None
        self.gimbal_lock_state: dict[str, Any] = {
            "active": False,
            "run_id": "",
            "status": "idle",
            "message": "idle",
            "reason": "",
            "target_raw": "",
            "target_terms": [],
            "detector": "face",
            "detector_requested": "face",
            "detector_resolved": "face",
            "detector_note": "",
            "target_human": False,
            "exclude_person": False,
            "face_only_mode": False,
            "single_face_mode": False,
            "face_anchor_bbox": None,
            "face_anchor_miss_frames": 0,
            "face_switch_pending_bbox": None,
            "face_switch_pending_frames": 0,
            "observe_wear_glasses": False,
            "observe_emotion": False,
            "observe_detail_note": "",
            "continuous": False,
            "started_ts": 0.0,
            "finished_ts": 0.0,
            "last_update_ts": 0.0,
            "iterations": 0,
            "stable_frames": 0,
            "required_stable_frames": int(VISION_GIMBAL_LOCK_STABLE_FRAMES),
            "timeout_sec": float(VISION_GIMBAL_LOCK_TIMEOUT_SEC),
            "center_tolerance_px": float(VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX),
            "hold_tolerance_scale": float(VISION_GIMBAL_LOCK_HOLD_TOLERANCE_SCALE),
            "min_score": float(VISION_GIMBAL_LOCK_MIN_SCORE),
            "max_rpm": float(VISION_GIMBAL_LOCK_MAX_RPM),
            "kp_yaw": float(VISION_GIMBAL_LOCK_KP_YAW),
            "kp_pitch": float(VISION_GIMBAL_LOCK_KP_PITCH),
            "err_ema_alpha": float(VISION_GIMBAL_LOCK_ERR_EMA_ALPHA),
            "cmd_min_rpm": float(VISION_GIMBAL_LOCK_CMD_MIN_RPM),
            "brake_zone_px": float(VISION_GIMBAL_LOCK_BRAKE_ZONE_PX),
            "brake_min_scale": float(VISION_GIMBAL_LOCK_BRAKE_MIN_SCALE),
            "cmd_slew_rpm_per_sec": float(VISION_GIMBAL_LOCK_CMD_SLEW_RPM_PER_SEC),
            "invert_yaw": bool(VISION_GIMBAL_LOCK_INVERT_YAW),
            "invert_pitch": bool(VISION_GIMBAL_LOCK_INVERT_PITCH),
            "search_sweep_rpm": float(VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM),
            "search_sweep_pulse_ms": int(VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS),
            "search_spin_deg": float(VISION_GIMBAL_LOCK_SEARCH_SPIN_DEG),
            "search_spin_clockwise": bool(VISION_GIMBAL_LOCK_SEARCH_SPIN_CLOCKWISE),
            "search_spin_progress_deg": 0.0,
            "search_spin_rounds": 0,
            "laser_blinks": int(VISION_GIMBAL_LOCK_LASER_BLINKS),
            "laser_on_ms": int(VISION_GIMBAL_LOCK_LASER_ON_MS),
            "laser_off_ms": int(VISION_GIMBAL_LOCK_LASER_OFF_MS),
            "blink_done": 0,
            "last_observe_summary": "",
            "last_error": "",
            "last_target": None,
            "last_command": None,
            "last_tracker_output": None,
            "locked": False,
            "result": None,
        }
        self._load_account_store()
        self._ensure_seed_account(username="123", password="123")

        if VISION_PROFILE in self.profiles:
            self._apply_profile_locked(VISION_PROFILE)

        if not self.enabled:
            self.last_error = "vision disabled by VISION_ENABLED=0"
            return

        try:
            import cv2  # type: ignore

            self.cv2 = cv2
        except Exception as exc:  # pragma: no cover - runtime environment dependent
            self.last_error = f"opencv import failed: {exc}"
            return

        if not self.face_only_mode:
            self._init_yolo()
        else:
            self.yolo_backend_active = ""
            self.yolo_error = "YOLO disabled by face-only mode"
        if VISION_YOLO_WORLD_ENABLED and ((not self.face_only_mode) or self.face_only_world_fusion):
            self._init_yolo_world()
            self._load_yolo_world_alias_map()
        else:
            self.yolo_world_error = (
                "YOLO-World disabled by face-only mode"
                if self.face_only_mode and not self.face_only_world_fusion
                else "YOLO-World disabled by config"
            )
        self._ensure_face_recognition()
        self._start_capture_worker()
        if VISION_YOLO_WORLD_ENABLED and ((not self.face_only_mode) or self.face_only_world_fusion):
            self._start_yolo_world_worker()
        self._start_wear_glasses_warmup()
        self._start_emotion_warmup()

    @staticmethod
    def _normalize_account_username(value: str) -> str:
        return str(value or "").strip()

    @staticmethod
    def _password_hash(password: str, salt_hex: str | None = None) -> str:
        salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
        rounds = 200000
        digest = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, rounds)
        return f"pbkdf2_sha256${rounds}${salt.hex()}${digest.hex()}"

    @staticmethod
    def _password_verify(password: str, encoded: str) -> bool:
        raw = str(encoded or "").strip()
        parts = raw.split("$")
        if len(parts) != 4 or parts[0] != "pbkdf2_sha256":
            return False
        try:
            rounds = int(parts[1])
            salt = bytes.fromhex(parts[2])
            expected = bytes.fromhex(parts[3])
        except Exception:
            return False
        actual = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, rounds)
        return hmac.compare_digest(actual, expected)

    @staticmethod
    def _is_checked_in_today(timestamp_text: str) -> bool:
        raw = str(timestamp_text or "").strip()
        if not raw:
            return False
        try:
            return datetime.fromisoformat(raw).date() == datetime.now().date()
        except Exception:
            return False

    @staticmethod
    def _mime_to_suffix(mime_type: str) -> str:
        mime = str(mime_type or "").strip().lower()
        if mime in ("image/jpeg", "image/jpg"):
            return ".jpg"
        if mime == "image/png":
            return ".png"
        if mime == "image/webp":
            return ".webp"
        if mime == "image/bmp":
            return ".bmp"
        return ".jpg"

    @staticmethod
    def _suffix_to_mime(path: Path) -> str:
        suffix = str(path.suffix or "").strip().lower()
        if suffix in (".jpg", ".jpeg"):
            return "image/jpeg"
        if suffix == ".png":
            return "image/png"
        if suffix == ".webp":
            return "image/webp"
        if suffix == ".bmp":
            return "image/bmp"
        return "application/octet-stream"

    def _sanitize_account_row(self, username: str, row: dict[str, Any] | None) -> dict[str, Any]:
        now = _ts_now()
        source = row if isinstance(row, dict) else {}
        display_name = str(source.get("display_name") or username).strip() or username
        portrait_relpath = str(source.get("portrait_relpath") or "").strip()
        return {
            "username": username,
            "display_name": display_name,
            "identity_label": username,
            "password_hash": str(source.get("password_hash") or "").strip(),
            "portrait_relpath": portrait_relpath,
            "created_at": str(source.get("created_at") or now),
            "updated_at": str(source.get("updated_at") or now),
            "last_check_in_at": str(source.get("last_check_in_at") or "").strip(),
        }

    @staticmethod
    def _sanitize_account_settings(settings: dict[str, Any] | None) -> dict[str, Any]:
        source = settings if isinstance(settings, dict) else {}
        try:
            interval_minutes = int(
                source.get(
                    "attendance_recheck_interval_minutes",
                    source.get("recheck_interval_minutes", VISION_ATTENDANCE_RECHECK_INTERVAL_MINUTES),
                )
            )
        except Exception:
            interval_minutes = VISION_ATTENDANCE_RECHECK_INTERVAL_MINUTES
        interval_minutes = max(1, min(10080, interval_minutes))
        return {
            "attendance_recheck_interval_minutes": interval_minutes,
        }

    def _account_settings_public(self, settings: dict[str, Any] | None = None) -> dict[str, Any]:
        clean = self._sanitize_account_settings(settings)
        interval_minutes = int(clean["attendance_recheck_interval_minutes"])
        interval_seconds = interval_minutes * 60
        return {
            "attendance_recheck_interval_minutes": interval_minutes,
            "attendance_recheck_interval_seconds": interval_seconds,
            "attendance_recheck_interval_hours": round(interval_minutes / 60.0, 2),
        }

    @staticmethod
    def _attendance_state(last_check_in_at: str, interval_minutes: int) -> dict[str, Any]:
        raw = str(last_check_in_at or "").strip()
        if not raw:
            return {
                "checked_in_valid": False,
                "attendance_expired": False,
                "attendance_status_text": "未打卡",
                "attendance_next_due_at": None,
                "attendance_remaining_seconds": 0,
            }
        try:
            last_dt = datetime.fromisoformat(raw)
        except Exception:
            return {
                "checked_in_valid": False,
                "attendance_expired": False,
                "attendance_status_text": "未打卡",
                "attendance_next_due_at": None,
                "attendance_remaining_seconds": 0,
            }
        next_due = last_dt + timedelta(minutes=max(1, int(interval_minutes)))
        now_dt = datetime.now()
        remaining_seconds = max(0, int((next_due - now_dt).total_seconds()))
        checked_in_valid = remaining_seconds > 0
        attendance_expired = not checked_in_valid
        return {
            "checked_in_valid": checked_in_valid,
            "attendance_expired": attendance_expired,
            "attendance_status_text": "已打卡" if checked_in_valid else "未打卡",
            "attendance_next_due_at": next_due.isoformat(timespec="seconds"),
            "attendance_remaining_seconds": remaining_seconds,
        }

    def _save_account_store_locked(self) -> None:
        self.account_store_path.parent.mkdir(parents=True, exist_ok=True)
        self.account_gallery_dir.mkdir(parents=True, exist_ok=True)
        self.accounts_db["updated_at"] = _ts_now()
        tmp_path = self.account_store_path.with_suffix(".json.tmp")
        tmp_path.write_text(
            json.dumps(self.accounts_db, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        tmp_path.replace(self.account_store_path)

    def _load_account_store(self) -> None:
        payload: dict[str, Any] = {
            "version": 1,
            "updated_at": _ts_now(),
            "settings": self._sanitize_account_settings(None),
            "accounts": {},
        }
        self.account_store_error = ""
        try:
            self.account_store_path.parent.mkdir(parents=True, exist_ok=True)
            self.account_gallery_dir.mkdir(parents=True, exist_ok=True)
            if self.account_store_path.exists():
                raw = json.loads(self.account_store_path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    payload["settings"] = self._sanitize_account_settings(
                        raw.get("settings") if isinstance(raw.get("settings"), dict) else None
                    )
                    rows = raw.get("accounts", {})
                    if isinstance(rows, dict):
                        for key, value in rows.items():
                            username = self._normalize_account_username(
                                str(getattr(value, "get", lambda _k, _d=None: "")("username", key) or key)
                            )
                            if not username:
                                continue
                            payload["accounts"][username] = self._sanitize_account_row(
                                username,
                                value if isinstance(value, dict) else None,
                            )
        except Exception as exc:
            self.account_store_error = f"account store load failed: {exc}"
        with self.accounts_lock:
            self.accounts_db = payload
            try:
                self._save_account_store_locked()
            except Exception as exc:
                self.account_store_error = f"account store save failed: {exc}"

    def _ensure_seed_account(self, username: str, password: str) -> None:
        account_name = self._normalize_account_username(username)
        if not account_name:
            return
        with self.accounts_lock:
            accounts = self.accounts_db.setdefault("accounts", {})
            if account_name in accounts:
                return
            accounts[account_name] = self._sanitize_account_row(
                account_name,
                {
                    "display_name": account_name,
                    "password_hash": self._password_hash(password),
                    "created_at": _ts_now(),
                    "updated_at": _ts_now(),
                },
            )
            try:
                self._save_account_store_locked()
            except Exception as exc:
                self.account_store_error = f"account store save failed: {exc}"

    def _decode_account_portrait(self, portrait_data: str) -> tuple[bytes | None, str, str]:
        raw = str(portrait_data or "").strip()
        if not raw:
            return None, "", "portrait data is required"
        mime_type = "image/jpeg"
        payload = raw
        match = re.match(r"^data:(image/[a-zA-Z0-9.+-]+);base64,(.+)$", raw, re.DOTALL)
        if match is not None:
            mime_type = str(match.group(1) or "image/jpeg").strip().lower()
            payload = str(match.group(2) or "").strip()
        payload = payload.replace("\n", "").replace("\r", "").replace(" ", "")
        try:
            image_bytes = base64.b64decode(payload, validate=True)
        except (ValueError, binascii.Error):
            return None, "", "portrait base64 invalid"
        if not image_bytes:
            return None, "", "portrait image is empty"
        if len(image_bytes) > 8 * 1024 * 1024:
            return None, "", "portrait image too large"
        return image_bytes, mime_type, ""

    def _write_account_portrait_locked(
        self,
        username: str,
        portrait_data: str,
    ) -> tuple[str, str]:
        image_bytes, mime_type, err = self._decode_account_portrait(portrait_data)
        if image_bytes is None:
            return "", err or "portrait decode failed"
        account_dir = self.account_gallery_dir / username
        account_dir.mkdir(parents=True, exist_ok=True)
        for child in list(account_dir.iterdir()):
            if child.is_file():
                try:
                    child.unlink()
                except Exception:
                    pass
        suffix = self._mime_to_suffix(mime_type)
        portrait_path = account_dir / f"portrait{suffix}"
        portrait_path.write_bytes(image_bytes)
        return f"{username}/{portrait_path.name}", ""

    def _account_public_row(self, row: dict[str, Any], settings: dict[str, Any] | None = None) -> dict[str, Any]:
        username = str(row.get("username") or "").strip()
        portrait_relpath = str(row.get("portrait_relpath") or "").strip()
        public_settings = self._account_settings_public(settings)
        attendance_state = self._attendance_state(
            str(row.get("last_check_in_at") or ""),
            int(public_settings["attendance_recheck_interval_minutes"]),
        )
        return {
            "username": username,
            "display_name": str(row.get("display_name") or username).strip() or username,
            "identity_label": str(row.get("identity_label") or username).strip() or username,
            "created_at": str(row.get("created_at") or "").strip() or None,
            "updated_at": str(row.get("updated_at") or "").strip() or None,
            "last_check_in_at": str(row.get("last_check_in_at") or "").strip() or None,
            "checked_in_today": bool(attendance_state["checked_in_valid"]),
            "checked_in_valid": bool(attendance_state["checked_in_valid"]),
            "attendance_expired": bool(attendance_state["attendance_expired"]),
            "attendance_status_text": str(attendance_state["attendance_status_text"]),
            "attendance_next_due_at": attendance_state["attendance_next_due_at"],
            "attendance_remaining_seconds": int(attendance_state["attendance_remaining_seconds"]),
            **public_settings,
            "has_portrait": bool(portrait_relpath),
            "portrait_url": (
                f"/api/vision/accounts/portrait?username={username}" if portrait_relpath else None
            ),
        }

    def accounts_status(self) -> dict[str, Any]:
        with self.accounts_lock:
            settings = self._sanitize_account_settings(
                self.accounts_db.get("settings") if isinstance(self.accounts_db.get("settings"), dict) else None
            )
            rows = [
                self._account_public_row(self._sanitize_account_row(name, value), settings)
                for name, value in self.accounts_db.get("accounts", {}).items()
            ]
        rows.sort(key=lambda item: str(item.get("username") or ""))
        checked_in_valid = sum(1 for item in rows if bool(item.get("checked_in_valid")))
        public_settings = self._account_settings_public(settings)
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "accounts": rows,
            "count": len(rows),
            "checked_in_today": checked_in_valid,
            "checked_in_valid_count": checked_in_valid,
            "unchecked_today": max(0, len(rows) - checked_in_valid),
            "needs_recheck_count": max(0, len(rows) - checked_in_valid),
            "settings": public_settings,
            "account_store_path": str(self.account_store_path),
            "face_gallery_dir": str(self.account_gallery_dir),
            "face_gallery_ready": bool(self.face_recognition_ready),
            "face_gallery_error": self.face_gallery_error or self.face_recognition_error or None,
            "account_store_error": self.account_store_error or None,
        }

    def account_authenticate(self, username: str, password: str) -> dict[str, Any]:
        account_name = self._normalize_account_username(username)
        if not account_name or not str(password or "").strip():
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "username and password are required",
            }
        with self.accounts_lock:
            row = self.accounts_db.get("accounts", {}).get(account_name)
            if not isinstance(row, dict):
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"account not found: {account_name}",
                }
            password_hash = str(row.get("password_hash") or "").strip()
            if not password_hash or not self._password_verify(password, password_hash):
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "invalid username or password",
                }
            settings = self._sanitize_account_settings(
                self.accounts_db.get("settings") if isinstance(self.accounts_db.get("settings"), dict) else None
            )
            account_row = self._account_public_row(self._sanitize_account_row(account_name, row), settings)
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "account": account_row,
            "settings": self._account_settings_public(settings),
            "message": f"authenticated: {account_name}",
        }

    def account_create(
        self,
        username: str,
        password: str,
        display_name: str = "",
        portrait_data: str = "",
    ) -> dict[str, Any]:
        account_name = self._normalize_account_username(username)
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", account_name):
            payload = self.accounts_status()
            payload["ok"] = False
            payload["error"] = "username must match [A-Za-z0-9][A-Za-z0-9_.-]{0,63}"
            return payload
        if not str(password or "").strip():
            payload = self.accounts_status()
            payload["ok"] = False
            payload["error"] = "password is required"
            return payload
        portrait_relpath = ""
        create_error = ""
        created = False
        with self.accounts_lock:
            accounts = self.accounts_db.setdefault("accounts", {})
            existing = accounts.get(account_name)
            created = not isinstance(existing, dict)
            now = _ts_now()
            base_row = self._sanitize_account_row(account_name, existing if isinstance(existing, dict) else None)
            row = self._sanitize_account_row(
                account_name,
                {
                    **base_row,
                    "display_name": str(display_name or base_row.get("display_name") or account_name).strip()
                    or account_name,
                    "password_hash": self._password_hash(password),
                    "created_at": base_row.get("created_at") if not created else now,
                    "updated_at": now,
                },
            )
            if str(portrait_data or "").strip():
                portrait_relpath, err = self._write_account_portrait_locked(
                    account_name,
                    portrait_data,
                )
                if err:
                    create_error = err
                else:
                    row["portrait_relpath"] = portrait_relpath
            if not create_error:
                accounts[account_name] = row
                try:
                    self._save_account_store_locked()
                except Exception as exc:
                    if created:
                        accounts.pop(account_name, None)
                    create_error = f"account store save failed: {exc}"
        if create_error:
            payload = self.accounts_status()
            payload["ok"] = False
            payload["error"] = create_error
            return payload
        reload_payload = None
        if portrait_relpath:
            reload_payload = self.face_recognition_reload()
        payload = self.accounts_status()
        payload["ok"] = True
        payload["message"] = (
            f"account created: {account_name}" if created else f"account updated: {account_name}"
        )
        payload["created"] = created
        payload["saved_username"] = account_name
        if reload_payload is not None:
            payload["face_recognition_reload"] = reload_payload
        return payload

    def account_mark_check_in(self, username: str, clear: bool = False) -> dict[str, Any]:
        account_name = self._normalize_account_username(username)
        mark_error = ""
        with self.accounts_lock:
            accounts = self.accounts_db.setdefault("accounts", {})
            row = accounts.get(account_name)
            if not isinstance(row, dict):
                mark_error = f"account not found: {account_name}"
            else:
                row = self._sanitize_account_row(account_name, row)
                row["last_check_in_at"] = "" if clear else _ts_now()
                row["updated_at"] = _ts_now()
                accounts[account_name] = row
                try:
                    self._save_account_store_locked()
                except Exception as exc:
                    mark_error = f"account store save failed: {exc}"
        if mark_error:
            payload = self.accounts_status()
            payload["ok"] = False
            payload["error"] = mark_error
            return payload
        payload = self.accounts_status()
        payload["ok"] = True
        payload["message"] = (
            f"attendance cleared: {account_name}" if clear else f"attendance marked: {account_name}"
        )
        return payload

    def account_update_settings(self, attendance_recheck_interval_minutes: Any = None) -> dict[str, Any]:
        settings_error = ""
        try:
            interval_minutes = int(attendance_recheck_interval_minutes)
        except Exception:
            interval_minutes = 0
        if interval_minutes <= 0:
            settings_error = "attendance_recheck_interval_minutes must be a positive integer"
        else:
            with self.accounts_lock:
                self.accounts_db["settings"] = self._sanitize_account_settings(
                    {"attendance_recheck_interval_minutes": interval_minutes}
                )
                try:
                    self._save_account_store_locked()
                except Exception as exc:
                    settings_error = f"account store save failed: {exc}"
        if settings_error:
            payload = self.accounts_status()
            payload["ok"] = False
            payload["error"] = settings_error
            return payload
        payload = self.accounts_status()
        payload["ok"] = True
        payload["message"] = "attendance settings updated"
        return payload

    def account_portrait_bytes(self, username: str) -> tuple[bytes | None, str, str]:
        account_name = self._normalize_account_username(username)
        with self.accounts_lock:
            row = self.accounts_db.get("accounts", {}).get(account_name)
            if not isinstance(row, dict):
                return None, "", f"account not found: {account_name}"
            portrait_relpath = str(row.get("portrait_relpath") or "").strip()
        if not portrait_relpath:
            return None, "", f"portrait not uploaded: {account_name}"
        portrait_path = (self.account_gallery_dir / portrait_relpath).resolve()
        try:
            portrait_path.relative_to(self.account_gallery_dir)
        except Exception:
            return None, "", "portrait path invalid"
        if not portrait_path.exists() or not portrait_path.is_file():
            return None, "", f"portrait file missing: {account_name}"
        try:
            return portrait_path.read_bytes(), self._suffix_to_mime(portrait_path), ""
        except Exception as exc:
            return None, "", f"portrait read failed: {exc}"

    def _apply_profile_locked(self, name: str) -> bool:
        profile = self.profiles.get(name)
        if profile is None:
            return False
        self.request_cfg["width"] = int(profile["width"])
        self.request_cfg["height"] = int(profile["height"])
        self.request_cfg["fps"] = float(profile["fps"])
        self.request_cfg["fourcc"] = str(profile["fourcc"]).upper()
        self.profile_name = name
        return True

    def _resolve_yolo_anchors(self, text: str) -> list[list[list[float]]]:
        # Default anchors for yolov5 family (input 640).
        default = [
            [[10.0, 13.0], [16.0, 30.0], [33.0, 23.0]],
            [[30.0, 61.0], [62.0, 45.0], [59.0, 119.0]],
            [[116.0, 90.0], [156.0, 198.0], [373.0, 326.0]],
        ]
        vals = parse_float_list(text)
        if len(vals) != 18:
            return default
        out: list[list[list[float]]] = []
        for base in range(0, 18, 6):
            group: list[list[float]] = []
            for i in range(0, 6, 2):
                group.append([float(vals[base + i]), float(vals[base + i + 1])])
            out.append(group)
        return out

    def _release_yolo_rknn(self) -> None:
        rknn = self.yolo_rknn
        self.yolo_rknn = None
        if rknn is None:
            return
        try:
            rknn.release()
        except Exception:
            pass

    def _release_yolo_ort(self) -> None:
        self.yolo_ort_session = None
        self.yolo_ort_input_name = ""
        self.yolo_ort_input_dtype = "tensor(float)"
        self.yolo_ort_input_layout = "nchw"

    def _release_yolo_world_rknn(self) -> None:
        rknn = self.yolo_world_rknn
        self.yolo_world_rknn = None
        if rknn is None:
            return
        try:
            rknn.release()
        except Exception:
            pass

    def _release_emotion_rknn(self) -> None:
        rknn = self.emotion_rknn
        self.emotion_rknn = None
        if rknn is None:
            return
        try:
            rknn.release()
        except Exception:
            pass

    def _release_emotion_face_rknn(self) -> None:
        rknn = self.emotion_face_rknn
        self.emotion_face_rknn = None
        if rknn is None:
            return
        try:
            rknn.release()
        except Exception:
            pass

    def _face_detector_requested_mode(self) -> str:
        mode = str(self.emotion_face_detector_requested or "yunet").strip().lower()
        if mode in ("auto", "yunet", "haar", "rknn", "none"):
            return mode
        return "yunet"

    def _face_detector_requested_enabled(self) -> bool:
        return self._face_detector_requested_mode() != "none"

    def _face_detector_active_mode(self) -> str:
        mode = str(self.emotion_face_detector_active or "").strip().lower()
        if mode in ("yunet", "haar", "rknn", "none"):
            return mode
        return ""

    def _resolve_rknn_core_mask(self, rknn_cls: Any, mode: str | None = None) -> Any:
        core_mode = str(mode or self.yolo_rknn_core or "auto").strip().lower()
        mode = core_mode
        if mode in ("", "auto"):
            return getattr(rknn_cls, "NPU_CORE_AUTO", None)
        if mode in ("0", "core0"):
            return getattr(rknn_cls, "NPU_CORE_0", None)
        if mode in ("1", "core1"):
            return getattr(rknn_cls, "NPU_CORE_1", None)
        if mode in ("2", "core2"):
            return getattr(rknn_cls, "NPU_CORE_2", None)
        if mode in ("0_1", "core0_1"):
            return getattr(rknn_cls, "NPU_CORE_0_1", None)
        if mode in ("0_1_2", "all", "core_all"):
            return getattr(rknn_cls, "NPU_CORE_0_1_2", None)
        return getattr(rknn_cls, "NPU_CORE_AUTO", None)

    @staticmethod
    def _load_yolo_world_text_embeddings_from_path(path_text: str) -> tuple[np.ndarray | None, str]:
        path = Path(path_text or "")
        if not path_text:
            return None, "YOLO-World text embedding path is empty"
        if not path.exists():
            return None, f"YOLO-World text embedding not found: {path}"
        try:
            arr = np.load(str(path))
        except Exception as exc:
            return None, f"YOLO-World text embedding load failed: {exc}"
        emb = np.asarray(arr, dtype=np.float32)
        if emb.ndim == 2:
            emb = np.expand_dims(emb, axis=0)
        if emb.ndim != 3:
            return None, f"YOLO-World text embedding shape invalid: {emb.shape}"
        return emb, ""

    @staticmethod
    def _load_yolo_world_labels_from_path(path_text: str) -> list[str]:
        path = Path(path_text or "")
        if not path_text or not path.exists():
            return []
        try:
            rows = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            return []
        return [row.strip() for row in rows if row.strip()]

    @staticmethod
    def _read_json_obj(path_text: str) -> tuple[dict[str, Any] | None, str]:
        path = Path(path_text or "")
        if not path_text:
            return None, "json path is empty"
        if not path.exists():
            return None, f"json file not found: {path}"
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            return None, f"json load failed: {exc}"
        if not isinstance(obj, dict):
            return None, "json file must be object"
        return obj, ""

    @staticmethod
    def _resolve_path(base_dir: Path, raw: str) -> str:
        text = str(raw or "").strip()
        if not text:
            return ""
        path = Path(text)
        if not path.is_absolute():
            path = base_dir / path
        return str(path.resolve())

    @staticmethod
    def _labels_count_from_embedding(emb: np.ndarray | None) -> int:
        if not isinstance(emb, np.ndarray):
            return 0
        if emb.ndim != 3:
            return 0
        return int(emb.shape[1])

    @classmethod
    def _build_yolo_world_label_vec_map(
        cls, labels: list[str], emb: np.ndarray | None
    ) -> dict[str, np.ndarray]:
        if not isinstance(emb, np.ndarray) or emb.ndim != 3:
            return {}
        total = int(emb.shape[1]) if emb.shape[1] > 0 else 0
        if total <= 0:
            return {}
        rows = [str(item or "").strip() for item in labels]
        if len(rows) < total:
            rows.extend(f"class_{idx}" for idx in range(len(rows), total))
        out: dict[str, np.ndarray] = {}
        for idx in range(total):
            key = cls._normalize_yolo_world_label_key(rows[idx])
            if not key or key in out:
                continue
            vec = np.asarray(emb[0, idx], dtype=np.float32).reshape(-1)
            norm = float(np.linalg.norm(vec))
            if norm <= 1e-8:
                continue
            out[key] = (vec / norm).astype(np.float32, copy=False)
        return out

    def _evaluate_yolo_world_vocab_compatibility(
        self,
        text_path: str,
        labels_path: str,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "ok": True,
            "safe_default": bool(self.yolo_world_vocab_safe_default),
            "min_overlap": int(self.yolo_world_vocab_safe_min_overlap),
            "min_mean_cos": float(self.yolo_world_vocab_safe_min_mean_cos),
            "min_anchor_cos": float(self.yolo_world_vocab_safe_min_anchor_cos),
            "anchors": list(self.yolo_world_vocab_safe_anchors),
            "baseline_text_path": self.yolo_world_vocab_baseline_text_path,
            "baseline_labels_path": self.yolo_world_vocab_baseline_labels_path,
        }

        baseline_emb = self.yolo_world_vocab_baseline_embeddings
        baseline_labels = list(self.yolo_world_vocab_baseline_labels)
        if baseline_emb is None:
            payload["ok"] = False
            payload["error"] = (
                self.yolo_world_vocab_baseline_error
                or "baseline embeddings unavailable; cannot run compatibility check"
            )
            return payload

        target_emb, target_err = self._load_yolo_world_text_embeddings_from_path(text_path)
        if target_emb is None:
            payload["ok"] = False
            payload["error"] = target_err or "target embeddings unavailable"
            return payload
        target_labels = self._load_yolo_world_labels_from_path(labels_path)
        if not target_labels:
            payload["ok"] = False
            payload["error"] = "target labels unavailable"
            return payload

        base_map = self._build_yolo_world_label_vec_map(baseline_labels, baseline_emb)
        target_map = self._build_yolo_world_label_vec_map(target_labels, target_emb)
        overlap_keys = sorted(set(base_map.keys()) & set(target_map.keys()))
        overlap_count = int(len(overlap_keys))
        payload["baseline_count"] = int(len(base_map))
        payload["target_count"] = int(len(target_map))
        payload["overlap_count"] = overlap_count
        payload["overlap_ratio"] = round(
            overlap_count / max(1, min(len(base_map), len(target_map))), 4
        )

        if overlap_count <= 0:
            payload["ok"] = False
            payload["error"] = "compatibility overlap is zero"
            return payload

        scores = np.array(
            [float(np.dot(base_map[key], target_map[key])) for key in overlap_keys],
            dtype=np.float32,
        )
        payload["cosine_mean"] = round(float(np.mean(scores)), 6)
        payload["cosine_min"] = round(float(np.min(scores)), 6)
        payload["cosine_p10"] = round(float(np.quantile(scores, 0.10)), 6)

        anchor_rows: list[dict[str, Any]] = []
        anchor_min: float | None = None
        for raw in self.yolo_world_vocab_safe_anchors:
            key = self._normalize_yolo_world_label_key(raw)
            if not key or key not in base_map or key not in target_map:
                continue
            cos = float(np.dot(base_map[key], target_map[key]))
            anchor_rows.append({"label": raw, "cosine": round(cos, 6)})
            if anchor_min is None or cos < anchor_min:
                anchor_min = cos
        payload["anchor_count"] = int(len(anchor_rows))
        payload["anchors_checked"] = anchor_rows
        payload["anchor_cosine_min"] = round(float(anchor_min), 6) if anchor_min is not None else None

        failures: list[str] = []
        if overlap_count < int(self.yolo_world_vocab_safe_min_overlap):
            failures.append(
                "overlap too small for safety validation "
                f"({overlap_count} < {int(self.yolo_world_vocab_safe_min_overlap)})"
            )
        mean_cos = float(payload.get("cosine_mean") or 0.0)
        if mean_cos < float(self.yolo_world_vocab_safe_min_mean_cos):
            failures.append(
                "mean cosine below threshold "
                f"({mean_cos:.4f} < {float(self.yolo_world_vocab_safe_min_mean_cos):.4f})"
            )
        if anchor_min is not None and anchor_min < float(self.yolo_world_vocab_safe_min_anchor_cos):
            failures.append(
                "anchor cosine below threshold "
                f"({anchor_min:.4f} < {float(self.yolo_world_vocab_safe_min_anchor_cos):.4f})"
            )

        payload["ok"] = len(failures) == 0
        if failures:
            payload["failures"] = failures
        return payload

    def _inspect_yolo_world_assets(
        self,
        model_path: str,
        text_path: str,
        labels_path: str,
        aliases_path: str = "",
    ) -> tuple[dict[str, Any], str]:
        out: dict[str, Any] = {
            "model_path": str(Path(model_path or "").resolve()) if model_path else "",
            "text_path": str(Path(text_path or "").resolve()) if text_path else "",
            "labels_path": str(Path(labels_path or "").resolve()) if labels_path else "",
            "aliases_path": str(Path(aliases_path or "").resolve()) if aliases_path else "",
            "warnings": [],
        }
        model = Path(model_path or "")
        if not model_path:
            return out, "yolo_world model path is empty"
        if not model.exists():
            return out, f"yolo_world model not found: {model}"
        emb, emb_err = self._load_yolo_world_text_embeddings_from_path(text_path)
        if emb is None:
            return out, emb_err
        labels = self._load_yolo_world_labels_from_path(labels_path)
        emb_count = self._labels_count_from_embedding(emb)
        label_count = len(labels)
        if emb_count <= 0:
            return out, "yolo_world text embedding is empty"
        if label_count <= 0:
            return out, "yolo_world labels file is empty"
        if label_count != emb_count:
            out["warnings"].append(
                f"labels count({label_count}) != embedding count({emb_count}); mapping may be inconsistent"
            )
        if aliases_path:
            _, alias_err = self._read_json_obj(aliases_path)
            if alias_err:
                out["warnings"].append(f"aliases warning: {alias_err}")
        out["embedding_shape"] = list(emb.shape)
        out["embedding_dtype"] = str(emb.dtype)
        out["embedding_count"] = int(emb_count)
        out["embedding_dim"] = int(emb.shape[2]) if emb.ndim == 3 else 0
        out["labels_count"] = int(label_count)
        out["labels_preview"] = labels[: min(12, len(labels))]
        return out, ""

    def _load_yolo_world_text_embeddings(self) -> tuple[np.ndarray | None, str]:
        return self._load_yolo_world_text_embeddings_from_path(self.yolo_world_text_path)

    def _load_yolo_world_labels(self) -> list[str]:
        return self._load_yolo_world_labels_from_path(self.yolo_world_labels_path)

    @staticmethod
    def _normalize_yolo_world_label_key(text: str) -> str:
        return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(text or "").strip().lower())

    @staticmethod
    def _split_yolo_world_label_tokens(raw: str) -> list[str]:
        text = str(raw or "").strip()
        if not text:
            return []
        parts = re.split(r"[,\n\r;|/]+", text)
        return [item.strip() for item in parts if item and item.strip()]

    def _yolo_world_label_count(self) -> int:
        emb = self.yolo_world_text_embeddings
        emb_count = int(emb.shape[1]) if isinstance(emb, np.ndarray) and emb.ndim == 3 else 0
        return max(len(self.yolo_world_labels), emb_count)

    def _resolve_yolo_world_class_filter(
        self, labels: str
    ) -> tuple[set[int] | None, list[str], list[str], str]:
        raw = str(labels or "").strip()
        if not raw:
            return None, [], [], "labels is empty"
        if raw.lower() in ("all", "*", "none", "off", "clear", "reset"):
            return None, [], [], ""

        tokens = self._split_yolo_world_label_tokens(raw)
        if not tokens:
            return None, [], [], "labels is empty"

        total = self._yolo_world_label_count()
        labels_all = [str(item or "").strip() for item in self.yolo_world_labels]
        normalized = [
            self._normalize_yolo_world_label_key(item)
            for item in labels_all
        ]
        exact_map: dict[str, int] = {}
        for idx, key in enumerate(normalized):
            if key and key not in exact_map:
                exact_map[key] = idx

        selected: list[int] = []
        selected_names: list[str] = []
        unknown: list[str] = []
        for token in tokens:
            item = str(token or "").strip()
            if not item:
                continue

            idx: int | None = None
            if item.isdigit():
                val = int(item)
                if 0 <= val < total:
                    idx = val
            else:
                key = self._normalize_yolo_world_label_key(item)
                if key:
                    idx = exact_map.get(key)
                    if idx is None and normalized:
                        matches = [i for i, cand in enumerate(normalized) if key in cand]
                        if len(matches) == 1:
                            idx = int(matches[0])

            if idx is None:
                unknown.append(item)
                continue
            if idx in selected:
                continue
            selected.append(idx)
            if 0 <= idx < len(labels_all):
                selected_names.append(labels_all[idx])
            else:
                selected_names.append(f"class_{idx}")

        if not selected:
            if unknown:
                return None, [], unknown, "no valid yolo_world labels matched"
            return None, [], [], "labels is empty"
        return set(selected), selected_names, unknown, ""

    def _yolo_world_filter_meta(self) -> dict[str, Any]:
        with self.lock:
            ids = (
                sorted(int(v) for v in self.yolo_world_class_filter_ids)
                if self.yolo_world_class_filter_ids is not None
                else []
            )
            names = [str(v) for v in self.yolo_world_class_filter_names]
            reason = str(self.yolo_world_class_filter_reason or "")
            updated = float(self.yolo_world_class_filter_updated_ts)
            prompt = str(self.yolo_world_prompt or "")
            prompt_include = [str(v) for v in self.yolo_world_prompt_include_terms]
            prompt_exclude = [str(v) for v in self.yolo_world_prompt_exclude_terms]
            prompt_unknown = [str(v) for v in self.yolo_world_prompt_unknown_terms]
            prompt_reason = str(self.yolo_world_prompt_reason or "")
            prompt_strict = bool(self.yolo_world_prompt_strict)
            prompt_updated = float(self.yolo_world_prompt_updated_ts)
            alias_count = int(sum(len(v) for v in self.yolo_world_alias_map.values()))
            alias_error = str(self.yolo_world_alias_error or "")
        return {
            "yolo_world_filter_active": bool(ids),
            "yolo_world_filter_count": int(len(ids)),
            "yolo_world_filter_ids": ids,
            "yolo_world_filter_labels": names,
            "yolo_world_filter_reason": reason or None,
            "yolo_world_filter_updated_at": (
                datetime.fromtimestamp(updated).isoformat(timespec="seconds")
                if updated > 0
                else None
            ),
            "yolo_world_prompt": prompt or None,
            "yolo_world_prompt_include_terms": prompt_include,
            "yolo_world_prompt_exclude_terms": prompt_exclude,
            "yolo_world_prompt_unknown_terms": prompt_unknown,
            "yolo_world_prompt_reason": prompt_reason or None,
            "yolo_world_prompt_strict": prompt_strict,
            "yolo_world_prompt_updated_at": (
                datetime.fromtimestamp(prompt_updated).isoformat(timespec="seconds")
                if prompt_updated > 0
                else None
            ),
            "yolo_world_aliases_path": self.yolo_world_aliases_path or None,
            "yolo_world_aliases_count": alias_count,
            "yolo_world_aliases_error": alias_error or None,
        }

    def yolo_world_filter_status(self) -> dict[str, Any]:
        with self.lock:
            labels = [str(item or "").strip() for item in self.yolo_world_labels]
            emb = self.yolo_world_text_embeddings
        emb_count = int(emb.shape[1]) if isinstance(emb, np.ndarray) and emb.ndim == 3 else 0
        label_count = max(len(labels), emb_count)
        if not labels and label_count > 0:
            labels = [f"class_{idx}" for idx in range(label_count)]

        warnings: list[str] = []
        payload = {
            "ok": True,
            "timestamp": _ts_now(),
            "yolo_world_ready": self._yolo_world_ready(),
            "available_labels_count": label_count,
            "available_labels": labels,
            **self._yolo_world_filter_meta(),
        }
        active_labels = [str(v) for v in payload.get("yolo_world_filter_labels", [])]
        if bool(payload.get("yolo_world_filter_active")) and len(active_labels) <= 1:
            if active_labels:
                warnings.append(
                    "single-label filter active; all other classes are hidden "
                    f"(current={active_labels[0]})"
                )
            else:
                warnings.append("class filter active with zero labels; check prompt/filter config")
        if active_labels and all(self._normalize_yolo_world_label_key(v) != "person" for v in active_labels):
            warnings.append("person class is excluded by current filter")
        if emb_count > 0 and labels and len(labels) != emb_count:
            warnings.append(
                f"labels count({len(labels)}) != embedding count({emb_count}); "
                "label-index mapping may be inconsistent"
            )
        if warnings:
            payload["warnings"] = warnings
        return payload

    def set_yolo_world_filter(
        self,
        labels: str,
        reason: str = "manual",
        preserve_prompt: bool = False,
    ) -> dict[str, Any]:
        ids, names, unknown, err = self._resolve_yolo_world_class_filter(labels)
        if err:
            payload = self.yolo_world_filter_status()
            payload["ok"] = False
            payload["error"] = err
            if unknown:
                payload["unknown_labels"] = unknown
            return payload
        if unknown:
            payload = self.yolo_world_filter_status()
            payload["ok"] = False
            payload["error"] = "unknown yolo_world labels"
            payload["unknown_labels"] = unknown
            return payload

        with self.lock:
            prev_ids = (
                set(self.yolo_world_class_filter_ids)
                if self.yolo_world_class_filter_ids is not None
                else None
            )
            prev_names = [str(v) for v in self.yolo_world_class_filter_names]
            self.yolo_world_class_filter_ids = set(ids) if ids is not None else None
            self.yolo_world_class_filter_names = list(names)
            self.yolo_world_class_filter_reason = str(reason or "manual")
            self.yolo_world_class_filter_updated_ts = time.time()
            if not preserve_prompt:
                self.yolo_world_prompt = ""
                self.yolo_world_prompt_include_terms = []
                self.yolo_world_prompt_exclude_terms = []
                self.yolo_world_prompt_unknown_terms = []
                self.yolo_world_prompt_reason = str(reason or "manual")
                self.yolo_world_prompt_strict = False
                self.yolo_world_prompt_updated_ts = time.time()
            changed = (
                prev_ids != self.yolo_world_class_filter_ids
                or prev_names != self.yolo_world_class_filter_names
            )
        if changed:
            # Clear stale async/cache result so new filter applies immediately.
            self._reset_yolo_world_cache()

        payload = self.yolo_world_filter_status()
        payload["ok"] = True
        payload["changed"] = bool(changed)
        payload["reason"] = str(reason or "manual")
        payload["message"] = (
            "yolo_world class filter updated"
            if payload.get("yolo_world_filter_active")
            else "yolo_world class filter cleared (all classes)"
        )
        return payload

    @staticmethod
    def _default_yolo_world_aliases() -> dict[str, list[str]]:
        # Canonical names must align with detect_classes.txt labels.
        return {
            "person": ["human", "people", "man", "woman", "boy", "girl", "行人", "人", "人员"],
            "bicycle": ["bike", "cycle", "自行车", "单车"],
            "car": ["auto", "vehicle", "sedan", "轿车", "汽车", "小车"],
            "motorcycle": ["motorbike", "moto", "摩托", "摩托车"],
            "airplane": ["plane", "aircraft", "飞机"],
            "bus": ["coach", "公交", "公交车", "大巴"],
            "train": ["列车", "火车"],
            "truck": ["lorry", "货车", "卡车"],
            "boat": ["ship", "vessel", "船", "小船"],
            "traffic light": ["signal", "红绿灯", "交通灯"],
            "fire hydrant": ["hydrant", "消防栓"],
            "stop sign": ["stop", "停车标志", "停牌"],
            "bench": ["长凳", "凳子"],
            "bird": ["小鸟", "鸟"],
            "cat": ["kitty", "小猫", "猫"],
            "dog": ["puppy", "小狗", "狗"],
            "horse": ["马"],
            "cow": ["奶牛", "牛"],
            "sheep": ["羊"],
            "backpack": ["bagpack", "背包", "书包"],
            "umbrella": ["伞", "雨伞"],
            "handbag": ["purse", "bag", "手提包"],
            "suitcase": ["luggage", "行李箱", "箱子"],
            "sports ball": ["ball", "球"],
            "baseball bat": ["bat", "球棒"],
            "tennis racket": ["racket", "网球拍", "球拍"],
            "bottle": ["瓶子", "水瓶"],
            "cup": ["mug", "杯子"],
            "fork": ["叉子"],
            "knife": ["刀", "小刀"],
            "spoon": ["勺子"],
            "bowl": ["碗"],
            "banana": ["香蕉"],
            "apple": ["苹果"],
            "orange": ["橙子"],
            "chair": ["seat", "椅子"],
            "couch": ["sofa", "沙发"],
            "potted plant": ["plant", "盆栽", "植物"],
            "bed": ["床"],
            "dining table": ["table", "desk", "餐桌", "桌子"],
            "toilet": ["wc", "马桶"],
            "tv": ["television", "screen", "电视", "显示器"],
            "laptop": ["notebook", "电脑", "笔记本"],
            "mouse": ["鼠标"],
            "remote": ["遥控器"],
            "keyboard": ["键盘"],
            "cell phone": ["phone", "mobile", "smartphone", "手机"],
            "microwave": ["微波炉"],
            "oven": ["烤箱"],
            "toaster": ["烤面包机"],
            "refrigerator": ["fridge", "冰箱"],
            "book": ["书"],
            "clock": ["时钟", "钟表"],
            "vase": ["花瓶"],
            "scissors": ["剪刀"],
            "teddy bear": ["teddy", "玩具熊"],
            "toothbrush": ["牙刷"],
        }

    @staticmethod
    def _coerce_terms_input(value: Any) -> list[str]:
        if isinstance(value, list):
            out = []
            for item in value:
                text = str(item or "").strip()
                if text:
                    out.append(text)
            return out
        text = str(value or "").strip()
        if not text:
            return []
        return [text]

    @staticmethod
    def _split_prompt_terms(text: str) -> list[str]:
        raw = str(text or "").strip()
        if not raw:
            return []
        blob = raw
        for token in ("，", "、", "；", "。", "和", "与", "以及", "或", "及", "+"):
            blob = blob.replace(token, ",")
        blob = re.sub(r"\b(and|or|plus|with)\b", ",", blob, flags=re.IGNORECASE)
        blob = re.sub(
            r"\b(detect|find|track|watch|focus|target|objects?|classes?)\b",
            " ",
            blob,
            flags=re.IGNORECASE,
        )
        parts = re.split(r"[,;/|\n\r\t]+", blob)
        out: list[str] = []
        for item in parts:
            clean = str(item or "").strip(" .:：-_\t")
            if not clean:
                continue
            clean = re.sub(
                r"^(只看|只关注|关注|检测|识别|查找|寻找|跟踪|仅看|只检测|看|要看|只关注)",
                "",
                clean,
            ).strip()
            clean = re.sub(
                r"^(detect|find|track|watch|focus|only|target|lookfor)\s+",
                "",
                clean,
                flags=re.IGNORECASE,
            ).strip()
            if not clean:
                continue
            out.append(clean)
        return out

    @staticmethod
    def _singularize_word(word: str) -> str:
        text = str(word or "").strip().lower()
        if len(text) <= 3:
            return text
        if text.endswith("ies") and len(text) > 4:
            return text[:-3] + "y"
        if text.endswith("es") and len(text) > 4:
            return text[:-2]
        if text.endswith("s") and not text.endswith("ss"):
            return text[:-1]
        return text

    def _load_yolo_world_alias_map(self) -> None:
        merged: dict[str, list[str]] = {}
        for key, vals in self._default_yolo_world_aliases().items():
            canon = str(key or "").strip()
            if not canon:
                continue
            merged.setdefault(canon, [])
            for item in vals:
                text = str(item or "").strip()
                if text:
                    merged[canon].append(text)

        self.yolo_world_alias_error = ""
        path = Path(self.yolo_world_aliases_path or "")
        if self.yolo_world_aliases_path and path.exists():
            try:
                obj = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(obj, dict):
                    for key, vals in obj.items():
                        canon = str(key or "").strip()
                        if not canon:
                            continue
                        merged.setdefault(canon, [])
                        if isinstance(vals, list):
                            rows = vals
                        else:
                            rows = [vals]
                        for item in rows:
                            text = str(item or "").strip()
                            if text:
                                merged[canon].append(text)
                else:
                    self.yolo_world_alias_error = f"alias file is not json object: {path}"
            except Exception as exc:
                self.yolo_world_alias_error = f"alias load failed: {exc}"

        for key, vals in dict(self.yolo_world_alias_inline_map).items():
            canon = str(key or "").strip()
            if not canon:
                continue
            merged.setdefault(canon, [])
            for item in vals:
                text = str(item or "").strip()
                if text:
                    merged[canon].append(text)

        normalized: dict[str, list[str]] = {}
        for canon, vals in merged.items():
            seen: set[str] = set()
            out: list[str] = []
            for item in [canon] + list(vals):
                text = str(item or "").strip()
                if not text:
                    continue
                key = text.lower()
                if key in seen:
                    continue
                seen.add(key)
                out.append(text)
            if out:
                normalized[canon] = out
        with self.lock:
            self.yolo_world_alias_map = normalized

    def _build_yolo_world_term_index(self) -> dict[str, set[int]]:
        with self.lock:
            labels = [str(item or "").strip() for item in self.yolo_world_labels]
            emb = self.yolo_world_text_embeddings
            alias_map = dict(self.yolo_world_alias_map)
        emb_count = int(emb.shape[1]) if isinstance(emb, np.ndarray) and emb.ndim == 3 else 0
        total = max(len(labels), emb_count)
        if total <= 0:
            return {}
        if len(labels) < total:
            labels = labels + [f"class_{idx}" for idx in range(len(labels), total)]

        out: dict[str, set[int]] = {}
        label_key_to_idx: dict[str, int] = {}
        for idx, label in enumerate(labels):
            key = self._normalize_yolo_world_label_key(label)
            if key and key not in label_key_to_idx:
                label_key_to_idx[key] = idx
            keys = {key}
            word = self._singularize_word(label)
            if word:
                keys.add(self._normalize_yolo_world_label_key(word))
            keys.add(self._normalize_yolo_world_label_key(f"{label}s"))
            for k in keys:
                if not k:
                    continue
                out.setdefault(k, set()).add(idx)

        for canon, aliases in alias_map.items():
            canon_key = self._normalize_yolo_world_label_key(canon)
            idx = label_key_to_idx.get(canon_key)
            if idx is None and canon.isdigit():
                val = int(canon)
                if 0 <= val < total:
                    idx = val
            if idx is None:
                continue
            for item in aliases:
                key = self._normalize_yolo_world_label_key(item)
                if not key:
                    continue
                out.setdefault(key, set()).add(idx)
        return out

    def _resolve_prompt_terms(
        self, terms: list[str], term_index: dict[str, set[int]]
    ) -> tuple[list[int], list[str], list[str], list[str]]:
        resolved_ids: list[int] = []
        resolved_terms: list[str] = []
        unknown_terms: list[str] = []
        ambiguous_terms: list[str] = []
        if not terms:
            return resolved_ids, resolved_terms, unknown_terms, ambiguous_terms

        all_keys = list(term_index.keys())
        with self.lock:
            labels_snapshot = [str(item or "").strip() for item in self.yolo_world_labels]
            emb_snapshot = self.yolo_world_text_embeddings
            alias_map_snapshot = dict(self.yolo_world_alias_map)
        emb_count_snapshot = (
            int(emb_snapshot.shape[1])
            if isinstance(emb_snapshot, np.ndarray) and emb_snapshot.ndim == 3
            else 0
        )
        total_snapshot = max(len(labels_snapshot), emb_count_snapshot)
        if len(labels_snapshot) < total_snapshot:
            labels_snapshot.extend(
                f"class_{idx}" for idx in range(len(labels_snapshot), total_snapshot)
            )
        label_key_to_idx_snapshot: dict[str, int] = {}
        for idx, label in enumerate(labels_snapshot):
            key = self._normalize_yolo_world_label_key(label)
            if key and key not in label_key_to_idx_snapshot:
                label_key_to_idx_snapshot[key] = idx

        for raw in terms:
            text = str(raw or "").strip()
            if not text:
                continue
            idx: int | None = None
            if text.isdigit():
                val = int(text)
                if val >= 0:
                    idx = val
            if idx is None:
                key = self._normalize_yolo_world_label_key(text)
                if key and key in term_index:
                    vals = sorted(term_index[key])
                    if len(vals) == 1:
                        idx = int(vals[0])
                    elif len(vals) > 1:
                        ambiguous_terms.append(text)
                        continue
                elif key:
                    matched_ids: set[int] = set()
                    matched_key_count = 0
                    for cand in all_keys:
                        if not cand:
                            continue
                        if key in cand or cand in key:
                            ids = term_index.get(cand)
                            if not ids:
                                continue
                            matched_key_count += 1
                            matched_ids.update(ids)
                    if len(matched_ids) == 1 and matched_key_count >= 1:
                        idx = int(next(iter(matched_ids)))
                    elif len(matched_ids) > 1:
                        ambiguous_terms.append(text)
                        continue
                if idx is None and key:
                    alias_ids: set[int] = set()
                    for canon, aliases in alias_map_snapshot.items():
                        canon_key = self._normalize_yolo_world_label_key(canon)
                        canon_idx = label_key_to_idx_snapshot.get(canon_key)
                        if canon_idx is None and canon.isdigit():
                            val = int(canon)
                            if 0 <= val < total_snapshot:
                                canon_idx = val
                        if canon_idx is None:
                            continue
                        for alias in aliases:
                            alias_key = self._normalize_yolo_world_label_key(alias)
                            if not alias_key:
                                continue
                            if key == alias_key or key in alias_key or alias_key in key:
                                alias_ids.add(canon_idx)
                    if len(alias_ids) == 1:
                        idx = int(next(iter(alias_ids)))
                    elif len(alias_ids) > 1:
                        ambiguous_terms.append(text)
                        continue
            if idx is None:
                unknown_terms.append(text)
                continue
            if idx in resolved_ids:
                continue
            resolved_ids.append(idx)
            resolved_terms.append(text)
        return resolved_ids, resolved_terms, unknown_terms, ambiguous_terms

    def yolo_world_prompt_status(self) -> dict[str, Any]:
        payload = self.yolo_world_filter_status()
        payload["api"] = "/api/vision/yolo_world/prompt"
        payload["supported"] = {
            "set": "/api/vision/yolo_world/prompt/set",
            "fields": [
                "prompt",
                "include",
                "exclude",
                "strict",
                "reason",
            ],
        }
        return payload

    @staticmethod
    def _coerce_alias_map(value: Any) -> dict[str, list[str]]:
        out: dict[str, list[str]] = {}
        if not isinstance(value, dict):
            return out
        for raw_key, raw_vals in value.items():
            canon = str(raw_key or "").strip()
            if not canon:
                continue
            vals: list[str] = []
            if isinstance(raw_vals, list):
                rows = raw_vals
            else:
                rows = [raw_vals]
            for row in rows:
                text = str(row or "").strip()
                if text:
                    vals.append(text)
            if vals:
                out[canon] = vals
        return out

    def _resolve_yolo_world_manifest_path(self, raw_name_or_path: str) -> tuple[Path | None, str]:
        raw = str(raw_name_or_path or "").strip()
        if not raw:
            return None, "manifest/name is empty"
        root = Path(self.yolo_world_vocab_dir or "")
        candidates: list[Path] = []
        src = Path(raw)
        if src.is_absolute() or "/" in raw:
            candidates.append(src)
        else:
            candidates.append(root / raw)
            if not raw.endswith(".json"):
                candidates.append(root / f"{raw}.json")
            if not raw.endswith(".manifest.json"):
                candidates.append(root / f"{raw}.manifest.json")
        seen: set[str] = set()
        for cand in candidates:
            key = str(cand)
            if key in seen:
                continue
            seen.add(key)
            if cand.exists() and cand.is_file():
                return cand.resolve(), ""
        return None, f"manifest not found: {raw}"

    def _load_yolo_world_vocab_manifest(self, manifest_path: Path) -> tuple[dict[str, Any], str]:
        obj, err = self._read_json_obj(str(manifest_path))
        if err or obj is None:
            return {}, err or "manifest load failed"
        base_dir = manifest_path.parent
        text_raw = (
            obj.get("text_embeddings")
            or obj.get("text_path")
            or obj.get("embeddings")
            or obj.get("text")
        )
        labels_raw = obj.get("labels_path") or obj.get("labels")
        model_raw = obj.get("model_path") or obj.get("model") or self.yolo_world_model_path
        aliases_raw = obj.get("aliases_path") or obj.get("aliases")

        if not isinstance(text_raw, str) or not text_raw.strip():
            return {}, f"manifest missing text embeddings path: {manifest_path}"
        if not isinstance(labels_raw, str) or not labels_raw.strip():
            return {}, f"manifest missing labels path: {manifest_path}"
        if not isinstance(model_raw, str) or not model_raw.strip():
            return {}, f"manifest missing model path: {manifest_path}"

        aliases_path = ""
        inline_aliases: dict[str, list[str]] = {}
        if isinstance(aliases_raw, str):
            aliases_path = self._resolve_path(base_dir, aliases_raw)
        elif isinstance(aliases_raw, dict):
            inline_aliases = self._coerce_alias_map(aliases_raw)

        name = str(obj.get("name") or "").strip()
        if not name:
            stem = manifest_path.name
            if stem.endswith(".manifest.json"):
                stem = stem[: -len(".manifest.json")]
            elif stem.endswith(".json"):
                stem = stem[: -len(".json")]
            name = stem or "custom"

        out = {
            "manifest_path": str(manifest_path.resolve()),
            "name": name,
            "description": str(obj.get("description") or "").strip() or None,
            "model_path": self._resolve_path(base_dir, str(model_raw)),
            "text_path": self._resolve_path(base_dir, str(text_raw)),
            "labels_path": self._resolve_path(base_dir, str(labels_raw)),
            "aliases_path": aliases_path,
            "aliases_inline": inline_aliases,
            "meta": {
                "version": str(obj.get("version") or "").strip() or None,
                "author": str(obj.get("author") or "").strip() or None,
                "tags": obj.get("tags") if isinstance(obj.get("tags"), list) else [],
            },
        }
        return out, ""

    def _clear_yolo_world_prompt_filter(self, reason: str) -> None:
        now_ts = time.time()
        with self.lock:
            self.yolo_world_class_filter_ids = None
            self.yolo_world_class_filter_names = []
            self.yolo_world_class_filter_reason = str(reason or "manual")
            self.yolo_world_class_filter_updated_ts = now_ts
            self.yolo_world_prompt = ""
            self.yolo_world_prompt_include_terms = []
            self.yolo_world_prompt_exclude_terms = []
            self.yolo_world_prompt_unknown_terms = []
            self.yolo_world_prompt_reason = str(reason or "manual")
            self.yolo_world_prompt_strict = False
            self.yolo_world_prompt_updated_ts = now_ts
        self._reset_yolo_world_cache()

    def yolo_world_vocab_status(self) -> dict[str, Any]:
        with self.lock:
            active = str(self.yolo_world_vocab_active or "")
            manifest = str(self.yolo_world_vocab_manifest or "")
            updated_ts = float(self.yolo_world_vocab_updated_ts)
            reason = str(self.yolo_world_vocab_reason or "")
            vocab_err = str(self.yolo_world_vocab_error or "")
            model_path = str(self.yolo_world_model_path or "")
            text_path = str(self.yolo_world_text_path or "")
            labels_path = str(self.yolo_world_labels_path or "")
            aliases_path = str(self.yolo_world_aliases_path or "")
            inline_alias_count = int(sum(len(v) for v in self.yolo_world_alias_inline_map.values()))
        inspect, inspect_err = self._inspect_yolo_world_assets(
            model_path=model_path,
            text_path=text_path,
            labels_path=labels_path,
            aliases_path=aliases_path,
        )
        payload: dict[str, Any] = {
            "ok": bool(self._yolo_world_ready()),
            "timestamp": _ts_now(),
            "api": "/api/vision/yolo_world/vocab",
            "vocab_root": self.yolo_world_vocab_dir,
            "active_vocab": active or None,
            "active_manifest": manifest or None,
            "vocab_reason": reason or None,
            "vocab_updated_at": (
                datetime.fromtimestamp(updated_ts).isoformat(timespec="seconds")
                if updated_ts > 0
                else None
            ),
            "vocab_error": vocab_err or None,
            "inline_aliases_count": inline_alias_count,
            "assets": inspect,
            "safety_defaults": {
                "safe": bool(self.yolo_world_vocab_safe_default),
                "min_overlap": int(self.yolo_world_vocab_safe_min_overlap),
                "min_mean_cos": float(self.yolo_world_vocab_safe_min_mean_cos),
                "min_anchor_cos": float(self.yolo_world_vocab_safe_min_anchor_cos),
                "anchors": list(self.yolo_world_vocab_safe_anchors),
            },
            "supported": {
                "list": "/api/vision/yolo_world/vocab/list",
                "apply": "/api/vision/yolo_world/vocab/apply",
                "reload": "/api/vision/yolo_world/vocab/reload",
                "apply_fields": [
                    "manifest|name",
                    "model",
                    "text",
                    "labels",
                    "aliases",
                    "reset",
                    "safe",
                    "reason",
                ],
            },
        }
        if inspect_err:
            payload["ok"] = False
            payload["asset_error"] = inspect_err
        return payload

    def yolo_world_vocab_list(self) -> dict[str, Any]:
        root = Path(self.yolo_world_vocab_dir or "")
        rows: list[dict[str, Any]] = []
        if not root.exists():
            return {
                "ok": True,
                "timestamp": _ts_now(),
                "api": "/api/vision/yolo_world/vocab/list",
                "vocab_root": str(root),
                "items": rows,
                "warning": f"vocab dir not found: {root}",
            }
        if not root.is_dir():
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "api": "/api/vision/yolo_world/vocab/list",
                "vocab_root": str(root),
                "error": f"vocab dir is not a directory: {root}",
                "items": rows,
            }

        for manifest_path in sorted(root.glob("*.manifest.json")):
            cfg, cfg_err = self._load_yolo_world_vocab_manifest(manifest_path)
            row: dict[str, Any] = {
                "manifest": str(manifest_path),
                "name": manifest_path.name.replace(".manifest.json", ""),
                "ok": False,
            }
            if cfg_err:
                row["error"] = cfg_err
                rows.append(row)
                continue
            inspect, inspect_err = self._inspect_yolo_world_assets(
                model_path=str(cfg.get("model_path") or ""),
                text_path=str(cfg.get("text_path") or ""),
                labels_path=str(cfg.get("labels_path") or ""),
                aliases_path=str(cfg.get("aliases_path") or ""),
            )
            row.update(
                {
                    "name": str(cfg.get("name") or row["name"]),
                    "description": cfg.get("description"),
                    "model_path": cfg.get("model_path"),
                    "text_path": cfg.get("text_path"),
                    "labels_path": cfg.get("labels_path"),
                    "aliases_path": cfg.get("aliases_path") or None,
                    "meta": cfg.get("meta", {}),
                    "ok": inspect_err == "",
                    "warnings": inspect.get("warnings", []),
                    "labels_count": inspect.get("labels_count"),
                    "embedding_count": inspect.get("embedding_count"),
                    "embedding_dim": inspect.get("embedding_dim"),
                }
            )
            if inspect_err:
                row["error"] = inspect_err
            rows.append(row)
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "api": "/api/vision/yolo_world/vocab/list",
            "vocab_root": str(root),
            "items": rows,
            "count": len(rows),
        }

    def apply_yolo_world_vocab(
        self,
        manifest: str = "",
        name: str = "",
        model_path: str = "",
        text_path: str = "",
        labels_path: str = "",
        aliases_path: str = "",
        reason: str = "manual",
        reset: bool = True,
        safe: bool | None = None,
    ) -> dict[str, Any]:
        source = str(manifest or name or "").strip()
        cfg: dict[str, Any] = {}
        if source:
            manifest_path, mf_err = self._resolve_yolo_world_manifest_path(source)
            if mf_err or manifest_path is None:
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": mf_err or "manifest not found",
                }
            cfg, mf_load_err = self._load_yolo_world_vocab_manifest(manifest_path)
            if mf_load_err:
                return {"ok": False, "timestamp": _ts_now(), "error": mf_load_err}

        target_model = (
            str(model_path).strip()
            or str(cfg.get("model_path") or "").strip()
            or str(self.yolo_world_model_path or "").strip()
        )
        target_text = (
            str(text_path).strip()
            or str(cfg.get("text_path") or "").strip()
            or str(self.yolo_world_text_path or "").strip()
        )
        target_labels = (
            str(labels_path).strip()
            or str(cfg.get("labels_path") or "").strip()
            or str(self.yolo_world_labels_path or "").strip()
        )
        target_aliases = (
            str(aliases_path).strip()
            or str(cfg.get("aliases_path") or "").strip()
            or str(self.yolo_world_aliases_path or "").strip()
        )
        target_inline_aliases = (
            self._coerce_alias_map(cfg.get("aliases_inline"))
            if isinstance(cfg.get("aliases_inline"), dict)
            else {}
        )

        inspect, inspect_err = self._inspect_yolo_world_assets(
            model_path=target_model,
            text_path=target_text,
            labels_path=target_labels,
            aliases_path=target_aliases,
        )
        if inspect_err:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": inspect_err,
                "assets": inspect,
            }
        safe_mode = bool(self.yolo_world_vocab_safe_default if safe is None else safe)
        compatibility = self._evaluate_yolo_world_vocab_compatibility(
            text_path=target_text,
            labels_path=target_labels,
        )
        if safe_mode and not bool(compatibility.get("ok", False)):
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "vocab safety check failed",
                "safe": safe_mode,
                "compatibility": compatibility,
                "assets": inspect,
            }

        with self.lock:
            previous = {
                "model_path": self.yolo_world_model_path,
                "text_path": self.yolo_world_text_path,
                "labels_path": self.yolo_world_labels_path,
                "aliases_path": self.yolo_world_aliases_path,
                "aliases_inline": dict(self.yolo_world_alias_inline_map),
                "active_vocab": self.yolo_world_vocab_active,
                "manifest": self.yolo_world_vocab_manifest,
                "updated_ts": self.yolo_world_vocab_updated_ts,
                "reason": self.yolo_world_vocab_reason,
                "error": self.yolo_world_vocab_error,
                "enabled": bool(self.enabled),
                "class_filter_ids": (
                    set(self.yolo_world_class_filter_ids)
                    if self.yolo_world_class_filter_ids is not None
                    else None
                ),
                "class_filter_names": list(self.yolo_world_class_filter_names),
                "class_filter_reason": self.yolo_world_class_filter_reason,
                "class_filter_updated_ts": self.yolo_world_class_filter_updated_ts,
                "prompt": self.yolo_world_prompt,
                "prompt_include": list(self.yolo_world_prompt_include_terms),
                "prompt_exclude": list(self.yolo_world_prompt_exclude_terms),
                "prompt_unknown": list(self.yolo_world_prompt_unknown_terms),
                "prompt_reason": self.yolo_world_prompt_reason,
                "prompt_strict": bool(self.yolo_world_prompt_strict),
                "prompt_updated_ts": self.yolo_world_prompt_updated_ts,
            }

        with self.yolo_world_reconfig_lock:
            self.yolo_world_model_path = target_model
            self.yolo_world_text_path = target_text
            self.yolo_world_labels_path = target_labels
            self.yolo_world_aliases_path = target_aliases
            self.yolo_world_alias_inline_map = target_inline_aliases
            if reset:
                self._clear_yolo_world_prompt_filter(reason=f"vocab apply: {reason}")

            switch_ok = True
            switch_err = ""
            if previous["enabled"]:
                self.set_enabled(False, reason=f"yolo_world vocab apply ({reason})")
                up_payload = self.set_enabled(True, reason=f"yolo_world vocab apply ({reason})")
                switch_ok = bool(up_payload.get("ok", False)) and bool(self._yolo_world_ready())
                if not switch_ok:
                    switch_err = str(
                        up_payload.get("error")
                        or self.yolo_world_error
                        or "failed to re-enable vision with new yolo_world vocab"
                    )
            else:
                self._init_yolo_world()
                self._load_yolo_world_alias_map()
                switch_ok = bool(self._yolo_world_ready())
                if not switch_ok:
                    switch_err = str(self.yolo_world_error or "failed to initialize yolo_world vocab")

            if not switch_ok:
                self.yolo_world_model_path = str(previous["model_path"] or "")
                self.yolo_world_text_path = str(previous["text_path"] or "")
                self.yolo_world_labels_path = str(previous["labels_path"] or "")
                self.yolo_world_aliases_path = str(previous["aliases_path"] or "")
                self.yolo_world_alias_inline_map = dict(previous["aliases_inline"])
                if previous["enabled"]:
                    self.set_enabled(False, reason="yolo_world vocab rollback")
                    self.set_enabled(True, reason="yolo_world vocab rollback")
                else:
                    self._init_yolo_world()
                    self._load_yolo_world_alias_map()
                with self.lock:
                    self.yolo_world_vocab_active = str(previous["active_vocab"] or "default")
                    self.yolo_world_vocab_manifest = str(previous["manifest"] or "")
                    self.yolo_world_vocab_updated_ts = float(previous["updated_ts"] or 0.0)
                    self.yolo_world_vocab_reason = str(previous["reason"] or "")
                    self.yolo_world_vocab_error = str(switch_err or "vocab switch failed")
                    self.yolo_world_class_filter_ids = (
                        set(previous["class_filter_ids"])
                        if previous["class_filter_ids"] is not None
                        else None
                    )
                    self.yolo_world_class_filter_names = list(previous["class_filter_names"])
                    self.yolo_world_class_filter_reason = str(previous["class_filter_reason"] or "")
                    self.yolo_world_class_filter_updated_ts = float(
                        previous["class_filter_updated_ts"] or 0.0
                    )
                    self.yolo_world_prompt = str(previous["prompt"] or "")
                    self.yolo_world_prompt_include_terms = list(previous["prompt_include"])
                    self.yolo_world_prompt_exclude_terms = list(previous["prompt_exclude"])
                    self.yolo_world_prompt_unknown_terms = list(previous["prompt_unknown"])
                    self.yolo_world_prompt_reason = str(previous["prompt_reason"] or "")
                    self.yolo_world_prompt_strict = bool(previous["prompt_strict"])
                    self.yolo_world_prompt_updated_ts = float(previous["prompt_updated_ts"] or 0.0)
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": switch_err or "vocab switch failed",
                    "rollback": True,
                    "safe": safe_mode,
                    "compatibility": compatibility,
                    "assets": inspect,
                }

            with self.lock:
                self.yolo_world_vocab_active = str(cfg.get("name") or Path(target_labels).stem or "custom")
                self.yolo_world_vocab_manifest = str(cfg.get("manifest_path") or "")
                self.yolo_world_vocab_updated_ts = time.time()
                self.yolo_world_vocab_reason = str(reason or "manual")
                self.yolo_world_vocab_error = ""

        payload = self.yolo_world_vocab_status()
        payload["ok"] = True
        payload["changed"] = True
        payload["reason"] = str(reason or "manual")
        payload["assets"] = inspect
        payload["safe"] = safe_mode
        payload["compatibility"] = compatibility
        payload["message"] = "yolo_world vocab applied"
        payload["reset"] = bool(reset)
        return payload

    def reload_yolo_world_vocab(self, reason: str = "manual") -> dict[str, Any]:
        with self.lock:
            manifest = str(self.yolo_world_vocab_manifest or "")
            model_path = str(self.yolo_world_model_path or "")
            text_path = str(self.yolo_world_text_path or "")
            labels_path = str(self.yolo_world_labels_path or "")
            aliases_path = str(self.yolo_world_aliases_path or "")
        if manifest:
            return self.apply_yolo_world_vocab(
                manifest=manifest,
                reason=reason or "reload",
                reset=False,
            )
        return self.apply_yolo_world_vocab(
            model_path=model_path,
            text_path=text_path,
            labels_path=labels_path,
            aliases_path=aliases_path,
            reason=reason or "reload",
            reset=False,
        )

    def set_yolo_world_prompt(
        self,
        prompt: str = "",
        include: Any = None,
        exclude: Any = None,
        reason: str = "manual",
        strict: bool | None = None,
    ) -> dict[str, Any]:
        strict_mode = (
            bool(strict)
            if strict is not None
            else bool(VISION_YOLO_WORLD_PROMPT_STRICT_DEFAULT)
        )
        include_terms = []
        for row in self._coerce_terms_input(include):
            include_terms.extend(self._split_prompt_terms(row))
        exclude_terms = []
        for row in self._coerce_terms_input(exclude):
            exclude_terms.extend(self._split_prompt_terms(row))
        if not include_terms and str(prompt or "").strip():
            include_terms = self._split_prompt_terms(str(prompt))

        include_terms = include_terms[: int(VISION_YOLO_WORLD_PROMPT_MAX_TERMS)]
        exclude_terms = exclude_terms[: int(VISION_YOLO_WORLD_PROMPT_MAX_TERMS)]

        term_index = self._build_yolo_world_term_index()
        include_ids, include_hits, include_unknown, include_amb = self._resolve_prompt_terms(
            include_terms, term_index
        )
        exclude_ids, exclude_hits, exclude_unknown, exclude_amb = self._resolve_prompt_terms(
            exclude_terms, term_index
        )
        final_unknown = include_unknown + include_amb + exclude_unknown + exclude_amb

        if strict_mode and final_unknown:
            payload = self.yolo_world_prompt_status()
            payload["ok"] = False
            payload["error"] = "strict prompt resolve failed"
            payload["unknown_terms"] = final_unknown
            payload["include_terms"] = include_terms
            payload["exclude_terms"] = exclude_terms
            return payload

        effective_ids = [idx for idx in include_ids if idx not in set(exclude_ids)]
        if include_terms and not effective_ids:
            payload = self.yolo_world_prompt_status()
            payload["ok"] = False
            payload["error"] = "no valid labels resolved from prompt terms"
            payload["unknown_terms"] = final_unknown
            payload["include_terms"] = include_terms
            payload["exclude_terms"] = exclude_terms
            return payload

        if effective_ids:
            labels_arg = ",".join(str(v) for v in sorted(effective_ids))
        else:
            labels_arg = "all"
        result = self.set_yolo_world_filter(
            labels=labels_arg,
            reason=reason,
            preserve_prompt=True,
        )
        if not bool(result.get("ok", False)):
            return result

        with self.lock:
            self.yolo_world_prompt = str(prompt or "")
            self.yolo_world_prompt_include_terms = list(include_terms)
            self.yolo_world_prompt_exclude_terms = list(exclude_terms)
            self.yolo_world_prompt_unknown_terms = list(final_unknown)
            self.yolo_world_prompt_reason = str(reason or "manual")
            self.yolo_world_prompt_strict = bool(strict_mode)
            self.yolo_world_prompt_updated_ts = time.time()

        payload = self.yolo_world_prompt_status()
        payload["ok"] = True
        payload["strict"] = bool(strict_mode)
        payload["include_terms"] = include_terms
        payload["exclude_terms"] = exclude_terms
        payload["matched_include_terms"] = include_hits
        payload["matched_exclude_terms"] = exclude_hits
        payload["unknown_terms"] = final_unknown
        payload["resolved_ids"] = sorted(effective_ids)
        payload["reason"] = str(reason or "manual")
        payload["message"] = (
            "yolo_world prompt applied"
            if effective_ids
            else "yolo_world prompt cleared to all labels"
        )
        return payload

    def _reset_yolo_world_cache(self) -> None:
        with self.lock:
            self.yolo_world_last_result_ts = 0.0
            self.yolo_world_last_result_at = 0.0
            self.yolo_world_last_result_objects = []
            self.yolo_world_last_result_err = ""
            self.yolo_world_last_result_metrics = {}
            self.yolo_world_async_result_ts = 0.0
            self.yolo_world_async_result_at = 0.0
            self.yolo_world_async_objects = []
            self.yolo_world_async_err = ""
            self.yolo_world_async_metrics = {}
            self.yolo_world_async_runtime_fps = 0.0
            self.yolo_world_async_last_loop_ts = 0.0

    def _yolo_world_async_get(
        self, max_age_ms: float = 500.0
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any]] | None:
        now_perf = time.perf_counter()
        with self.lock:
            at = float(self.yolo_world_async_result_at)
            objects = [dict(obj) for obj in self.yolo_world_async_objects]
            err = str(self.yolo_world_async_err or "")
            metrics = dict(self.yolo_world_async_metrics)
            runtime_fps = float(self.yolo_world_async_runtime_fps)
        if at <= 0.0:
            return None
        age_ms = (now_perf - at) * 1000.0
        if max_age_ms > 0 and age_ms > max_age_ms:
            return None
        metrics["async"] = True
        metrics["async_fps"] = round(runtime_fps, 2)
        metrics["async_age_ms"] = round(max(0.0, age_ms), 2)
        return objects, err, metrics

    def _yolo_world_async_set(
        self, frame_ts: float, objects: list[dict[str, Any]], err: str, metrics: dict[str, Any]
    ) -> None:
        now_perf = time.perf_counter()
        with self.lock:
            prev_ts = float(self.yolo_world_async_last_loop_ts)
            if prev_ts > 0:
                dt = max(0.0001, now_perf - prev_ts)
                inst_fps = 1.0 / dt
                if self.yolo_world_async_runtime_fps <= 0:
                    self.yolo_world_async_runtime_fps = inst_fps
                else:
                    self.yolo_world_async_runtime_fps = (
                        self.yolo_world_async_runtime_fps * 0.85
                    ) + (inst_fps * 0.15)
            else:
                self.yolo_world_async_runtime_fps = 0.0
            self.yolo_world_async_last_loop_ts = now_perf
            self.yolo_world_async_result_ts = float(frame_ts) if frame_ts > 0 else 0.0
            self.yolo_world_async_result_at = now_perf
            self.yolo_world_async_objects = [dict(obj) for obj in objects]
            self.yolo_world_async_err = str(err or "")
            self.yolo_world_async_metrics = dict(metrics)

    def _yolo_world_cache_get(
        self, frame_ts: float
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any]] | None:
        ttl_ms = max(0.0, float(self.yolo_world_cache_ttl_ms))
        now_perf = time.perf_counter()
        with self.lock:
            cached_ts = float(self.yolo_world_last_result_ts)
            cached_at = float(self.yolo_world_last_result_at)
            cached_objects = [dict(obj) for obj in self.yolo_world_last_result_objects]
            cached_err = str(self.yolo_world_last_result_err or "")
            cached_metrics = dict(self.yolo_world_last_result_metrics)
        if cached_at <= 0.0:
            return None
        same_frame = frame_ts > 0 and cached_ts > 0 and abs(cached_ts - frame_ts) < 1e-6
        age_ms = (now_perf - cached_at) * 1000.0
        within_ttl = ttl_ms > 0.0 and age_ms <= ttl_ms
        if not same_frame and not within_ttl:
            return None
        cached_metrics["cache_hit"] = True
        cached_metrics["cache_age_ms"] = round(max(0.0, age_ms), 2)
        return cached_objects, cached_err, cached_metrics

    def _yolo_world_cache_set(
        self, frame_ts: float, objects: list[dict[str, Any]], err: str, metrics: dict[str, Any]
    ) -> None:
        with self.lock:
            self.yolo_world_last_result_ts = float(frame_ts) if frame_ts > 0 else 0.0
            self.yolo_world_last_result_at = time.perf_counter()
            self.yolo_world_last_result_objects = [dict(obj) for obj in objects]
            self.yolo_world_last_result_err = str(err or "")
            self.yolo_world_last_result_metrics = dict(metrics)

    def _init_yolo_world(self) -> None:
        self._release_yolo_world_rknn()
        self.yolo_world_text_embeddings = None
        self.yolo_world_labels = []
        self.yolo_world_last_stable_objects = []
        self.yolo_world_spike_streak = 0
        self.yolo_world_drop_streak = 0
        self._reset_yolo_world_cache()
        self.yolo_world_error = "YOLO-World disabled"
        model_path = Path(self.yolo_world_model_path or "")
        if not self.yolo_world_model_path:
            return
        if not model_path.exists():
            self.yolo_world_error = f"YOLO-World model not found: {model_path}"
            return

        emb, emb_err = self._load_yolo_world_text_embeddings()
        if emb is None:
            self.yolo_world_error = emb_err
            return
        self.yolo_world_text_embeddings = emb
        labels = self._load_yolo_world_labels()
        if labels:
            self.yolo_world_labels = labels

        try:
            from rknnlite.api import RKNNLite  # type: ignore
        except Exception as exc:
            self.yolo_world_error = f"rknnlite import failed: {exc}"
            return

        rknn = RKNNLite()
        try:
            ret = rknn.load_rknn(str(model_path))
        except Exception as exc:
            self.yolo_world_error = f"YOLO-World RKNN load exception: {exc}"
            return
        if ret != 0:
            self.yolo_world_error = f"YOLO-World RKNN load failed: ret={ret}"
            return

        init_kwargs: dict[str, Any] = {}
        core_mask = self._resolve_rknn_core_mask(RKNNLite, self.yolo_world_rknn_core)
        if core_mask is not None:
            init_kwargs["core_mask"] = core_mask
        try:
            ret = rknn.init_runtime(**init_kwargs)
        except Exception as exc:
            try:
                rknn.release()
            except Exception:
                pass
            self.yolo_world_error = f"YOLO-World RKNN init exception: {exc}"
            return
        if ret != 0:
            try:
                rknn.release()
            except Exception:
                pass
            self.yolo_world_error = f"YOLO-World RKNN init failed: ret={ret}"
            return

        self.yolo_world_rknn = rknn
        self.yolo_world_error = ""
        if self.enabled:
            self._start_yolo_world_worker()

    def _init_yolo_rknn(self) -> tuple[bool, str]:
        model_path = Path(self.yolo_rknn_model_path)
        if not self.yolo_rknn_model_path:
            return False, "RKNN model path is empty"
        if not model_path.exists():
            return False, f"RKNN model not found: {model_path}"
        try:
            from rknnlite.api import RKNNLite  # type: ignore
        except Exception as exc:
            return False, f"rknnlite import failed: {exc}"

        rknn = RKNNLite()
        try:
            ret = rknn.load_rknn(str(model_path))
        except Exception as exc:
            return False, f"RKNN load exception: {exc}"
        if ret != 0:
            return False, f"RKNN load failed: ret={ret}"

        init_kwargs: dict[str, Any] = {}
        core_mask = self._resolve_rknn_core_mask(RKNNLite)
        if core_mask is not None:
            init_kwargs["core_mask"] = core_mask
        try:
            ret = rknn.init_runtime(**init_kwargs)
        except Exception as exc:
            try:
                rknn.release()
            except Exception:
                pass
            return False, f"RKNN init runtime exception: {exc}"
        if ret != 0:
            try:
                rknn.release()
            except Exception:
                pass
            return False, f"RKNN init runtime failed: ret={ret}"

        self.yolo_rknn = rknn
        self.yolo_backend_active = "rknn"
        self.yolo_error = ""
        return True, ""

    def _init_yolo_opencv(self) -> tuple[bool, str]:
        if self.cv2 is None:
            return False, "opencv unavailable"
        if not self.yolo_model_path:
            return False, "YOLO disabled: VISION_YOLO_MODEL is empty"
        model_path = Path(self.yolo_model_path)
        if not model_path.exists():
            return False, f"YOLO model not found: {model_path}"
        try:
            self.yolo_net = self.cv2.dnn.readNet(str(model_path))
            self.yolo_backend_active = "opencv"
            self.yolo_error = ""
            return True, ""
        except Exception as exc:  # pragma: no cover - runtime environment dependent
            self.yolo_net = None
            return False, f"YOLO init failed: {exc}"

    def _init_yolo_onnxruntime(self) -> tuple[bool, str]:
        if self.cv2 is None:
            return False, "opencv unavailable"
        if not self.yolo_model_path:
            return False, "YOLO disabled: VISION_YOLO_MODEL is empty"
        model_path = Path(self.yolo_model_path)
        if not model_path.exists():
            return False, f"YOLO model not found: {model_path}"
        try:
            import onnxruntime as ort  # type: ignore
        except Exception as exc:
            return False, f"onnxruntime import failed: {exc}"
        providers = ["CPUExecutionProvider"]
        try:
            avail = list(ort.get_available_providers())
        except Exception:
            avail = []
        if "ACLExecutionProvider" in avail:
            providers = ["ACLExecutionProvider", "CPUExecutionProvider"]
        try:
            so = ort.SessionOptions()
            so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            sess = ort.InferenceSession(str(model_path), sess_options=so, providers=providers)
        except Exception as exc:
            return False, f"YOLO init failed: {exc}"
        inputs = list(sess.get_inputs())
        if not inputs:
            return False, "YOLO init failed: empty onnx inputs"
        inp = inputs[0]
        layout = "nchw"
        shape = list(inp.shape) if isinstance(inp.shape, (list, tuple)) else []
        if len(shape) >= 4:
            c1 = shape[1]
            c_last = shape[-1]
            if c_last == 3 or str(c_last) == "3":
                layout = "nhwc"
            elif c1 == 3 or str(c1) == "3":
                layout = "nchw"
        self.yolo_ort_session = sess
        self.yolo_ort_input_name = str(inp.name or "")
        self.yolo_ort_input_dtype = str(inp.type or "tensor(float)")
        self.yolo_ort_input_layout = layout
        self.yolo_backend_active = "onnxruntime"
        self.yolo_error = ""
        return True, ""

    def _init_yolo(self) -> None:
        self.yolo_net = None
        self._release_yolo_rknn()
        self._release_yolo_ort()
        self.yolo_backend_active = ""
        self.yolo_last_stable_objects = []
        self.yolo_spike_streak = 0
        self.yolo_last_suppressed_spike = False
        if self.yolo_backend_requested == "off":
            self.yolo_error = "YOLO disabled by config"
            return
        errors: list[str] = []
        if self.yolo_backend_requested in ("rknn", "auto"):
            ok, err = self._init_yolo_rknn()
            if ok:
                return
            errors.append(err)
            if self.yolo_backend_requested == "rknn":
                self.yolo_error = err
                return
        if self.yolo_backend_requested in ("onnxruntime", "auto"):
            ok, err = self._init_yolo_onnxruntime()
            if ok:
                return
            errors.append(err)
            if self.yolo_backend_requested == "onnxruntime":
                self.yolo_error = err
                return
        if self.yolo_backend_requested in ("opencv", "auto"):
            ok, err = self._init_yolo_opencv()
            if ok:
                return
            errors.append(err)
            if self.yolo_backend_requested == "opencv":
                self.yolo_error = err
                return
        self.yolo_error = "; ".join([e for e in errors if e]) or "YOLO unavailable"

    def _normalize_yolo_output(self, raw_output: Any) -> tuple[np.ndarray, str]:
        out = raw_output
        if isinstance(out, (list, tuple)):
            if len(out) == 0:
                return np.empty((0, 0), dtype=np.float32), "objectness"
            out = out[0]
        arr = np.asarray(out)
        if arr.ndim == 4:
            arr = arr.reshape(arr.shape[0], arr.shape[1], -1)
        if arr.ndim == 3 and arr.shape[0] == 1:
            arr = arr[0]
        if arr.ndim != 2:
            return np.empty((0, 0), dtype=np.float32), "objectness"
        mode = "objectness"
        if arr.shape[0] < arr.shape[1] and arr.shape[0] <= 512:
            arr = arr.T
            mode = "no_objectness"
        if arr.shape[1] == 6:
            mode = "xyxy"
        return arr.astype(np.float32, copy=False), mode

    def _scale_and_clip_xyxy(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        frame_w: int,
        frame_h: int,
    ) -> tuple[int, int, int, int]:
        vals = np.array([x1, y1, x2, y2], dtype=np.float32)
        max_abs = float(np.max(np.abs(vals))) if vals.size else 0.0
        if max_abs <= 1.5:
            vals[0::2] *= float(frame_w)
            vals[1::2] *= float(frame_h)
        else:
            vals[0::2] *= float(frame_w) / float(self.yolo_input)
            vals[1::2] *= float(frame_h) / float(self.yolo_input)
        ix1 = int(np.clip(round(float(min(vals[0], vals[2]))), 0, max(0, frame_w - 1)))
        iy1 = int(np.clip(round(float(min(vals[1], vals[3]))), 0, max(0, frame_h - 1)))
        ix2 = int(np.clip(round(float(max(vals[0], vals[2]))), 0, max(0, frame_w - 1)))
        iy2 = int(np.clip(round(float(max(vals[1], vals[3]))), 0, max(0, frame_h - 1)))
        return ix1, iy1, ix2, iy2

    def _postprocess_yolo_preds(
        self,
        preds: np.ndarray,
        mode: str,
        frame_w: int,
        frame_h: int,
    ) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None:
            return [], "opencv unavailable"
        if preds.size == 0:
            return [], ""
        if preds.ndim != 2 or preds.shape[1] < 6:
            return [], ""

        rows = preds.astype(np.float32, copy=False)
        if mode == "xyxy":
            cls_ids = np.rint(rows[:, 5]).astype(np.int32)
            scores_arr = rows[:, 4]
            boxes_in = rows[:, :4]
        else:
            boxes_xywh_in = rows[:, :4]
            class_scores = rows[:, 4:] if mode == "no_objectness" else rows[:, 5:]
            if class_scores.size == 0:
                return [], ""
            cls_ids = np.argmax(class_scores, axis=1).astype(np.int32)
            cls_prob = class_scores[np.arange(class_scores.shape[0]), cls_ids]
            if mode == "no_objectness":
                scores_arr = cls_prob.astype(np.float32, copy=False)
            else:
                scores_arr = (rows[:, 4] * cls_prob).astype(np.float32, copy=False)
            boxes_in = np.empty((boxes_xywh_in.shape[0], 4), dtype=np.float32)
            boxes_in[:, 0] = boxes_xywh_in[:, 0] - boxes_xywh_in[:, 2] * 0.5
            boxes_in[:, 1] = boxes_xywh_in[:, 1] - boxes_xywh_in[:, 3] * 0.5
            boxes_in[:, 2] = boxes_xywh_in[:, 0] + boxes_xywh_in[:, 2] * 0.5
            boxes_in[:, 3] = boxes_xywh_in[:, 1] + boxes_xywh_in[:, 3] * 0.5

        keep_mask = scores_arr >= float(self.yolo_conf)
        if self.yolo_class_filter:
            allowed = np.isin(cls_ids, np.array(self.yolo_class_filter, dtype=np.int32))
            keep_mask = np.logical_and(keep_mask, allowed)
        if not np.any(keep_mask):
            return [], ""

        boxes = boxes_in[keep_mask]
        cls_ids = cls_ids[keep_mask]
        scores_arr = scores_arr[keep_mask]

        max_abs = float(np.max(np.abs(boxes))) if boxes.size else 0.0
        if max_abs <= 1.5:
            boxes[:, 0] *= float(frame_w)
            boxes[:, 2] *= float(frame_w)
            boxes[:, 1] *= float(frame_h)
            boxes[:, 3] *= float(frame_h)
        else:
            sx = float(frame_w) / float(self.yolo_input)
            sy = float(frame_h) / float(self.yolo_input)
            boxes[:, 0] *= sx
            boxes[:, 2] *= sx
            boxes[:, 1] *= sy
            boxes[:, 3] *= sy

        x1 = np.minimum(boxes[:, 0], boxes[:, 2])
        y1 = np.minimum(boxes[:, 1], boxes[:, 3])
        x2 = np.maximum(boxes[:, 0], boxes[:, 2])
        y2 = np.maximum(boxes[:, 1], boxes[:, 3])

        x1 = np.clip(np.rint(x1), 0, max(0, frame_w - 1)).astype(np.int32)
        y1 = np.clip(np.rint(y1), 0, max(0, frame_h - 1)).astype(np.int32)
        x2 = np.clip(np.rint(x2), 0, max(0, frame_w - 1)).astype(np.int32)
        y2 = np.clip(np.rint(y2), 0, max(0, frame_h - 1)).astype(np.int32)

        bw = np.maximum(0, x2 - x1)
        bh = np.maximum(0, y2 - y1)
        valid = np.logical_and(bw > 1, bh > 1)
        if not np.any(valid):
            return [], ""

        x1 = x1[valid]
        y1 = y1[valid]
        x2 = x2[valid]
        y2 = y2[valid]
        bw = bw[valid]
        bh = bh[valid]
        cls_ids = cls_ids[valid]
        scores_arr = scores_arr[valid]

        boxes_xywh = np.stack([x1, y1, bw, bh], axis=1).tolist()
        scores_list = scores_arr.astype(np.float32).tolist()
        keep = self.cv2.dnn.NMSBoxes(
            bboxes=boxes_xywh,
            scores=scores_list,
            score_threshold=self.yolo_conf,
            nms_threshold=self.yolo_nms,
        )
        if keep is None or len(keep) == 0:
            return [], ""

        out: list[dict[str, Any]] = []
        for idx in np.array(keep).reshape(-1).tolist():
            i = int(idx)
            xi1 = int(x1[i])
            yi1 = int(y1[i])
            xi2 = int(x2[i])
            yi2 = int(y2[i])
            area = float(max(0, xi2 - xi1) * max(0, yi2 - yi1))
            cx = float(xi1 + xi2) * 0.5
            cy = float(yi1 + yi2) * 0.5
            out.append(
                {
                    "type": "yolo",
                    "cx": cx,
                    "cy": cy,
                    "area": area,
                    "bbox_xywh": [xi1, yi1, int(bw[i]), int(bh[i])],
                    "bbox_xyxy": [xi1, yi1, xi2, yi2],
                    "score": float(scores_arr[i]),
                    "class_id": int(cls_ids[i]),
                }
            )
        out.sort(key=lambda d: d["area"], reverse=True)
        return out, ""

    def get_request_config(self) -> dict[str, Any]:
        with self.lock:
            return dict(self.request_cfg)

    def _yolo_ready(self) -> bool:
        if self.yolo_backend_active == "rknn":
            return self.yolo_rknn is not None
        if self.yolo_backend_active == "onnxruntime":
            return self.yolo_ort_session is not None and bool(self.yolo_ort_input_name)
        if self.yolo_backend_active == "opencv":
            return self.yolo_net is not None
        return False

    def _yolo_active_model_path(self) -> str | None:
        if self.yolo_backend_active == "rknn":
            return self.yolo_rknn_model_path or None
        if self.yolo_backend_active == "onnxruntime":
            return self.yolo_model_path or None
        if self.yolo_backend_active == "opencv":
            return self.yolo_model_path or None
        return None

    def _yolo_world_ready(self) -> bool:
        return self.yolo_world_rknn is not None and self.yolo_world_text_embeddings is not None

    def profile_status(self) -> dict[str, Any]:
        with self.lock:
            cfg = dict(self.request_cfg)
            profile_name = self.profile_name
        stream_width, stream_height = self._resolve_stream_size(
            int(cfg.get("width", 0)),
            int(cfg.get("height", 0)),
        )
        return {
            "ok": self.enabled and self.cv2 is not None,
            "enabled": bool(self.enabled),
            "timestamp": _ts_now(),
            "current": profile_name,
            "available": sorted(self.profiles.keys()),
            "request": cfg,
            "stream_output": {
                "width": int(stream_width),
                "height": int(stream_height),
                "configured_width": int(self.stream_output_width),
                "configured_height": int(self.stream_output_height),
            },
            "pipeline_requested": self.pipeline_requested,
            "pipeline_active": self.pipeline_active or None,
            "stream_enabled": self.stream_enabled,
            "stream_default_enabled": VISION_STREAM_ENABLED,
            "yolo_ready": self._yolo_ready(),
            "yolo_model": self._yolo_active_model_path(),
            "yolo_backend_requested": self.yolo_backend_requested,
            "yolo_backend_active": self.yolo_backend_active or None,
            "yolo_model_onnx": self.yolo_model_path or None,
            "yolo_model_rknn": self.yolo_rknn_model_path or None,
            "yolo_error": self.yolo_error or None,
            "yolo_max_objects": int(self.yolo_max_objects),
            "yolo_adaptive_trigger": int(self.yolo_adaptive_trigger),
            "yolo_adaptive_conf": float(self.yolo_adaptive_conf),
            "yolo_spike_count": int(self.yolo_spike_count),
            "yolo_spike_factor": float(self.yolo_spike_factor),
            "yolo_spike_confirm": int(self.yolo_spike_confirm),
            "yolo_suppressed_spike": bool(self.yolo_last_suppressed_spike),
            "yolo_world_ready": self._yolo_world_ready(),
            "yolo_world_model": self.yolo_world_model_path or None,
            "yolo_world_text": self.yolo_world_text_path or None,
            "yolo_world_labels": self.yolo_world_labels_path or None,
            "yolo_world_error": self.yolo_world_error or None,
            "yolo_world_vocab_dir": self.yolo_world_vocab_dir or None,
            "yolo_world_vocab_active": self.yolo_world_vocab_active or None,
            "yolo_world_vocab_manifest": self.yolo_world_vocab_manifest or None,
            "yolo_world_vocab_reason": self.yolo_world_vocab_reason or None,
            "yolo_world_vocab_updated_at": (
                datetime.fromtimestamp(self.yolo_world_vocab_updated_ts).isoformat(timespec="seconds")
                if self.yolo_world_vocab_updated_ts > 0
                else None
            ),
            "yolo_world_vocab_error": self.yolo_world_vocab_error or None,
            "yolo_world_rknn_core": self.yolo_world_rknn_core,
            "yolo_world_single_flight": bool(self.yolo_world_single_flight),
            "yolo_world_async_enabled": bool(self.yolo_world_async_enabled),
            "yolo_world_async_fps": float(self.yolo_world_async_fps),
            "yolo_world_cache_ttl_ms": float(self.yolo_world_cache_ttl_ms),
            "yolo_world_pre_nms_cap": int(self.yolo_world_pre_nms_cap),
            "face_only_mode": bool(self.face_only_mode),
            "gimbal_serial": self.gimbal_status(),
            "gimbal_lock": self.gimbal_lock_status(include_serial=False),
            **self._wear_glasses_status(),
            **self._face_recognition_status(),
            **self._emotion_status(),
            **self._yolo_world_filter_meta(),
        }

    def _start_capture_worker(self) -> None:
        with self.lock:
            thread = self.capture_thread
        if thread is not None and thread.is_alive():
            return
        self.stop_event.clear()
        thread = threading.Thread(
            target=self._capture_loop,
            name="vision-capture",
            daemon=True,
        )
        with self.lock:
            self.capture_thread = thread
        thread.start()

    def _start_yolo_world_worker(self) -> None:
        if not self.yolo_world_async_enabled:
            return
        if not self._yolo_world_ready():
            return
        with self.lock:
            thread = self.yolo_world_thread
        if thread is not None and thread.is_alive():
            return
        self.stop_event.clear()
        thread = threading.Thread(
            target=self._yolo_world_loop,
            name="vision-yolo-world",
            daemon=True,
        )
        with self.lock:
            self.yolo_world_thread = thread
        thread.start()

    def _wear_glasses_warmup_loop(self) -> None:
        if not self.wear_glasses_enabled:
            return
        try:
            self._ensure_wear_glasses_model()
        except Exception:
            return

    def _start_wear_glasses_warmup(self) -> None:
        if not self.wear_glasses_enabled:
            return
        with self.lock:
            thread = self.wear_glasses_warmup_thread
        if thread is not None and thread.is_alive():
            return
        thread = threading.Thread(
            target=self._wear_glasses_warmup_loop,
            name="vision-wear-glasses-warmup",
            daemon=True,
        )
        with self.lock:
            self.wear_glasses_warmup_thread = thread
        thread.start()

    def _emotion_warmup_loop(self) -> None:
        if not self.emotion_enabled:
            return
        try:
            self._ensure_emotion_model()
        except Exception:
            return

    def _start_emotion_warmup(self) -> None:
        if not self.emotion_enabled:
            return
        with self.lock:
            thread = self.emotion_warmup_thread
        if thread is not None and thread.is_alive():
            return
        thread = threading.Thread(
            target=self._emotion_warmup_loop,
            name="vision-emotion-warmup",
            daemon=True,
        )
        with self.lock:
            self.emotion_warmup_thread = thread
        thread.start()

    def _shutdown_vision_runtime(self) -> None:
        self.stop_event.set()
        self._close_capture()
        with self.lock:
            thread = self.capture_thread
            self.capture_thread = None
            yolo_thread = self.yolo_world_thread
            self.yolo_world_thread = None
            wg_warmup_thread = self.wear_glasses_warmup_thread
            self.wear_glasses_warmup_thread = None
            emo_warmup_thread = self.emotion_warmup_thread
            self.emotion_warmup_thread = None
        if (
            thread is not None
            and thread.is_alive()
            and thread is not threading.current_thread()
        ):
            thread.join(timeout=1.2)
        if (
            yolo_thread is not None
            and yolo_thread.is_alive()
            and yolo_thread is not threading.current_thread()
        ):
            yolo_thread.join(timeout=1.2)
        if (
            wg_warmup_thread is not None
            and wg_warmup_thread.is_alive()
            and wg_warmup_thread is not threading.current_thread()
        ):
            wg_warmup_thread.join(timeout=1.2)
        if (
            emo_warmup_thread is not None
            and emo_warmup_thread.is_alive()
            and emo_warmup_thread is not threading.current_thread()
        ):
            emo_warmup_thread.join(timeout=1.2)

        self._release_yolo_rknn()
        self._release_yolo_ort()
        self.yolo_net = None
        self.yolo_backend_active = ""
        self.yolo_last_stable_objects = []
        self.yolo_spike_streak = 0
        self.yolo_last_suppressed_spike = False
        self.yolo_error = "YOLO disabled by runtime"

        self._release_yolo_world_rknn()
        self.yolo_world_text_embeddings = None
        self.yolo_world_labels = []
        self.yolo_world_last_stable_objects = []
        self.yolo_world_spike_streak = 0
        self._reset_yolo_world_cache()
        self.yolo_world_error = "YOLO-World disabled by runtime"
        self._release_emotion_rknn()
        self._release_emotion_face_rknn()
        with self.emotion_lock:
            self.emotion_recognizer = None
            self.emotion_ready = False
            self.emotion_error = "emotion disabled by runtime"
            self.emotion_rknn_labels = list(EMOTION_RKNN_DEFAULT_LABELS)
            self.emotion_rknn_labels_error = ""
            self.emotion_face_detector_obj = None
            self.emotion_face_detector_active = "none"
            self.emotion_face_detector = "none"
            self.emotion_face_input_cached = (0, 0)
            self.emotion_face_detector_error = "emotion face detector disabled by runtime"
        with self.emotion_cache_lock:
            self.emotion_last_eval_ts = 0.0
            self.emotion_cache_ts = 0.0
            self.emotion_cache_items = []
        with self.face_recognition_lock:
            self.face_recognizer = None
            self.face_recognition_ready = False
            self.face_recognition_error = "face recognition disabled by runtime"
            self.face_recognition_backend_active = "none"
            self.face_recognition_target_active = "none"
            self.face_gallery_items = []
            self.face_gallery_identity_count = 0
            self.face_gallery_image_count = 0
            self.face_gallery_updated_ts = 0.0
            self.face_gallery_error = ""
        self.gimbal_lock_stop(wait=True, reason="vision-shutdown")
        self.gimbal_serial.close()

        with self.lock:
            self.latest_frame = None
            self.latest_frame_ts = 0.0
            self.capture_fps = 0.0
            self.last_frame_jpeg = None
            self.last_jpeg_ts = 0.0
            self.last_jpeg_source_ts = 0.0
            self.read_fail_count = 0
            self.open_fail_count = 0
            self.reopen_requested = False

    def set_enabled(self, enabled: bool, reason: str = "manual") -> dict[str, Any]:
        target = bool(enabled)
        with self.lock:
            prev_state = bool(self.enabled)
        if target == prev_state:
            payload = self.profile_status()
            payload["ok"] = True
            payload["previous_enabled"] = prev_state
            payload["enabled_changed"] = False
            payload["reason"] = reason or "manual"
            payload["message"] = "vision already enabled" if target else "vision already disabled"
            return payload

        if target:
            if self.cv2 is None:
                try:
                    import cv2  # type: ignore

                    self.cv2 = cv2
                except Exception as exc:
                    with self.lock:
                        self.enabled = False
                        self.last_error = f"opencv import failed: {exc}"
                    payload = self.profile_status()
                    payload["ok"] = False
                    payload["error"] = self.last_error
                    payload["previous_enabled"] = prev_state
                    payload["enabled_changed"] = False
                    payload["reason"] = reason or "manual"
                    return payload

            self._init_yolo()
            self._init_yolo_world()
            self._load_yolo_world_alias_map()
            self._ensure_face_recognition(reload_gallery=True)
            self._start_capture_worker()
            self._start_yolo_world_worker()
            self._start_wear_glasses_warmup()
            self._start_emotion_warmup()
            with self.lock:
                self.enabled = True
                self.last_error = ""
            payload = self.profile_status()
            payload["ok"] = True
            payload["previous_enabled"] = prev_state
            payload["enabled_changed"] = True
            payload["reason"] = reason or "manual"
            payload["message"] = "vision enabled"
            return payload

        with self.lock:
            self.enabled = False
            self.last_error = f"vision disabled by {reason or 'manual'}"
        self._shutdown_vision_runtime()
        payload = self.profile_status()
        payload["ok"] = True
        payload["previous_enabled"] = prev_state
        payload["enabled_changed"] = True
        payload["reason"] = reason or "manual"
        payload["message"] = "vision disabled"
        payload["note"] = "runtime override only; service restart restores VISION_ENABLED default"
        return payload

    def toggle_enabled(self, reason: str = "manual") -> dict[str, Any]:
        with self.lock:
            next_state = not bool(self.enabled)
        return self.set_enabled(next_state, reason=reason)

    def is_stream_enabled(self) -> bool:
        with self.lock:
            return bool(self.stream_enabled)

    def set_stream_enabled(self, enabled: bool, reason: str = "manual") -> dict[str, Any]:
        next_state = bool(enabled)
        with self.lock:
            prev_state = bool(self.stream_enabled)
            self.stream_enabled = next_state
        payload = self.profile_status()
        payload["previous_stream_enabled"] = prev_state
        payload["stream_changed"] = prev_state != next_state
        payload["reason"] = reason or "manual"
        payload["message"] = (
            "preview stream enabled"
            if next_state
            else "preview stream disabled"
        )
        payload["note"] = "runtime override only; service restart restores VISION_STREAM_ENABLED default"
        return payload

    def toggle_stream_enabled(self, reason: str = "manual") -> dict[str, Any]:
        with self.lock:
            next_state = not bool(self.stream_enabled)
        return self.set_stream_enabled(next_state, reason=reason)

    def set_emotion_enabled(self, enabled: bool, reason: str = "manual") -> dict[str, Any]:
        next_state = bool(enabled)
        with self.lock:
            prev_state = bool(self.emotion_enabled)
            self.emotion_enabled = next_state
            # Keep emotion as an explicit showcase toggle instead of restoring auto mode.
            self.emotion_auto = False
        if next_state:
            with self.emotion_lock:
                self.emotion_error = ""
                if self.emotion_face_detector_error == "emotion face detector disabled by runtime":
                    self.emotion_face_detector_error = ""
            self._start_emotion_warmup()
        else:
            self._release_emotion_rknn()
            self._release_emotion_face_rknn()
            with self.emotion_lock:
                self.emotion_recognizer = None
                self.emotion_ready = False
                self.emotion_error = "emotion disabled by runtime"
                self.emotion_rknn_labels = list(EMOTION_RKNN_DEFAULT_LABELS)
                self.emotion_rknn_labels_error = ""
                self.emotion_face_detector_obj = None
                self.emotion_face_detector_active = "none"
                self.emotion_face_detector = "none"
                self.emotion_face_input_cached = (0, 0)
                self.emotion_face_detector_error = "emotion face detector disabled by runtime"
                self.emotion_refresh_pending = False
                self.emotion_last_eval_ts = 0.0
            self._set_emotion_cache([])
        payload = self.profile_status()
        payload["previous_emotion_enabled"] = prev_state
        payload["emotion_changed"] = prev_state != next_state
        payload["reason"] = reason or "manual"
        payload["message"] = (
            "emotion inference enabled"
            if next_state
            else "emotion inference disabled"
        )
        payload["note"] = "runtime override only; service restart restores VISION_EMOTION_ENABLED default"
        return payload

    def gimbal_status(self) -> dict[str, Any]:
        return self.gimbal_serial.status()

    def gimbal_command(
        self,
        *,
        yaw_rpm: float,
        pitch_rpm: float,
        laser_enabled: Any = None,
        enabled: Any = None,
        stability_enabled: Any = None,
        auto_stop_ms: int | None = None,
        reason: str = "manual",
    ) -> dict[str, Any]:
        return self.gimbal_serial.send_speed(
            yaw_rpm=yaw_rpm,
            pitch_rpm=pitch_rpm,
            laser_flag=laser_enabled,
            enabled_flag=enabled,
            stability_flag=stability_enabled,
            auto_stop_ms=auto_stop_ms,
            reason=reason,
        )

    @staticmethod
    def _gimbal_lock_norm_key(text: Any) -> str:
        return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(text or "").strip().lower())

    @staticmethod
    def _gimbal_lock_detector_key(detector: str) -> str:
        key = str(detector or "auto").strip().lower()
        if key in ("yolo11", "yolo-11", "yolo_11"):
            key = "yolo"
        if key in ("head", "face-only", "face_only"):
            key = "face"
        if key in ("face+world", "face-world", "fusion", "face_world"):
            key = "auto"
        if key in ("smart", "adaptive"):
            key = "auto"
        return key

    @staticmethod
    def _gimbal_lock_detector_preset(detector_key: str) -> dict[str, float | int]:
        return dict(VISION_GIMBAL_LOCK_DETECTOR_PRESETS.get(str(detector_key or ""), {}))

    @staticmethod
    def _gimbal_lock_is_human_keys(keys: set[str]) -> bool:
        if not keys:
            return False
        return any(str(item or "") in VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM for item in keys)

    def _gimbal_lock_object_keys(self, obj: dict[str, Any]) -> set[str]:
        cls_name = str(obj.get("class_name") or "").strip()
        cls_key = self._gimbal_lock_norm_key(cls_name)
        obj_type = str(obj.get("type") or "").strip().lower()
        out: set[str] = set()
        if cls_key:
            out.add(cls_key)
        if obj_type == "face" or cls_key == "face":
            out.update(VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM)
        elif cls_key in VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM:
            out.update(VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM)
        return {item for item in out if item}

    def _gimbal_lock_resolve_detector(
        self,
        detector: str,
        target_keys: set[str],
    ) -> tuple[str | None, str, bool]:
        requested = self._gimbal_lock_detector_key(detector)
        human_target = self._gimbal_lock_is_human_keys(target_keys)

        if requested in ("off", "none", "rect"):
            return None, f"unsupported detector for lock: {requested}", human_target
        if requested not in ("auto", "face", "yolo", "yolo_world"):
            return None, f"unsupported detector for lock: {requested}", human_target

        if requested == "auto":
            resolved = "face" if human_target else "yolo_world"
        else:
            resolved = requested

        notes: list[str] = []
        if resolved == "face" and not self._face_detector_requested_enabled():
            if self._yolo_world_ready():
                resolved = "yolo_world"
                notes.append("face detector disabled, fallback to yolo_world")
            elif self._yolo_ready():
                resolved = "yolo"
                notes.append("face detector disabled, fallback to yolo")
            else:
                return None, "face detector disabled and no fallback detector ready", human_target
        elif resolved == "yolo_world" and not self._yolo_world_ready():
            if self._yolo_ready():
                resolved = "yolo"
                notes.append("yolo_world unavailable, fallback to yolo")
            elif self._face_detector_requested_enabled():
                resolved = "face"
                notes.append("yolo_world unavailable, fallback to face")
            else:
                return None, "yolo_world unavailable and no fallback detector ready", human_target
        elif resolved == "yolo" and not self._yolo_ready():
            if self._yolo_world_ready():
                resolved = "yolo_world"
                notes.append("yolo unavailable, fallback to yolo_world")
            elif self._face_detector_requested_enabled():
                resolved = "face"
                notes.append("yolo unavailable, fallback to face")
            else:
                return None, "yolo unavailable and no fallback detector ready", human_target

        if requested == "auto":
            mode = "human-target" if human_target else "non-human-target"
            notes.insert(0, f"auto detector selected {resolved} ({mode})")
        return resolved, "; ".join(item for item in notes if item), human_target

    def _gimbal_lock_terms(self, target: str) -> tuple[list[str], set[str]]:
        source = self._split_yolo_world_label_tokens(str(target or "").strip())
        if not source and str(target or "").strip():
            source = [str(target or "").strip()]
        seen: set[str] = set()
        terms: list[str] = []
        for item in source:
            key = self._gimbal_lock_norm_key(item)
            if not key or key in seen:
                continue
            seen.add(key)
            terms.append(item.strip())
        term_keys = {self._gimbal_lock_norm_key(item) for item in terms if self._gimbal_lock_norm_key(item)}

        with self.lock:
            alias_map = dict(self.yolo_world_alias_map)

        canon_keys: set[str] = set()
        for canon, aliases in alias_map.items():
            canon_key = self._gimbal_lock_norm_key(canon)
            if not canon_key:
                continue
            if canon_key in term_keys:
                canon_keys.add(canon_key)
                continue
            for alias in aliases:
                alias_key = self._gimbal_lock_norm_key(alias)
                if alias_key and alias_key in term_keys:
                    canon_keys.add(canon_key)
                    break
        if not canon_keys:
            canon_keys = set(term_keys)
        if self._gimbal_lock_is_human_keys(canon_keys):
            canon_keys.update(VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM)
        return terms, canon_keys

    def _gimbal_lock_collect_candidates(
        self,
        objects: list[dict[str, Any]],
        *,
        frame_w: int,
        frame_h: int,
        target_keys: set[str],
        min_score: float,
        exclude_person: bool = False,
        prefer_largest: bool = False,
    ) -> list[dict[str, Any]]:
        if not isinstance(objects, list) or not objects:
            return []
        cx0 = float(frame_w) * 0.5
        cy0 = float(frame_h) * 0.5
        candidates: list[tuple[float, float, float, dict[str, Any]]] = []
        for obj in objects:
            if not isinstance(obj, dict):
                continue
            obj_type = str(obj.get("type") or "").strip().lower()
            obj_keys = self._gimbal_lock_object_keys(obj)
            if exclude_person and obj_type == "yolo_world":
                if any(item in VISION_GIMBAL_LOCK_HUMAN_TARGET_KEYS_NORM for item in obj_keys):
                    continue
            if target_keys:
                matched = False
                for tok in target_keys:
                    token = str(tok or "")
                    if not token:
                        continue
                    if token in obj_keys:
                        matched = True
                        break
                    if len(token) >= 2 and any(token in key for key in obj_keys):
                        matched = True
                        break
                if not matched:
                    continue
            score = float(obj.get("score") or 0.0)
            if score < float(min_score):
                continue
            cx = float(obj.get("cx") or 0.0)
            cy = float(obj.get("cy") or 0.0)
            dist = abs(cx - cx0) + abs(cy - cy0)
            bbox = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
            area = 0.0
            if bbox is not None:
                width = max(0.0, float(bbox[2] - bbox[0]))
                height = max(0.0, float(bbox[3] - bbox[1]))
                area = width * height
            candidates.append((area, score, -dist, obj))
        if not candidates:
            return []
        if prefer_largest:
            candidates.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
        else:
            candidates.sort(key=lambda item: (item[1], item[2], item[0]), reverse=True)
        return [dict(item[3]) for item in candidates]

    def _gimbal_lock_pick_target(
        self,
        objects: list[dict[str, Any]],
        *,
        frame_w: int,
        frame_h: int,
        target_keys: set[str],
        min_score: float,
        exclude_person: bool = False,
    ) -> dict[str, Any] | None:
        candidates = self._gimbal_lock_collect_candidates(
            objects,
            frame_w=frame_w,
            frame_h=frame_h,
            target_keys=target_keys,
            min_score=min_score,
            exclude_person=exclude_person,
        )
        if not candidates:
            return None
        return dict(candidates[0])

    @staticmethod
    def _gimbal_lock_bbox_center_distance_norm(
        a: list[int],
        b: list[int],
        *,
        frame_w: int,
        frame_h: int,
    ) -> float:
        diag = max(1.0, (float(frame_w) * float(frame_w) + float(frame_h) * float(frame_h)) ** 0.5)
        ax = (float(a[0]) + float(a[2])) * 0.5
        ay = (float(a[1]) + float(a[3])) * 0.5
        bx = (float(b[0]) + float(b[2])) * 0.5
        by = (float(b[1]) + float(b[3])) * 0.5
        dist = ((ax - bx) * (ax - bx) + (ay - by) * (ay - by)) ** 0.5
        return float(dist / diag)

    def _gimbal_lock_pick_single_face_target(
        self,
        candidates: list[dict[str, Any]],
        *,
        anchor_bbox: list[int] | None,
        pending_bbox: list[int] | None,
        pending_frames: int,
        miss_frames: int,
        frame_w: int,
        frame_h: int,
    ) -> tuple[dict[str, Any] | None, list[int] | None, list[int] | None, int, int, str]:
        keep_iou = float(VISION_GIMBAL_LOCK_FACE_KEEP_IOU)
        keep_center_norm = float(VISION_GIMBAL_LOCK_FACE_KEEP_CENTER_NORM)
        miss_grace = int(VISION_GIMBAL_LOCK_FACE_MISS_GRACE_FRAMES)
        switch_confirm = int(VISION_GIMBAL_LOCK_FACE_SWITCH_CONFIRM_FRAMES)

        def bbox_of(obj: dict[str, Any]) -> list[int] | None:
            return self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))

        if not candidates:
            return None, anchor_bbox, None, 0, int(max(0, miss_frames)) + 1, "no-candidate"

        if anchor_bbox is None:
            lead = dict(candidates[0])
            return lead, bbox_of(lead), None, 0, 0, "init"

        best_same: dict[str, Any] | None = None
        best_same_bbox: list[int] | None = None
        best_same_score = -1.0
        for cand in candidates:
            cbbox = bbox_of(cand)
            if cbbox is None:
                continue
            iou = self._bbox_iou_xyxy(anchor_bbox, cbbox)
            dist_norm = self._gimbal_lock_bbox_center_distance_norm(
                anchor_bbox,
                cbbox,
                frame_w=frame_w,
                frame_h=frame_h,
            )
            if iou < keep_iou and dist_norm > keep_center_norm:
                continue
            continuity = (
                (iou * 1.2)
                + ((1.0 - min(1.0, dist_norm)) * 0.6)
                + (float(cand.get("score") or 0.0) * 0.2)
            )
            if continuity > best_same_score:
                best_same_score = continuity
                best_same = cand
                best_same_bbox = cbbox
        if best_same is not None:
            return dict(best_same), best_same_bbox, None, 0, 0, "anchor"

        next_miss = int(max(0, miss_frames)) + 1
        if next_miss <= miss_grace:
            return None, anchor_bbox, None, 0, next_miss, "hold-miss"

        lead = dict(candidates[0])
        lead_bbox = bbox_of(lead)
        if lead_bbox is None:
            return lead, None, None, 0, 0, "reacquire-no-bbox"

        pending_next = 1
        if pending_bbox is not None:
            pending_iou = self._bbox_iou_xyxy(pending_bbox, lead_bbox)
            pending_dist_norm = self._gimbal_lock_bbox_center_distance_norm(
                pending_bbox,
                lead_bbox,
                frame_w=frame_w,
                frame_h=frame_h,
            )
            if pending_iou >= keep_iou or pending_dist_norm <= max(0.01, keep_center_norm * 0.75):
                pending_next = int(max(1, pending_frames)) + 1
        if pending_next < switch_confirm:
            return None, anchor_bbox, lead_bbox, pending_next, next_miss, "switch-pending"
        return lead, lead_bbox, None, 0, 0, "switch"

    def _gimbal_lock_set_state(self, **kwargs: Any) -> None:
        now_ts = time.time()
        with self.gimbal_lock_state_lock:
            self.gimbal_lock_state.update(kwargs)
            self.gimbal_lock_state["last_update_ts"] = now_ts

    @staticmethod
    def _fmt_iso(ts: float) -> str | None:
        if ts <= 0:
            return None
        return datetime.fromtimestamp(ts).isoformat(timespec="seconds")

    def gimbal_lock_status(self, include_serial: bool = True) -> dict[str, Any]:
        with self.gimbal_lock_state_lock:
            payload = dict(self.gimbal_lock_state)
            thread = self.gimbal_lock_thread
            payload["thread_alive"] = bool(thread is not None and thread.is_alive())
        payload["ok"] = True
        payload["timestamp"] = _ts_now()
        payload["started_at"] = self._fmt_iso(float(payload.get("started_ts") or 0.0))
        payload["finished_at"] = self._fmt_iso(float(payload.get("finished_ts") or 0.0))
        payload["last_update_at"] = self._fmt_iso(float(payload.get("last_update_ts") or 0.0))
        payload["summary"] = str(payload.get("message") or payload.get("status") or "idle")
        if include_serial:
            payload["gimbal_serial"] = self.gimbal_status()
        return payload

    def _gimbal_lock_emit_stop(self, reason: str, laser_flag: int = 2) -> None:
        try:
            self.gimbal_command(
                yaw_rpm=0.0,
                pitch_rpm=0.0,
                laser_enabled=laser_flag,
                auto_stop_ms=0,
                reason=reason,
            )
        except Exception:
            pass

    def _gimbal_lock_blink_laser(
        self,
        *,
        blinks: int,
        on_ms: int,
        off_ms: int,
        run_id: str,
        stop_event: threading.Event | None = None,
    ) -> int:
        done = 0
        for idx in range(max(0, int(blinks))):
            if stop_event is not None and stop_event.is_set():
                break
            self.gimbal_command(
                yaw_rpm=0.0,
                pitch_rpm=0.0,
                laser_enabled=1,
                auto_stop_ms=0,
                reason=f"{run_id}:laser-on:{idx + 1}",
            )
            time.sleep(max(0.01, float(on_ms) / 1000.0))
            self.gimbal_command(
                yaw_rpm=0.0,
                pitch_rpm=0.0,
                laser_enabled=0,
                auto_stop_ms=0,
                reason=f"{run_id}:laser-off:{idx + 1}",
            )
            done += 1
            if idx + 1 < int(blinks):
                time.sleep(max(0.01, float(off_ms) / 1000.0))
        return done

    def _gimbal_lock_worker(self, run_id: str, params: dict[str, Any]) -> None:
        started_ts = time.time()
        target = str(params.get("target") or "").strip()
        detector_requested = (
            str(params.get("detector_requested") or params.get("detector") or "auto")
            .strip()
            .lower()
            or "auto"
        )
        detector_resolved = (
            str(params.get("detector_resolved") or params.get("detector") or "face")
            .strip()
            .lower()
            or "face"
        )
        detector_note = str(params.get("detector_note") or "")
        target_human = bool(params.get("target_human", False))
        exclude_person = bool(params.get("exclude_person", False))
        timeout_sec = float(params.get("timeout_sec") or VISION_GIMBAL_LOCK_TIMEOUT_SEC)
        loop_interval = float(params.get("loop_interval_sec") or VISION_GIMBAL_LOCK_LOOP_INTERVAL_SEC)
        center_tol_px = float(params.get("center_tolerance_px") or VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX)
        hold_tol_scale = float(
            params.get("hold_tolerance_scale")
            if params.get("hold_tolerance_scale") is not None
            else VISION_GIMBAL_LOCK_HOLD_TOLERANCE_SCALE
        )
        hold_tol_scale = float(max(1.0, min(3.0, hold_tol_scale)))
        stable_required = int(
            params.get("required_stable_frames")
            if params.get("required_stable_frames") is not None
            else (
                params.get("stable_frames")
                if params.get("stable_frames") is not None
                else VISION_GIMBAL_LOCK_STABLE_FRAMES
            )
        )
        min_score = float(params.get("min_score") or VISION_GIMBAL_LOCK_MIN_SCORE)
        max_rpm = float(params.get("max_rpm") or VISION_GIMBAL_LOCK_MAX_RPM)
        kp_yaw = float(params.get("kp_yaw") or VISION_GIMBAL_LOCK_KP_YAW)
        kp_pitch = float(params.get("kp_pitch") or VISION_GIMBAL_LOCK_KP_PITCH)
        err_ema_alpha = float(
            params.get("err_ema_alpha")
            if params.get("err_ema_alpha") is not None
            else VISION_GIMBAL_LOCK_ERR_EMA_ALPHA
        )
        err_ema_alpha = float(max(0.05, min(1.0, err_ema_alpha)))
        cmd_min_rpm = float(
            params.get("cmd_min_rpm")
            if params.get("cmd_min_rpm") is not None
            else VISION_GIMBAL_LOCK_CMD_MIN_RPM
        )
        cmd_min_rpm = float(max(0.0, min(max_rpm, cmd_min_rpm)))
        brake_zone_px = float(
            params.get("brake_zone_px")
            if params.get("brake_zone_px") is not None
            else VISION_GIMBAL_LOCK_BRAKE_ZONE_PX
        )
        brake_zone_px = float(max(4.0, min(640.0, brake_zone_px)))
        brake_min_scale = float(
            params.get("brake_min_scale")
            if params.get("brake_min_scale") is not None
            else VISION_GIMBAL_LOCK_BRAKE_MIN_SCALE
        )
        brake_min_scale = float(max(0.05, min(1.0, brake_min_scale)))
        cmd_slew_rpm_per_sec = float(
            params.get("cmd_slew_rpm_per_sec")
            if params.get("cmd_slew_rpm_per_sec") is not None
            else VISION_GIMBAL_LOCK_CMD_SLEW_RPM_PER_SEC
        )
        cmd_slew_rpm_per_sec = float(max(0.0, min(400.0, cmd_slew_rpm_per_sec)))
        invert_yaw = bool(params.get("invert_yaw", VISION_GIMBAL_LOCK_INVERT_YAW))
        invert_pitch = bool(params.get("invert_pitch", VISION_GIMBAL_LOCK_INVERT_PITCH))
        continuous = bool(params.get("continuous", False))
        sweep_rpm = float(
            params.get("search_sweep_rpm")
            if params.get("search_sweep_rpm") is not None
            else VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM
        )
        sweep_pulse_ms = int(
            params.get("search_sweep_pulse_ms")
            if params.get("search_sweep_pulse_ms") is not None
            else VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS
        )
        search_spin_deg = float(
            params.get("search_spin_deg")
            if params.get("search_spin_deg") is not None
            else VISION_GIMBAL_LOCK_SEARCH_SPIN_DEG
        )
        search_spin_deg = float(max(30.0, min(2160.0, search_spin_deg)))
        search_spin_clockwise = bool(
            params.get("search_spin_clockwise")
            if params.get("search_spin_clockwise") is not None
            else VISION_GIMBAL_LOCK_SEARCH_SPIN_CLOCKWISE
        )
        laser_blinks = int(
            params.get("laser_blinks")
            if params.get("laser_blinks") is not None
            else VISION_GIMBAL_LOCK_LASER_BLINKS
        )
        laser_on_ms = int(params.get("laser_on_ms") or VISION_GIMBAL_LOCK_LASER_ON_MS)
        laser_off_ms = int(params.get("laser_off_ms") or VISION_GIMBAL_LOCK_LASER_OFF_MS)
        reason = str(params.get("reason") or "manual")
        observe_wear_glasses = bool(params.get("observe_wear_glasses", False))
        observe_emotion = bool(params.get("observe_emotion", False))
        observe_detail_note = str(params.get("observe_detail_note") or "")
        single_face_mode = bool(
            params.get("single_face_mode")
            if params.get("single_face_mode") is not None
            else (
                bool(VISION_GIMBAL_LOCK_SINGLE_FACE_TARGET)
                and bool(target_human)
                and detector_resolved == "face"
            )
        )
        face_anchor_bbox = self._normalize_bbox_xyxy(params.get("face_anchor_bbox"))
        face_anchor_miss_frames = int(max(0, int(params.get("face_anchor_miss_frames") or 0)))
        face_switch_pending_bbox = self._normalize_bbox_xyxy(params.get("face_switch_pending_bbox"))
        face_switch_pending_frames = int(max(0, int(params.get("face_switch_pending_frames") or 0)))

        stable_frames = 0
        iterations = 0
        blink_done = 0
        last_target: dict[str, Any] | None = None
        err_x_ema: float | None = None
        err_y_ema: float | None = None
        prev_yaw_cmd = 0.0
        prev_pitch_cmd = 0.0
        search_spin_progress_deg = float(max(0.0, float(params.get("search_spin_progress_deg") or 0.0)))
        search_spin_rounds = int(max(0, int(params.get("search_spin_rounds") or 0)))
        search_yaw_sign = 1.0 if search_spin_clockwise else -1.0
        target_terms_raw = params.get("target_terms_resolved")
        target_keys_raw = params.get("target_keys_resolved")
        if isinstance(target_terms_raw, list):
            target_terms = [str(item).strip() for item in target_terms_raw if str(item or "").strip()]
        else:
            target_terms = []
        if isinstance(target_keys_raw, list):
            target_keys = {
                self._gimbal_lock_norm_key(item) for item in target_keys_raw if self._gimbal_lock_norm_key(item)
            }
        else:
            target_keys = set()
        if not target_terms and not target_keys:
            target_terms, target_keys = self._gimbal_lock_terms(target)

        final_status = "failed"
        final_message = "lock failed"
        final_error = ""
        locked = False
        result_payload: dict[str, Any] = {}
        self._gimbal_lock_set_state(
            status="running",
            message="lock task running",
            reason=reason,
            target_raw=target,
            target_terms=target_terms,
            detector=detector_resolved,
            detector_requested=detector_requested,
            detector_resolved=detector_resolved,
            detector_note=detector_note or None,
            target_human=bool(target_human),
            exclude_person=bool(exclude_person),
            single_face_mode=bool(single_face_mode),
            face_anchor_bbox=face_anchor_bbox,
            face_anchor_miss_frames=int(face_anchor_miss_frames),
            face_switch_pending_bbox=face_switch_pending_bbox,
            face_switch_pending_frames=int(face_switch_pending_frames),
            observe_wear_glasses=bool(observe_wear_glasses),
            observe_emotion=bool(observe_emotion),
            observe_detail_note=observe_detail_note,
            continuous=continuous,
            started_ts=started_ts,
            finished_ts=0.0,
            iterations=0,
            stable_frames=0,
            required_stable_frames=stable_required,
            timeout_sec=timeout_sec,
            center_tolerance_px=center_tol_px,
            hold_tolerance_scale=hold_tol_scale,
            min_score=min_score,
            max_rpm=max_rpm,
            kp_yaw=kp_yaw,
            kp_pitch=kp_pitch,
            err_ema_alpha=err_ema_alpha,
            cmd_min_rpm=cmd_min_rpm,
            brake_zone_px=brake_zone_px,
            brake_min_scale=brake_min_scale,
            cmd_slew_rpm_per_sec=cmd_slew_rpm_per_sec,
            invert_yaw=invert_yaw,
            invert_pitch=invert_pitch,
            search_sweep_rpm=sweep_rpm,
            search_sweep_pulse_ms=sweep_pulse_ms,
            search_spin_deg=search_spin_deg,
            search_spin_clockwise=bool(search_spin_clockwise),
            search_spin_progress_deg=round(float(search_spin_progress_deg), 2),
            search_spin_rounds=int(search_spin_rounds),
            laser_blinks=laser_blinks,
            laser_on_ms=laser_on_ms,
            laser_off_ms=laser_off_ms,
            blink_done=0,
            last_observe_summary="",
            last_error="",
            last_target=None,
            last_command=None,
            last_tracker_output=None,
            locked=False,
            result=None,
        )

        def _issue_search_spin(reason_suffix: str) -> None:
            nonlocal search_spin_progress_deg, search_spin_rounds
            if sweep_rpm <= 0:
                return
            # Search is speed-driven (rpm): estimate scanned yaw degrees for one-loop progress.
            pulse_ms = int(sweep_pulse_ms if sweep_pulse_ms > 0 else max(60, int(loop_interval * 1400.0)))
            yaw_rpm = search_yaw_sign * abs(float(sweep_rpm))
            cmd = self.gimbal_command(
                yaw_rpm=yaw_rpm,
                pitch_rpm=0.0,
                laser_enabled=2,
                auto_stop_ms=pulse_ms,
                reason=f"{run_id}:{reason_suffix}",
            )
            pulse_sec = max(float(loop_interval), float(pulse_ms) / 1000.0)
            deg_step = abs(float(yaw_rpm)) * 6.0 * pulse_sec
            if search_spin_deg > 1e-6 and deg_step > 0.0:
                scanned = float(search_spin_progress_deg) + float(deg_step)
                completed = int(scanned // float(search_spin_deg))
                if completed > 0:
                    search_spin_rounds += int(completed)
                search_spin_progress_deg = float(scanned % float(search_spin_deg))
            self._gimbal_lock_set_state(
                last_command=cmd.get("command"),
                search_spin_progress_deg=round(float(search_spin_progress_deg), 2),
                search_spin_rounds=int(search_spin_rounds),
            )

        try:
            while True:
                iterations += 1
                elapsed = time.time() - started_ts
                if self.gimbal_lock_stop_event.is_set():
                    final_status = "stopped"
                    final_message = "lock task stopped"
                    final_error = "stopped by request"
                    break
                if elapsed >= timeout_sec:
                    final_status = "timeout"
                    final_message = "lock task timeout"
                    final_error = "target not locked before timeout"
                    break

                obs = self.observe(
                    detector=detector_resolved,
                    wear_glasses=bool(observe_wear_glasses),
                    emotion=bool(observe_emotion),
                )
                obs_ok = bool(obs.get("ok", False))
                obs_summary = str(obs.get("summary") or "")
                objects = obs.get("objects") if isinstance(obs.get("objects"), list) else []
                frame = obs.get("frame") if isinstance(obs.get("frame"), dict) else {}
                frame_w = int(frame.get("width") or 0)
                frame_h = int(frame.get("height") or 0)

                if not obs_ok or frame_w <= 0 or frame_h <= 0:
                    err = str(obs.get("error") or "observe failed")
                    final_error = err
                    stable_frames = 0
                    err_x_ema = None
                    err_y_ema = None
                    prev_yaw_cmd = 0.0
                    prev_pitch_cmd = 0.0
                    self._gimbal_lock_set_state(
                        iterations=iterations,
                        stable_frames=stable_frames,
                        message=f"observe failed: {err}",
                        single_face_mode=bool(single_face_mode),
                        face_anchor_bbox=face_anchor_bbox,
                        face_anchor_miss_frames=int(face_anchor_miss_frames),
                        face_switch_pending_bbox=face_switch_pending_bbox,
                        face_switch_pending_frames=int(face_switch_pending_frames),
                        last_observe_summary=obs_summary,
                        last_error=err,
                        last_tracker_output={
                            "mode": "observe_failed",
                            "detector_requested": detector_requested,
                            "detector_resolved": detector_resolved,
                            "single_face_mode": bool(single_face_mode),
                            "face_anchor_miss_frames": int(face_anchor_miss_frames),
                            "face_switch_pending_frames": int(face_switch_pending_frames),
                            "observe_wear_glasses": bool(observe_wear_glasses),
                            "observe_emotion": bool(observe_emotion),
                            "error": err,
                            "search_spin_progress_deg": round(float(search_spin_progress_deg), 2),
                            "search_spin_rounds": int(search_spin_rounds),
                        },
                    )
                    _issue_search_spin("search-observe-fail")
                    time.sleep(loop_interval)
                    continue

                picked_mode = "default"
                if single_face_mode:
                    candidates = self._gimbal_lock_collect_candidates(
                        objects,
                        frame_w=frame_w,
                        frame_h=frame_h,
                        target_keys=target_keys,
                        min_score=min_score,
                        exclude_person=exclude_person,
                        prefer_largest=True,
                    )
                    (
                        picked,
                        face_anchor_bbox,
                        face_switch_pending_bbox,
                        face_switch_pending_frames,
                        face_anchor_miss_frames,
                        picked_mode,
                    ) = self._gimbal_lock_pick_single_face_target(
                        candidates,
                        anchor_bbox=face_anchor_bbox,
                        pending_bbox=face_switch_pending_bbox,
                        pending_frames=face_switch_pending_frames,
                        miss_frames=face_anchor_miss_frames,
                        frame_w=frame_w,
                        frame_h=frame_h,
                    )
                else:
                    picked = self._gimbal_lock_pick_target(
                        objects,
                        frame_w=frame_w,
                        frame_h=frame_h,
                        target_keys=target_keys,
                        min_score=min_score,
                        exclude_person=exclude_person,
                    )
                    if picked is not None:
                        face_anchor_bbox = self._normalize_bbox_xyxy(picked.get("bbox_xyxy"))
                        face_anchor_miss_frames = 0
                        face_switch_pending_bbox = None
                        face_switch_pending_frames = 0
                if picked is None:
                    stable_frames = 0
                    err_x_ema = None
                    err_y_ema = None
                    prev_yaw_cmd = 0.0
                    prev_pitch_cmd = 0.0
                    searching_message = "target not found, searching"
                    if single_face_mode and picked_mode in ("hold-miss", "switch-pending"):
                        searching_message = (
                            f"face anchor hold ({int(face_anchor_miss_frames)}/"
                            f"{int(VISION_GIMBAL_LOCK_FACE_MISS_GRACE_FRAMES)}), waiting stable switch"
                        )
                    elif search_spin_deg > 1e-6:
                        searching_message = (
                            f"target not found, yaw searching "
                            f"{search_spin_progress_deg:.0f}/{search_spin_deg:.0f} deg "
                            f"(rounds={int(search_spin_rounds)})"
                        )
                    self._gimbal_lock_set_state(
                        iterations=iterations,
                        stable_frames=stable_frames,
                        message=searching_message,
                        single_face_mode=bool(single_face_mode),
                        face_anchor_bbox=face_anchor_bbox,
                        face_anchor_miss_frames=int(face_anchor_miss_frames),
                        face_switch_pending_bbox=face_switch_pending_bbox,
                        face_switch_pending_frames=int(face_switch_pending_frames),
                        last_observe_summary=obs_summary,
                        last_target=None,
                        last_tracker_output={
                            "mode": "search",
                            "detector_requested": detector_requested,
                            "detector_resolved": detector_resolved,
                            "single_face_mode": bool(single_face_mode),
                            "face_pick_mode": picked_mode,
                            "face_anchor_bbox_xyxy": (
                                [int(v) for v in face_anchor_bbox] if face_anchor_bbox else None
                            ),
                            "face_anchor_miss_frames": int(face_anchor_miss_frames),
                            "face_switch_pending_frames": int(face_switch_pending_frames),
                            "observe_wear_glasses": bool(observe_wear_glasses),
                            "observe_emotion": bool(observe_emotion),
                            "frame_width": int(frame_w),
                            "frame_height": int(frame_h),
                            "target_terms": list(target_terms),
                            "search_spin_progress_deg": round(float(search_spin_progress_deg), 2),
                            "search_spin_rounds": int(search_spin_rounds),
                        },
                    )
                    allow_sweep = not (
                        single_face_mode and picked_mode in ("hold-miss", "switch-pending")
                    )
                    if allow_sweep:
                        _issue_search_spin("search")
                    time.sleep(loop_interval)
                    continue

                last_target = dict(picked)
                picked_bbox = self._normalize_bbox_xyxy(picked.get("bbox_xyxy"))
                if picked_bbox is not None:
                    face_anchor_bbox = picked_bbox
                face_anchor_miss_frames = 0
                face_switch_pending_bbox = None
                face_switch_pending_frames = 0
                cx = float(picked.get("cx") or 0.0)
                cy = float(picked.get("cy") or 0.0)
                score = float(picked.get("score") or 0.0)
                err_x_raw = cx - float(frame_w) * 0.5
                err_y_raw = cy - float(frame_h) * 0.5
                if err_x_ema is None:
                    err_x_ema = err_x_raw
                    err_y_ema = err_y_raw
                else:
                    err_x_ema = (err_ema_alpha * err_x_raw) + ((1.0 - err_ema_alpha) * float(err_x_ema))
                    err_y_ema = (err_ema_alpha * err_y_raw) + ((1.0 - err_ema_alpha) * float(err_y_ema))
                err_x = float(err_x_ema)
                err_y = float(err_y_ema)
                active_tol_px = float(center_tol_px)
                if continuous and locked:
                    active_tol_px = float(max(center_tol_px, center_tol_px * hold_tol_scale))
                yaw_in_tol = abs(err_x) <= active_tol_px
                pitch_in_tol = abs(err_y) <= active_tol_px
                in_tol = yaw_in_tol and pitch_in_tol and score >= min_score
                if in_tol:
                    stable_frames += 1
                    yaw_cmd = 0.0
                    pitch_cmd = 0.0
                    prev_yaw_cmd = 0.0
                    prev_pitch_cmd = 0.0
                else:
                    stable_frames = 0
                    yaw_cmd = 0.0 if yaw_in_tol else (err_x * kp_yaw) * (-1.0 if invert_yaw else 1.0)
                    pitch_cmd = 0.0 if pitch_in_tol else (err_y * kp_pitch) * (-1.0 if invert_pitch else 1.0)
                    if brake_zone_px > 1.0:
                        yaw_ratio = min(1.0, abs(err_x) / brake_zone_px)
                        pitch_ratio = min(1.0, abs(err_y) / brake_zone_px)
                        yaw_scale = brake_min_scale + ((1.0 - brake_min_scale) * yaw_ratio)
                        pitch_scale = brake_min_scale + ((1.0 - brake_min_scale) * pitch_ratio)
                        yaw_cmd *= yaw_scale
                        pitch_cmd *= pitch_scale
                    if abs(yaw_cmd) < cmd_min_rpm:
                        yaw_cmd = 0.0
                    if abs(pitch_cmd) < cmd_min_rpm:
                        pitch_cmd = 0.0
                yaw_cmd = float(max(-max_rpm, min(max_rpm, yaw_cmd)))
                pitch_cmd = float(max(-max_rpm, min(max_rpm, pitch_cmd)))
                if cmd_slew_rpm_per_sec > 1e-6 and (not in_tol):
                    max_delta = float(cmd_slew_rpm_per_sec) * max(0.01, float(loop_interval))
                    yaw_cmd = float(max(prev_yaw_cmd - max_delta, min(prev_yaw_cmd + max_delta, yaw_cmd)))
                    pitch_cmd = float(max(prev_pitch_cmd - max_delta, min(prev_pitch_cmd + max_delta, pitch_cmd)))
                cmd = self.gimbal_command(
                    yaw_rpm=yaw_cmd,
                    pitch_rpm=pitch_cmd,
                    laser_enabled=2,
                    auto_stop_ms=0,
                    reason=f"{run_id}:track",
                )
                cmd_ok = bool(cmd.get("ok", False))
                if not cmd_ok:
                    final_error = str(cmd.get("error") or "gimbal command failed")
                else:
                    prev_yaw_cmd = float(yaw_cmd)
                    prev_pitch_cmd = float(pitch_cmd)
                tracker_output = {
                    "mode": "track",
                    "detector_requested": detector_requested,
                    "detector_resolved": detector_resolved,
                    "single_face_mode": bool(single_face_mode),
                    "face_pick_mode": picked_mode,
                    "face_anchor_bbox_xyxy": (
                        [int(v) for v in face_anchor_bbox] if face_anchor_bbox else None
                    ),
                    "face_anchor_miss_frames": int(face_anchor_miss_frames),
                    "face_switch_pending_frames": int(face_switch_pending_frames),
                    "observe_wear_glasses": bool(observe_wear_glasses),
                    "observe_emotion": bool(observe_emotion),
                    "observe_detail_note": observe_detail_note or None,
                    "frame_width": int(frame_w),
                    "frame_height": int(frame_h),
                    "target_class_name": picked.get("class_name"),
                    "target_class_id": picked.get("class_id"),
                    "score": round(float(score), 4),
                    "cx": round(float(cx), 2),
                    "cy": round(float(cy), 2),
                    "err_x_px": round(float(err_x), 2),
                    "err_y_px": round(float(err_y), 2),
                    "err_x_raw_px": round(float(err_x_raw), 2),
                    "err_y_raw_px": round(float(err_y_raw), 2),
                    "yaw_in_tolerance": bool(yaw_in_tol),
                    "pitch_in_tolerance": bool(pitch_in_tol),
                    "yaw_rpm": round(float(yaw_cmd), 4),
                    "pitch_rpm": round(float(pitch_cmd), 4),
                    "cmd_slew_rpm_per_sec": round(float(cmd_slew_rpm_per_sec), 2),
                    "brake_zone_px": round(float(brake_zone_px), 2),
                    "brake_min_scale": round(float(brake_min_scale), 4),
                    "in_tolerance": bool(in_tol),
                    "stable_frames": int(stable_frames),
                    "required_stable_frames": int(stable_required),
                }
                self._gimbal_lock_set_state(
                    iterations=iterations,
                    stable_frames=stable_frames,
                    single_face_mode=bool(single_face_mode),
                    face_anchor_bbox=face_anchor_bbox,
                    face_anchor_miss_frames=int(face_anchor_miss_frames),
                    face_switch_pending_bbox=face_switch_pending_bbox,
                    face_switch_pending_frames=int(face_switch_pending_frames),
                    message=(
                        f"tracking {picked.get('class_name') or 'target'} "
                        f"err=({err_x:.1f},{err_y:.1f}) tol={active_tol_px:.1f} "
                        f"stable={stable_frames}/{stable_required}"
                    ),
                    last_observe_summary=obs_summary,
                    last_error=final_error if not cmd_ok else "",
                    last_target={
                        "class_name": picked.get("class_name"),
                        "class_id": picked.get("class_id"),
                        "score": score,
                        "cx": cx,
                        "cy": cy,
                        "err_x_px": round(err_x, 2),
                        "err_y_px": round(err_y, 2),
                        "err_x_raw_px": round(err_x_raw, 2),
                        "err_y_raw_px": round(err_y_raw, 2),
                    },
                    last_command=cmd.get("command"),
                    last_tracker_output=tracker_output,
                )
                if not cmd_ok:
                    final_status = "error"
                    final_message = "gimbal command failed during lock"
                    break

                if stable_frames >= stable_required:
                    locked = True
                    if continuous:
                        self._gimbal_lock_set_state(
                            status="running",
                            message="target locked, continuous tracking",
                            locked=True,
                        )
                        time.sleep(loop_interval)
                        continue

                    self._gimbal_lock_set_state(
                        status="confirming",
                        message="target locked, confirming by laser",
                        locked=True,
                    )
                    self._gimbal_lock_emit_stop(reason=f"{run_id}:locked-stop", laser_flag=2)
                    blink_done = self._gimbal_lock_blink_laser(
                        blinks=laser_blinks,
                        on_ms=laser_on_ms,
                        off_ms=laser_off_ms,
                        run_id=run_id,
                        stop_event=self.gimbal_lock_stop_event,
                    )
                    self._gimbal_lock_emit_stop(reason=f"{run_id}:locked-finish", laser_flag=0)
                    final_status = "done"
                    final_message = "target locked and laser confirmation sent"
                    result_payload = {
                        "locked": True,
                        "continuous": False,
                        "blink_done": int(blink_done),
                        "target": last_target,
                        "elapsed_sec": round(time.time() - started_ts, 3),
                    }
                    break

                time.sleep(loop_interval)

            if not locked:
                self._gimbal_lock_emit_stop(reason=f"{run_id}:finish-stop", laser_flag=0)
        except Exception as exc:
            final_status = "error"
            final_message = "lock worker exception"
            final_error = str(exc)
            self._gimbal_lock_emit_stop(reason=f"{run_id}:exception-stop", laser_flag=0)
        finally:
            finished_ts = time.time()
            if not result_payload:
                result_payload = {
                    "locked": bool(locked),
                    "continuous": bool(continuous),
                    "blink_done": int(blink_done),
                    "target": last_target,
                    "elapsed_sec": round(max(0.0, finished_ts - started_ts), 3),
                }
            self._gimbal_lock_set_state(
                active=False,
                status=final_status,
                message=final_message,
                finished_ts=finished_ts,
                iterations=iterations,
                stable_frames=stable_frames,
                single_face_mode=bool(single_face_mode),
                face_anchor_bbox=face_anchor_bbox,
                face_anchor_miss_frames=int(face_anchor_miss_frames),
                face_switch_pending_bbox=face_switch_pending_bbox,
                face_switch_pending_frames=int(face_switch_pending_frames),
                search_spin_progress_deg=round(float(search_spin_progress_deg), 2),
                search_spin_rounds=int(search_spin_rounds),
                blink_done=blink_done,
                last_error=final_error,
                last_target=last_target,
                locked=bool(locked),
                result=result_payload,
            )
            with self.gimbal_lock_state_lock:
                if self.gimbal_lock_thread is threading.current_thread():
                    self.gimbal_lock_thread = None

    def gimbal_lock_start(
        self,
        *,
        target: str,
        detector: str = "auto",
        timeout_sec: float | None = None,
        continuous: bool | None = None,
        center_tolerance_px: float | None = None,
        stable_frames: int | None = None,
        min_score: float | None = None,
        max_rpm: float | None = None,
        kp_yaw: float | None = None,
        kp_pitch: float | None = None,
        invert_yaw: bool | None = None,
        invert_pitch: bool | None = None,
        search_sweep_rpm: float | None = None,
        search_sweep_pulse_ms: int | None = None,
        search_spin_deg: float | None = None,
        search_spin_clockwise: bool | None = None,
        laser_blinks: int | None = None,
        laser_on_ms: int | None = None,
        laser_off_ms: int | None = None,
        wear_glasses: bool | None = None,
        emotion: bool | None = None,
        face_only: bool | None = None,
        reason: str = "manual",
    ) -> dict[str, Any]:
        face_only_mode = bool(face_only)
        detector_key = self._gimbal_lock_detector_key(detector)
        if face_only_mode:
            detector_key = "face"
        if detector_key not in ("auto", "face", "yolo", "yolo_world"):
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"unsupported detector for lock: {detector_key}",
            }
        target_text = str(target or "").strip()
        target_terms_resolved, target_keys_resolved = self._gimbal_lock_terms(target_text)
        detector_note_extra = ""
        if face_only_mode and not self._gimbal_lock_is_human_keys(target_keys_resolved):
            target_text = "person"
            target_terms_resolved, target_keys_resolved = self._gimbal_lock_terms(target_text)
            detector_note_extra = "face_only requested, target forced to person"
        detector_resolved, detector_note, target_human = self._gimbal_lock_resolve_detector(
            detector_key,
            target_keys_resolved,
        )
        if not detector_resolved:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": detector_note or f"unsupported detector for lock: {detector_key}",
                "detector_requested": detector_key,
            }
        if face_only_mode and detector_resolved != "face":
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "face_only requested but face detector unavailable",
                "detector_requested": detector_key,
                "detector_resolved": detector_resolved,
            }
        if detector_note_extra:
            detector_note = "; ".join(
                item for item in (detector_note, detector_note_extra) if str(item or "").strip()
            )

        observe_wear_glasses = bool(wear_glasses) if wear_glasses is not None else False
        observe_emotion = bool(emotion) if emotion is not None else False
        if face_only_mode:
            observe_wear_glasses = False
            observe_emotion = False
        observe_detail_note = ""
        if (observe_wear_glasses or observe_emotion) and not bool(target_human):
            observe_wear_glasses = False
            observe_emotion = False
            observe_detail_note = "human detail flags ignored for non-human target"

        exclude_person = bool(
            detector_key == "auto"
            and detector_resolved == "yolo_world"
            and bool(target_keys_resolved)
            and not bool(target_human)
        )
        single_face_mode = bool(
            VISION_GIMBAL_LOCK_SINGLE_FACE_TARGET
            and bool(target_human)
            and detector_resolved == "face"
        )
        serial_status = self.gimbal_status()
        if not bool(serial_status.get("enabled", False)):
            payload = self.gimbal_lock_status(include_serial=True)
            payload["ok"] = False
            payload["error"] = "gimbal serial disabled"
            return payload
        if not bool(serial_status.get("configured", False)):
            payload = self.gimbal_lock_status(include_serial=True)
            payload["ok"] = False
            payload["error"] = "gimbal serial port not configured"
            return payload

        with self.gimbal_lock_state_lock:
            running = bool(self.gimbal_lock_thread is not None and self.gimbal_lock_thread.is_alive())
        if running:
            payload = self.gimbal_lock_status(include_serial=True)
            payload["ok"] = False
            payload["error"] = "gimbal lock task already running"
            return payload

        with self.gimbal_lock_state_lock:
            running = bool(self.gimbal_lock_thread is not None and self.gimbal_lock_thread.is_alive())
            if running:
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "gimbal lock task already running",
                    "active": True,
                }
            run_id = f"lock-{int(time.time() * 1000):x}"
            started_ts = time.time()
            self.gimbal_lock_stop_event.clear()
            self.gimbal_lock_state.update(
                {
                    "active": True,
                    "run_id": run_id,
                    "status": "starting",
                    "message": "starting lock task",
                    "reason": str(reason or "manual"),
                    "target_raw": target_text,
                    "target_terms": list(target_terms_resolved),
                    "detector": detector_resolved,
                    "detector_requested": detector_key,
                    "detector_resolved": detector_resolved,
                    "detector_note": detector_note or None,
                    "target_human": bool(target_human),
                    "exclude_person": bool(exclude_person),
                    "face_only_mode": bool(face_only_mode),
                    "single_face_mode": bool(single_face_mode),
                    "face_anchor_bbox": None,
                    "face_anchor_miss_frames": 0,
                    "face_switch_pending_bbox": None,
                    "face_switch_pending_frames": 0,
                    "observe_wear_glasses": bool(observe_wear_glasses),
                    "observe_emotion": bool(observe_emotion),
                    "observe_detail_note": observe_detail_note,
                    "continuous": bool(continuous),
                    "started_ts": started_ts,
                    "finished_ts": 0.0,
                    "last_update_ts": started_ts,
                    "iterations": 0,
                    "stable_frames": 0,
                    "required_stable_frames": int(
                        max(1, min(60, int(stable_frames if stable_frames is not None else VISION_GIMBAL_LOCK_STABLE_FRAMES)))
                    ),
                    "timeout_sec": float(
                        max(
                            1.0,
                            min(
                                VISION_GIMBAL_LOCK_TIMEOUT_MAX_SEC,
                                float(timeout_sec if timeout_sec is not None else VISION_GIMBAL_LOCK_TIMEOUT_SEC),
                            ),
                        )
                    ),
                    "center_tolerance_px": float(
                        max(
                            2.0,
                            min(
                                320.0,
                                float(
                                    center_tolerance_px
                                    if center_tolerance_px is not None
                                    else VISION_GIMBAL_LOCK_CENTER_TOLERANCE_PX
                                ),
                            ),
                        )
                    ),
                    "hold_tolerance_scale": float(VISION_GIMBAL_LOCK_HOLD_TOLERANCE_SCALE),
                    "min_score": float(
                        max(0.01, min(0.99, float(min_score if min_score is not None else VISION_GIMBAL_LOCK_MIN_SCORE)))
                    ),
                    "max_rpm": float(
                        max(1.0, min(50.0, float(max_rpm if max_rpm is not None else VISION_GIMBAL_LOCK_MAX_RPM)))
                    ),
                    "kp_yaw": float(
                        max(0.001, min(1.0, float(kp_yaw if kp_yaw is not None else VISION_GIMBAL_LOCK_KP_YAW)))
                    ),
                    "kp_pitch": float(
                        max(
                            0.001,
                            min(1.0, float(kp_pitch if kp_pitch is not None else VISION_GIMBAL_LOCK_KP_PITCH)),
                        )
                    ),
                    "err_ema_alpha": float(VISION_GIMBAL_LOCK_ERR_EMA_ALPHA),
                    "cmd_min_rpm": float(VISION_GIMBAL_LOCK_CMD_MIN_RPM),
                    "brake_zone_px": float(VISION_GIMBAL_LOCK_BRAKE_ZONE_PX),
                    "brake_min_scale": float(VISION_GIMBAL_LOCK_BRAKE_MIN_SCALE),
                    "cmd_slew_rpm_per_sec": float(VISION_GIMBAL_LOCK_CMD_SLEW_RPM_PER_SEC),
                    "invert_yaw": bool(
                        VISION_GIMBAL_LOCK_INVERT_YAW if invert_yaw is None else bool(invert_yaw)
                    ),
                    "invert_pitch": bool(
                        VISION_GIMBAL_LOCK_INVERT_PITCH
                        if invert_pitch is None
                        else bool(invert_pitch)
                    ),
                    "search_sweep_rpm": float(
                        max(
                            0.0,
                            min(
                                40.0,
                                float(
                                    search_sweep_rpm
                                    if search_sweep_rpm is not None
                                    else VISION_GIMBAL_LOCK_SEARCH_SWEEP_RPM
                                ),
                            ),
                        )
                    ),
                    "search_sweep_pulse_ms": int(
                        max(
                            0,
                            min(
                                1200,
                                int(
                                    search_sweep_pulse_ms
                                    if search_sweep_pulse_ms is not None
                                    else VISION_GIMBAL_LOCK_SEARCH_SWEEP_PULSE_MS
                                ),
                            ),
                        )
                    ),
                    "search_spin_deg": float(
                        max(
                            30.0,
                            min(
                                2160.0,
                                float(
                                    search_spin_deg
                                    if search_spin_deg is not None
                                    else VISION_GIMBAL_LOCK_SEARCH_SPIN_DEG
                                ),
                            ),
                        )
                    ),
                    "search_spin_clockwise": bool(
                        VISION_GIMBAL_LOCK_SEARCH_SPIN_CLOCKWISE
                        if search_spin_clockwise is None
                        else bool(search_spin_clockwise)
                    ),
                    "search_spin_progress_deg": 0.0,
                    "search_spin_rounds": 0,
                    "laser_blinks": int(
                        max(
                            0,
                            min(12, int(laser_blinks if laser_blinks is not None else VISION_GIMBAL_LOCK_LASER_BLINKS)),
                        )
                    ),
                    "laser_on_ms": int(
                        max(
                            40,
                            min(
                                1000,
                                int(laser_on_ms if laser_on_ms is not None else VISION_GIMBAL_LOCK_LASER_ON_MS),
                            ),
                        )
                    ),
                    "laser_off_ms": int(
                        max(
                            40,
                            min(
                                1000,
                                int(laser_off_ms if laser_off_ms is not None else VISION_GIMBAL_LOCK_LASER_OFF_MS),
                            ),
                        )
                    ),
                    "blink_done": 0,
                    "last_observe_summary": "",
                    "last_error": "",
                    "last_target": None,
                    "last_command": None,
                    "last_tracker_output": None,
                    "locked": False,
                    "result": None,
                }
            )
            params = dict(self.gimbal_lock_state)
            params["target"] = target_text
            params["detector"] = detector_resolved
            params["detector_requested"] = detector_key
            params["detector_resolved"] = detector_resolved
            params["detector_note"] = detector_note
            params["target_human"] = bool(target_human)
            params["exclude_person"] = bool(exclude_person)
            params["face_only_mode"] = bool(face_only_mode)
            params["single_face_mode"] = bool(single_face_mode)
            params["face_anchor_bbox"] = None
            params["face_anchor_miss_frames"] = 0
            params["face_switch_pending_bbox"] = None
            params["face_switch_pending_frames"] = 0
            params["target_terms_resolved"] = list(target_terms_resolved)
            params["target_keys_resolved"] = sorted(target_keys_resolved)
            params["observe_wear_glasses"] = bool(observe_wear_glasses)
            params["observe_emotion"] = bool(observe_emotion)
            params["observe_detail_note"] = observe_detail_note
            params["loop_interval_sec"] = float(VISION_GIMBAL_LOCK_LOOP_INTERVAL_SEC)
            thread = threading.Thread(
                target=self._gimbal_lock_worker,
                args=(run_id, params),
                name=f"vision-gimbal-lock-{run_id[-6:]}",
                daemon=True,
            )
            self.gimbal_lock_thread = thread
            thread.start()

        payload = self.gimbal_lock_status(include_serial=True)
        payload["ok"] = True
        payload["message"] = "gimbal lock task started"
        return payload

    def gimbal_lock_stop(self, wait: bool = False, reason: str = "manual") -> dict[str, Any]:
        thread: threading.Thread | None = None
        with self.gimbal_lock_state_lock:
            thread = self.gimbal_lock_thread
            running = bool(thread is not None and thread.is_alive())
            self.gimbal_lock_stop_event.set()
            self.gimbal_lock_state["reason"] = str(reason or "manual")
            if running:
                self.gimbal_lock_state["status"] = "stopping"
                self.gimbal_lock_state["message"] = "stop requested"
                self.gimbal_lock_state["last_update_ts"] = time.time()
        if wait and thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=4.0)
        if not wait:
            self._gimbal_lock_emit_stop(reason=f"lock-stop:{reason}", laser_flag=0)
        payload = self.gimbal_lock_status(include_serial=True)
        payload["ok"] = True
        payload["message"] = (
            "gimbal lock stop requested" if payload.get("thread_alive", False) else "gimbal lock idle"
        )
        return payload

    def gimbal_laser_blink(
        self,
        *,
        blinks: int | None = None,
        period_ms: int | None = None,
        laser_on_ms: int | None = None,
        laser_off_ms: int | None = None,
        reason: str = "manual",
    ) -> dict[str, Any]:
        serial_status = self.gimbal_status()
        if not bool(serial_status.get("enabled", False)):
            payload = dict(serial_status)
            payload["ok"] = False
            payload["error"] = "gimbal serial disabled"
            payload["summary"] = "laser blink unavailable: gimbal serial disabled"
            return payload
        if not bool(serial_status.get("configured", False)):
            payload = dict(serial_status)
            payload["ok"] = False
            payload["error"] = "gimbal serial port not configured"
            payload["summary"] = "laser blink unavailable: serial port not configured"
            return payload

        with self.gimbal_lock_state_lock:
            lock_running = bool(self.gimbal_lock_thread is not None and self.gimbal_lock_thread.is_alive())
        if lock_running:
            payload = self.gimbal_lock_status(include_serial=True)
            payload["ok"] = False
            payload["error"] = "gimbal lock task running; stop lock first"
            payload["summary"] = "laser blink rejected while lock task is running"
            return payload

        if not self.gimbal_laser_blink_lock.acquire(blocking=False):
            payload = self.gimbal_status()
            payload["ok"] = False
            payload["error"] = "laser blink task already running"
            payload["summary"] = "laser blink task already running"
            return payload

        try:
            blink_count = int(max(1, min(12, int(blinks if blinks is not None else 6))))
            period_value: int | None = None
            if period_ms is not None:
                period_value = int(max(80, min(2000, int(period_ms))))
            half_default = int(
                max(40, min(1000, round(float(period_value) * 0.5)))
            ) if period_value is not None else None
            on_value = int(
                max(
                    40,
                    min(
                        2000,
                        int(
                            laser_on_ms
                            if laser_on_ms is not None
                            else (half_default if half_default is not None else VISION_GIMBAL_LOCK_LASER_ON_MS)
                        ),
                    ),
                )
            )
            off_value = int(
                max(
                    40,
                    min(
                        2000,
                        int(
                            laser_off_ms
                            if laser_off_ms is not None
                            else (half_default if half_default is not None else VISION_GIMBAL_LOCK_LASER_OFF_MS)
                        ),
                    ),
                )
            )
            run_id = f"blink-{int(time.time() * 1000):x}"
            started_ts = time.time()
            blink_done = 0
            blink_error = ""
            for idx in range(max(0, int(blink_count))):
                on_resp = self.gimbal_command(
                    yaw_rpm=0.0,
                    pitch_rpm=0.0,
                    laser_enabled=1,
                    auto_stop_ms=0,
                    reason=f"{run_id}:laser-on:{idx + 1}",
                )
                if not bool(on_resp.get("ok", False)):
                    blink_error = str(on_resp.get("error") or "laser on command failed")
                    break
                time.sleep(max(0.01, float(on_value) / 1000.0))
                off_resp = self.gimbal_command(
                    yaw_rpm=0.0,
                    pitch_rpm=0.0,
                    laser_enabled=0,
                    auto_stop_ms=0,
                    reason=f"{run_id}:laser-off:{idx + 1}",
                )
                if not bool(off_resp.get("ok", False)):
                    blink_error = str(off_resp.get("error") or "laser off command failed")
                    break
                blink_done += 1
                if idx + 1 < int(blink_count):
                    time.sleep(max(0.01, float(off_value) / 1000.0))
            self._gimbal_lock_emit_stop(reason=f"{run_id}:finish-stop", laser_flag=0)
            elapsed_sec = round(max(0.0, time.time() - started_ts), 3)
            payload = self.gimbal_status()
            payload.update(
                {
                    "ok": bool(blink_done == blink_count and not blink_error),
                    "timestamp": _ts_now(),
                    "reason": str(reason or "manual"),
                    "blinks": int(blink_count),
                    "blink_done": int(blink_done),
                    "laser_on_ms": int(on_value),
                    "laser_off_ms": int(off_value),
                    "period_ms": int(on_value + off_value),
                    "elapsed_sec": elapsed_sec,
                    "message": (
                        "laser blink completed"
                        if blink_done == blink_count and not blink_error
                        else "laser blink interrupted"
                    ),
                }
            )
            payload["summary"] = (
                f"laser blink done {blink_done}/{blink_count} "
                f"(on={on_value}ms, off={off_value}ms)"
            )
            if blink_error:
                payload["error"] = blink_error
            elif blink_done != blink_count:
                payload["error"] = "laser blink interrupted"
            return payload
        except Exception as exc:
            self._gimbal_lock_emit_stop(reason="blink:exception-stop", laser_flag=0)
            payload = self.gimbal_status()
            payload["ok"] = False
            payload["error"] = str(exc)
            payload["summary"] = "laser blink failed"
            return payload
        finally:
            self.gimbal_laser_blink_lock.release()

    def set_profile(self, name: str) -> dict[str, Any]:
        key = (name or "").strip().lower()
        if key == "custom":
            with self.lock:
                current = str(self.profile_name or "").strip().lower()
                if current and current not in self.profiles:
                    payload = self.profile_status()
                    payload["ok"] = True
                    payload["message"] = "profile kept as custom"
                    return payload
            key = "clear60"
        if not key:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "profile name required",
                "available": sorted(self.profiles.keys()),
            }
        with self.lock:
            ok = self._apply_profile_locked(key)
        if not ok:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"unsupported profile: {key}",
                "available": sorted(self.profiles.keys()),
            }
        self.request_reopen(f"profile:{key}")
        payload = self.profile_status()
        payload["message"] = f"profile switched to {key}"
        return payload

    def request_reopen(self, reason: str = "") -> None:
        with self.lock:
            self.reopen_requested = True
            if reason:
                self.last_error = reason

    def _trigger_recovery(self, reason: str) -> None:
        if not self.auto_recover:
            return
        now_ts = time.time()
        with self.lock:
            cooldown = max(1.0, VISION_AUTO_RECOVER_COOLDOWN_SEC)
            if self.recover_running:
                return
            if (now_ts - self.last_recover_attempt_ts) < cooldown:
                return
            self.recover_running = True
            self.last_recover_attempt_ts = now_ts
            self.last_recover_reason = reason
        thread = threading.Thread(
            target=self._recover_worker,
            args=(reason,),
            name="vision-recover",
            daemon=True,
        )
        thread.start()

    def trigger_recovery(self, reason: str = "manual") -> dict[str, Any]:
        if not self.auto_recover:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "auto recovery disabled",
            }
        now_ts = time.time()
        with self.lock:
            running = self.recover_running
            cooldown = max(1.0, VISION_AUTO_RECOVER_COOLDOWN_SEC)
            left = max(0.0, cooldown - (now_ts - self.last_recover_attempt_ts))
        if running:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "recovery already running",
            }
        if left > 0:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "recovery cooldown",
                "cooldown_left_sec": round(left, 2),
            }
        self._trigger_recovery(reason=reason)
        return {
            "ok": True,
            "timestamp": _ts_now(),
            "message": "recovery triggered",
            "reason": reason,
        }

    def _recover_worker(self, reason: str) -> None:
        ok = True
        message = "soft reopen"
        try:
            script_path = Path(VISION_AUTO_RECOVER_SCRIPT) if VISION_AUTO_RECOVER_SCRIPT else None
            # Stale frames are often transient; prefer soft reopen before USB-level reset.
            reason_text = str(reason or "").strip().lower()
            needs_usb_reset = reason_text.startswith("open_fail_count=") or reason_text.startswith(
                "read_fail_count="
            )
            if needs_usb_reset and VISION_USB_DEVICE and script_path and script_path.exists():
                cmd = [str(script_path), "--no-restart", VISION_USB_DEVICE]
                try:
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=20,
                        check=False,
                    )
                    ok = result.returncode == 0
                    message = (result.stdout.strip() or result.stderr.strip() or "usb recover done")[
                        :240
                    ]
                except Exception as exc:  # pragma: no cover - runtime environment dependent
                    ok = False
                    message = f"usb recover exception: {exc}"
            elif not needs_usb_reset:
                message = f"soft reopen only ({reason_text or 'unknown'})"

            # Force-close current capture to unblock stuck ffmpeg reads after hotplug.
            self._close_capture()
            self.request_reopen(f"auto-recover:{reason}")
        except Exception as exc:  # pragma: no cover - runtime environment dependent
            ok = False
            message = f"recover worker exception: {exc}"
        finally:
            with self.lock:
                self.recover_running = False
                self.recover_count += 1
                self.last_recover_ts = time.time()
                self.last_recover_reason = reason
                self.last_recover_ok = ok
                self.last_recover_msg = message
                if not ok:
                    self.last_error = message

    def _build_ffmpeg_cmd(self, cfg: dict[str, Any]) -> list[str]:
        camera_input = camera_to_device(cfg.get("camera", 0))
        req_fourcc = str(cfg.get("fourcc", "MJPG")).upper()
        req_width = int(cfg.get("width", 640))
        req_height = int(cfg.get("height", 480))
        req_fps = max(1.0, float(cfg.get("fps", 30.0)))
        req_rotate = int(cfg.get("rotate", 0))
        req_flip = int(cfg.get("flip", -1))
        ff_input_fmt = "mjpeg" if req_fourcc == "MJPG" else "yuyv422"
        vf_filters: list[str] = []
        if req_rotate == 90:
            vf_filters.append("transpose=2")
        elif req_rotate == 180:
            vf_filters.append("hflip")
            vf_filters.append("vflip")
        elif req_rotate == 270:
            vf_filters.append("transpose=1")
        if req_flip == 0:
            vf_filters.append("vflip")
        elif req_flip == 1:
            vf_filters.append("hflip")
        elif req_flip == -1:
            vf_filters.append("hflip")
            vf_filters.append("vflip")
        return [
            VISION_FFMPEG_BIN,
            "-hide_banner",
            "-loglevel",
            VISION_FFMPEG_LOGLEVEL,
            "-nostdin",
            "-fflags",
            "nobuffer",
            "-flags",
            "low_delay",
            "-probesize",
            str(int(VISION_FFMPEG_PROBESIZE)),
            "-analyzeduration",
            str(int(VISION_FFMPEG_ANALYZEDURATION_US)),
            "-f",
            "v4l2",
            "-input_format",
            ff_input_fmt,
            "-video_size",
            f"{req_width}x{req_height}",
            "-framerate",
            str(int(round(req_fps))),
            "-i",
            camera_input,
            "-an",
            *(
                ["-vf", ",".join(vf_filters)]
                if vf_filters
                else []
            ),
            "-pix_fmt",
            "bgr24",
            "-f",
            "rawvideo",
            "pipe:1",
        ]

    def _open_capture_opencv(self, cfg: dict[str, Any]) -> tuple[bool, str]:
        if self.cv2 is None:
            return False, "opencv unavailable"
        cv2 = self.cv2
        backend = str(cfg.get("backend", "v4l2")).lower()
        camera_spec = cfg.get("camera", 0)
        camera_input = camera_to_device(camera_spec)
        req_fourcc = str(cfg.get("fourcc", "MJPG")).upper()
        req_width = int(cfg.get("width", 640))
        req_height = int(cfg.get("height", 480))
        req_fps = float(cfg.get("fps", 30.0))

        cap_target: int | str = camera_spec if isinstance(camera_spec, int) else camera_input
        if backend == "v4l2":
            cap = cv2.VideoCapture(cap_target, cv2.CAP_V4L2)
            if not cap.isOpened():
                cap.release()
                cap = cv2.VideoCapture(cap_target)
        else:
            cap = cv2.VideoCapture(cap_target)

        if not cap.isOpened():
            try:
                cap.release()
            except Exception:
                pass
            return False, f"cannot open camera {camera_to_label(camera_spec)}"

        if req_fourcc and len(req_fourcc) == 4:
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*req_fourcc))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, req_width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, req_height)
        cap.set(cv2.CAP_PROP_FPS, req_fps)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self.cap = cap
        self.pipeline_active = "opencv"
        return True, ""

    def _open_capture_ffmpeg(self, cfg: dict[str, Any]) -> tuple[bool, str]:
        req_width = int(cfg.get("width", 640))
        req_height = int(cfg.get("height", 480))
        req_fps = max(1.0, float(cfg.get("fps", 30.0)))
        req_rotate = int(cfg.get("rotate", 0))
        if req_width <= 0 or req_height <= 0:
            return False, "invalid frame size"
        out_width = int(req_width)
        out_height = int(req_height)
        if req_rotate in (90, 270):
            out_width, out_height = out_height, out_width
        try:
            proc = subprocess.Popen(
                self._build_ffmpeg_cmd(cfg),
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                bufsize=out_width * out_height * 3 * 2,
            )
        except Exception as exc:
            return False, f"ffmpeg start failed: {exc}"
        time.sleep(min(0.2, 1.0 / req_fps))
        if proc.poll() is not None:
            return False, f"ffmpeg exited early ({proc.returncode})"
        self.ffmpeg_proc = proc
        self.ffmpeg_shape = (out_height, out_width, 3)
        self.ffmpeg_frame_bytes = out_width * out_height * 3
        self.pipeline_active = "ffmpeg"
        return True, ""

    def _open_capture(self) -> bool:
        cfg = self.get_request_config()
        camera_spec = cfg.get("camera", 0)
        mode = self.pipeline_requested
        attempts = ["opencv"]
        if mode == "ffmpeg":
            attempts = ["ffmpeg"]
        elif mode == "auto":
            attempts = ["ffmpeg", "opencv"]
        errors: list[str] = []
        for item in attempts:
            if item == "ffmpeg":
                ok, err = self._open_capture_ffmpeg(cfg)
            else:
                ok, err = self._open_capture_opencv(cfg)
            if ok:
                with self.lock:
                    self.read_fail_count = 0
                    self.open_fail_count = 0
                    self.last_fail_ts = 0.0
                    self.last_error = ""
                return True
            errors.append(err or item)
            self._close_capture()
        self.pipeline_active = ""
        self.last_error = f"cannot open camera {camera_to_label(camera_spec)} via {', '.join(errors)}"
        return False

    def _close_capture(self) -> None:
        cap = self.cap
        proc = self.ffmpeg_proc
        self.cap = None
        self.ffmpeg_proc = None
        self.ffmpeg_shape = None
        self.ffmpeg_frame_bytes = 0
        self.pipeline_active = ""
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass
        if proc is not None:
            try:
                if proc.stdout is not None:
                    proc.stdout.close()
            except Exception:
                pass
            try:
                proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    def _capture_ready(self) -> bool:
        proc = self.ffmpeg_proc
        if proc is not None:
            return proc.poll() is None and proc.stdout is not None
        return self.cap is not None and self.cap.isOpened()

    def _read_capture_frame(self) -> tuple[bool, Any | None]:
        proc = self.ffmpeg_proc
        shape = self.ffmpeg_shape
        frame_bytes = self.ffmpeg_frame_bytes
        if proc is not None:
            if proc.stdout is None or shape is None or frame_bytes <= 0:
                return False, None
            try:
                fd = proc.stdout.fileno()
            except Exception:
                return False, None
            try:
                chunks: list[bytes] = []
                received = 0
                deadline = time.time() + (VISION_FFMPEG_READ_TIMEOUT_MS / 1000.0)
                while received < frame_bytes:
                    remaining = max(0.0, deadline - time.time())
                    if remaining <= 0.0:
                        return False, None
                    ready, _, _ = select.select([fd], [], [], remaining)
                    if not ready:
                        return False, None
                    chunk = os.read(fd, frame_bytes - received)
                    if not chunk:
                        return False, None
                    chunks.append(chunk)
                    received += len(chunk)
                data = b"".join(chunks)
            except Exception:
                return False, None
            if not data or len(data) != frame_bytes:
                return False, None
            arr = np.frombuffer(data, dtype=np.uint8)
            try:
                frame = arr.reshape(shape)
            except Exception:
                return False, None
            return True, frame
        if self.cap is None:
            return False, None
        ret, frame = self.cap.read()
        return bool(ret), frame

    def _ensure_capture(self) -> bool:
        with self.lock:
            reopen = self.reopen_requested
            if reopen:
                self.reopen_requested = False
        if reopen:
            self._close_capture()
        if self._capture_ready():
            return True
        self._close_capture()
        return self._open_capture()

    def _capture_loop(self) -> None:
        if self.cv2 is None:
            return

        fail_sleep = max(0.05, VISION_FAIL_COOLDOWN)
        reopen_sleep = max(0.05, VISION_REOPEN_DELAY)

        while not self.stop_event.is_set():
            if not self._ensure_capture():
                cfg = self.get_request_config()
                camera_spec = cfg.get("camera", 0)
                with self.lock:
                    self.open_fail_count += 1
                    open_fail_count = self.open_fail_count
                    if not self.last_error:
                        self.last_error = f"cannot open camera {camera_to_label(camera_spec)}"
                    self.last_fail_ts = time.time()
                if (
                    self.auto_recover
                    and VISION_AUTO_RECOVER_FAIL_THRESHOLD > 0
                    and open_fail_count >= VISION_AUTO_RECOVER_FAIL_THRESHOLD
                ):
                    self._trigger_recovery(f"open_fail_count={open_fail_count}")
                self.stop_event.wait(fail_sleep)
                continue

            ret, frame = self._read_capture_frame()
            if ret and frame is not None:
                cfg = self.get_request_config()
                req_rotate = int(cfg.get("rotate", 0))
                req_flip = int(cfg.get("flip", -1))
                req_fps = float(cfg.get("fps", 30.0))
                # ffmpeg pipeline already applies rotate/flip via -vf in _build_ffmpeg_cmd.
                if self.pipeline_active != "ffmpeg":
                    if req_rotate == 90:
                        frame = self.cv2.rotate(frame, self.cv2.ROTATE_90_COUNTERCLOCKWISE)
                    elif req_rotate == 180:
                        frame = self.cv2.rotate(frame, self.cv2.ROTATE_180)
                    elif req_rotate == 270:
                        frame = self.cv2.rotate(frame, self.cv2.ROTATE_90_CLOCKWISE)
                    if req_flip in (-1, 0, 1):
                        frame = self.cv2.flip(frame, req_flip)
                now_ts = time.time()
                with self.lock:
                    if self.latest_frame_ts > 0:
                        dt = max(0.0001, now_ts - self.latest_frame_ts)
                        inst_fps = 1.0 / dt
                        inst_fps = min(inst_fps, max(1.0, req_fps * 1.5))
                        if self.capture_fps <= 0:
                            self.capture_fps = inst_fps
                        else:
                            self.capture_fps = (self.capture_fps * 0.85) + (inst_fps * 0.15)
                    else:
                        self.capture_fps = 0.0
                    self.latest_frame = frame
                    self.latest_frame_ts = now_ts
                    self.read_fail_count = 0
                    self.open_fail_count = 0
                    self.last_error = ""
                    self.last_fail_ts = 0.0
                continue

            with self.lock:
                self.read_fail_count += 1
                self.last_error = f"camera read failed (count={self.read_fail_count})"
                self.last_fail_ts = time.time()
                fail_count = self.read_fail_count

            if (
                self.auto_recover
                and VISION_AUTO_RECOVER_FAIL_THRESHOLD > 0
                and fail_count >= VISION_AUTO_RECOVER_FAIL_THRESHOLD
            ):
                self._trigger_recovery(f"read_fail_count={fail_count}")

            if VISION_REOPEN_FAILS > 0 and fail_count >= VISION_REOPEN_FAILS:
                self._close_capture()
                self.stop_event.wait(reopen_sleep)
            else:
                self.stop_event.wait(0.01)

        self._close_capture()

    def _yolo_world_loop(self) -> None:
        interval = 1.0 / max(1.0, float(self.yolo_world_async_fps))
        while not self.stop_event.is_set():
            loop_started = time.perf_counter()
            frame, err, frame_ts = self._snapshot_frame()
            if frame is None:
                self._yolo_world_async_set(
                    frame_ts,
                    [],
                    err or "frame unavailable",
                    {
                        "cache_hit": False,
                        "single_flight": bool(self.yolo_world_single_flight),
                        "wait_ms": 0.0,
                        "preprocess_ms": 0.0,
                        "infer_ms": 0.0,
                        "postprocess_ms": 0.0,
                        "detect_ms": 0.0,
                        "suppressed_spike": False,
                        "worker": True,
                    },
                )
                elapsed = max(0.0, time.perf_counter() - loop_started)
                self.stop_event.wait(max(0.0, min(0.05, interval) - elapsed))
                continue
            objects, world_err, world_meta = self._detect_yolo_world(
                frame, frame_ts=frame_ts, use_cache=False
            )
            out_meta = dict(world_meta)
            out_meta["worker"] = True
            self._yolo_world_async_set(frame_ts, objects, world_err, out_meta)
            elapsed = max(0.0, time.perf_counter() - loop_started)
            self.stop_event.wait(max(0.0, interval - elapsed))

    def _snapshot_frame(self, copy_frame: bool = True) -> tuple[Any | None, str, float]:
        if not self.enabled:
            return None, "vision disabled", 0.0
        if self.cv2 is None:
            return None, self.last_error or "opencv unavailable", 0.0
        with self.lock:
            frame = self.latest_frame
            ts = self.latest_frame_ts
            err = self.last_error
        if frame is None:
            return None, err or "frame unavailable", 0.0
        if ts > 0 and (time.time() - ts) * 1000.0 > max(100.0, VISION_MAX_FRAME_AGE_MS):
            age_ms = max(0.0, (time.time() - ts) * 1000.0)
            if (
                self.auto_recover
                and age_ms >= max(100.0, VISION_AUTO_RECOVER_STALE_THRESHOLD_MS)
            ):
                self._trigger_recovery(f"stale_frame_ms={age_ms:.1f}")
            return None, "stale frame", ts
        if not copy_frame:
            return frame, "", ts
        try:
            return frame.copy(), "", ts
        except Exception:
            return None, "frame copy failed", ts

    def _encode_jpeg(self, frame: Any) -> tuple[bytes | None, str]:
        if self.cv2 is None:
            return None, "opencv unavailable"
        quality = max(30, min(100, int(VISION_JPEG_QUALITY)))
        ok, buf = self.cv2.imencode(
            ".jpg",
            frame,
            [int(self.cv2.IMWRITE_JPEG_QUALITY), quality],
        )
        if not ok:
            return None, "jpeg encode failed"
        return bytes(buf), ""

    def _prepare_stream_frame(self, frame: Any) -> Any:
        if frame is None or self.cv2 is None:
            return frame
        try:
            src_h, src_w = frame.shape[:2]
        except Exception:
            return frame
        dst_w, dst_h = self._resolve_stream_size(src_w, src_h)
        if dst_w == src_w and dst_h == src_h:
            return frame
        interp = self.cv2.INTER_AREA if (dst_w < src_w or dst_h < src_h) else self.cv2.INTER_LINEAR
        try:
            return self.cv2.resize(frame, (dst_w, dst_h), interpolation=interp)
        except Exception:
            return frame

    def register_stream_client(self, client_id: str) -> None:
        with self.lock:
            if client_id not in self.stream_clients:
                self.stream_clients[client_id] = {"fps": 0.0, "last_ts": 0.0}

    def unregister_stream_client(self, client_id: str) -> None:
        with self.lock:
            self.stream_clients.pop(client_id, None)

    def note_stream_frame(self, client_id: str) -> None:
        now_ts = time.time()
        with self.lock:
            stat = self.stream_clients.get(client_id)
            if stat is None:
                stat = {"fps": 0.0, "last_ts": 0.0}
                self.stream_clients[client_id] = stat
            if stat["last_ts"] > 0:
                dt = max(0.0001, now_ts - stat["last_ts"])
                inst = min(1000.0, 1.0 / dt)
                if stat["fps"] <= 0:
                    stat["fps"] = inst
                else:
                    stat["fps"] = (stat["fps"] * 0.85) + (inst * 0.15)
            stat["last_ts"] = now_ts

    def get_stream_stats(self) -> dict[str, float | int]:
        now_ts = time.time()
        stale = max(0.2, VISION_STREAM_FPS_STALE_SEC)
        with self.lock:
            stale_ids = [
                cid
                for cid, stat in self.stream_clients.items()
                if stat.get("last_ts", 0.0) > 0 and (now_ts - stat["last_ts"]) > stale
            ]
            for cid in stale_ids:
                self.stream_clients.pop(cid, None)
            active = [
                stat for stat in self.stream_clients.values() if stat.get("last_ts", 0.0) > 0
            ]
        if not active:
            return {"clients": 0, "fps_avg": 0.0, "fps_total": 0.0}
        fps_total = float(sum(max(0.0, float(stat.get("fps", 0.0))) for stat in active))
        clients = int(len(active))
        fps_avg = fps_total / max(1, clients)
        return {"clients": clients, "fps_avg": fps_avg, "fps_total": fps_total}

    def get_capture_fps(self) -> float:
        with self.lock:
            return float(self.capture_fps)

    def _resolve_stream_size(self, source_width: int, source_height: int) -> tuple[int, int]:
        src_w = max(1, int(source_width or 0))
        src_h = max(1, int(source_height or 0))
        target_w = int(self.stream_output_width)
        target_h = int(self.stream_output_height)
        if target_w <= 0 and target_h <= 0:
            return src_w, src_h
        if target_w <= 0:
            target_w = max(1, int(round(src_w * (float(target_h) / float(src_h)))))
        elif target_h <= 0:
            target_h = max(1, int(round(src_h * (float(target_w) / float(src_w)))))
        return max(1, target_w), max(1, target_h)

    def _camera_state(self, frame_age_ms: float | None = None) -> dict[str, Any]:
        req_cfg = self.get_request_config()
        camera_spec = req_cfg.get("camera", 0)
        stream_width, stream_height = self._resolve_stream_size(
            int(req_cfg.get("width", 0)),
            int(req_cfg.get("height", 0)),
        )
        try:
            camera_index: int | None = int(camera_spec)
        except (TypeError, ValueError):
            camera_index = None
        with self.lock:
            fail_count = self.read_fail_count
            open_fail_count = self.open_fail_count
            cap_fps = self.capture_fps
            yolo_world_async_runtime_fps = self.yolo_world_async_runtime_fps
            recover_count = self.recover_count
            recover_running = self.recover_running
            recover_ts = self.last_recover_ts
            recover_reason = self.last_recover_reason
            recover_ok = self.last_recover_ok
            recover_msg = self.last_recover_msg
            profile_name = self.profile_name
        stream_stats = self.get_stream_stats()
        return {
            "enabled": bool(self.enabled),
            "index": camera_index,
            "device": camera_to_device(camera_spec),
            "backend": str(req_cfg.get("backend", "v4l2")),
            "pipeline_requested": self.pipeline_requested,
            "pipeline_active": self.pipeline_active or None,
            "stream_enabled": self.stream_enabled,
            "request": {
                "width": int(req_cfg.get("width", 0)),
                "height": int(req_cfg.get("height", 0)),
                "fps": float(req_cfg.get("fps", 0)),
                "fourcc": str(req_cfg.get("fourcc", "")),
            },
            "stream_output": {
                "width": int(stream_width),
                "height": int(stream_height),
                "configured_width": int(self.stream_output_width),
                "configured_height": int(self.stream_output_height),
            },
            "profile": profile_name,
            "read_fail_count": fail_count,
            "open_fail_count": open_fail_count,
            "frame_age_ms": frame_age_ms,
            "capture_fps": cap_fps,
            "stream_fps": float(stream_stats["fps_avg"]),
            "stream_fps_total": float(stream_stats["fps_total"]),
            "stream_clients": int(stream_stats["clients"]),
            "yolo_ready": self._yolo_ready(),
            "yolo_model": self._yolo_active_model_path(),
            "yolo_backend_requested": self.yolo_backend_requested,
            "yolo_backend_active": self.yolo_backend_active or None,
            "yolo_error": self.yolo_error or None,
            "yolo_max_objects": int(self.yolo_max_objects),
            "yolo_adaptive_trigger": int(self.yolo_adaptive_trigger),
            "yolo_adaptive_conf": float(self.yolo_adaptive_conf),
            "yolo_spike_count": int(self.yolo_spike_count),
            "yolo_spike_factor": float(self.yolo_spike_factor),
            "yolo_spike_confirm": int(self.yolo_spike_confirm),
            "yolo_suppressed_spike": bool(self.yolo_last_suppressed_spike),
            "yolo_world_ready": self._yolo_world_ready(),
            "yolo_world_model": self.yolo_world_model_path or None,
            "yolo_world_error": self.yolo_world_error or None,
            "yolo_world_rknn_core": self.yolo_world_rknn_core,
            "yolo_world_single_flight": bool(self.yolo_world_single_flight),
            "yolo_world_async_enabled": bool(self.yolo_world_async_enabled),
            "yolo_world_async_fps": float(self.yolo_world_async_fps),
            "yolo_world_async_runtime_fps": float(yolo_world_async_runtime_fps),
            "yolo_world_cache_ttl_ms": float(self.yolo_world_cache_ttl_ms),
            "yolo_world_pre_nms_cap": int(self.yolo_world_pre_nms_cap),
            **self._wear_glasses_status(),
            **self._emotion_status(),
            **self._yolo_world_filter_meta(),
            "auto_recover_enabled": self.auto_recover,
            "recover_count": recover_count,
            "recover_running": recover_running,
            "last_recover_ts": (
                datetime.fromtimestamp(recover_ts).isoformat(timespec="seconds")
                if recover_ts > 0
                else None
            ),
            "last_recover_reason": recover_reason or None,
            "last_recover_ok": recover_ok,
            "last_recover_message": recover_msg or None,
        }

    def _detect_rectangles(self, frame: Any) -> list[dict[str, Any]]:
        # Lightweight contour-based rectangle detection for generic "box target" use.
        if self.cv2 is None:
            return []
        cv2 = self.cv2
        h, w = frame.shape[:2]
        img_area = float(h * w)
        if img_area <= 0:
            return []

        min_area = img_area * max(0.0, VISION_MIN_AREA_RATIO)
        max_area = img_area * min(1.0, max(VISION_MAX_AREA_RATIO, 0.0))
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (3, 3), 0)
        _, thr = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        edges = cv2.Canny(thr, 25, 75)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        out: list[dict[str, Any]] = []
        for cnt in contours:
            area = float(cv2.contourArea(cnt))
            if area < min_area or area > max_area:
                continue
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
            if len(approx) != 4 or not cv2.isContourConvex(approx):
                continue
            x, y, bw, bh = cv2.boundingRect(approx)
            cx = float(x + bw / 2.0)
            cy = float(y + bh / 2.0)
            out.append(
                {
                    "type": "rect",
                    "cx": cx,
                    "cy": cy,
                    "area": float(area),
                    "bbox_xywh": [int(x), int(y), int(bw), int(bh)],
                    "score": None,
                }
            )

        out.sort(key=lambda d: d["area"], reverse=True)
        return out

    def _detect_yolo_opencv(self, frame: Any) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None:
            return [], "opencv unavailable"
        if self.yolo_net is None:
            return [], self.yolo_error or "YOLO unavailable"

        h, w = frame.shape[:2]
        blob = self.cv2.dnn.blobFromImage(
            frame,
            scalefactor=1.0 / 255.0,
            size=(self.yolo_input, self.yolo_input),
            mean=(0.0, 0.0, 0.0),
            swapRB=True,
            crop=False,
        )
        try:
            self.yolo_net.setInput(blob)
            raw_out = self.yolo_net.forward()
        except Exception as exc:
            self.yolo_error = f"YOLO forward failed: {exc}"
            return [], self.yolo_error
        preds, mode = self._normalize_yolo_output(raw_out)
        return self._postprocess_yolo_preds(preds=preds, mode=mode, frame_w=w, frame_h=h)

    def _detect_yolo_onnxruntime(self, frame: Any) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None:
            return [], "opencv unavailable"
        sess = self.yolo_ort_session
        if sess is None or not self.yolo_ort_input_name:
            return [], self.yolo_error or "YOLO unavailable"
        h, w = frame.shape[:2]
        img = self.cv2.cvtColor(frame, self.cv2.COLOR_BGR2RGB)
        if img.shape[1] != self.yolo_input or img.shape[0] != self.yolo_input:
            img = self.cv2.resize(img, (self.yolo_input, self.yolo_input))
        if self.yolo_ort_input_layout == "nhwc":
            inp = np.expand_dims(img, axis=0)
        else:
            inp = np.expand_dims(img.transpose(2, 0, 1), axis=0)
        dtype = str(self.yolo_ort_input_dtype or "tensor(float)").lower()
        if "float16" in dtype:
            inp = (inp.astype(np.float16, copy=False) / np.float16(255.0)).astype(
                np.float16, copy=False
            )
        elif "float" in dtype:
            inp = (inp.astype(np.float32, copy=False) / np.float32(255.0)).astype(
                np.float32, copy=False
            )
        else:
            inp = inp.astype(np.uint8, copy=False)
        try:
            outputs = sess.run(None, {self.yolo_ort_input_name: inp})
        except Exception as exc:
            self.yolo_error = f"YOLO ONNXRuntime inference failed: {exc}"
            return [], self.yolo_error
        if not outputs:
            self.yolo_error = "YOLO ONNXRuntime inference returned no outputs"
            return [], self.yolo_error
        preds, mode = self._normalize_yolo_output(outputs[0])
        return self._postprocess_yolo_preds(preds=preds, mode=mode, frame_w=w, frame_h=h)

    def _reshape_rknn_yolov5_tensor(self, out: Any) -> np.ndarray | None:
        arr = np.asarray(out)
        if arr.size == 0:
            return None
        if arr.ndim == 5 and arr.shape[0] == 1:
            arr = arr[0]
        if arr.ndim == 4 and arr.shape[0] == 1:
            arr = arr[0]
        # NCHW packed: [255, H, W] -> [3, 85, H, W]
        if arr.ndim == 3 and arr.shape[0] % 3 == 0:
            c = int(arr.shape[0] // 3)
            if c >= 6:
                return arr.reshape(3, c, arr.shape[1], arr.shape[2]).astype(np.float32, copy=False)
        # NHWC packed: [H, W, 255] -> [3, 85, H, W]
        if arr.ndim == 3 and arr.shape[2] % 3 == 0:
            c = int(arr.shape[2] // 3)
            if c >= 6:
                return (
                    arr.reshape(arr.shape[0], arr.shape[1], 3, c)
                    .transpose(2, 3, 0, 1)
                    .astype(np.float32, copy=False)
                )
        # Direct [3, 85, H, W]
        if arr.ndim == 4 and arr.shape[0] == 3 and arr.shape[1] >= 6:
            return arr.astype(np.float32, copy=False)
        # Direct [3, H, W, 85]
        if arr.ndim == 4 and arr.shape[0] == 3 and arr.shape[-1] >= 6:
            return arr.transpose(0, 3, 1, 2).astype(np.float32, copy=False)
        return None

    def _is_rknn_yolo11_rkopt_output(self, outputs: list[Any]) -> bool:
        if len(outputs) < 6 or (len(outputs) % 3) != 0:
            return False
        try:
            first = np.asarray(outputs[0])
            second = np.asarray(outputs[1])
        except Exception:
            return False
        if first.ndim != 4 or second.ndim != 4:
            return False
        if int(first.shape[0]) != 1 or int(second.shape[0]) != 1:
            return False
        # RKOPT yolo11 detect head: [1,64,H,W] + [1,80,H,W] (+ score_sum)
        if int(first.shape[1]) != 64:
            return False
        return int(second.shape[1]) >= 20

    @staticmethod
    def _softmax_axis2(x: np.ndarray) -> np.ndarray:
        x_max = np.max(x, axis=2, keepdims=True)
        e = np.exp(x - x_max)
        denom = np.sum(e, axis=2, keepdims=True)
        denom = np.maximum(denom, 1e-9)
        return e / denom

    def _yolo11_dfl(self, position: np.ndarray) -> np.ndarray:
        # Distribution Focal Loss decode: [N,64,H,W] -> [N,4,H,W]
        n, c, h, w = position.shape
        p_num = 4
        bins = int(c // p_num)
        if bins <= 0:
            return np.zeros((n, 4, h, w), dtype=np.float32)
        y = position.reshape(n, p_num, bins, h, w).astype(np.float32, copy=False)
        y = self._softmax_axis2(y)
        acc = np.arange(bins, dtype=np.float32).reshape(1, 1, bins, 1, 1)
        return np.sum(y * acc, axis=2)

    def _yolo11_box_process(self, position: np.ndarray) -> np.ndarray:
        gh, gw = int(position.shape[2]), int(position.shape[3])
        col, row = np.meshgrid(np.arange(0, gw), np.arange(0, gh))
        col = col.reshape(1, 1, gh, gw).astype(np.float32)
        row = row.reshape(1, 1, gh, gw).astype(np.float32)
        grid = np.concatenate((col, row), axis=1)
        stride = np.array(
            [float(self.yolo_input) / float(gh), float(self.yolo_input) / float(gw)],
            dtype=np.float32,
        ).reshape(1, 2, 1, 1)

        pos = self._yolo11_dfl(position)
        box_xy = grid + 0.5 - pos[:, 0:2, :, :]
        box_xy2 = grid + 0.5 + pos[:, 2:4, :, :]
        return np.concatenate((box_xy * stride, box_xy2 * stride), axis=1)

    @staticmethod
    def _yolo11_sp_flatten(tensor: np.ndarray) -> np.ndarray:
        ch = int(tensor.shape[1])
        return tensor.transpose(0, 2, 3, 1).reshape(-1, ch)

    def _decode_rknn_yolo11_rkopt(
        self, outputs: list[Any], frame_w: int, frame_h: int
    ) -> tuple[list[dict[str, Any]], str]:
        pair_per_branch = len(outputs) // 3
        if pair_per_branch < 2:
            return [], "RKNN output shape unsupported for yolo11 rkopt decode"

        boxes_list: list[np.ndarray] = []
        classes_list: list[np.ndarray] = []
        scores_list: list[np.ndarray] = []

        for i in range(3):
            cls_idx = pair_per_branch * i + 1
            pos_idx = pair_per_branch * i
            if pos_idx >= len(outputs) or cls_idx >= len(outputs):
                continue
            pos_tensor = np.asarray(outputs[pos_idx], dtype=np.float32)
            cls_tensor = np.asarray(outputs[cls_idx], dtype=np.float32)
            if pos_tensor.ndim != 4 or cls_tensor.ndim != 4:
                continue
            if float(np.max(cls_tensor)) > 1.5 or float(np.min(cls_tensor)) < -0.5:
                cls_tensor = 1.0 / (1.0 + np.exp(-np.clip(cls_tensor, -16.0, 16.0)))
            else:
                cls_tensor = np.clip(cls_tensor, 0.0, 1.0)

            obj_tensor = np.ones_like(cls_tensor[:, :1, :, :], dtype=np.float32)
            score_idx = pair_per_branch * i + 2
            if score_idx < len(outputs):
                raw_score = np.asarray(outputs[score_idx], dtype=np.float32)
                if raw_score.ndim == 4:
                    if (
                        int(raw_score.shape[1]) == int(cls_tensor.shape[2])
                        and int(raw_score.shape[2]) == int(cls_tensor.shape[3])
                    ):
                        # Some exports provide NHWC score maps; normalize to NCHW.
                        raw_score = raw_score.transpose(0, 3, 1, 2)
                    if (
                        int(raw_score.shape[2]) == int(cls_tensor.shape[2])
                        and int(raw_score.shape[3]) == int(cls_tensor.shape[3])
                    ):
                        if int(raw_score.shape[1]) == 1:
                            obj_tensor = raw_score[:, :1, :, :]
                        else:
                            obj_tensor = np.max(raw_score, axis=1, keepdims=True)
            if float(np.max(obj_tensor)) > 1.5 or float(np.min(obj_tensor)) < -0.5:
                obj_tensor = 1.0 / (1.0 + np.exp(-np.clip(obj_tensor, -16.0, 16.0)))
            else:
                obj_tensor = np.clip(obj_tensor, 0.0, 1.0)

            boxes_list.append(self._yolo11_box_process(pos_tensor))
            classes_list.append(cls_tensor)
            scores_list.append(obj_tensor)

        if not boxes_list:
            return [], "RKNN output shape unsupported for yolo11 rkopt decode"

        boxes_flat = np.concatenate([self._yolo11_sp_flatten(v) for v in boxes_list], axis=0)
        classes_flat = np.concatenate([self._yolo11_sp_flatten(v) for v in classes_list], axis=0)
        scores_flat = np.concatenate([self._yolo11_sp_flatten(v) for v in scores_list], axis=0)

        box_conf = scores_flat.reshape(-1)
        class_max = np.max(classes_flat, axis=-1)
        class_ids = np.argmax(classes_flat, axis=-1)
        conf = class_max * box_conf

        keep = conf >= float(self.yolo_conf)
        if self.yolo_class_filter:
            allowed = np.isin(class_ids, np.array(self.yolo_class_filter, dtype=np.int32))
            keep = np.logical_and(keep, allowed)
        if not np.any(keep):
            return [], ""

        boxes = boxes_flat[keep]
        class_ids = class_ids[keep]
        conf = conf[keep]

        nboxes: list[np.ndarray] = []
        nclasses: list[np.ndarray] = []
        nscores: list[np.ndarray] = []
        for c in np.unique(class_ids):
            inds = np.where(class_ids == c)
            b = boxes[inds]
            s = conf[inds]
            cc = class_ids[inds]
            keep_idx = self._yolo_world_nms_boxes(b, s)
            if keep_idx.size == 0:
                continue
            nboxes.append(b[keep_idx])
            nclasses.append(cc[keep_idx])
            nscores.append(s[keep_idx])

        if not nboxes:
            return [], ""

        boxes_out = np.concatenate(nboxes, axis=0)
        classes_out = np.concatenate(nclasses, axis=0)
        scores_out = np.concatenate(nscores, axis=0)

        sx = float(frame_w) / float(self.yolo_input)
        sy = float(frame_h) / float(self.yolo_input)

        out: list[dict[str, Any]] = []
        for i in range(boxes_out.shape[0]):
            x1, y1, x2, y2 = [float(v) for v in boxes_out[i]]
            xi1 = int(np.clip(round(min(x1, x2) * sx), 0, max(0, frame_w - 1)))
            yi1 = int(np.clip(round(min(y1, y2) * sy), 0, max(0, frame_h - 1)))
            xi2 = int(np.clip(round(max(x1, x2) * sx), 0, max(0, frame_w - 1)))
            yi2 = int(np.clip(round(max(y1, y2) * sy), 0, max(0, frame_h - 1)))
            bw = max(0, xi2 - xi1)
            bh = max(0, yi2 - yi1)
            if bw <= 1 or bh <= 1:
                continue
            out.append(
                {
                    "type": "yolo",
                    "cx": float(xi1 + xi2) * 0.5,
                    "cy": float(yi1 + yi2) * 0.5,
                    "area": float(bw * bh),
                    "bbox_xywh": [int(xi1), int(yi1), int(bw), int(bh)],
                    "bbox_xyxy": [int(xi1), int(yi1), int(xi2), int(yi2)],
                    "score": float(scores_out[i]),
                    "class_id": int(classes_out[i]),
                }
            )

        out.sort(key=lambda d: d["area"], reverse=True)
        return out, ""

    def _decode_rknn_yolov5(
        self, outputs: list[Any], frame_w: int, frame_h: int
    ) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None:
            return [], "opencv unavailable"
        tensors: list[np.ndarray] = []
        for out in outputs:
            t = self._reshape_rknn_yolov5_tensor(out)
            if t is None:
                continue
            # Some exports output logits; normalize to [0,1] when needed.
            if float(np.max(t)) > 1.5 or float(np.min(t)) < -0.5:
                t = 1.0 / (1.0 + np.exp(-t))
            tensors.append(t)
        if not tensors:
            return [], "RKNN output shape unsupported for yolov5 decode"

        tensors.sort(key=lambda x: x.shape[2], reverse=True)
        anchor_groups = self.yolo_anchors
        if not anchor_groups:
            return [], "YOLO anchors unavailable"

        boxes_xywh: list[list[int]] = []
        scores: list[float] = []
        cls_ids: list[int] = []
        xyxy_raw: list[tuple[int, int, int, int]] = []

        for i, tensor in enumerate(tensors):
            if i >= len(anchor_groups):
                break
            if tensor.ndim != 4 or tensor.shape[0] != 3 or tensor.shape[1] < 6:
                continue
            gh, gw = int(tensor.shape[2]), int(tensor.shape[3])
            anchors = np.array(anchor_groups[i], dtype=np.float32).reshape(3, 2, 1, 1)
            pos = tensor[:, :4, :, :]
            obj = tensor[:, 4:5, :, :]
            cls = tensor[:, 5:, :, :]
            if cls.size == 0:
                continue

            col, row = np.meshgrid(np.arange(gw), np.arange(gh))
            grid = np.stack([col, row], axis=0).reshape(1, 2, gh, gw).astype(np.float32)
            stride = np.array(
                [float(self.yolo_input) / float(gw), float(self.yolo_input) / float(gh)],
                dtype=np.float32,
            ).reshape(1, 2, 1, 1)

            box_xy = (pos[:, :2, :, :] * 2.0 - 0.5 + grid) * stride
            box_wh = np.power(pos[:, 2:4, :, :] * 2.0, 2.0) * anchors
            xyxy = np.concatenate(
                [
                    box_xy[:, 0:1, :, :] - box_wh[:, 0:1, :, :] * 0.5,
                    box_xy[:, 1:2, :, :] - box_wh[:, 1:2, :, :] * 0.5,
                    box_xy[:, 0:1, :, :] + box_wh[:, 0:1, :, :] * 0.5,
                    box_xy[:, 1:2, :, :] + box_wh[:, 1:2, :, :] * 0.5,
                ],
                axis=1,
            )

            boxes = xyxy.transpose(0, 2, 3, 1).reshape(-1, 4)
            obj_scores = obj.transpose(0, 2, 3, 1).reshape(-1)
            cls_scores = cls.transpose(0, 2, 3, 1).reshape(-1, cls.shape[1])
            class_ids = np.argmax(cls_scores, axis=1)
            class_max = cls_scores[np.arange(cls_scores.shape[0]), class_ids]
            conf = obj_scores * class_max

            keep = conf >= self.yolo_conf
            if self.yolo_class_filter:
                allowed = np.isin(class_ids, np.array(self.yolo_class_filter, dtype=np.int32))
                keep = np.logical_and(keep, allowed)
            if not np.any(keep):
                continue

            boxes = boxes[keep]
            class_ids = class_ids[keep]
            conf = conf[keep]
            scale_x = float(frame_w) / float(self.yolo_input)
            scale_y = float(frame_h) / float(self.yolo_input)

            for j in range(boxes.shape[0]):
                x1 = int(np.clip(round(float(boxes[j, 0]) * scale_x), 0, max(0, frame_w - 1)))
                y1 = int(np.clip(round(float(boxes[j, 1]) * scale_y), 0, max(0, frame_h - 1)))
                x2 = int(np.clip(round(float(boxes[j, 2]) * scale_x), 0, max(0, frame_w - 1)))
                y2 = int(np.clip(round(float(boxes[j, 3]) * scale_y), 0, max(0, frame_h - 1)))
                bw_i = max(0, x2 - x1)
                bh_i = max(0, y2 - y1)
                if bw_i <= 1 or bh_i <= 1:
                    continue
                boxes_xywh.append([x1, y1, bw_i, bh_i])
                scores.append(float(conf[j]))
                cls_ids.append(int(class_ids[j]))
                xyxy_raw.append((x1, y1, x2, y2))

        if not boxes_xywh:
            return [], ""

        keep = self.cv2.dnn.NMSBoxes(
            bboxes=boxes_xywh,
            scores=scores,
            score_threshold=self.yolo_conf,
            nms_threshold=self.yolo_nms,
        )
        if keep is None or len(keep) == 0:
            return [], ""

        out: list[dict[str, Any]] = []
        for idx in np.array(keep).reshape(-1).tolist():
            i = int(idx)
            x1, y1, x2, y2 = xyxy_raw[i]
            area = float(max(0, x2 - x1) * max(0, y2 - y1))
            cx = float(x1 + x2) * 0.5
            cy = float(y1 + y2) * 0.5
            out.append(
                {
                    "type": "yolo",
                    "cx": cx,
                    "cy": cy,
                    "area": area,
                    "bbox_xywh": [int(x1), int(y1), int(x2 - x1), int(y2 - y1)],
                    "bbox_xyxy": [int(x1), int(y1), int(x2), int(y2)],
                    "score": float(scores[i]),
                    "class_id": int(cls_ids[i]),
                }
            )
        out.sort(key=lambda d: d["area"], reverse=True)
        return out, ""

    def _detect_yolo_rknn(self, frame: Any) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None:
            return [], "opencv unavailable"
        if self.yolo_rknn is None:
            return [], self.yolo_error or "rknn unavailable"
        h, w = frame.shape[:2]
        # rknnlite inputs are typically uint8 RGB NHWC.
        img = self.cv2.cvtColor(frame, self.cv2.COLOR_BGR2RGB)
        if img.shape[1] != self.yolo_input or img.shape[0] != self.yolo_input:
            img = self.cv2.resize(img, (self.yolo_input, self.yolo_input))
        img = np.expand_dims(img, axis=0)
        try:
            outputs = self.yolo_rknn.inference(inputs=[img], data_format=["nhwc"])
        except TypeError:
            outputs = self.yolo_rknn.inference(inputs=[img])
        except Exception as exc:
            self.yolo_error = f"YOLO RKNN inference failed: {exc}"
            return [], self.yolo_error
        if outputs is None:
            self.yolo_error = "YOLO RKNN inference returned no outputs"
            return [], self.yolo_error
        single_out: Any | None = None
        if isinstance(outputs, (list, tuple)):
            if len(outputs) == 0:
                self.yolo_error = "YOLO RKNN inference returned empty outputs"
                return [], self.yolo_error
            if len(outputs) == 1:
                single_out = outputs[0]
        else:
            single_out = outputs
        if single_out is not None:
            preds, mode = self._normalize_yolo_output(single_out)
            if preds.size > 0:
                return self._postprocess_yolo_preds(preds=preds, mode=mode, frame_w=w, frame_h=h)
        if not isinstance(outputs, (list, tuple)):
            outputs = [outputs]
        if self._is_rknn_yolo11_rkopt_output(list(outputs)):
            try:
                return self._decode_rknn_yolo11_rkopt(outputs=list(outputs), frame_w=w, frame_h=h)
            except Exception as exc:
                self.yolo_error = f"YOLO RKNN yolo11 decode failed: {exc}"
                return [], self.yolo_error
        try:
            return self._decode_rknn_yolov5(outputs=list(outputs), frame_w=w, frame_h=h)
        except Exception as exc:
            self.yolo_error = f"YOLO RKNN decode failed: {exc}"
            return [], self.yolo_error

    def _detect_yolo(self, frame: Any) -> tuple[list[dict[str, Any]], str]:
        objects: list[dict[str, Any]] = []
        err = ""
        if self.yolo_backend_active == "rknn":
            objects, err = self._detect_yolo_rknn(frame)
        elif self.yolo_backend_active == "onnxruntime":
            objects, err = self._detect_yolo_onnxruntime(frame)
        elif self.yolo_backend_active == "opencv":
            objects, err = self._detect_yolo_opencv(frame)
        else:
            with self.lock:
                self.yolo_last_suppressed_spike = False
            return [], self.yolo_error or "YOLO unavailable"

        if err:
            with self.lock:
                self.yolo_last_suppressed_spike = False
            return [], err

        objects = self._sanitize_yolo_objects(objects)
        objects, suppressed = self._stabilize_yolo_objects(objects)
        with self.lock:
            self.yolo_last_suppressed_spike = bool(suppressed)
            if not suppressed:
                self.yolo_error = ""
        return objects, ""

    def _sanitize_yolo_objects(self, objects: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if not objects:
            return []
        cleaned: list[dict[str, Any]] = []
        for obj in objects:
            bbox = obj.get("bbox_xyxy")
            if not isinstance(bbox, (list, tuple)) or len(bbox) < 4:
                continue
            try:
                x1 = int(bbox[0])
                y1 = int(bbox[1])
                x2 = int(bbox[2])
                y2 = int(bbox[3])
                score = float(obj.get("score") or 0.0)
            except Exception:
                continue
            if not np.isfinite(score):
                continue
            bw = max(0, x2 - x1)
            bh = max(0, y2 - y1)
            if bw <= 1 or bh <= 1:
                continue
            area = float(obj.get("area") or float(bw * bh))
            if not np.isfinite(area) or area <= 1.0:
                area = float(bw * bh)
            one = dict(obj)
            one["bbox_xyxy"] = [int(x1), int(y1), int(x2), int(y2)]
            one["bbox_xywh"] = [int(x1), int(y1), int(bw), int(bh)]
            one["cx"] = float(x1 + x2) * 0.5
            one["cy"] = float(y1 + y2) * 0.5
            one["area"] = float(area)
            one["score"] = float(np.clip(score, 0.0, 1.0))
            cleaned.append(one)

        if len(cleaned) >= self.yolo_adaptive_trigger:
            cleaned = [
                obj
                for obj in cleaned
                if float(obj.get("score") or 0.0) >= float(self.yolo_adaptive_conf)
            ]

        if self.yolo_max_objects > 0 and len(cleaned) > self.yolo_max_objects:
            cleaned.sort(key=lambda d: float(d.get("score") or 0.0), reverse=True)
            cleaned = cleaned[: self.yolo_max_objects]

        cleaned.sort(key=lambda d: float(d.get("area") or 0.0), reverse=True)
        return cleaned

    def _stabilize_yolo_objects(
        self, objects: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], bool]:
        current_count = int(len(objects))
        with self.lock:
            stable_prev = [dict(obj) for obj in self.yolo_last_stable_objects]
            prev_count = int(len(stable_prev))
            spike_threshold = max(
                int(self.yolo_spike_count),
                int(round(float(prev_count) * float(self.yolo_spike_factor))),
            )
            is_spike = current_count >= spike_threshold and current_count > prev_count
            if is_spike:
                self.yolo_spike_streak += 1
            else:
                self.yolo_spike_streak = 0

            if is_spike and self.yolo_spike_streak < self.yolo_spike_confirm:
                return stable_prev, True

            self.yolo_last_stable_objects = [dict(obj) for obj in objects]
            self.yolo_spike_streak = 0
            return objects, False

    def _letter_box(
        self, img: Any, new_shape: int, pad_color: tuple[int, int, int] = (0, 0, 0)
    ) -> tuple[Any, float, tuple[float, float]]:
        if self.cv2 is None:
            return img, 1.0, (0.0, 0.0)
        h, w = img.shape[:2]
        r = min(float(new_shape) / float(h), float(new_shape) / float(w))
        new_unpad = (int(round(w * r)), int(round(h * r)))
        dw = float(new_shape - new_unpad[0]) / 2.0
        dh = float(new_shape - new_unpad[1]) / 2.0
        if (w, h) != new_unpad:
            img = self.cv2.resize(img, new_unpad, interpolation=self.cv2.INTER_LINEAR)
        top = int(round(dh - 0.1))
        bottom = int(round(dh + 0.1))
        left = int(round(dw - 0.1))
        right = int(round(dw + 0.1))
        img = self.cv2.copyMakeBorder(
            img,
            top,
            bottom,
            left,
            right,
            self.cv2.BORDER_CONSTANT,
            value=pad_color,
        )
        return img, r, (dw, dh)

    def _yolo_world_box_process(self, position: np.ndarray) -> np.ndarray:
        gh, gw = int(position.shape[2]), int(position.shape[3])
        col, row = np.meshgrid(np.arange(0, gw), np.arange(0, gh))
        col = col.reshape(1, 1, gh, gw)
        row = row.reshape(1, 1, gh, gw)
        grid = np.concatenate((col, row), axis=1).astype(np.float32)
        stride = np.array(
            [float(self.yolo_world_input) / float(gh), float(self.yolo_world_input) / float(gw)],
            dtype=np.float32,
        ).reshape(1, 2, 1, 1)
        box_xy = grid + 0.5 - position[:, 0:2, :, :]
        box_xy2 = grid + 0.5 + position[:, 2:4, :, :]
        return np.concatenate((box_xy * stride, box_xy2 * stride), axis=1)

    @staticmethod
    def _yolo_world_sp_flatten(tensor: np.ndarray) -> np.ndarray:
        ch = int(tensor.shape[1])
        return tensor.transpose(0, 2, 3, 1).reshape(-1, ch)

    def _yolo_world_filter_boxes(
        self, boxes: np.ndarray, box_confidences: np.ndarray, box_class_probs: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        box_conf = box_confidences.reshape(-1)
        class_max_score = np.max(box_class_probs, axis=-1)
        classes = np.argmax(box_class_probs, axis=-1)
        keep_pos = np.where((class_max_score * box_conf) >= float(self.yolo_world_conf))
        scores = (class_max_score * box_conf)[keep_pos]
        return boxes[keep_pos], classes[keep_pos], scores

    def _yolo_world_nms_boxes(self, boxes: np.ndarray, scores: np.ndarray) -> np.ndarray:
        if boxes.shape[0] == 0:
            return np.empty((0,), dtype=np.int32)
        x = boxes[:, 0]
        y = boxes[:, 1]
        w = boxes[:, 2] - boxes[:, 0]
        h = boxes[:, 3] - boxes[:, 1]
        areas = w * h
        order = scores.argsort()[::-1]
        keep: list[int] = []
        while order.size > 0:
            i = int(order[0])
            keep.append(i)
            xx1 = np.maximum(x[i], x[order[1:]])
            yy1 = np.maximum(y[i], y[order[1:]])
            xx2 = np.minimum(x[i] + w[i], x[order[1:]] + w[order[1:]])
            yy2 = np.minimum(y[i] + h[i], y[order[1:]] + h[order[1:]])
            w1 = np.maximum(0.0, xx2 - xx1 + 0.00001)
            h1 = np.maximum(0.0, yy2 - yy1 + 0.00001)
            inter = w1 * h1
            denom = np.maximum(1e-6, areas[i] + areas[order[1:]] - inter)
            ovr = inter / denom
            inds = np.where(ovr <= float(self.yolo_world_nms))[0]
            order = order[inds + 1]
        return np.array(keep, dtype=np.int32)

    def _dedupe_yolo_world_cross_class(
        self, objects: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        if self.cv2 is None or len(objects) <= 1:
            return objects
        boxes: list[list[int]] = []
        scores: list[float] = []
        for obj in objects:
            xywh = obj.get("bbox_xywh")
            if not isinstance(xywh, list) or len(xywh) != 4:
                continue
            boxes.append([int(xywh[0]), int(xywh[1]), int(xywh[2]), int(xywh[3])])
            scores.append(float(obj.get("score") or 0.0))
        if len(boxes) <= 1:
            return objects
        try:
            keep = self.cv2.dnn.NMSBoxes(
                bboxes=boxes,
                scores=scores,
                score_threshold=float(self.yolo_world_conf),
                nms_threshold=max(0.35, float(self.yolo_world_nms)),
            )
        except Exception:
            return objects
        if keep is None or len(keep) == 0:
            return []
        idxs = [int(i) for i in np.array(keep).reshape(-1).tolist()]
        return [objects[i] for i in idxs if 0 <= i < len(objects)]

    def _postprocess_yolo_world(
        self, outputs: list[Any], frame_w: int, frame_h: int, ratio: float, dw: float, dh: float
    ) -> tuple[list[dict[str, Any]], str]:
        if not outputs:
            return [], ""
        branches = 3
        pair_per_branch = len(outputs) // branches
        if pair_per_branch < 2:
            return [], "YOLO-World output shape unsupported"

        boxes: list[np.ndarray] = []
        classes_conf: list[np.ndarray] = []
        scores: list[np.ndarray] = []
        for i in range(branches):
            cls_tensor = np.asarray(outputs[pair_per_branch * i], dtype=np.float32)
            pos_tensor = np.asarray(outputs[pair_per_branch * i + 1], dtype=np.float32)
            if cls_tensor.ndim != 4 or pos_tensor.ndim != 4:
                continue
            boxes.append(self._yolo_world_box_process(pos_tensor))
            classes_conf.append(cls_tensor)
            scores.append(np.ones_like(cls_tensor[:, :1, :, :], dtype=np.float32))
        if not boxes:
            return [], "YOLO-World outputs empty"

        boxes_flat = np.concatenate([self._yolo_world_sp_flatten(v) for v in boxes], axis=0)
        classes_flat = np.concatenate([self._yolo_world_sp_flatten(v) for v in classes_conf], axis=0)
        scores_flat = np.concatenate([self._yolo_world_sp_flatten(v) for v in scores], axis=0)

        boxes_f, classes_f, scores_f = self._yolo_world_filter_boxes(
            boxes_flat, scores_flat, classes_flat
        )
        if boxes_f.size == 0:
            return [], ""

        nboxes: list[np.ndarray] = []
        nclasses: list[np.ndarray] = []
        nscores: list[np.ndarray] = []
        for c in set(classes_f.tolist()):
            inds = np.where(classes_f == c)
            b = boxes_f[inds]
            s = scores_f[inds]
            cc = classes_f[inds]
            keep = self._yolo_world_nms_boxes(b, s)
            if keep.size == 0:
                continue
            nboxes.append(b[keep])
            nclasses.append(cc[keep])
            nscores.append(s[keep])
        if not nboxes:
            return [], ""

        boxes_out = np.concatenate(nboxes, axis=0)
        classes_out = np.concatenate(nclasses, axis=0)
        scores_out = np.concatenate(nscores, axis=0)
        inv = 1.0 / max(1e-6, float(ratio))

        out: list[dict[str, Any]] = []
        for i in range(boxes_out.shape[0]):
            x1, y1, x2, y2 = [float(v) for v in boxes_out[i]]
            x1 = (x1 - float(dw)) * inv
            y1 = (y1 - float(dh)) * inv
            x2 = (x2 - float(dw)) * inv
            y2 = (y2 - float(dh)) * inv
            xi1 = int(np.clip(round(min(x1, x2)), 0, max(0, frame_w - 1)))
            yi1 = int(np.clip(round(min(y1, y2)), 0, max(0, frame_h - 1)))
            xi2 = int(np.clip(round(max(x1, x2)), 0, max(0, frame_w - 1)))
            yi2 = int(np.clip(round(max(y1, y2)), 0, max(0, frame_h - 1)))
            bw = max(0, xi2 - xi1)
            bh = max(0, yi2 - yi1)
            if bw <= 1 or bh <= 1:
                continue
            cid = int(classes_out[i])
            score = float(scores_out[i])
            cname = (
                self.yolo_world_labels[cid]
                if 0 <= cid < len(self.yolo_world_labels)
                else f"class_{cid}"
            )
            out.append(
                {
                    "type": "yolo_world",
                    "cx": float(xi1 + xi2) * 0.5,
                    "cy": float(yi1 + yi2) * 0.5,
                    "area": float(bw * bh),
                    "bbox_xywh": [xi1, yi1, bw, bh],
                    "bbox_xyxy": [xi1, yi1, xi2, yi2],
                    "score": score,
                    "class_id": cid,
                    "class_name": cname,
                }
            )
        with self.lock:
            class_filter = (
                set(self.yolo_world_class_filter_ids)
                if self.yolo_world_class_filter_ids is not None
                else None
            )
        if class_filter is not None:
            out = [
                obj
                for obj in out
                if int(obj.get("class_id", -1)) in class_filter
            ]
        if len(out) >= self.yolo_world_adaptive_trigger:
            out = [
                obj
                for obj in out
                if float(obj.get("score") or 0.0) >= float(self.yolo_world_adaptive_conf)
            ]
        if self.yolo_world_pre_nms_cap > 0 and len(out) > self.yolo_world_pre_nms_cap:
            out.sort(key=lambda d: float(d.get("score") or 0.0), reverse=True)
            out = out[: self.yolo_world_pre_nms_cap]
        out = self._dedupe_yolo_world_cross_class(out)
        if self.yolo_world_max_objects > 0 and len(out) > self.yolo_world_max_objects:
            out.sort(key=lambda d: float(d.get("score") or 0.0), reverse=True)
            out = out[: self.yolo_world_max_objects]
        out.sort(key=lambda d: d["area"], reverse=True)
        return out, ""

    def _stabilize_yolo_world_objects(
        self, objects: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], bool]:
        current_count = int(len(objects))
        with self.lock:
            stable_prev = [dict(obj) for obj in self.yolo_world_last_stable_objects]
            prev_count = int(len(stable_prev))
            is_drop = current_count == 0 and prev_count > 0
            if is_drop:
                self.yolo_world_drop_streak += 1
            else:
                self.yolo_world_drop_streak = 0

            # Prevent one-frame dropouts that cause visible box flicker on static targets.
            if is_drop and self.yolo_world_drop_streak < 2:
                return stable_prev, True

            spike_threshold = max(
                int(self.yolo_world_spike_count),
                int(round(float(prev_count) * float(self.yolo_world_spike_factor))),
            )
            is_spike = current_count >= spike_threshold
            if is_spike:
                self.yolo_world_spike_streak += 1
            else:
                self.yolo_world_spike_streak = 0

            if is_spike and self.yolo_world_spike_streak < self.yolo_world_spike_confirm:
                return stable_prev, True

            self.yolo_world_last_stable_objects = [dict(obj) for obj in objects]
            self.yolo_world_spike_streak = 0
            self.yolo_world_drop_streak = 0
            return objects, False

    def _detect_yolo_world(
        self, frame: Any, frame_ts: float = 0.0, use_cache: bool = True
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
        metrics: dict[str, Any] = {
            "cache_hit": False,
            "single_flight": bool(self.yolo_world_single_flight),
            "wait_ms": 0.0,
            "preprocess_ms": 0.0,
            "infer_ms": 0.0,
            "postprocess_ms": 0.0,
            "detect_ms": 0.0,
            "suppressed_spike": False,
        }
        detect_started = time.perf_counter()
        if self.cv2 is None:
            metrics["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
            return [], "opencv unavailable", metrics
        if self.yolo_world_rknn is None or self.yolo_world_text_embeddings is None:
            metrics["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
            return [], self.yolo_world_error or "YOLO-World unavailable", metrics

        if use_cache:
            cached = self._yolo_world_cache_get(frame_ts)
            if cached is not None:
                objs, err, cache_meta = cached
                out_meta = dict(metrics)
                out_meta.update(cache_meta)
                out_meta["single_flight"] = bool(self.yolo_world_single_flight)
                out_meta["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                return objs, err, out_meta

        wait_started = time.perf_counter()
        if self.yolo_world_single_flight:
            self.yolo_world_infer_lock.acquire()
        metrics["wait_ms"] = round((time.perf_counter() - wait_started) * 1000.0, 2)
        try:
            if use_cache:
                cached = self._yolo_world_cache_get(frame_ts)
                if cached is not None:
                    objs, err, cache_meta = cached
                    waited_ms = float(metrics.get("wait_ms", 0.0))
                    out_meta = dict(metrics)
                    out_meta.update(cache_meta)
                    out_meta["wait_ms"] = round(waited_ms, 2)
                    out_meta["single_flight"] = bool(self.yolo_world_single_flight)
                    out_meta["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                    return objs, err, out_meta

            h, w = frame.shape[:2]

            t0 = time.perf_counter()
            img = self.cv2.cvtColor(frame, self.cv2.COLOR_BGR2RGB)
            img, ratio, (dw, dh) = self._letter_box(
                img,
                new_shape=self.yolo_world_input,
                pad_color=(0, 0, 0),
            )
            # YOLO-World RKNN model is static-shape; keep image tensor in uint8 NHWC.
            img_in = np.expand_dims(img, axis=0).astype(np.uint8, copy=False)
            text_in = self.yolo_world_text_embeddings.astype(np.float32, copy=False)
            metrics["preprocess_ms"] = round((time.perf_counter() - t0) * 1000.0, 2)

            t1 = time.perf_counter()
            try:
                outputs = self.yolo_world_rknn.inference(
                    inputs=[img_in, text_in],
                    data_format=["nhwc", "nhwc"],
                )
            except TypeError:
                outputs = self.yolo_world_rknn.inference(inputs=[img_in, text_in])
            except Exception as exc:
                self.yolo_world_error = f"YOLO-World inference failed: {exc}"
                metrics["infer_ms"] = round((time.perf_counter() - t1) * 1000.0, 2)
                metrics["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                self._yolo_world_cache_set(
                    frame_ts,
                    [],
                    self.yolo_world_error,
                    metrics,
                )
                return [], self.yolo_world_error, metrics
            metrics["infer_ms"] = round((time.perf_counter() - t1) * 1000.0, 2)
            if outputs is None:
                self.yolo_world_error = "YOLO-World inference returned no outputs"
                metrics["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                self._yolo_world_cache_set(
                    frame_ts,
                    [],
                    self.yolo_world_error,
                    metrics,
                )
                return [], self.yolo_world_error, metrics
            if not isinstance(outputs, list):
                outputs = [outputs]

            t2 = time.perf_counter()
            try:
                objs, err = self._postprocess_yolo_world(
                    outputs=list(outputs),
                    frame_w=w,
                    frame_h=h,
                    ratio=ratio,
                    dw=dw,
                    dh=dh,
                )
                suppressed = False
                if not err:
                    objs, suppressed = self._stabilize_yolo_world_objects(objs)
                    metrics["suppressed_spike"] = bool(suppressed)
                    if suppressed:
                        self.yolo_world_error = ""
                if err:
                    self.yolo_world_error = err
                elif not suppressed:
                    self.yolo_world_error = ""
                metrics["postprocess_ms"] = round((time.perf_counter() - t2) * 1000.0, 2)
                metrics["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                self._yolo_world_cache_set(frame_ts, objs, err, metrics)
                return objs, err, metrics
            except Exception as exc:
                self.yolo_world_error = f"YOLO-World decode failed: {exc}"
                metrics["postprocess_ms"] = round((time.perf_counter() - t2) * 1000.0, 2)
                metrics["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                self._yolo_world_cache_set(frame_ts, [], self.yolo_world_error, metrics)
                return [], self.yolo_world_error, metrics
        finally:
            if self.yolo_world_single_flight:
                self.yolo_world_infer_lock.release()

    def _wear_glasses_status(self) -> dict[str, Any]:
        return {
            "wear_glasses_enabled": bool(self.wear_glasses_enabled),
            "wear_glasses_auto": bool(self.wear_glasses_auto),
            "wear_glasses_ready": bool(self.wear_glasses_ready),
            "wear_glasses_error": self.wear_glasses_error or None,
            "wear_glasses_clip_model": self.wear_glasses_clip_model_name or None,
            "wear_glasses_device_requested": self.wear_glasses_device_request or None,
            "wear_glasses_device_active": self.wear_glasses_device_active or None,
            "wear_glasses_max_persons": int(self.wear_glasses_max_persons),
            "wear_glasses_min_margin": float(self.wear_glasses_min_margin),
            "wear_glasses_head_ratio": float(self.wear_glasses_head_ratio),
            "wear_glasses_head_width_ratio": float(self.wear_glasses_head_width_ratio),
            "wear_glasses_update_interval_ms": float(self.wear_glasses_update_interval_ms),
            "wear_glasses_cache_ttl_ms": float(self.wear_glasses_cache_ttl_ms),
            "wear_glasses_cache_match_iou": float(self.wear_glasses_cache_match_iou),
            "wear_glasses_cache_max_center_dist": float(self.wear_glasses_cache_max_center_dist),
        }

    def _face_recognition_status(self) -> dict[str, Any]:
        return {
            "face_recognition_enabled": bool(self.face_recognition_enabled),
            "face_recognition_auto": bool(self.face_recognition_auto),
            "face_recognition_ready": bool(self.face_recognition_ready),
            "face_recognition_error": self.face_recognition_error or None,
            "face_recognition_model_path": self.face_recognition_model_path or None,
            "face_recognition_backend_requested": self.face_recognition_backend_requested or None,
            "face_recognition_backend_active": self.face_recognition_backend_active or None,
            "face_recognition_target_requested": self.face_recognition_target_requested or None,
            "face_recognition_target_active": self.face_recognition_target_active or None,
            "face_recognition_gallery_dir": self.face_recognition_gallery_dir or None,
            "face_recognition_gallery_identities": int(self.face_gallery_identity_count),
            "face_recognition_gallery_images": int(self.face_gallery_image_count),
            "face_recognition_gallery_updated_at": (
                datetime.fromtimestamp(self.face_gallery_updated_ts).isoformat(timespec="seconds")
                if self.face_gallery_updated_ts > 0
                else None
            ),
            "face_recognition_gallery_error": self.face_gallery_error or None,
            "face_recognition_threshold": float(self.face_recognition_threshold),
            "face_recognition_peak_threshold": float(self.face_recognition_peak_threshold),
            "face_recognition_support_threshold": float(self.face_recognition_support_threshold),
            "face_recognition_min_support": int(self.face_recognition_min_support),
            "face_recognition_topk": int(self.face_recognition_topk),
            "face_recognition_min_face_size": int(self.face_recognition_min_face_size),
            "face_recognition_min_score": float(self.face_recognition_min_score),
            "face_recognition_max_yaw_deg": float(self.face_recognition_max_yaw_deg),
            "face_recognition_max_pitch_deg": float(self.face_recognition_max_pitch_deg),
            "face_recognition_max_roll_deg": float(self.face_recognition_max_roll_deg),
            "face_recognition_unknown_label": self.face_recognition_unknown_label or None,
        }

    def _emotion_status(self) -> dict[str, Any]:
        return {
            "emotion_enabled": bool(self.emotion_enabled),
            "emotion_auto": bool(self.emotion_auto),
            "emotion_ready": bool(self.emotion_ready),
            "emotion_error": self.emotion_error or None,
            "emotion_engine": self.emotion_engine or None,
            "emotion_model": self.emotion_model_name or None,
            "emotion_rknn_model_path": self.emotion_rknn_model_path or None,
            "emotion_rknn_input": int(self.emotion_rknn_input),
            "emotion_rknn_core": self.emotion_rknn_core or None,
            "emotion_rknn_layout": self.emotion_rknn_layout or None,
            "emotion_rknn_dtype": self.emotion_rknn_dtype or None,
            "emotion_rknn_color": self.emotion_rknn_color or None,
            "emotion_rknn_softmax": bool(self.emotion_rknn_softmax),
            "emotion_rknn_labels_file": self.emotion_rknn_labels_file or None,
            "emotion_rknn_labels_count": int(len(self.emotion_rknn_labels)),
            "emotion_rknn_labels": list(self.emotion_rknn_labels),
            "emotion_rknn_labels_error": self.emotion_rknn_labels_error or None,
            "emotion_require_face": bool(self.emotion_require_face),
            "emotion_face_detector_requested": self.emotion_face_detector_requested or None,
            "emotion_face_detector_active": self._face_detector_active_mode() or None,
            "emotion_face_detector": self._face_detector_active_mode()
            or self.emotion_face_detector_requested
            or None,
            "emotion_face_model_path": self.emotion_face_model_path or None,
            "emotion_face_rknn_model_path": self.emotion_face_rknn_model_path or None,
            "emotion_face_rknn_input": int(self.emotion_face_rknn_input),
            "emotion_face_rknn_conf": float(self.emotion_face_rknn_conf),
            "emotion_face_rknn_nms": float(self.emotion_face_rknn_nms),
            "emotion_face_rknn_class_id": int(self.emotion_face_rknn_class_id),
            "emotion_face_rknn_core": self.emotion_face_rknn_core or None,
            "emotion_face_rknn_type": self.emotion_face_rknn_type or None,
            "emotion_face_detector_error": self.emotion_face_detector_error or None,
            "emotion_max_persons": int(self.emotion_max_persons),
            "emotion_min_confidence": float(self.emotion_min_confidence),
            "emotion_head_ratio": float(self.emotion_head_ratio),
            "emotion_head_width_ratio": float(self.emotion_head_width_ratio),
            "emotion_face_input_size": int(self.emotion_face_input_size),
            "emotion_face_score": float(self.emotion_face_score),
            "emotion_face_nms": float(self.emotion_face_nms),
            "emotion_face_topk": int(self.emotion_face_topk),
            "emotion_face_expand": float(self.emotion_face_expand),
            "emotion_face_min_size": int(self.emotion_face_min_size),
            "person_head_box_top_ratio": float(self.person_head_box_top_ratio),
            "person_head_box_width_ratio": float(self.person_head_box_width_ratio),
            "person_head_face_detect_live": bool(self.person_head_face_detect_live),
            "face_only_mode": bool(self.face_only_mode),
            "face_only_world_fusion": bool(self.face_only_world_fusion),
            "face_only_world_strict": bool(self.face_only_world_strict),
            "face_detect_max_side": int(self.face_detect_max_side),
            "face_update_interval_ms": float(self.face_update_interval_ms),
            "face_attr_expand": float(self.face_attr_expand),
            "face_max_objects": int(self.face_max_objects),
            "face_max_area_ratio": float(self.face_max_area_ratio),
            "face_min_aspect_ratio": float(self.face_min_aspect_ratio),
            "face_max_aspect_ratio": float(self.face_max_aspect_ratio),
            "face_min_score": float(self.face_min_score),
            "emotion_update_interval_ms": float(self.emotion_update_interval_ms),
            "emotion_cache_ttl_ms": float(self.emotion_cache_ttl_ms),
            "emotion_cache_match_iou": float(self.emotion_cache_match_iou),
            "emotion_cache_max_center_dist": float(self.emotion_cache_max_center_dist),
        }

    def _resolve_wear_glasses_device(self, torch_mod: Any) -> str:
        req = str(self.wear_glasses_device_request or "auto").strip().lower()
        if req in ("", "auto"):
            try:
                return "cuda" if bool(torch_mod.cuda.is_available()) else "cpu"
            except Exception:
                return "cpu"
        if req in ("cpu", "cuda", "mps"):
            return req
        return "cpu"

    @staticmethod
    def _repair_logging_level_aliases() -> None:
        std_levels = [
            (logging.CRITICAL, "CRITICAL"),
            (logging.ERROR, "ERROR"),
            (logging.WARNING, "WARNING"),
            (logging.INFO, "INFO"),
            (logging.DEBUG, "DEBUG"),
            (logging.NOTSET, "NOTSET"),
        ]
        try:
            name_map = getattr(logging, "_nameToLevel", {})
            for level_num, level_name in std_levels:
                if level_name not in name_map:
                    logging.addLevelName(level_num, level_name)
        except Exception:
            return

    def _ensure_wear_glasses_model(self) -> tuple[bool, str]:
        if not self.wear_glasses_enabled:
            return False, "wear_glasses disabled"
        with self.model_load_lock:
            with self.wear_glasses_lock:
                if (
                    self.wear_glasses_ready
                    and self.wear_glasses_model is not None
                    and self.wear_glasses_preprocess is not None
                    and self.wear_glasses_torch is not None
                    and self.wear_glasses_pil_image is not None
                    and self.wear_glasses_text_pos is not None
                    and self.wear_glasses_text_neg is not None
                ):
                    return True, ""
                try:
                    self._repair_logging_level_aliases()
                    import clip as clip_mod  # type: ignore
                    import torch as torch_mod
                    from PIL import Image as PILImage
                except Exception as exc:
                    self.wear_glasses_error = f"wear_glasses import failed: {exc}"
                    return False, self.wear_glasses_error

                device = self._resolve_wear_glasses_device(torch_mod)
                try:
                    model, preprocess = clip_mod.load(self.wear_glasses_clip_model_name, device=device)
                except Exception as exc:
                    if device != "cpu":
                        try:
                            device = "cpu"
                            model, preprocess = clip_mod.load(
                                self.wear_glasses_clip_model_name, device=device
                            )
                        except Exception as retry_exc:
                            self.wear_glasses_error = (
                                f"wear_glasses clip load failed: {exc}; retry cpu failed: {retry_exc}"
                            )
                            return False, self.wear_glasses_error
                    else:
                        self.wear_glasses_error = f"wear_glasses clip load failed: {exc}"
                        return False, self.wear_glasses_error

                try:
                    model.eval()
                    with torch_mod.no_grad():
                        pos_tok = clip_mod.tokenize(WEAR_GLASSES_POSITIVE_PROMPTS, truncate=True).to(
                            device
                        )
                        neg_tok = clip_mod.tokenize(WEAR_GLASSES_NEGATIVE_PROMPTS, truncate=True).to(
                            device
                        )
                        pos_feat = model.encode_text(pos_tok).float()
                        neg_feat = model.encode_text(neg_tok).float()
                        pos_feat = pos_feat / pos_feat.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                        neg_feat = neg_feat / neg_feat.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                        pos_mean = pos_feat.mean(dim=0, keepdim=True)
                        neg_mean = neg_feat.mean(dim=0, keepdim=True)
                        pos_mean = pos_mean / pos_mean.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                        neg_mean = neg_mean / neg_mean.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                except Exception as exc:
                    self.wear_glasses_error = f"wear_glasses text feature init failed: {exc}"
                    return False, self.wear_glasses_error

                self.wear_glasses_model = model
                self.wear_glasses_preprocess = preprocess
                self.wear_glasses_torch = torch_mod
                self.wear_glasses_pil_image = PILImage
                self.wear_glasses_text_pos = pos_mean
                self.wear_glasses_text_neg = neg_mean
                self.wear_glasses_device_active = device
                self.wear_glasses_ready = True
                self.wear_glasses_error = ""
                return True, ""

    def _ensure_yunet_model_file(self) -> str:
        raw = str(self.emotion_face_model_path or "").strip()
        if not raw:
            self.emotion_face_detector_error = "emotion face model path empty"
            return ""
        path = Path(raw).expanduser()
        tmp_path = path.with_suffix(path.suffix + ".download")

        def _looks_like_lfs_pointer(model_path: Path) -> bool:
            try:
                head = model_path.read_bytes()[:256]
            except Exception:
                return False
            return b"git-lfs.github.com/spec/v1" in head

        def _is_valid_model(model_path: Path) -> bool:
            if not model_path.is_file():
                return False
            try:
                size = int(model_path.stat().st_size)
            except Exception:
                return False
            if size < int(YUNET_MODEL_MIN_BYTES):
                return False
            if _looks_like_lfs_pointer(model_path):
                return False
            return True

        if _is_valid_model(path):
            return str(path)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            self.emotion_face_detector_error = f"emotion face model mkdir failed: {exc}"
            return ""
        last_err = ""
        for url in YUNET_MODEL_URLS:
            try:
                urllib.request.urlretrieve(url, str(tmp_path))
            except Exception as exc:
                last_err = f"{url}: {exc}"
                continue
            if _is_valid_model(tmp_path):
                try:
                    tmp_path.replace(path)
                except Exception as exc:
                    self.emotion_face_detector_error = f"emotion face model move failed: {exc}"
                    return ""
                return str(path)
            if _looks_like_lfs_pointer(tmp_path):
                last_err = f"{url}: downloaded git-lfs pointer, not binary model"
            else:
                try:
                    size = int(tmp_path.stat().st_size)
                except Exception:
                    size = -1
                last_err = f"{url}: invalid model file size={size}"
        try:
            if tmp_path.is_file():
                tmp_path.unlink()
        except Exception:
            pass
        self.emotion_face_detector_error = f"emotion face model download failed: {last_err}"
        return ""

    def _load_emotion_rknn_labels(self) -> tuple[list[str], str]:
        labels: list[str] = []
        err = ""
        labels_file = str(self.emotion_rknn_labels_file or "").strip()
        if labels_file:
            path = Path(labels_file).expanduser()
            if not path.is_file():
                err = f"emotion rknn labels file not found: {path}"
            else:
                try:
                    labels = [
                        line.strip()
                        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines()
                        if line.strip()
                    ]
                except Exception as exc:
                    err = f"emotion rknn labels file read failed: {exc}"
        if not labels:
            raw = str(self.emotion_rknn_labels_raw or "").strip()
            if raw:
                labels = [item.strip() for item in re.split(r"[,\n;]", raw) if item.strip()]
        if not labels:
            labels = list(EMOTION_RKNN_DEFAULT_LABELS)
        return labels, err

    def _init_emotion_rknn_model(self) -> tuple[bool, str]:
        model_raw = str(self.emotion_rknn_model_path or "").strip()
        if not model_raw:
            return False, "emotion rknn model path empty"
        model_path = Path(model_raw).expanduser()
        if not model_path.is_file():
            return False, f"emotion rknn model not found: {model_path}"
        try:
            from rknnlite.api import RKNNLite  # type: ignore
        except Exception as exc:
            return False, f"rknnlite import failed: {exc}"
        labels, labels_err = self._load_emotion_rknn_labels()
        rknn = RKNNLite()
        try:
            ret = rknn.load_rknn(str(model_path))
        except Exception as exc:
            return False, f"emotion rknn load exception: {exc}"
        if ret != 0:
            return False, f"emotion rknn load failed: ret={ret}"
        init_kwargs: dict[str, Any] = {}
        core_mask = self._resolve_rknn_core_mask(RKNNLite, self.emotion_rknn_core)
        if core_mask is not None:
            init_kwargs["core_mask"] = core_mask
        try:
            ret = rknn.init_runtime(**init_kwargs)
        except Exception as exc:
            try:
                rknn.release()
            except Exception:
                pass
            return False, f"emotion rknn init exception: {exc}"
        if ret != 0:
            try:
                rknn.release()
            except Exception:
                pass
            return False, f"emotion rknn init failed: ret={ret}"
        self._release_emotion_rknn()
        with self.emotion_lock:
            self.emotion_rknn = rknn
            self.emotion_recognizer = None
            self.emotion_rknn_labels = list(labels)
            self.emotion_rknn_labels_error = labels_err or ""
        return True, ""

    def _init_emotion_face_detector_rknn(self) -> tuple[bool, str]:
        model_raw = str(self.emotion_face_rknn_model_path or "").strip()
        if not model_raw:
            return False, "emotion rknn face model path empty"
        model_path = Path(model_raw).expanduser()
        if not model_path.is_file():
            return False, f"emotion rknn face model not found: {model_path}"
        try:
            from rknnlite.api import RKNNLite  # type: ignore
        except Exception as exc:
            return False, f"rknnlite import failed: {exc}"
        rknn = RKNNLite()
        try:
            ret = rknn.load_rknn(str(model_path))
        except Exception as exc:
            return False, f"emotion rknn load exception: {exc}"
        if ret != 0:
            return False, f"emotion rknn load failed: ret={ret}"
        init_kwargs: dict[str, Any] = {}
        core_mask = self._resolve_rknn_core_mask(RKNNLite, self.emotion_face_rknn_core)
        if core_mask is not None:
            init_kwargs["core_mask"] = core_mask
        try:
            ret = rknn.init_runtime(**init_kwargs)
        except Exception as exc:
            try:
                rknn.release()
            except Exception:
                pass
            return False, f"emotion rknn init exception: {exc}"
        if ret != 0:
            try:
                rknn.release()
            except Exception:
                pass
            return False, f"emotion rknn init failed: ret={ret}"
        self._release_emotion_face_rknn()
        with self.emotion_lock:
            self.emotion_face_rknn = rknn
            self.emotion_face_detector_obj = None
            self.emotion_face_detector_active = "rknn"
            self.emotion_face_detector = "rknn"
            self.emotion_face_input_cached = (0, 0)
            self.emotion_face_detector_error = ""
        return True, ""

    def _init_emotion_face_detector_opencv(self, mode: str) -> tuple[bool, str]:
        if self.cv2 is None:
            return False, "opencv unavailable"
        use_mode = "haar" if str(mode or "").strip().lower() == "haar" else "yunet"
        cv2 = self.cv2
        try:
            if use_mode == "haar":
                haar_path = str(Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml")
                classifier = cv2.CascadeClassifier(haar_path)
                if classifier.empty():
                    return False, f"emotion haar load failed: {haar_path}"
                self._release_emotion_face_rknn()
                with self.emotion_lock:
                    self.emotion_face_detector_obj = classifier
                    self.emotion_haar_path = haar_path
                    self.emotion_face_detector_active = "haar"
                    self.emotion_face_detector = "haar"
                    self.emotion_face_detector_error = ""
                return True, ""

            if not hasattr(cv2, "FaceDetectorYN"):
                return False, "opencv FaceDetectorYN unavailable"
            model_path = self._ensure_yunet_model_file()
            if not model_path:
                return False, self.emotion_face_detector_error or "emotion face model unavailable"
            detector = cv2.FaceDetectorYN.create(
                model=model_path,
                config="",
                input_size=(int(self.emotion_face_input_size), int(self.emotion_face_input_size)),
                score_threshold=float(self.emotion_face_score),
                nms_threshold=float(self.emotion_face_nms),
                top_k=int(self.emotion_face_topk),
            )
            self._release_emotion_face_rknn()
            with self.emotion_lock:
                self.emotion_face_detector_obj = detector
                self.emotion_face_input_cached = (0, 0)
                self.emotion_face_model_path = model_path
                self.emotion_face_detector_active = "yunet"
                self.emotion_face_detector = "yunet"
                self.emotion_face_detector_error = ""
            return True, ""
        except Exception as exc:
            return False, f"emotion face detector init failed: {exc}"

    def _ensure_emotion_face_detector(self) -> tuple[bool, str]:
        requested = self._face_detector_requested_mode()
        if requested == "none":
            with self.emotion_lock:
                self.emotion_face_detector_active = "none"
                self.emotion_face_detector = "none"
            return False, "emotion face detector disabled"

        active_mode = self._face_detector_active_mode()
        with self.emotion_lock:
            opencv_ready = self.emotion_face_detector_obj is not None
            rknn_ready = self.emotion_face_rknn is not None
        if active_mode == "rknn" and rknn_ready and requested in ("auto", "rknn"):
            return True, ""
        if (
            active_mode in ("yunet", "haar")
            and opencv_ready
            and (requested == "auto" or requested == active_mode)
        ):
            return True, ""

        errors: list[str] = []
        if requested in ("rknn", "auto"):
            ok, err = self._init_emotion_face_detector_rknn()
            if ok:
                return True, ""
            if err:
                errors.append(err)
            if requested == "rknn":
                self.emotion_face_detector_error = err or "emotion face detector unavailable"
                with self.emotion_lock:
                    self.emotion_face_detector_active = "none"
                    self.emotion_face_detector = "none"
                return False, self.emotion_face_detector_error

        if requested in ("yunet", "auto"):
            ok, err = self._init_emotion_face_detector_opencv("yunet")
            if ok:
                return True, ""
            if err:
                errors.append(err)
            if requested == "yunet":
                self.emotion_face_detector_error = err or "emotion yunet detector unavailable"
                with self.emotion_lock:
                    self.emotion_face_detector_active = "none"
                    self.emotion_face_detector = "none"
                return False, self.emotion_face_detector_error

        if requested in ("haar", "auto"):
            ok, err = self._init_emotion_face_detector_opencv("haar")
            if ok:
                return True, ""
            if err:
                errors.append(err)
            if requested == "haar":
                self.emotion_face_detector_error = err or "emotion haar detector unavailable"
                with self.emotion_lock:
                    self.emotion_face_detector_active = "none"
                    self.emotion_face_detector = "none"
                return False, self.emotion_face_detector_error

        final_err = "; ".join([e for e in errors if e]) or "emotion face detector unavailable"
        self.emotion_face_detector_error = final_err
        with self.emotion_lock:
            self.emotion_face_detector_active = "none"
            self.emotion_face_detector = "none"
        return False, final_err

    @staticmethod
    def _expand_bbox_xyxy(
        bbox_xyxy: list[int], frame_w: int, frame_h: int, scale: float
    ) -> list[int] | None:
        if not isinstance(bbox_xyxy, list) or len(bbox_xyxy) != 4:
            return None
        x1, y1, x2, y2 = [int(v) for v in bbox_xyxy]
        if x2 <= x1 or y2 <= y1:
            return None
        cx = (x1 + x2) * 0.5
        cy = (y1 + y2) * 0.5
        w = max(1.0, float(x2 - x1) * float(scale))
        h = max(1.0, float(y2 - y1) * float(scale))
        nx1 = int(round(cx - w * 0.5))
        ny1 = int(round(cy - h * 0.5))
        nx2 = int(round(cx + w * 0.5))
        ny2 = int(round(cy + h * 0.5))
        nx1 = max(0, min(frame_w - 1, nx1))
        ny1 = max(0, min(frame_h - 1, ny1))
        nx2 = max(0, min(frame_w - 1, nx2))
        ny2 = max(0, min(frame_h - 1, ny2))
        if nx2 <= nx1 or ny2 <= ny1:
            return None
        return [nx1, ny1, nx2, ny2]

    def _postprocess_face_rknn_preds(
        self, preds: np.ndarray, mode: str, frame_w: int, frame_h: int
    ) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None:
            return [], "opencv unavailable"
        if preds.size == 0:
            return [], ""
        if preds.ndim != 2 or preds.shape[1] < 6:
            return [], "emotion rknn face output shape unsupported"

        rows = preds.astype(np.float32, copy=False)
        if mode == "xyxy":
            cls_ids = np.rint(rows[:, 5]).astype(np.int32)
            scores_arr = rows[:, 4]
            boxes_in = rows[:, :4]
        else:
            boxes_xywh_in = rows[:, :4]
            class_scores = rows[:, 4:] if mode == "no_objectness" else rows[:, 5:]
            if class_scores.size == 0:
                return [], "emotion rknn face class scores empty"
            cls_ids = np.argmax(class_scores, axis=1).astype(np.int32)
            cls_prob = class_scores[np.arange(class_scores.shape[0]), cls_ids]
            if mode == "no_objectness":
                scores_arr = cls_prob.astype(np.float32, copy=False)
            else:
                scores_arr = (rows[:, 4] * cls_prob).astype(np.float32, copy=False)
            boxes_in = np.empty((boxes_xywh_in.shape[0], 4), dtype=np.float32)
            boxes_in[:, 0] = boxes_xywh_in[:, 0] - boxes_xywh_in[:, 2] * 0.5
            boxes_in[:, 1] = boxes_xywh_in[:, 1] - boxes_xywh_in[:, 3] * 0.5
            boxes_in[:, 2] = boxes_xywh_in[:, 0] + boxes_xywh_in[:, 2] * 0.5
            boxes_in[:, 3] = boxes_xywh_in[:, 1] + boxes_xywh_in[:, 3] * 0.5

        keep_mask = scores_arr >= float(self.emotion_face_rknn_conf)
        class_id = int(self.emotion_face_rknn_class_id)
        if class_id >= 0:
            keep_mask = np.logical_and(keep_mask, cls_ids == class_id)
        if not np.any(keep_mask):
            return [], ""

        boxes = boxes_in[keep_mask]
        scores_arr = scores_arr[keep_mask]
        max_abs = float(np.max(np.abs(boxes))) if boxes.size else 0.0
        if max_abs <= 1.5:
            boxes[:, 0] *= float(frame_w)
            boxes[:, 2] *= float(frame_w)
            boxes[:, 1] *= float(frame_h)
            boxes[:, 3] *= float(frame_h)
        else:
            sx = float(frame_w) / float(self.emotion_face_rknn_input)
            sy = float(frame_h) / float(self.emotion_face_rknn_input)
            boxes[:, 0] *= sx
            boxes[:, 2] *= sx
            boxes[:, 1] *= sy
            boxes[:, 3] *= sy

        x1 = np.clip(np.rint(np.minimum(boxes[:, 0], boxes[:, 2])), 0, max(0, frame_w - 1)).astype(
            np.int32
        )
        y1 = np.clip(np.rint(np.minimum(boxes[:, 1], boxes[:, 3])), 0, max(0, frame_h - 1)).astype(
            np.int32
        )
        x2 = np.clip(np.rint(np.maximum(boxes[:, 0], boxes[:, 2])), 0, max(0, frame_w - 1)).astype(
            np.int32
        )
        y2 = np.clip(np.rint(np.maximum(boxes[:, 1], boxes[:, 3])), 0, max(0, frame_h - 1)).astype(
            np.int32
        )

        bw = np.maximum(0, x2 - x1)
        bh = np.maximum(0, y2 - y1)
        min_side = int(max(8, self.emotion_face_min_size))
        valid = np.logical_and(bw >= min_side, bh >= min_side)
        if not np.any(valid):
            return [], ""

        x1 = x1[valid]
        y1 = y1[valid]
        x2 = x2[valid]
        y2 = y2[valid]
        bw = bw[valid]
        bh = bh[valid]
        scores = scores_arr[valid].astype(np.float32).tolist()
        boxes_xywh = np.stack([x1, y1, bw, bh], axis=1).tolist()
        keep = self.cv2.dnn.NMSBoxes(
            bboxes=boxes_xywh,
            scores=scores,
            score_threshold=float(self.emotion_face_rknn_conf),
            nms_threshold=float(self.emotion_face_rknn_nms),
        )
        if keep is None or len(keep) == 0:
            return [], ""
        out: list[dict[str, Any]] = []
        for idx in np.array(keep).reshape(-1).tolist():
            i = int(idx)
            out.append(
                {
                    "bbox_xyxy": [int(x1[i]), int(y1[i]), int(x2[i]), int(y2[i])],
                    "score": float(scores[i]),
                }
            )
        out.sort(key=lambda d: float(d.get("score", 0.0)), reverse=True)
        if self.emotion_face_topk > 0:
            out = out[: int(self.emotion_face_topk)]
        return out, ""

    @staticmethod
    def _reshape_face_rknn_tensor(raw: Any, channels: int) -> np.ndarray | None:
        arr = np.asarray(raw, dtype=np.float32)
        if arr.size == 0:
            return None
        arr = np.squeeze(arr)
        if arr.ndim == 0:
            return None
        if arr.ndim == 1:
            if channels != 1:
                return None
            return arr.reshape(-1, 1).astype(np.float32, copy=False)
        if arr.ndim == 2:
            if arr.shape[1] == channels:
                return arr.astype(np.float32, copy=False)
            if arr.shape[0] == channels:
                return arr.T.astype(np.float32, copy=False)
            return None
        if arr.shape[-1] == channels:
            return arr.reshape(-1, channels).astype(np.float32, copy=False)
        if arr.shape[0] == channels:
            moved = np.moveaxis(arr, 0, -1)
            return moved.reshape(-1, channels).astype(np.float32, copy=False)
        return None

    @staticmethod
    def _retinaface_prior_box(input_size: int) -> np.ndarray:
        # Match Rockchip RetinaFace demo anchors for 320/640 fixed-size inputs.
        anchors: list[list[float]] = []
        min_sizes = ((16, 32), (64, 128), (256, 512))
        steps = (8, 16, 32)
        input_h = int(input_size)
        input_w = int(input_size)
        for level, step in enumerate(steps):
            feat_h = int(np.ceil(float(input_h) / float(step)))
            feat_w = int(np.ceil(float(input_w) / float(step)))
            for i in range(feat_h):
                cy = (float(i) + 0.5) * float(step) / float(input_h)
                for j in range(feat_w):
                    cx = (float(j) + 0.5) * float(step) / float(input_w)
                    for min_size in min_sizes[level]:
                        s_kx = float(min_size) / float(input_w)
                        s_ky = float(min_size) / float(input_h)
                        anchors.append([cx, cy, s_kx, s_ky])
        return np.asarray(anchors, dtype=np.float32)

    def _retinaface_priors_for_count(
        self, num_priors: int, preferred_input: int
    ) -> tuple[np.ndarray | None, int]:
        if num_priors <= 0:
            return None, int(preferred_input)
        candidates = [int(preferred_input), 320, 640]
        deduped: list[int] = []
        for val in candidates:
            if val not in deduped and val > 0:
                deduped.append(val)
        for input_size in deduped:
            cached = self.retinaface_priors_cache.get(input_size)
            if cached is None:
                cached = self._retinaface_prior_box(input_size)
                self.retinaface_priors_cache[input_size] = cached
            if int(cached.shape[0]) == int(num_priors):
                return cached, int(input_size)
        return None, int(preferred_input)

    @staticmethod
    def _normalize_retinaface_tensor(raw: Any) -> np.ndarray | None:
        arr = np.asarray(raw, dtype=np.float32)
        if arr.size == 0:
            return None
        arr = np.squeeze(arr)
        if arr.ndim == 0:
            return None
        if arr.ndim == 1:
            return None
        if arr.ndim == 3 and arr.shape[0] == 1:
            arr = arr[0]
        if arr.ndim != 2:
            return None
        if arr.shape[1] in (1, 2, 4, 10):
            return arr.astype(np.float32, copy=False)
        if arr.shape[0] in (1, 2, 4, 10):
            return arr.T.astype(np.float32, copy=False)
        return None

    def _decode_face_rknn_retinaface_outputs(
        self,
        tensors: list[Any],
        frame_w: int,
        frame_h: int,
        input_size: int,
        ratio: float,
        dw: float,
        dh: float,
    ) -> tuple[list[dict[str, Any]], str, bool]:
        if self.cv2 is None:
            return [], "opencv unavailable", False
        if len(tensors) < 3:
            return [], "", False

        norm = [self._normalize_retinaface_tensor(t) for t in tensors]
        norm = [t for t in norm if t is not None]
        if len(norm) < 3:
            return [], "", False

        loc_candidates = [t for t in norm if int(t.shape[1]) == 4]
        conf_candidates = [t for t in norm if int(t.shape[1]) in (1, 2)]
        landm_candidates = [t for t in norm if int(t.shape[1]) == 10]
        if not loc_candidates or not conf_candidates or not landm_candidates:
            return [], "emotion rknn retinaface outputs missing loc/conf/landm", True

        loc: np.ndarray | None = None
        conf: np.ndarray | None = None
        landm: np.ndarray | None = None
        for loc_arr in loc_candidates:
            n = int(loc_arr.shape[0])
            conf_arr = next((x for x in conf_candidates if int(x.shape[0]) == n), None)
            landm_arr = next((x for x in landm_candidates if int(x.shape[0]) == n), None)
            if conf_arr is not None and landm_arr is not None:
                loc, conf, landm = loc_arr, conf_arr, landm_arr
                break
        if loc is None or conf is None or landm is None:
            return [], "emotion rknn retinaface output length mismatch", True

        priors, priors_input = self._retinaface_priors_for_count(
            num_priors=int(loc.shape[0]),
            preferred_input=int(input_size),
        )
        if priors is None:
            return [], "emotion rknn retinaface prior count mismatch", True

        variances = (0.1, 0.2)
        loc_arr = loc.astype(np.float32, copy=False)
        priors_arr = priors.astype(np.float32, copy=False)
        conf_arr = conf.astype(np.float32, copy=False)
        landm_arr = landm.astype(np.float32, copy=False)

        boxes = np.concatenate(
            (
                priors_arr[:, :2] + loc_arr[:, :2] * variances[0] * priors_arr[:, 2:],
                priors_arr[:, 2:] * np.exp(np.clip(loc_arr[:, 2:], -16.0, 16.0) * variances[1]),
            ),
            axis=1,
        )
        boxes[:, :2] -= boxes[:, 2:] * 0.5
        boxes[:, 2:] += boxes[:, :2]

        landmarks = np.concatenate(
            (
                priors_arr[:, :2] + landm_arr[:, 0:2] * variances[0] * priors_arr[:, 2:],
                priors_arr[:, :2] + landm_arr[:, 2:4] * variances[0] * priors_arr[:, 2:],
                priors_arr[:, :2] + landm_arr[:, 4:6] * variances[0] * priors_arr[:, 2:],
                priors_arr[:, :2] + landm_arr[:, 6:8] * variances[0] * priors_arr[:, 2:],
                priors_arr[:, :2] + landm_arr[:, 8:10] * variances[0] * priors_arr[:, 2:],
            ),
            axis=1,
        ).reshape(-1, 5, 2)

        if conf_arr.shape[1] >= 2:
            scores = conf_arr[:, 1]
        else:
            scores = conf_arr[:, 0]

        conf_thr = float(self.emotion_face_rknn_conf)
        keep = np.nonzero(scores >= conf_thr)[0]
        if keep.size == 0:
            return [], "", True
        boxes = boxes[keep]
        landmarks = landmarks[keep]
        scores = scores[keep]

        order = scores.argsort()[::-1]
        boxes = boxes[order]
        landmarks = landmarks[order]
        scores = scores[order]

        scale = float(priors_input)
        boxes *= scale
        landmarks *= scale

        inv_ratio = 1.0 / max(1e-6, float(ratio))
        boxes[:, 0::2] = (boxes[:, 0::2] - float(dw)) * inv_ratio
        boxes[:, 1::2] = (boxes[:, 1::2] - float(dh)) * inv_ratio
        landmarks[:, :, 0] = (landmarks[:, :, 0] - float(dw)) * inv_ratio
        landmarks[:, :, 1] = (landmarks[:, :, 1] - float(dh)) * inv_ratio

        x1 = np.clip(np.rint(np.minimum(boxes[:, 0], boxes[:, 2])), 0, max(0, frame_w - 1)).astype(
            np.int32
        )
        y1 = np.clip(np.rint(np.minimum(boxes[:, 1], boxes[:, 3])), 0, max(0, frame_h - 1)).astype(
            np.int32
        )
        x2 = np.clip(np.rint(np.maximum(boxes[:, 0], boxes[:, 2])), 0, max(0, frame_w - 1)).astype(
            np.int32
        )
        y2 = np.clip(np.rint(np.maximum(boxes[:, 1], boxes[:, 3])), 0, max(0, frame_h - 1)).astype(
            np.int32
        )
        bw = np.maximum(0, x2 - x1).astype(np.int32)
        bh = np.maximum(0, y2 - y1).astype(np.int32)
        min_side = int(max(8, self.emotion_face_min_size))
        valid = np.logical_and(bw >= min_side, bh >= min_side)
        if not np.any(valid):
            return [], "", True

        x1 = x1[valid]
        y1 = y1[valid]
        x2 = x2[valid]
        y2 = y2[valid]
        bw = bw[valid]
        bh = bh[valid]
        scores = scores[valid].astype(np.float32)
        landmarks = landmarks[valid]

        boxes_xywh = np.stack([x1, y1, bw, bh], axis=1).tolist()
        score_list = scores.tolist()
        keep_idx = self.cv2.dnn.NMSBoxes(
            bboxes=boxes_xywh,
            scores=score_list,
            score_threshold=conf_thr,
            nms_threshold=float(self.emotion_face_rknn_nms),
        )
        if keep_idx is None or len(keep_idx) == 0:
            return [], "", True

        out: list[dict[str, Any]] = []
        max_w = max(0, frame_w - 1)
        max_h = max(0, frame_h - 1)
        for idx in np.asarray(keep_idx).reshape(-1).tolist():
            i = int(idx)
            lm = landmarks[i]
            lm_xy = np.stack(
                [
                    np.clip(np.rint(lm[:, 0]), 0, max_w).astype(np.int32),
                    np.clip(np.rint(lm[:, 1]), 0, max_h).astype(np.int32),
                ],
                axis=1,
            ).tolist()
            out.append(
                {
                    "bbox_xyxy": [int(x1[i]), int(y1[i]), int(x2[i]), int(y2[i])],
                    "score": float(score_list[i]),
                    "landmarks_xy": lm_xy,
                }
            )

        out.sort(key=lambda d: float(d.get("score", 0.0)), reverse=True)
        if self.emotion_face_topk > 0:
            out = out[: int(self.emotion_face_topk)]
        return out, "", True

    def _decode_face_rknn_yunet_outputs(
        self, tensors: list[Any], frame_w: int, frame_h: int
    ) -> tuple[list[dict[str, Any]], str, bool]:
        if self.cv2 is None:
            return [], "opencv unavailable", False
        if len(tensors) < 12:
            return [], "", False

        cls_list = tensors[0:3]
        obj_list = tensors[3:6]
        bbox_list = tensors[6:9]
        kps_list = tensors[9:12]

        input_size = int(max(64, self.emotion_face_rknn_input))
        min_side = int(max(8, self.emotion_face_min_size))
        sx = float(frame_w) / float(input_size)
        sy = float(frame_h) / float(input_size)
        conf = float(self.emotion_face_rknn_conf)
        nms = float(self.emotion_face_rknn_nms)

        score_parts: list[np.ndarray] = []
        box_xywh_parts: list[np.ndarray] = []
        box_xyxy_parts: list[np.ndarray] = []
        landmarks_parts: list[np.ndarray] = []
        max_w = max(0, frame_w - 1)
        max_h = max(0, frame_h - 1)

        for i in range(3):
            cls = self._reshape_face_rknn_tensor(cls_list[i], 1)
            obj = self._reshape_face_rknn_tensor(obj_list[i], 1)
            bbox = self._reshape_face_rknn_tensor(bbox_list[i], 4)
            kps = self._reshape_face_rknn_tensor(kps_list[i], 10)
            if cls is None or obj is None or bbox is None or kps is None:
                return [], "emotion rknn yunet output shape unsupported", False
            if cls.shape[0] == 0:
                continue
            if (
                obj.shape[0] != cls.shape[0]
                or bbox.shape[0] != cls.shape[0]
                or kps.shape[0] != cls.shape[0]
            ):
                return [], "emotion rknn yunet output length mismatch", False

            count = int(cls.shape[0])
            cols = int(round(np.sqrt(float(count))))
            if cols <= 0 or cols * cols != count:
                return [], "emotion rknn yunet grid shape unsupported", False
            stride_f = float(input_size) / float(cols)
            stride = int(round(stride_f))
            if stride <= 0 or abs(float(stride) - stride_f) > 1e-3:
                return [], "emotion rknn yunet stride unsupported", False

            cls_arr = np.clip(cls[:, 0], 0.0, 1.0)
            obj_arr = np.clip(obj[:, 0], 0.0, 1.0)
            score_arr = np.sqrt(cls_arr * obj_arr)
            keep_idx = np.nonzero(score_arr >= conf)[0]
            if keep_idx.size == 0:
                continue

            c = (keep_idx % cols).astype(np.float32)
            r = (keep_idx // cols).astype(np.float32)
            bbox_keep = bbox[keep_idx]
            score_keep = score_arr[keep_idx].astype(np.float32, copy=False)

            cx = (c + bbox_keep[:, 0]) * float(stride)
            cy = (r + bbox_keep[:, 1]) * float(stride)
            bw = np.exp(np.clip(bbox_keep[:, 2], -16.0, 16.0)) * float(stride)
            bh = np.exp(np.clip(bbox_keep[:, 3], -16.0, 16.0)) * float(stride)

            x1 = cx - bw * 0.5
            y1 = cy - bh * 0.5
            x2 = cx + bw * 0.5
            y2 = cy + bh * 0.5

            fx1 = np.clip(np.rint(x1 * sx), 0, max_w).astype(np.int32)
            fy1 = np.clip(np.rint(y1 * sy), 0, max_h).astype(np.int32)
            fx2 = np.clip(np.rint(x2 * sx), 0, max_w).astype(np.int32)
            fy2 = np.clip(np.rint(y2 * sy), 0, max_h).astype(np.int32)
            bw_i = np.maximum(0, fx2 - fx1).astype(np.int32)
            bh_i = np.maximum(0, fy2 - fy1).astype(np.int32)
            valid = np.logical_and(bw_i >= min_side, bh_i >= min_side)
            if not np.any(valid):
                continue

            fx1 = fx1[valid]
            fy1 = fy1[valid]
            fx2 = fx2[valid]
            fy2 = fy2[valid]
            bw_i = bw_i[valid]
            bh_i = bh_i[valid]
            score_keep = score_keep[valid]
            c = c[valid]
            r = r[valid]

            box_xywh_parts.append(np.stack([fx1, fy1, bw_i, bh_i], axis=1))
            box_xyxy_parts.append(np.stack([fx1, fy1, fx2, fy2], axis=1))
            score_parts.append(score_keep)

            kps_keep = kps[keep_idx][valid].reshape(-1, 5, 2).astype(np.float32, copy=False)
            lm_x = (kps_keep[:, :, 0] + c[:, None]) * float(stride) * sx
            lm_y = (kps_keep[:, :, 1] + r[:, None]) * float(stride) * sy
            lm_xy = np.stack(
                [
                    np.clip(np.rint(lm_x), 0, max_w).astype(np.int32),
                    np.clip(np.rint(lm_y), 0, max_h).astype(np.int32),
                ],
                axis=2,
            )
            landmarks_parts.append(lm_xy)

        if not box_xywh_parts:
            return [], "", True

        boxes_xywh_arr = np.concatenate(box_xywh_parts, axis=0)
        boxes_xyxy_arr = np.concatenate(box_xyxy_parts, axis=0)
        scores_arr = np.concatenate(score_parts, axis=0)
        landmarks_arr = np.concatenate(landmarks_parts, axis=0)
        boxes_xywh = boxes_xywh_arr.tolist()
        scores = scores_arr.astype(np.float32).tolist()

        keep = self.cv2.dnn.NMSBoxes(
            bboxes=boxes_xywh,
            scores=scores,
            score_threshold=conf,
            nms_threshold=nms,
        )
        if keep is None or len(keep) == 0:
            return [], "", True

        out: list[dict[str, Any]] = []
        for idx in np.asarray(keep).reshape(-1).tolist():
            i = int(idx)
            row: dict[str, Any] = {
                "bbox_xyxy": [int(v) for v in boxes_xyxy_arr[i].tolist()],
                "score": float(scores[i]),
            }
            if i < landmarks_arr.shape[0]:
                row["landmarks_xy"] = landmarks_arr[i].tolist()
            out.append(row)

        out.sort(key=lambda d: float(d.get("score", 0.0)), reverse=True)
        if self.emotion_face_topk > 0:
            out = out[: int(self.emotion_face_topk)]
        return out, "", True

    def _detect_faces_rknn(self, frame: Any) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None or frame is None:
            return [], "opencv unavailable"
        with self.emotion_lock:
            rknn = self.emotion_face_rknn
        if rknn is None:
            return [], "emotion rknn detector unavailable"

        h, w = frame.shape[:2]
        input_size = int(max(64, self.emotion_face_rknn_input))
        face_type = str(self.emotion_face_rknn_type or "auto").strip().lower()

        img_bgr = frame
        if img_bgr.shape[1] != input_size or img_bgr.shape[0] != input_size:
            img_bgr = self.cv2.resize(
                img_bgr, (input_size, input_size), interpolation=self.cv2.INTER_LINEAR
            )
        img_rgb = self.cv2.cvtColor(img_bgr, self.cv2.COLOR_BGR2RGB)
        retina_bgr, retina_ratio, (retina_dw, retina_dh) = self._letter_box(
            frame, new_shape=input_size, pad_color=(114, 114, 114)
        )
        retina_rgb = self.cv2.cvtColor(retina_bgr, self.cv2.COLOR_BGR2RGB)

        # Try model-specific inputs first, then generic fallback when in auto mode.
        attempts: list[tuple[str, np.ndarray, list[str] | None, dict[str, Any]]] = []
        if face_type in ("auto", "yunet"):
            img_nhwc_bgr = np.expand_dims(img_bgr, axis=0).astype(np.uint8, copy=False)
            attempts.append(("yunet", img_nhwc_bgr, ["nhwc"], {}))
        if face_type in ("auto", "yolo"):
            img_nhwc = np.expand_dims(img_rgb, axis=0).astype(np.uint8, copy=False)
            attempts.append(("yolo", img_nhwc, ["nhwc"], {}))
        if face_type in ("auto", "retinaface"):
            img_nhwc_retina = np.expand_dims(retina_rgb, axis=0).astype(np.uint8, copy=False)
            attempts.append(
                (
                    "retinaface",
                    img_nhwc_retina,
                    ["nhwc"],
                    {
                        "ratio": float(retina_ratio),
                        "dw": float(retina_dw),
                        "dh": float(retina_dh),
                        "input_size": int(input_size),
                    },
                )
            )

        errors: list[str] = []
        for mode, img_in, data_format, extra in attempts:
            try:
                if data_format is None:
                    outputs = rknn.inference(inputs=[img_in])
                else:
                    outputs = rknn.inference(inputs=[img_in], data_format=data_format)
            except TypeError:
                try:
                    outputs = rknn.inference(inputs=[img_in])
                except Exception as exc:
                    errors.append(f"emotion rknn {mode} inference failed: {exc}")
                    continue
            except Exception as exc:
                errors.append(f"emotion rknn {mode} inference failed: {exc}")
                continue

            if outputs is None:
                errors.append(f"emotion rknn {mode} inference returned no outputs")
                continue
            tensors = list(outputs) if isinstance(outputs, (list, tuple)) else [outputs]

            if mode == "yunet":
                faces, err, matched = self._decode_face_rknn_yunet_outputs(
                    tensors=tensors,
                    frame_w=w,
                    frame_h=h,
                )
                if matched:
                    if err:
                        errors.append(err)
                    else:
                        return faces, ""
                    if face_type == "yunet":
                        break
                    continue

            if mode == "retinaface":
                faces, err, matched = self._decode_face_rknn_retinaface_outputs(
                    tensors=tensors,
                    frame_w=w,
                    frame_h=h,
                    input_size=int(extra.get("input_size") or input_size),
                    ratio=float(extra.get("ratio") or 1.0),
                    dw=float(extra.get("dw") or 0.0),
                    dh=float(extra.get("dh") or 0.0),
                )
                if matched:
                    if err:
                        errors.append(err)
                    else:
                        return faces, ""
                    if face_type == "retinaface":
                        break
                    continue

            best_err = "emotion rknn face output unsupported"
            for tensor in tensors:
                preds, decode_mode = self._normalize_yolo_output(tensor)
                if preds.size == 0:
                    continue
                faces, err = self._postprocess_face_rknn_preds(
                    preds=preds,
                    mode=decode_mode,
                    frame_w=w,
                    frame_h=h,
                )
                if err:
                    best_err = err
                    continue
                return faces, ""
            errors.append(best_err)

        final_err = "; ".join([e for e in errors if e]) or "emotion rknn face output unsupported"
        return [], final_err

    def _detect_faces(self, frame: Any) -> tuple[list[dict[str, Any]], str]:
        if self.cv2 is None or frame is None:
            return [], "opencv unavailable"
        if not self._face_detector_requested_enabled():
            return [], "emotion face detector disabled"
        ready, ready_err = self._ensure_emotion_face_detector()
        if not ready:
            return [], ready_err or "emotion face detector unavailable"

        mode = self._face_detector_active_mode()
        if mode == "rknn":
            return self._detect_faces_rknn(frame)

        h, w = frame.shape[:2]
        min_side = int(max(8, self.emotion_face_min_size))
        if mode == "haar":
            with self.emotion_lock:
                classifier = self.emotion_face_detector_obj
            if classifier is None:
                return [], "emotion haar detector unavailable"
            try:
                gray = self.cv2.cvtColor(frame, self.cv2.COLOR_BGR2GRAY)
                raw = classifier.detectMultiScale(
                    gray,
                    scaleFactor=1.1,
                    minNeighbors=4,
                    minSize=(min_side, min_side),
                )
            except Exception as exc:
                return [], f"emotion haar detect failed: {exc}"
            faces: list[dict[str, Any]] = []
            for row in raw:
                x, y, bw, bh = [int(v) for v in row[:4]]
                if bw < min_side or bh < min_side:
                    continue
                x1 = max(0, min(w - 1, x))
                y1 = max(0, min(h - 1, y))
                x2 = max(0, min(w - 1, x + bw))
                y2 = max(0, min(h - 1, y + bh))
                if x2 <= x1 or y2 <= y1:
                    continue
                faces.append(
                    {
                        "bbox_xyxy": [x1, y1, x2, y2],
                        "score": 0.5,
                    }
                )
            faces.sort(key=lambda d: float(d.get("score", 0.0)), reverse=True)
            if self.emotion_face_topk > 0:
                faces = faces[: int(self.emotion_face_topk)]
            return faces, ""

        with self.emotion_lock:
            detector = self.emotion_face_detector_obj
        if detector is None:
            return [], "emotion yunet detector unavailable"
        try:
            with self.emotion_lock:
                if self.emotion_face_input_cached != (int(w), int(h)):
                    detector.setInputSize((int(w), int(h)))
                    self.emotion_face_input_cached = (int(w), int(h))
            _, raw_faces = detector.detect(frame)
        except Exception as exc:
            return [], f"emotion yunet detect failed: {exc}"
        if raw_faces is None or len(raw_faces) == 0:
            return [], ""
        out: list[dict[str, Any]] = []
        for row in np.asarray(raw_faces):
            if row.shape[0] < 5:
                continue
            x, y, bw, bh = [float(v) for v in row[:4]]
            score = float(row[-1])
            if score < float(self.emotion_face_score):
                continue
            if bw < min_side or bh < min_side:
                continue
            x1 = max(0, min(w - 1, int(round(x))))
            y1 = max(0, min(h - 1, int(round(y))))
            x2 = max(0, min(w - 1, int(round(x + bw))))
            y2 = max(0, min(h - 1, int(round(y + bh))))
            if x2 <= x1 or y2 <= y1:
                continue
            out.append(
                {
                    "bbox_xyxy": [x1, y1, x2, y2],
                    "score": score,
                    "landmarks_xy": [
                        [int(round(float(row[4]))), int(round(float(row[5])))],
                        [int(round(float(row[6]))), int(round(float(row[7])))],
                        [int(round(float(row[8]))), int(round(float(row[9])))],
                        [int(round(float(row[10]))), int(round(float(row[11])))],
                        [int(round(float(row[12]))), int(round(float(row[13])))],
                    ]
                    if row.shape[0] >= 14
                    else None,
                }
            )
        out.sort(key=lambda d: float(d.get("score", 0.0)), reverse=True)
        if self.emotion_face_topk > 0:
            out = out[: int(self.emotion_face_topk)]
        return out, ""

    def _face_recognition_backend_candidates(self) -> list[tuple[int, int, str, str]]:
        if self.cv2 is None:
            return []
        dnn = getattr(self.cv2, "dnn", None)
        if dnn is None:
            return []
        opencv_backend = int(getattr(dnn, "DNN_BACKEND_OPENCV", 0))
        cpu_target = int(getattr(dnn, "DNN_TARGET_CPU", 0))
        timvx_backend = getattr(dnn, "DNN_BACKEND_TIMVX", None)
        npu_target = getattr(dnn, "DNN_TARGET_NPU", None)

        backend_req = str(self.face_recognition_backend_requested or "auto").strip().lower()
        target_req = str(self.face_recognition_target_requested or "auto").strip().lower()
        out: list[tuple[int, int, str, str]] = []

        def add(backend_id: Any, target_id: Any, backend_name: str, target_name: str) -> None:
            try:
                b_id = int(backend_id)
                t_id = int(target_id)
            except Exception:
                return
            item = (b_id, t_id, backend_name, target_name)
            if item not in out:
                out.append(item)

        wants_timvx = backend_req in ("auto", "timvx", "npu")
        wants_cpu = target_req in ("auto", "cpu", "")
        wants_npu = target_req in ("auto", "npu", "timvx")
        if wants_timvx and timvx_backend is not None:
            if wants_npu and npu_target is not None:
                add(timvx_backend, npu_target, "timvx", "npu")
            if wants_cpu:
                add(timvx_backend, cpu_target, "timvx", "cpu")
        if backend_req in ("auto", "opencv", "default", ""):
            add(opencv_backend, cpu_target, "opencv", "cpu")
        elif backend_req == "timvx" and not out:
            if wants_cpu:
                add(opencv_backend, cpu_target, "opencv", "cpu")
        return out

    @staticmethod
    def _normalize_face_feature_vector(feature: Any) -> np.ndarray | None:
        try:
            arr = np.asarray(feature, dtype=np.float32).reshape(-1)
        except Exception:
            return None
        if arr.size == 0:
            return None
        norm = float(np.linalg.norm(arr))
        if norm <= 1e-9:
            return None
        return (arr / norm).astype(np.float32, copy=False)

    def _build_face_recognition_row(self, face: dict[str, Any]) -> np.ndarray | None:
        bbox = self._normalize_bbox_xyxy(face.get("bbox_xyxy"))
        landmarks = self._normalize_face_landmarks_xy(face.get("landmarks_xy"))
        if landmarks is None:
            attrs = face.get("attributes")
            if isinstance(attrs, dict):
                landmarks = self._normalize_face_landmarks_xy(attrs.get("face_landmarks_xy"))
        if bbox is None or landmarks is None:
            return None
        x1, y1, x2, y2 = [int(v) for v in bbox]
        bw = int(x2 - x1)
        bh = int(y2 - y1)
        if bw < int(self.face_recognition_min_face_size) or bh < int(self.face_recognition_min_face_size):
            return None
        score = float(face.get("score") or 0.0)
        if score < float(self.face_recognition_min_score):
            return None
        row = [
            float(x1),
            float(y1),
            float(bw),
            float(bh),
        ]
        for px, py in landmarks:
            row.append(float(px))
            row.append(float(py))
        row.append(score)
        return np.asarray(row, dtype=np.float32)

    def _extract_face_feature(self, frame: Any, face: dict[str, Any]) -> tuple[np.ndarray | None, str]:
        if self.cv2 is None or frame is None:
            return None, "opencv unavailable"
        recognizer = self.face_recognizer
        if recognizer is None:
            return None, "face recognizer unavailable"
        face_row = self._build_face_recognition_row(face)
        if face_row is None:
            return None, "face recognition requires 5-point landmarks and valid face size"
        try:
            aligned = recognizer.alignCrop(frame, face_row)
        except Exception as exc:
            return None, f"face align failed: {exc}"
        if aligned is None:
            return None, "face align returned no image"
        try:
            feature = recognizer.feature(aligned)
        except Exception as exc:
            return None, f"face feature extraction failed: {exc}"
        norm = self._normalize_face_feature_vector(feature)
        if norm is None:
            return None, "face feature normalization failed"
        return norm, ""

    def _face_recognition_pose_gate(self, face: dict[str, Any]) -> tuple[bool, list[str]]:
        attrs = face.get("attributes")
        if not isinstance(attrs, dict):
            return True, []
        reasons: list[str] = []
        try:
            yaw_deg = abs(float(attrs.get("face_yaw_deg")))
        except Exception:
            yaw_deg = None
        try:
            pitch_deg = abs(float(attrs.get("face_pitch_deg")))
        except Exception:
            pitch_deg = None
        try:
            roll_deg = abs(float(attrs.get("face_roll_deg")))
        except Exception:
            roll_deg = None
        if yaw_deg is not None and yaw_deg > float(self.face_recognition_max_yaw_deg):
            reasons.append(
                f"yaw {yaw_deg:.2f}>{float(self.face_recognition_max_yaw_deg):.2f}"
            )
        if pitch_deg is not None and pitch_deg > float(self.face_recognition_max_pitch_deg):
            reasons.append(
                f"pitch {pitch_deg:.2f}>{float(self.face_recognition_max_pitch_deg):.2f}"
            )
        if roll_deg is not None and roll_deg > float(self.face_recognition_max_roll_deg):
            reasons.append(
                f"roll {roll_deg:.2f}>{float(self.face_recognition_max_roll_deg):.2f}"
            )
        return len(reasons) == 0, reasons

    def _load_face_gallery(self) -> tuple[bool, str]:
        if self.cv2 is None:
            return False, "opencv unavailable"
        gallery_raw = str(self.face_recognition_gallery_dir or "").strip()
        if not gallery_raw:
            self.face_gallery_items = []
            self.face_gallery_identity_count = 0
            self.face_gallery_image_count = 0
            self.face_gallery_updated_ts = 0.0
            self.face_gallery_error = "gallery directory empty"
            return False, self.face_gallery_error
        gallery_dir = Path(gallery_raw)
        if not gallery_dir.exists():
            self.face_gallery_items = []
            self.face_gallery_identity_count = 0
            self.face_gallery_image_count = 0
            self.face_gallery_updated_ts = 0.0
            self.face_gallery_error = f"gallery directory not found: {gallery_dir}"
            return False, self.face_gallery_error

        allowed_ext = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
        items: list[dict[str, Any]] = []
        total_images = 0
        load_errors: list[str] = []
        for identity_dir in sorted(gallery_dir.iterdir(), key=lambda p: p.name.lower()):
            if not identity_dir.is_dir():
                continue
            samples: list[np.ndarray] = []
            sample_count = 0
            for img_path in sorted(identity_dir.rglob("*"), key=lambda p: str(p).lower()):
                if (not img_path.is_file()) or img_path.suffix.lower() not in allowed_ext:
                    continue
                sample_count += 1
                total_images += 1
                try:
                    frame = self.cv2.imread(str(img_path))
                except Exception as exc:
                    load_errors.append(f"{identity_dir.name}/{img_path.name}: imread failed: {exc}")
                    continue
                if frame is None or getattr(frame, "size", 0) == 0:
                    load_errors.append(f"{identity_dir.name}/{img_path.name}: image load failed")
                    continue
                faces, face_err = self._detect_faces(frame)
                if not faces:
                    load_errors.append(
                        f"{identity_dir.name}/{img_path.name}: {face_err or 'no face detected'}"
                    )
                    continue
                best_face = max(
                    faces,
                    key=lambda row: (
                        float(row.get("score") or 0.0),
                        float(
                            max(
                                1,
                                (
                                    (self._normalize_bbox_xyxy(row.get('bbox_xyxy')) or [0, 0, 1, 1])[2]
                                    - (self._normalize_bbox_xyxy(row.get('bbox_xyxy')) or [0, 0, 1, 1])[0]
                                )
                                * (
                                    (self._normalize_bbox_xyxy(row.get('bbox_xyxy')) or [0, 0, 1, 1])[3]
                                    - (self._normalize_bbox_xyxy(row.get('bbox_xyxy')) or [0, 0, 1, 1])[1]
                                ),
                            )
                        ),
                    ),
                )
                feature, feat_err = self._extract_face_feature(frame, best_face)
                if feature is None:
                    load_errors.append(
                        f"{identity_dir.name}/{img_path.name}: {feat_err or 'face feature unavailable'}"
                    )
                    continue
                samples.append(feature)
            if not samples:
                if sample_count > 0:
                    load_errors.append(f"{identity_dir.name}: no usable face samples")
                continue
            mean_feature = self._normalize_face_feature_vector(np.mean(np.stack(samples), axis=0))
            if mean_feature is None:
                load_errors.append(f"{identity_dir.name}: feature aggregation failed")
                continue
            items.append(
                {
                    "label": identity_dir.name,
                    "feature": mean_feature,
                    "sample_features": [np.asarray(item, dtype=np.float32) for item in samples],
                    "samples": int(len(samples)),
                }
            )

        self.face_gallery_items = items
        self.face_gallery_identity_count = int(len(items))
        self.face_gallery_image_count = int(total_images)
        self.face_gallery_updated_ts = time.time()
        self.face_gallery_error = "; ".join(load_errors[:6]) if load_errors else ""
        if not items:
            err = self.face_gallery_error or "face gallery empty"
            self.face_gallery_error = err
            return False, err
        return True, self.face_gallery_error

    def _ensure_face_recognition(self, reload_gallery: bool = False) -> tuple[bool, str]:
        if not bool(self.face_recognition_enabled):
            self.face_recognition_ready = False
            self.face_recognition_error = "face recognition disabled by config"
            return False, self.face_recognition_error
        if self.cv2 is None:
            self.face_recognition_ready = False
            self.face_recognition_error = "opencv unavailable"
            return False, self.face_recognition_error
        model_path = str(self.face_recognition_model_path or "").strip()
        if not model_path:
            self.face_recognition_ready = False
            self.face_recognition_error = "face recognition model path empty"
            return False, self.face_recognition_error
        path_obj = Path(model_path)
        if not path_obj.exists():
            self.face_recognition_ready = False
            self.face_recognition_error = f"face recognition model not found: {path_obj}"
            return False, self.face_recognition_error

        with self.face_recognition_lock:
            if self.face_recognizer is None:
                errors: list[str] = []
                for backend_id, target_id, backend_name, target_name in (
                    self._face_recognition_backend_candidates()
                ):
                    try:
                        recognizer = self.cv2.FaceRecognizerSF.create(
                            str(path_obj),
                            "",
                            int(backend_id),
                            int(target_id),
                        )
                    except Exception as exc:
                        errors.append(f"{backend_name}/{target_name}: {exc}")
                        continue
                    self.face_recognizer = recognizer
                    self.face_recognition_backend_active = backend_name
                    self.face_recognition_target_active = target_name
                    self.face_recognition_error = ""
                    break
                if self.face_recognizer is None:
                    self.face_recognition_backend_active = "none"
                    self.face_recognition_target_active = "none"
                    self.face_recognition_ready = False
                    self.face_recognition_error = (
                        "; ".join(errors[:4]) or "face recognizer init failed"
                    )
                    return False, self.face_recognition_error

            if reload_gallery or not self.face_gallery_items:
                ok, gallery_err = self._load_face_gallery()
                self.face_recognition_ready = bool(ok and self.face_recognizer is not None)
                if not ok:
                    self.face_recognition_error = gallery_err or "face gallery unavailable"
                    return False, self.face_recognition_error

            self.face_recognition_ready = bool(
                self.face_recognizer is not None and len(self.face_gallery_items) > 0
            )
            if not self.face_recognition_ready:
                self.face_recognition_error = self.face_gallery_error or "face recognition unavailable"
                return False, self.face_recognition_error
            self.face_recognition_error = ""
            return True, ""

    def _recognize_faces(
        self,
        frame: Any,
        objects: list[dict[str, Any]],
        recognize: bool | None = None,
    ) -> dict[str, Any]:
        requested = bool(self.face_recognition_auto if recognize is None else bool(recognize))
        payload: dict[str, Any] = {
            "ok": False,
            "enabled": bool(self.face_recognition_enabled),
            "requested": bool(requested),
            "ready": bool(self.face_recognition_ready),
            "gallery_identities": int(self.face_gallery_identity_count),
            "gallery_images": int(self.face_gallery_image_count),
            "threshold": float(self.face_recognition_threshold),
            "evaluated": 0,
            "recognized": 0,
            "latency_ms": 0.0,
        }
        if not requested:
            payload["ok"] = True
            return payload
        if not objects:
            payload["ok"] = True
            return payload
        started = time.perf_counter()
        ok, err = self._ensure_face_recognition()
        payload["ready"] = bool(self.face_recognition_ready)
        if not ok:
            payload["error"] = err or self.face_recognition_error or "face recognition unavailable"
            payload["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return payload

        gallery = list(self.face_gallery_items)
        for obj in objects:
            if str(obj.get("type") or "").strip().lower() != "face":
                continue
            payload["evaluated"] = int(payload["evaluated"]) + 1
            attrs = obj.setdefault("attributes", {})
            if not isinstance(attrs, dict):
                attrs = {}
                obj["attributes"] = attrs
            feature, feat_err = self._extract_face_feature(frame, obj)
            if feature is None:
                attrs["identity_error"] = feat_err or "face feature unavailable"
                continue
            best_label = ""
            best_score = -1.0
            best_samples = 0
            best_support = 0
            best_peak_score = -1.0
            for item in gallery:
                sample_features = item.get("sample_features")
                sample_scores: list[float] = []
                if isinstance(sample_features, list):
                    for sample_feature in sample_features:
                        try:
                            sample_scores.append(float(np.dot(feature, sample_feature)))
                        except Exception:
                            continue
                if not sample_scores:
                    gallery_feature = item.get("feature")
                    if gallery_feature is None:
                        continue
                    try:
                        sample_scores.append(float(np.dot(feature, gallery_feature)))
                    except Exception:
                        continue
                sample_scores.sort(reverse=True)
                topk = max(1, min(int(self.face_recognition_topk), len(sample_scores)))
                agg_score = float(sum(sample_scores[:topk]) / float(topk))
                peak_score = float(sample_scores[0])
                support_count = int(
                    sum(
                        1
                        for score in sample_scores
                        if score >= float(self.face_recognition_support_threshold)
                    )
                )
                if (
                    agg_score > best_score
                    or (
                        abs(agg_score - best_score) <= 1e-6
                        and peak_score > best_peak_score
                    )
                ):
                    best_score = agg_score
                    best_peak_score = peak_score
                    best_support = support_count
                    best_label = str(item.get("label") or "")
                    best_samples = int(item.get("samples") or len(sample_scores))
            attrs["identity_score"] = round(float(best_score), 4) if best_score >= 0 else None
            attrs["identity_peak_score"] = (
                round(float(best_peak_score), 4) if best_peak_score >= 0 else None
            )
            attrs["identity_threshold"] = float(self.face_recognition_threshold)
            attrs["identity_peak_threshold"] = float(self.face_recognition_peak_threshold)
            attrs["identity_support_threshold"] = float(self.face_recognition_support_threshold)
            attrs["identity_support"] = int(best_support)
            attrs["identity_min_support"] = int(self.face_recognition_min_support)
            attrs["identity_best_candidate"] = best_label or None
            attrs["identity_samples"] = int(best_samples)
            required_support = max(
                1,
                min(int(self.face_recognition_min_support), int(best_samples or 1)),
            )
            pose_ok, pose_reasons = self._face_recognition_pose_gate(obj)
            attrs["identity_pose_ok"] = bool(pose_ok)
            attrs["identity_reject_reasons"] = []
            if not pose_ok:
                attrs["identity_reject_reasons"].extend(pose_reasons)
            if best_score < float(self.face_recognition_threshold):
                attrs["identity_reject_reasons"].append(
                    f"score {best_score:.4f}<{float(self.face_recognition_threshold):.4f}"
                )
            if best_peak_score < float(self.face_recognition_peak_threshold):
                attrs["identity_reject_reasons"].append(
                    f"peak {best_peak_score:.4f}<{float(self.face_recognition_peak_threshold):.4f}"
                )
            if best_support < required_support:
                attrs["identity_reject_reasons"].append(
                    f"support {int(best_support)}<{int(required_support)}"
                )
            if (
                best_score >= float(self.face_recognition_threshold)
                and best_peak_score >= float(self.face_recognition_peak_threshold)
                and best_support >= required_support
                and pose_ok
                and best_label
            ):
                attrs["identity_label"] = best_label
                attrs["identity_match"] = True
                payload["recognized"] = int(payload["recognized"]) + 1
            else:
                attrs["identity_label"] = self.face_recognition_unknown_label
                attrs["identity_match"] = False
        payload["ok"] = True
        payload["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
        return payload

    def face_recognition_status(self) -> dict[str, Any]:
        payload = {
            "ok": True,
            "timestamp": _ts_now(),
            **self._face_recognition_status(),
        }
        if not bool(payload.get("face_recognition_ready")):
            payload["ok"] = False
        payload["summary"] = (
            f"ready identities={int(self.face_gallery_identity_count)}"
            if bool(self.face_recognition_ready)
            else (self.face_recognition_error or "face recognition unavailable")
        )
        return payload

    def face_recognition_reload(self) -> dict[str, Any]:
        ok, err = self._ensure_face_recognition(reload_gallery=True)
        payload = self.face_recognition_status()
        payload["ok"] = bool(ok)
        payload["timestamp"] = _ts_now()
        if ok:
            payload["message"] = "face recognition gallery reloaded"
        else:
            payload["error"] = err or self.face_recognition_error or "face recognition reload failed"
            payload["message"] = payload["error"]
        return payload

    def _resize_frame_for_face_detect(self, frame: Any) -> tuple[Any, float]:
        if frame is None or self.cv2 is None:
            return frame, 1.0
        max_side = int(self.face_detect_max_side)
        if max_side <= 0:
            return frame, 1.0
        h, w = frame.shape[:2]
        longest = max(int(w), int(h))
        if longest <= max_side:
            return frame, 1.0
        scale = float(max_side) / float(longest)
        nw = max(2, int(round(float(w) * scale)))
        nh = max(2, int(round(float(h) * scale)))
        try:
            resized = self.cv2.resize(frame, (nw, nh), interpolation=self.cv2.INTER_LINEAR)
            return resized, float(scale)
        except Exception:
            return frame, 1.0

    def _scale_face_candidate(
        self,
        face: dict[str, Any],
        scale: float,
        frame_w: int,
        frame_h: int,
    ) -> dict[str, Any] | None:
        if scale >= 0.999:
            return dict(face)
        bbox = self._normalize_bbox_xyxy(face.get("bbox_xyxy"))
        if bbox is None:
            return None
        inv = 1.0 / max(1e-6, float(scale))
        x1 = max(0, min(frame_w - 1, int(round(float(bbox[0]) * inv))))
        y1 = max(0, min(frame_h - 1, int(round(float(bbox[1]) * inv))))
        x2 = max(0, min(frame_w - 1, int(round(float(bbox[2]) * inv))))
        y2 = max(0, min(frame_h - 1, int(round(float(bbox[3]) * inv))))
        if x2 <= x1 or y2 <= y1:
            return None
        out = dict(face)
        out["bbox_xyxy"] = [x1, y1, x2, y2]
        lm = self._normalize_face_landmarks_xy(face.get("landmarks_xy"))
        if lm is not None:
            scaled_lm: list[list[int]] = []
            for px, py in lm:
                sx = max(0, min(frame_w - 1, int(round(float(px) * inv))))
                sy = max(0, min(frame_h - 1, int(round(float(py) * inv))))
                scaled_lm.append([sx, sy])
            out["landmarks_xy"] = scaled_lm
        return out

    @staticmethod
    def _clone_detection_objects(objects: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for obj in objects:
            row = dict(obj)
            attrs = obj.get("attributes")
            if isinstance(attrs, dict):
                row["attributes"] = dict(attrs)
            out.append(row)
        return out

    def _face_cache_get(self, frame_ts: float = 0.0) -> tuple[list[dict[str, Any]] | None, str]:
        with self.face_cache_lock:
            cache_ts = float(self.face_cache_ts)
            last_eval = float(self.face_last_eval_ts)
            src_ts = float(self.face_cache_source_ts)
            err = str(self.face_cache_error or "")
            cached = self._clone_detection_objects(self.face_cache_objects)
        if cache_ts <= 0:
            return None, ""
        same_source = frame_ts > 0 and abs(src_ts - frame_ts) < 1e-6
        since_eval_ms = max(0.0, (time.time() - last_eval) * 1000.0) if last_eval > 0 else 1e9
        if (not same_source) and since_eval_ms > float(self.face_update_interval_ms):
            return None, ""
        return cached, err

    def _face_cache_set(
        self,
        objects: list[dict[str, Any]],
        err: str = "",
        frame_ts: float = 0.0,
    ) -> None:
        now = time.time()
        with self.face_cache_lock:
            self.face_last_eval_ts = now
            self.face_cache_ts = now
            self.face_cache_source_ts = float(frame_ts) if frame_ts > 0 else 0.0
            self.face_cache_objects = self._clone_detection_objects(objects)
            self.face_cache_error = str(err or "")

    def _collect_yolo_world_person_boxes(
        self,
        frame: Any,
        frame_ts: float = 0.0,
        force_world_fusion: bool = False,
    ) -> tuple[list[list[int]] | None, str]:
        if (not force_world_fusion) and (
            (not self.face_only_mode) or (not self.face_only_world_fusion)
        ):
            return None, ""
        if not self._yolo_world_ready():
            return None, "yolo_world unavailable"
        world_objects: list[dict[str, Any]] = []
        world_err = ""
        if self.yolo_world_async_enabled:
            async_res = self._yolo_world_async_get(max_age_ms=1000.0)
            if async_res is not None:
                world_objects, world_err, _ = async_res
            else:
                if self.face_only_mode:
                    return [], "yolo_world async warming"
                world_objects, world_err, _ = self._detect_yolo_world(frame, frame_ts=frame_ts)
        else:
            world_objects, world_err, _ = self._detect_yolo_world(frame, frame_ts=frame_ts)
        if world_err:
            return [], world_err
        persons: list[list[int]] = []
        for obj in world_objects:
            if str(obj.get("type") or "") != "yolo_world":
                continue
            cls_name = str(obj.get("class_name") or "").strip().lower()
            if cls_name:
                if cls_name != "person":
                    continue
            else:
                try:
                    if int(obj.get("class_id") or -1) != 0:
                        continue
                except Exception:
                    continue
            bbox = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
            if bbox is not None:
                persons.append(bbox)
        return persons, ""

    @staticmethod
    def _face_center_in_bbox(face_bbox_xyxy: list[int], body_bbox_xyxy: list[int]) -> bool:
        if len(face_bbox_xyxy) != 4 or len(body_bbox_xyxy) != 4:
            return False
        fx1, fy1, fx2, fy2 = [int(v) for v in face_bbox_xyxy]
        bx1, by1, bx2, by2 = [int(v) for v in body_bbox_xyxy]
        if fx2 <= fx1 or fy2 <= fy1 or bx2 <= bx1 or by2 <= by1:
            return False
        cx = float(fx1 + fx2) * 0.5
        cy = float(fy1 + fy2) * 0.5
        bw = float(bx2 - bx1)
        bh = float(by2 - by1)
        pad_w = bw * 0.08
        pad_h = bh * 0.08
        return (
            cx >= float(bx1) - pad_w
            and cx <= float(bx2) + pad_w
            and cy >= float(by1) - pad_h
            and cy <= float(by2) + pad_h
        )

    def _face_bbox_passes_quality_gate(self, bbox_xyxy: list[int], frame_w: int, frame_h: int) -> bool:
        if len(bbox_xyxy) != 4:
            return False
        x1, y1, x2, y2 = [int(v) for v in bbox_xyxy]
        bw = int(x2 - x1)
        bh = int(y2 - y1)
        if bw <= 0 or bh <= 0:
            return False
        frame_area = float(max(1, frame_w * frame_h))
        area_ratio = float(bw * bh) / frame_area
        if area_ratio > float(self.face_max_area_ratio):
            return False
        aspect = float(bw) / float(max(1, bh))
        if aspect < float(self.face_min_aspect_ratio) or aspect > float(self.face_max_aspect_ratio):
            return False
        return True

    @staticmethod
    def _face_center_bonus(cx: float, cy: float, frame_w: int, frame_h: int) -> float:
        if frame_w <= 1 or frame_h <= 1:
            return 0.0
        dx = abs(float(cx) - float(frame_w) * 0.5) / max(1.0, float(frame_w) * 0.5)
        dy = abs(float(cy) - float(frame_h) * 0.5) / max(1.0, float(frame_h) * 0.5)
        return float(max(0.0, 1.0 - (dx * 0.85 + dy * 1.15)))

    @staticmethod
    def _face_landmarks_plausible(landmarks_xy: list[list[int]], bbox_xyxy: list[int]) -> bool:
        if len(landmarks_xy) != 5 or len(bbox_xyxy) != 4:
            return False
        try:
            pts = [[float(p[0]), float(p[1])] for p in landmarks_xy]
            x1, y1, x2, y2 = [float(v) for v in bbox_xyxy]
        except Exception:
            return False
        bw = max(1.0, x2 - x1)
        bh = max(1.0, y2 - y1)
        left_eye, right_eye = sorted([pts[0], pts[1]], key=lambda p: p[0])
        nose = pts[2]
        mouth_l, mouth_r = sorted([pts[3], pts[4]], key=lambda p: p[0])

        eye_dx = abs(right_eye[0] - left_eye[0])
        if eye_dx < 0.12 * bw or eye_dx > 0.85 * bw:
            return False

        eye_mid_y = 0.5 * (left_eye[1] + right_eye[1])
        mouth_mid_y = 0.5 * (mouth_l[1] + mouth_r[1])
        if mouth_mid_y <= eye_mid_y + 0.08 * bh:
            return False
        if nose[1] < eye_mid_y - 0.06 * bh or nose[1] > mouth_mid_y + 0.18 * bh:
            return False

        eye_mid_x = 0.5 * (left_eye[0] + right_eye[0])
        if abs(nose[0] - eye_mid_x) > 0.38 * bw:
            return False
        return True

    def _detect_face_objects(
        self,
        frame: Any,
        frame_ts: float = 0.0,
        use_world_fusion: bool = False,
        world_strict: bool = False,
    ) -> tuple[list[dict[str, Any]], str]:
        if not use_world_fusion:
            cached, cached_err = self._face_cache_get(frame_ts=frame_ts)
            if cached is not None:
                return cached, cached_err
        src_h, src_w = frame.shape[:2]
        face_frame, face_scale = self._resize_frame_for_face_detect(frame)
        faces_raw, face_err = self._detect_faces(face_frame)
        faces: list[dict[str, Any]] = []
        for item in faces_raw:
            scaled = self._scale_face_candidate(item, face_scale, src_w, src_h)
            if scaled is not None:
                faces.append(scaled)
        if not faces and face_err:
            return [], face_err
        person_boxes, world_err = self._collect_yolo_world_person_boxes(
            frame, frame_ts=frame_ts, force_world_fusion=bool(use_world_fusion)
        )
        person_count = len(person_boxes) if isinstance(person_boxes, list) else 0
        out: list[dict[str, Any]] = []
        frame_area = float(max(1, src_w * src_h))
        for face in faces:
            bbox = self._normalize_bbox_xyxy(face.get("bbox_xyxy"))
            if bbox is None:
                continue
            if not self._face_bbox_passes_quality_gate(bbox, src_w, src_h):
                continue
            x1, y1, x2, y2 = [int(v) for v in bbox]
            bw = int(x2 - x1)
            bh = int(y2 - y1)
            cx = float(x1 + x2) * 0.5
            cy = float(y1 + y2) * 0.5
            area = float(max(1, bw * bh))
            area_ratio = area / frame_area
            attrs: dict[str, Any] = {}
            match = False
            if isinstance(person_boxes, list):
                match = any(
                    self._face_center_in_bbox([x1, y1, x2, y2], person_bbox)
                    for person_bbox in person_boxes
                )
                attrs["world_person_match"] = bool(match)
                attrs["world_person_count"] = int(person_count)
                attrs["world_source"] = "yolo_world"
                if (self.face_only_world_strict or world_strict) and (not match):
                    continue
            score = float(face.get("score") or 0.0)
            if score < float(self.face_min_score):
                continue
            lm = self._normalize_face_landmarks_xy(face.get("landmarks_xy"))
            if lm is not None:
                if not self._face_landmarks_plausible(lm, [x1, y1, x2, y2]):
                    continue
                attrs["face_landmarks_xy"] = [[int(p[0]), int(p[1])] for p in lm]
                pose = self._estimate_face_pose_from_landmarks(lm)
                if isinstance(pose, dict):
                    attrs.update(pose)
            attrs["face_area_ratio"] = round(float(area_ratio), 4)

            center_bonus = self._face_center_bonus(cx, cy, src_w, src_h)
            area_score = float(min(1.0, area_ratio / max(1e-6, float(self.face_max_area_ratio))))
            priority = score * 0.62 + center_bonus * 0.28 + area_score * 0.10
            if match:
                priority += 0.20
            row: dict[str, Any] = {
                "type": "face",
                "class_id": 0,
                "class_name": "face",
                "score": score,
                "bbox_xywh": [int(x1), int(y1), int(bw), int(bh)],
                "bbox_xyxy": [int(x1), int(y1), int(x2), int(y2)],
                "cx": cx,
                "cy": cy,
                "area": area,
                "_priority": round(priority, 6),
            }
            if attrs:
                row["attributes"] = attrs
            out.append(row)
        out.sort(
            key=lambda d: (
                float(d.get("_priority", 0.0)),
                float(d.get("score", 0.0)),
            ),
            reverse=True,
        )
        if self.face_max_objects > 0:
            out = out[: int(self.face_max_objects)]
        for row in out:
            row.pop("_priority", None)
        if out:
            if not use_world_fusion:
                self._face_cache_set(out, err="", frame_ts=frame_ts)
            return out, ""
        if face_err:
            if not use_world_fusion:
                self._face_cache_set(out, err=face_err, frame_ts=frame_ts)
            return out, face_err
        if world_err and (self.face_only_world_strict or world_strict):
            if not use_world_fusion:
                self._face_cache_set(out, err=world_err, frame_ts=frame_ts)
            return out, world_err
        if not use_world_fusion:
            self._face_cache_set(out, err="", frame_ts=frame_ts)
        return out, ""

    @staticmethod
    def _is_yolo_world_person_object(obj: dict[str, Any]) -> bool:
        if str(obj.get("type") or "").strip().lower() != "yolo_world":
            return False
        cls_name = str(obj.get("class_name") or "").strip().lower()
        if cls_name:
            return cls_name == "person"
        try:
            return int(obj.get("class_id") or -1) == 0
        except Exception:
            return False

    def _detect_face_world_objects(
        self, frame: Any, frame_ts: float = 0.0
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
        started = time.perf_counter()
        face_started = time.perf_counter()
        face_objects, face_err = self._detect_face_objects(
            frame,
            frame_ts=frame_ts,
            use_world_fusion=True,
            world_strict=False,
        )
        face_detect_ms = round((time.perf_counter() - face_started) * 1000.0, 2)

        world_objects: list[dict[str, Any]] = []
        world_err = ""
        world_meta: dict[str, Any] = {}
        if self.yolo_world_async_enabled:
            async_res = self._yolo_world_async_get(max_age_ms=1000.0)
            if async_res is not None:
                world_objects, world_err, world_meta = async_res
            else:
                world_objects, world_err, world_meta = self._detect_yolo_world(
                    frame, frame_ts=frame_ts
                )
                world_meta["fallback_sync"] = True
        else:
            world_objects, world_err, world_meta = self._detect_yolo_world(
                frame, frame_ts=frame_ts
            )

        # Avoid duplicate human output: keep face as the human target, keep non-person yolo_world.
        world_person_filtered = 0
        world_non_person: list[dict[str, Any]] = []
        for obj in world_objects:
            if self._is_yolo_world_person_object(obj):
                world_person_filtered += 1
                continue
            world_non_person.append(obj)
        merged = [dict(obj) for obj in face_objects] + [dict(obj) for obj in world_non_person]

        meta: dict[str, Any] = {
            "face_world_fusion": True,
            "face_detect_ms": face_detect_ms,
            "world_raw_objects": int(len(world_objects)),
            "world_objects": int(len(world_non_person)),
            "world_person_filtered": int(world_person_filtered),
            "face_objects": int(len(face_objects)),
        }
        if "detect_ms" in world_meta:
            meta["world_detect_ms"] = float(world_meta.get("detect_ms") or 0.0)
        if "infer_ms" in world_meta:
            meta["world_infer_ms"] = float(world_meta.get("infer_ms") or 0.0)
        if "fallback_sync" in world_meta:
            meta["world_fallback_sync"] = bool(world_meta.get("fallback_sync"))
        if "cache_hit" in world_meta:
            meta["world_cache_hit"] = bool(world_meta.get("cache_hit"))
        if "suppressed_spike" in world_meta:
            meta["world_suppressed_spike"] = bool(world_meta.get("suppressed_spike"))
        if face_err:
            meta["face_error"] = face_err
        if world_err:
            meta["world_error"] = world_err
        meta["detect_ms"] = round((time.perf_counter() - started) * 1000.0, 2)

        if not merged and face_err:
            return [], face_err, meta
        if not merged and world_err:
            return [], world_err, meta
        return merged, "", meta

    def _ensure_emotion_model(self) -> tuple[bool, str]:
        if not self.emotion_enabled:
            return False, "emotion disabled"
        if self.emotion_require_face:
            face_ok, face_err = self._ensure_emotion_face_detector()
            if not face_ok:
                self.emotion_error = face_err or "emotion face detector unavailable"
                return False, self.emotion_error
        with self.model_load_lock:
            if self.emotion_engine == "rknn":
                with self.emotion_lock:
                    if self.emotion_ready and self.emotion_rknn is not None:
                        return True, ""
                ok, err = self._init_emotion_rknn_model()
                if not ok:
                    self.emotion_error = err or "emotion rknn unavailable"
                    return False, self.emotion_error
                with self.emotion_lock:
                    self.emotion_ready = True
                    self.emotion_error = ""
                return True, ""

            with self.emotion_lock:
                if self.emotion_ready and self.emotion_recognizer is not None:
                    return True, ""
            try:
                self._repair_logging_level_aliases()
                from emotiefflib.facial_analysis import EmotiEffLibRecognizer
            except Exception as exc:
                self.emotion_error = f"emotion import failed: {exc}"
                return False, self.emotion_error
            try:
                recognizer = EmotiEffLibRecognizer(
                    engine=self.emotion_engine,
                    model_name=self.emotion_model_name,
                    device="cpu",
                )
            except Exception as exc:
                self.emotion_error = f"emotion model load failed: {exc}"
                return False, self.emotion_error
            self._release_emotion_rknn()
            with self.emotion_lock:
                self.emotion_recognizer = recognizer
                self.emotion_ready = True
                self.emotion_error = ""
                self.emotion_rknn_labels_error = ""
            return True, ""

    def _person_upper_crop(
        self,
        frame: Any,
        bbox_xyxy: list[int],
        top_ratio: float,
        width_ratio: float,
        min_side: int = 12,
    ) -> Any | None:
        if self.cv2 is None or frame is None:
            return None
        if not isinstance(bbox_xyxy, list) or len(bbox_xyxy) != 4:
            return None
        h, w = frame.shape[:2]
        x1, y1, x2, y2 = [int(v) for v in bbox_xyxy]
        x1 = max(0, min(w - 1, x1))
        y1 = max(0, min(h - 1, y1))
        x2 = max(0, min(w - 1, x2))
        y2 = max(0, min(h - 1, y2))
        if x2 <= x1 or y2 <= y1:
            return None
        person_w = max(1, x2 - x1)
        width_ratio = float(width_ratio)
        if width_ratio < 0.999:
            keep_w = max(12, int(round(float(person_w) * width_ratio)))
            keep_w = min(person_w, keep_w)
            cx = int(round((x1 + x2) * 0.5))
            nx1 = cx - keep_w // 2
            nx2 = nx1 + keep_w
            if nx1 < 0:
                nx2 += -nx1
                nx1 = 0
            if nx2 > w:
                shift = nx2 - w
                nx1 = max(0, nx1 - shift)
                nx2 = w
            x1, x2 = int(nx1), int(nx2)
            if x2 <= x1:
                return None
        person_h = max(1, y2 - y1)
        head_y2 = int(round(y1 + float(top_ratio) * float(person_h)))
        head_y2 = max(y1 + 1, min(h, head_y2))
        crop = frame[y1:head_y2, x1:x2]
        if crop is None or crop.size == 0:
            return None
        if crop.shape[0] < int(min_side) or crop.shape[1] < int(min_side):
            return None
        return crop

    def _person_head_crop(self, frame: Any, bbox_xyxy: list[int]) -> Any | None:
        return self._person_upper_crop(
            frame=frame,
            bbox_xyxy=bbox_xyxy,
            top_ratio=self.wear_glasses_head_ratio,
            width_ratio=self.wear_glasses_head_width_ratio,
            min_side=12,
        )

    def _person_face_crop(self, frame: Any, bbox_xyxy: list[int]) -> Any | None:
        return self._person_upper_crop(
            frame=frame,
            bbox_xyxy=bbox_xyxy,
            top_ratio=self.emotion_head_ratio,
            width_ratio=self.emotion_head_width_ratio,
            min_side=20,
        )

    def _predict_wear_glasses_crop(self, crop_bgr: Any) -> tuple[dict[str, Any] | None, str]:
        if self.cv2 is None:
            return None, "opencv unavailable"
        with self.wear_glasses_lock:
            model = self.wear_glasses_model
            preprocess = self.wear_glasses_preprocess
            torch_mod = self.wear_glasses_torch
            pil_image = self.wear_glasses_pil_image
            pos_feat = self.wear_glasses_text_pos
            neg_feat = self.wear_glasses_text_neg
            device = self.wear_glasses_device_active or "cpu"
        if (
            model is None
            or preprocess is None
            or torch_mod is None
            or pil_image is None
            or pos_feat is None
            or neg_feat is None
        ):
            return None, "wear_glasses model not initialized"
        try:
            rgb = self.cv2.cvtColor(crop_bgr, self.cv2.COLOR_BGR2RGB)
            pil_obj = pil_image.fromarray(rgb)
            inp = preprocess(pil_obj).unsqueeze(0).to(device)
            with torch_mod.no_grad():
                img_feat = model.encode_image(inp).float()
                img_feat = img_feat / img_feat.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                pos_score = float((img_feat @ pos_feat.T).item())
                neg_score = float((img_feat @ neg_feat.T).item())
            margin = float(pos_score - neg_score)
            confidence = float(1.0 / (1.0 + np.exp(-12.0 * margin)))
            wear = bool(margin >= float(self.wear_glasses_min_margin))
            return {
                "wear_glasses": wear,
                "wear_score": pos_score,
                "no_wear_score": neg_score,
                "margin": margin,
                "confidence": confidence,
            }, ""
        except Exception as exc:
            return None, f"wear_glasses predict failed: {exc}"

    @staticmethod
    def _normalize_bbox_xyxy(raw_bbox: Any) -> list[int] | None:
        if not isinstance(raw_bbox, list) or len(raw_bbox) != 4:
            return None
        try:
            x1, y1, x2, y2 = [int(v) for v in raw_bbox]
        except Exception:
            return None
        if x2 <= x1 or y2 <= y1:
            return None
        return [x1, y1, x2, y2]

    @staticmethod
    def _set_object_bbox_xyxy(obj: dict[str, Any], bbox_xyxy: list[int]) -> None:
        x1, y1, x2, y2 = [int(v) for v in bbox_xyxy]
        if x2 <= x1 or y2 <= y1:
            return
        bw = int(x2 - x1)
        bh = int(y2 - y1)
        obj["bbox_xyxy"] = [x1, y1, x2, y2]
        obj["bbox_xywh"] = [x1, y1, bw, bh]
        obj["cx"] = float(x1 + x2) * 0.5
        obj["cy"] = float(y1 + y2) * 0.5
        obj["area"] = float(max(1, bw * bh))

    @staticmethod
    def _normalize_face_landmarks_xy(raw: Any) -> list[list[int]] | None:
        if not isinstance(raw, list) or len(raw) != 5:
            return None
        out: list[list[int]] = []
        for pt in raw:
            if not isinstance(pt, list) or len(pt) != 2:
                return None
            try:
                x = int(round(float(pt[0])))
                y = int(round(float(pt[1])))
            except Exception:
                return None
            out.append([x, y])
        return out

    @staticmethod
    def _estimate_face_pose_from_landmarks(
        landmarks_xy: list[list[int]],
    ) -> dict[str, Any] | None:
        pts = VisionService._normalize_face_landmarks_xy(landmarks_xy)
        if pts is None:
            return None
        # YuNet ordering can vary across wrappers; normalize by x-position.
        eyes = sorted([pts[0], pts[1]], key=lambda p: p[0])
        mouth = sorted([pts[3], pts[4]], key=lambda p: p[0])
        left_eye, right_eye = eyes
        nose = pts[2]
        left_mouth, right_mouth = mouth

        eye_dx = float(right_eye[0] - left_eye[0])
        if abs(eye_dx) < 4.0:
            return None
        eye_mid_y = float(left_eye[1] + right_eye[1]) * 0.5
        mouth_mid_y = float(left_mouth[1] + right_mouth[1]) * 0.5
        eye_mouth_dy = max(4.0, mouth_mid_y - eye_mid_y)

        nose_ratio_x = (float(nose[0]) - float(left_eye[0])) / max(4.0, eye_dx)
        nose_ratio_y = (float(nose[1]) - eye_mid_y) / eye_mouth_dy
        yaw_norm = float(np.clip((nose_ratio_x - 0.50) * 2.0, -1.0, 1.0))
        pitch_norm = float(np.clip((nose_ratio_y - 0.52) * 2.0, -1.0, 1.0))
        roll_deg = float(np.degrees(np.arctan2(float(right_eye[1] - left_eye[1]), eye_dx)))
        yaw_deg = float(yaw_norm * 45.0)
        pitch_deg = float(pitch_norm * 35.0)

        horizontal = "center"
        if yaw_norm >= 0.22:
            horizontal = "right"
        elif yaw_norm <= -0.22:
            horizontal = "left"
        vertical = "center"
        if pitch_norm >= 0.22:
            vertical = "down"
        elif pitch_norm <= -0.22:
            vertical = "up"

        if horizontal == "center" and vertical == "center":
            pose_label = "front"
        elif horizontal != "center" and vertical != "center":
            pose_label = f"{horizontal}_{vertical}"
        elif horizontal != "center":
            pose_label = horizontal
        else:
            pose_label = vertical

        return {
            "face_pose_label": pose_label,
            "face_pose_horizontal": horizontal,
            "face_pose_vertical": vertical,
            "face_yaw_deg": round(yaw_deg, 2),
            "face_pitch_deg": round(pitch_deg, 2),
            "face_roll_deg": round(roll_deg, 2),
            "face_pose_confidence": round(
                float(
                    min(
                        1.0,
                        0.35
                        + 0.45 * min(1.0, abs(yaw_norm))
                        + 0.20 * min(1.0, abs(pitch_norm)),
                    )
                ),
                3,
            ),
        }

    @staticmethod
    def _person_upper_bbox_xyxy_from_body(
        bbox_xyxy: list[int], top_ratio: float, width_ratio: float, min_side: int = 12
    ) -> list[int] | None:
        if not isinstance(bbox_xyxy, list) or len(bbox_xyxy) != 4:
            return None
        x1, y1, x2, y2 = [int(v) for v in bbox_xyxy]
        if x2 <= x1 or y2 <= y1:
            return None
        person_w = max(1, x2 - x1)
        if width_ratio < 0.999:
            keep_w = max(int(min_side), int(round(float(person_w) * float(width_ratio))))
            keep_w = min(person_w, keep_w)
            cx = int(round((x1 + x2) * 0.5))
            nx1 = cx - keep_w // 2
            nx2 = nx1 + keep_w
            if nx1 < x1:
                nx2 += x1 - nx1
                nx1 = x1
            if nx2 > x2:
                shift = nx2 - x2
                nx1 = max(x1, nx1 - shift)
                nx2 = x2
            x1, x2 = int(nx1), int(nx2)
            if x2 <= x1:
                return None
        person_h = max(1, y2 - y1)
        head_y2 = int(round(y1 + float(top_ratio) * float(person_h)))
        head_y2 = max(y1 + 1, min(y2, head_y2))
        if (x2 - x1) < int(min_side) or (head_y2 - y1) < int(min_side):
            return None
        return [int(x1), int(y1), int(x2), int(head_y2)]

    def _replace_person_boxes_with_head(
        self, frame: Any, objects: list[dict[str, Any]], allow_face_detect: bool = True
    ) -> dict[str, Any]:
        person_entries: list[tuple[int, dict[str, Any], list[int]]] = []
        for idx, obj in enumerate(objects):
            if str(obj.get("class_name") or "").strip().lower() != "person":
                continue
            body_bbox = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
            if body_bbox is None:
                continue
            person_entries.append((idx, obj, body_bbox))
        if not person_entries:
            return {"person_candidates": 0, "head_replaced": 0, "face_detected": 0}

        need_face_detect = False
        for _, obj, _ in person_entries:
            attrs = obj.get("attributes")
            face_bbox = None
            if isinstance(attrs, dict):
                face_bbox = self._normalize_bbox_xyxy(attrs.get("face_bbox_xyxy"))
            if face_bbox is None:
                need_face_detect = True
                break

        matched_faces: dict[int, dict[str, Any]] = {}
        face_count = 0
        face_err = ""
        if (
            need_face_detect
            and bool(allow_face_detect)
            and frame is not None
            and self._face_detector_requested_enabled()
        ):
            faces, face_err = self._detect_faces(frame)
            face_count = int(len(faces))
            used_face_ids: set[int] = set()
            for idx, _, body_bbox in person_entries:
                x1, y1, x2, y2 = [int(v) for v in body_bbox]
                person_w = max(1, x2 - x1)
                person_h = max(1, y2 - y1)
                # Allow partial-body person boxes: extend candidate region above body top.
                ex1 = x1 - int(round(person_w * 0.25))
                ex2 = x2 + int(round(person_w * 0.25))
                ey1 = y1 - int(round(person_h * 0.40))
                ey2 = y1 + int(round(person_h * 0.62))
                target_x = (x1 + x2) * 0.5
                target_y = y1 + float(person_h) * 0.22
                best_face_id = -1
                best_score = -1.0
                for fid, face in enumerate(faces):
                    if fid in used_face_ids:
                        continue
                    fbbox = self._normalize_bbox_xyxy(face.get("bbox_xyxy"))
                    if fbbox is None:
                        continue
                    fx1, fy1, fx2, fy2 = [int(v) for v in fbbox]
                    fcx = (fx1 + fx2) * 0.5
                    fcy = (fy1 + fy2) * 0.5
                    if not bool(ex1 <= fcx <= ex2 and ey1 <= fcy <= ey2):
                        continue
                    face_w = max(1.0, float(fx2 - fx1))
                    face_h = max(1.0, float(fy2 - fy1))
                    face_area_ratio = (face_w * face_h) / max(1.0, float(person_w * person_h))
                    if face_area_ratio < 0.005 or face_area_ratio > 0.30:
                        continue
                    if fcy > (y1 + float(person_h) * 0.62):
                        continue
                    iou = self._bbox_iou_xyxy(body_bbox, fbbox)
                    span_x = max(1.0, float(ex2 - ex1))
                    span_y = max(1.0, float(ey2 - ey1))
                    dx = abs(fcx - target_x) / span_x
                    dy = abs(fcy - target_y) / span_y
                    dist_score = max(0.0, 1.0 - (dx * 0.8 + dy * 1.2))
                    score = float(face.get("score", 0.0)) * 0.55 + iou * 0.35 + dist_score
                    if score > best_score:
                        best_score = score
                        best_face_id = fid
                if best_face_id < 0:
                    continue
                used_face_ids.add(best_face_id)
                fbbox = self._normalize_bbox_xyxy(faces[best_face_id].get("bbox_xyxy"))
                if fbbox is None:
                    continue
                expanded = self._expand_bbox_xyxy(
                    fbbox,
                    frame_w=int(frame.shape[1]),
                    frame_h=int(frame.shape[0]),
                    scale=float(self.emotion_face_expand),
                )
                landmarks = self._normalize_face_landmarks_xy(faces[best_face_id].get("landmarks_xy"))
                matched_faces[idx] = {
                    "bbox_xyxy": expanded if expanded is not None else fbbox,
                    "landmarks_xy": landmarks,
                }

        head_replaced = 0
        face_used = 0
        for idx, obj, body_bbox in person_entries:
            obj["body_bbox_xyxy"] = [int(v) for v in body_bbox]
            attrs = obj.setdefault("attributes", {})
            if not isinstance(attrs, dict):
                attrs = {}
                obj["attributes"] = attrs
            attrs.setdefault("body_bbox_xyxy", [int(v) for v in body_bbox])

            face_bbox = self._normalize_bbox_xyxy(attrs.get("face_bbox_xyxy"))
            face_landmarks = self._normalize_face_landmarks_xy(attrs.get("face_landmarks_xy"))
            source = "face_attr"
            if face_bbox is None:
                matched = matched_faces.get(idx)
                face_bbox = self._normalize_bbox_xyxy(
                    matched.get("bbox_xyxy") if isinstance(matched, dict) else None
                )
                source = "face_detect"
                if face_bbox is not None:
                    attrs["face_bbox_xyxy"] = [int(v) for v in face_bbox]
                if isinstance(matched, dict):
                    face_landmarks = self._normalize_face_landmarks_xy(matched.get("landmarks_xy"))
                if face_landmarks is not None:
                    attrs["face_landmarks_xy"] = [[int(p[0]), int(p[1])] for p in face_landmarks]
            head_bbox = face_bbox
            if head_bbox is None:
                head_bbox = self._person_upper_bbox_xyxy_from_body(
                    body_bbox,
                    top_ratio=float(self.person_head_box_top_ratio),
                    width_ratio=float(self.person_head_box_width_ratio),
                    min_side=12,
                )
                source = "upper_fallback"
            if head_bbox is None:
                continue

            self._set_object_bbox_xyxy(obj, head_bbox)
            obj["head_bbox_xyxy"] = [int(v) for v in head_bbox]
            attrs["head_bbox_xyxy"] = [int(v) for v in head_bbox]
            attrs["head_bbox_source"] = source
            attrs["person_box_mode"] = "head"
            pose = self._estimate_face_pose_from_landmarks(face_landmarks) if face_landmarks else None
            if isinstance(pose, dict):
                attrs.update(pose)
            if source.startswith("face_"):
                face_used += 1
            head_replaced += 1

        payload: dict[str, Any] = {
            "person_candidates": int(len(person_entries)),
            "head_replaced": int(head_replaced),
            "face_detected": int(face_count),
            "face_used": int(face_used),
        }
        if face_err:
            payload["face_error"] = face_err
        return payload

    @staticmethod
    def _bbox_iou_xyxy(a: list[int], b: list[int]) -> float:
        ax1, ay1, ax2, ay2 = [int(v) for v in a]
        bx1, by1, bx2, by2 = [int(v) for v in b]
        ix1 = max(ax1, bx1)
        iy1 = max(ay1, by1)
        ix2 = min(ax2, bx2)
        iy2 = min(ay2, by2)
        iw = max(0, ix2 - ix1)
        ih = max(0, iy2 - iy1)
        inter = float(iw * ih)
        if inter <= 0:
            return 0.0
        area_a = float(max(1, (ax2 - ax1) * (ay2 - ay1)))
        area_b = float(max(1, (bx2 - bx1) * (by2 - by1)))
        union = max(1.0, area_a + area_b - inter)
        return inter / union

    @staticmethod
    def _bbox_center_dist_norm(a: list[int], b: list[int]) -> float:
        ax1, ay1, ax2, ay2 = [float(v) for v in a]
        bx1, by1, bx2, by2 = [float(v) for v in b]
        acx = (ax1 + ax2) * 0.5
        acy = (ay1 + ay2) * 0.5
        bcx = (bx1 + bx2) * 0.5
        bcy = (by1 + by2) * 0.5
        dist = float(np.hypot(acx - bcx, acy - bcy))
        scale = max(1.0, max(ax2 - ax1, ay2 - ay1))
        return dist / scale

    @staticmethod
    def _is_face_object(obj: dict[str, Any]) -> bool:
        obj_type = str(obj.get("type") or "").strip().lower()
        cls_name = str(obj.get("class_name") or "").strip().lower()
        return obj_type == "face" or cls_name == "face"

    def _crop_bbox_with_expand(
        self, frame: Any, bbox_xyxy: list[int], scale: float, min_side: int
    ) -> tuple[Any | None, list[int] | None]:
        if frame is None:
            return None, None
        h, w = frame.shape[:2]
        bbox = self._normalize_bbox_xyxy(bbox_xyxy)
        if bbox is None:
            return None, None
        expanded = self._expand_bbox_xyxy(
            bbox,
            frame_w=int(w),
            frame_h=int(h),
            scale=float(max(1.0, scale)),
        )
        use_bbox = expanded if expanded is not None else bbox
        x1, y1, x2, y2 = [int(v) for v in use_bbox]
        if x2 <= x1 or y2 <= y1:
            return None, None
        crop = frame[y1:y2, x1:x2]
        if crop is None or crop.size == 0:
            return None, None
        if crop.shape[0] < int(min_side) or crop.shape[1] < int(min_side):
            return None, None
        return crop, [int(x1), int(y1), int(x2), int(y2)]

    def _wear_glasses_person_indices(self, objects: list[dict[str, Any]]) -> list[int]:
        if self.face_only_mode:
            person_indices = [
                idx for idx, obj in enumerate(objects) if self._is_face_object(obj)
            ]
        else:
            person_indices = [
                idx
                for idx, obj in enumerate(objects)
                if str(obj.get("class_name") or "").strip().lower() == "person"
            ]
            # In face/face_world mode there may be no "person" class object;
            # fall back to explicit face targets for attribute inference.
            if not person_indices:
                person_indices = [
                    idx for idx, obj in enumerate(objects) if self._is_face_object(obj)
                ]
        if self.wear_glasses_max_persons > 0:
            person_indices = person_indices[: int(self.wear_glasses_max_persons)]
        return person_indices

    def _apply_person_wear_attrs(
        self,
        obj: dict[str, Any],
        wear: bool,
        margin: float,
        confidence: float,
        source: str,
    ) -> None:
        attrs = obj.setdefault("attributes", {})
        if not isinstance(attrs, dict):
            return
        attrs["wear_glasses"] = bool(wear)
        attrs["wear_glasses_margin"] = float(margin)
        attrs["wear_glasses_confidence"] = float(confidence)
        attrs["wear_glasses_source"] = str(source or "clip")

    def _set_wear_glasses_cache(self, cache_items: list[dict[str, Any]]) -> None:
        now = time.time()
        with self.wear_glasses_cache_lock:
            self.wear_glasses_last_eval_ts = now
            self.wear_glasses_cache_ts = now
            self.wear_glasses_cache_items = [dict(item) for item in cache_items]

    def _wear_glasses_refresh_worker(self, frame: Any, objects: list[dict[str, Any]]) -> None:
        try:
            self._infer_wear_glasses(frame, objects, allow_compute=True)
        finally:
            with self.wear_glasses_refresh_lock:
                self.wear_glasses_refresh_pending = False

    def _schedule_wear_glasses_refresh(self, frame: Any, objects: list[dict[str, Any]]) -> None:
        if not self.wear_glasses_enabled or frame is None or not objects:
            return
        with self.wear_glasses_refresh_lock:
            if self.wear_glasses_refresh_pending:
                return
            self.wear_glasses_refresh_pending = True
        try:
            frame_copy = frame.copy()
        except Exception:
            with self.wear_glasses_refresh_lock:
                self.wear_glasses_refresh_pending = False
            return
        obj_copy = self._clone_detection_objects(objects)
        thread = threading.Thread(
            target=self._wear_glasses_refresh_worker,
            args=(frame_copy, obj_copy),
            name="vision-wear-refresh",
            daemon=True,
        )
        thread.start()

    def _apply_wear_glasses_cache(
        self, objects: list[dict[str, Any]], max_age_ms: float | None = None
    ) -> dict[str, Any] | None:
        now = time.time()
        ttl_ms = float(self.wear_glasses_cache_ttl_ms if max_age_ms is None else max_age_ms)
        with self.wear_glasses_cache_lock:
            cache_ts = float(self.wear_glasses_cache_ts)
            cache_items = [dict(item) for item in self.wear_glasses_cache_items]
        if cache_ts <= 0 or not cache_items:
            return None
        cache_age_ms = max(0.0, (now - cache_ts) * 1000.0)
        if ttl_ms > 0 and cache_age_ms > ttl_ms:
            return None

        person_indices = self._wear_glasses_person_indices(objects)
        used_cache_ids: set[int] = set()
        items: list[dict[str, Any]] = []
        wear_count = 0
        evaluated = 0
        iou_threshold = float(self.wear_glasses_cache_match_iou)
        dist_threshold = float(self.wear_glasses_cache_max_center_dist)
        if self.face_only_mode:
            iou_threshold = min(iou_threshold, 0.20)
            dist_threshold = max(dist_threshold, 0.75)
        for obj_idx in person_indices:
            obj = objects[obj_idx]
            bbox = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
            row: dict[str, Any] = {
                "object_index": int(obj_idx),
                "bbox_xyxy": bbox if bbox is not None else None,
            }
            if bbox is None:
                row["ok"] = False
                row["error"] = "invalid bbox"
                items.append(row)
                continue

            best_id = -1
            best_iou = 0.0
            best_dist_norm = 999.0
            for cid, cache in enumerate(cache_items):
                if cid in used_cache_ids:
                    continue
                cache_bbox = self._normalize_bbox_xyxy(cache.get("bbox_xyxy"))
                if cache_bbox is None:
                    continue
                iou = self._bbox_iou_xyxy(bbox, cache_bbox)
                dist_norm = self._bbox_center_dist_norm(bbox, cache_bbox)
                if iou > best_iou or (abs(iou - best_iou) < 1e-9 and dist_norm < best_dist_norm):
                    best_iou = iou
                    best_dist_norm = dist_norm
                    best_id = cid

            iou_ok = best_iou >= iou_threshold
            dist_ok = best_dist_norm <= dist_threshold
            if best_id < 0 or not (iou_ok or dist_ok):
                row["ok"] = False
                row["error"] = "cache miss"
                items.append(row)
                continue

            used_cache_ids.add(best_id)
            cached = cache_items[best_id]
            wear = bool(cached.get("wear_glasses"))
            margin = float(cached.get("wear_glasses_margin") or 0.0)
            confidence = float(cached.get("wear_glasses_confidence") or 0.0)
            source = str(cached.get("wear_glasses_source") or "clip_cache")
            self._apply_person_wear_attrs(obj, wear, margin, confidence, source)
            row.update(
                {
                    "ok": True,
                    "wear_glasses": wear,
                    "margin": margin,
                    "confidence": confidence,
                    "cached": True,
                    "match_iou": round(best_iou, 3),
                    "match_dist_norm": round(best_dist_norm, 3),
                }
            )
            if wear:
                wear_count += 1
            evaluated += 1
            items.append(row)

        return {
            "ok": True,
            "enabled": bool(self.wear_glasses_enabled),
            "cached": True,
            "model": self.wear_glasses_clip_model_name or None,
            "device": self.wear_glasses_device_active or None,
            "max_persons": int(self.wear_glasses_max_persons),
            "min_margin": float(self.wear_glasses_min_margin),
            "items": items,
            "wear_glasses_count": int(wear_count),
            "person_candidates": int(len(person_indices)),
            "person_evaluated": int(evaluated),
            "cache_age_ms": round(cache_age_ms, 2),
        }

    def _infer_wear_glasses(
        self,
        frame: Any,
        objects: list[dict[str, Any]],
        allow_compute: bool = True,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        base = {
            "ok": False,
            "enabled": bool(self.wear_glasses_enabled),
            "cached": False,
            "model": self.wear_glasses_clip_model_name or None,
            "device": self.wear_glasses_device_active or None,
            "max_persons": int(self.wear_glasses_max_persons),
            "min_margin": float(self.wear_glasses_min_margin),
            "items": [],
            "wear_glasses_count": 0,
            "person_candidates": 0,
            "person_evaluated": 0,
        }
        if not self.wear_glasses_enabled:
            base["error"] = "wear_glasses disabled by config"
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        person_indices = self._wear_glasses_person_indices(objects)
        base["person_candidates"] = int(len(person_indices))
        if not person_indices:
            if not self.face_only_mode:
                self._set_wear_glasses_cache([])
            base["ok"] = True
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        with self.wear_glasses_cache_lock:
            last_eval_ts = float(self.wear_glasses_last_eval_ts)
        since_eval_ms = (
            max(0.0, (time.time() - last_eval_ts) * 1000.0) if last_eval_ts > 0 else None
        )
        cached_payload = self._apply_wear_glasses_cache(objects)
        if cached_payload is not None:
            cached_payload["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            if since_eval_ms is not None:
                cached_payload["since_eval_ms"] = round(since_eval_ms, 2)
            need_refresh = bool(allow_compute) and (
                int(cached_payload.get("person_evaluated") or 0)
                < int(cached_payload.get("person_candidates") or 0)
            )
            if (not allow_compute) or (
                since_eval_ms is not None
                and since_eval_ms < float(self.wear_glasses_update_interval_ms)
                and not need_refresh
            ):
                return cached_payload

        if not allow_compute:
            base["error"] = "wear_glasses cache warming"
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        if not self.wear_glasses_infer_lock.acquire(blocking=False):
            cached_payload = self._apply_wear_glasses_cache(
                objects, max_age_ms=max(self.wear_glasses_cache_ttl_ms, 5000.0)
            )
            if cached_payload is not None:
                cached_payload["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                cached_payload["stale"] = True
                return cached_payload
            base["error"] = "wear_glasses busy"
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        try:
            with self.wear_glasses_cache_lock:
                last_eval_ts = float(self.wear_glasses_last_eval_ts)
            since_eval_ms = (
                max(0.0, (time.time() - last_eval_ts) * 1000.0) if last_eval_ts > 0 else None
            )
            if (
                since_eval_ms is not None
                and since_eval_ms < float(self.wear_glasses_update_interval_ms)
            ):
                cached_payload = self._apply_wear_glasses_cache(objects)
                if cached_payload is not None:
                    cached_payload["latency_ms"] = round(
                        (time.perf_counter() - started) * 1000.0, 2
                    )
                    cached_payload["since_eval_ms"] = round(since_eval_ms, 2)
                    return cached_payload

            ready, ready_err = self._ensure_wear_glasses_model()
            if not ready:
                base["error"] = ready_err or "wear_glasses model unavailable"
                base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                return base
            base["device"] = self.wear_glasses_device_active or None

            items: list[dict[str, Any]] = []
            wear_count = 0
            cache_items: list[dict[str, Any]] = []
            for obj_idx in person_indices:
                obj = objects[obj_idx]
                bbox_list = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
                is_face_target = self._is_face_object(obj)
                row: dict[str, Any] = {
                    "object_index": int(obj_idx),
                    "bbox_xyxy": bbox_list if bbox_list is not None else None,
                    "target": "face" if is_face_target else "person",
                }
                crop = None
                cache_bbox = bbox_list
                source = "clip_person"
                if bbox_list is not None:
                    if is_face_target:
                        crop, cache_bbox = self._crop_bbox_with_expand(
                            frame=frame,
                            bbox_xyxy=bbox_list,
                            scale=float(self.face_attr_expand),
                            min_side=16,
                        )
                        source = "clip_face"
                    else:
                        crop = self._person_head_crop(frame, bbox_list)
                if crop is None:
                    row["ok"] = False
                    row["error"] = "invalid crop"
                    items.append(row)
                    continue
                pred, pred_err = self._predict_wear_glasses_crop(crop)
                if pred is None:
                    row["ok"] = False
                    row["error"] = pred_err or "wear_glasses predict failed"
                    items.append(row)
                    continue
                row["ok"] = True
                row.update(pred)
                items.append(row)
                wear = bool(pred.get("wear_glasses"))
                margin = float(pred.get("margin") or 0.0)
                confidence = float(pred.get("confidence") or 0.0)
                self._apply_person_wear_attrs(obj, wear, margin, confidence, source)
                if wear:
                    wear_count += 1
                if cache_bbox is not None:
                    cache_items.append(
                        {
                            "bbox_xyxy": cache_bbox,
                            "wear_glasses": wear,
                            "wear_glasses_margin": margin,
                            "wear_glasses_confidence": confidence,
                            "wear_glasses_source": source,
                        }
                    )

            self._set_wear_glasses_cache(cache_items)
            base["ok"] = True
            base["items"] = items
            base["person_evaluated"] = int(len(items))
            base["wear_glasses_count"] = int(wear_count)
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base
        finally:
            self.wear_glasses_infer_lock.release()

    def _emotion_person_indices(self, objects: list[dict[str, Any]]) -> list[int]:
        # Emotion supports both explicit face targets and person targets.
        # face-only mode is one source of face targets, but face detector can also
        # be used when face-only mode is disabled.
        person_indices = []
        for idx, obj in enumerate(objects):
            if self._is_face_object(obj):
                person_indices.append(idx)
                continue
            if str(obj.get("class_name") or "").strip().lower() == "person":
                person_indices.append(idx)
        if self.emotion_max_persons > 0:
            person_indices = person_indices[: int(self.emotion_max_persons)]
        return person_indices

    @staticmethod
    def _normalize_emotion_label(label: str) -> str:
        raw = str(label or "").strip().lower()
        if not raw:
            return "unknown"
        if raw in EMOTION_LABEL_ALIAS:
            return EMOTION_LABEL_ALIAS[raw]
        return re.sub(r"\s+", "_", raw)

    def _apply_person_emotion_attrs(
        self, obj: dict[str, Any], label: str, confidence: float, source: str, accepted: bool
    ) -> None:
        attrs = obj.setdefault("attributes", {})
        if not isinstance(attrs, dict):
            return
        attrs["emotion_label"] = str(label or "unknown")
        attrs["emotion_confidence"] = float(confidence)
        attrs["emotion_source"] = str(source or "emotiefflib")
        attrs["emotion_accepted"] = bool(accepted)

    def _predict_emotion_crop(self, crop_bgr: Any) -> tuple[dict[str, Any] | None, str]:
        if self.cv2 is None:
            return None, "opencv unavailable"
        with self.emotion_lock:
            engine = str(self.emotion_engine or "onnx").strip().lower()
            recognizer = self.emotion_recognizer
            emotion_rknn = self.emotion_rknn
            rknn_input = int(self.emotion_rknn_input)
            rknn_layout = str(self.emotion_rknn_layout or "nchw").strip().lower()
            rknn_dtype = str(self.emotion_rknn_dtype or "float32").strip().lower()
            rknn_color = str(self.emotion_rknn_color or "rgb").strip().lower()
            rknn_labels = list(self.emotion_rknn_labels)
            rknn_mean = np.asarray(self.emotion_rknn_mean, dtype=np.float32).reshape(1, 1, 3)
            rknn_std = np.asarray(self.emotion_rknn_std, dtype=np.float32).reshape(1, 1, 3)
            rknn_softmax = bool(self.emotion_rknn_softmax)
        if engine == "rknn":
            if emotion_rknn is None:
                return None, "emotion rknn model not initialized"
            try:
                img = self.cv2.resize(crop_bgr, (rknn_input, rknn_input))
                if rknn_color == "rgb":
                    img = self.cv2.cvtColor(img, self.cv2.COLOR_BGR2RGB)
                if rknn_dtype == "uint8":
                    img_in = img.astype(np.uint8, copy=False)
                else:
                    img_in = img.astype(np.float32, copy=False) / 255.0
                    img_in = (img_in - rknn_mean) / rknn_std
                if rknn_layout == "nchw":
                    img_in = np.transpose(img_in, (2, 0, 1))
                img_in = np.expand_dims(img_in, axis=0)
                data_format = [rknn_layout] if rknn_layout in ("nchw", "nhwc") else None
                if data_format is None:
                    outputs = emotion_rknn.inference(inputs=[img_in])
                else:
                    outputs = emotion_rknn.inference(inputs=[img_in], data_format=data_format)
            except TypeError:
                try:
                    outputs = emotion_rknn.inference(inputs=[img_in])
                except Exception as exc:
                    return None, f"emotion rknn inference failed: {exc}"
            except Exception as exc:
                return None, f"emotion rknn inference failed: {exc}"
            if outputs is None:
                return None, "emotion rknn inference returned no outputs"
            tensor = outputs[0] if isinstance(outputs, (list, tuple)) else outputs
            arr = np.asarray(tensor, dtype=np.float32)
            if arr.size == 0:
                return None, "emotion rknn output empty"
            if arr.ndim >= 2:
                arr = arr.reshape(arr.shape[0], -1)
                arr = arr[0]
            logits = arr.reshape(-1).astype(np.float32, copy=False)
            if logits.size == 0:
                return None, "emotion rknn output shape unsupported"
            logits = np.nan_to_num(logits, nan=-1e9, posinf=1e9, neginf=-1e9)
            m = float(np.max(logits))
            exp = np.exp(logits - m)
            probs = exp / max(1e-12, float(np.sum(exp)))
            cls_id = int(np.argmax(probs))
            score = float(probs[cls_id])
            label_raw = (
                str(rknn_labels[cls_id])
                if 0 <= cls_id < len(rknn_labels)
                else f"class_{int(cls_id)}"
            )
            label = self._normalize_emotion_label(label_raw)
            confidence = score if rknn_softmax else float(np.max(logits))
            if not np.isfinite(confidence):
                confidence = score
            confidence = float(np.clip(confidence, 0.0, 1.0))
            accepted = bool(confidence >= float(self.emotion_min_confidence))
            return {
                "emotion_label": label,
                "emotion_label_raw": label_raw,
                "emotion_confidence": confidence,
                "emotion_accepted": accepted,
            }, ""
        if recognizer is None:
            return None, "emotion model not initialized"
        try:
            rgb = self.cv2.cvtColor(crop_bgr, self.cv2.COLOR_BGR2RGB)
            labels, scores = recognizer.predict_emotions(rgb, logits=False)
            if not labels:
                return None, "emotion label empty"
            label_raw = str(labels[0] or "")
            label = self._normalize_emotion_label(label_raw)
            score_arr = np.asarray(scores[0], dtype=np.float32).reshape(-1)
            confidence = float(np.max(score_arr)) if score_arr.size > 0 else 0.0
            accepted = bool(confidence >= float(self.emotion_min_confidence))
            return {
                "emotion_label": label,
                "emotion_label_raw": label,
                "emotion_confidence": confidence,
                "emotion_accepted": accepted,
            }, ""
        except Exception as exc:
            return None, f"emotion predict failed: {exc}"

    def _set_emotion_cache(self, cache_items: list[dict[str, Any]]) -> None:
        now = time.time()
        with self.emotion_cache_lock:
            self.emotion_last_eval_ts = now
            self.emotion_cache_ts = now
            self.emotion_cache_items = [dict(item) for item in cache_items]

    def _emotion_refresh_worker(self, frame: Any, objects: list[dict[str, Any]]) -> None:
        try:
            self._infer_emotion(frame, objects, allow_compute=True)
        finally:
            with self.emotion_refresh_lock:
                self.emotion_refresh_pending = False

    def _schedule_emotion_refresh(self, frame: Any, objects: list[dict[str, Any]]) -> None:
        if not self.emotion_enabled or frame is None or not objects:
            return
        with self.emotion_refresh_lock:
            if self.emotion_refresh_pending:
                return
            self.emotion_refresh_pending = True
        try:
            frame_copy = frame.copy()
        except Exception:
            with self.emotion_refresh_lock:
                self.emotion_refresh_pending = False
            return
        obj_copy = self._clone_detection_objects(objects)
        thread = threading.Thread(
            target=self._emotion_refresh_worker,
            args=(frame_copy, obj_copy),
            name="vision-emotion-refresh",
            daemon=True,
        )
        thread.start()

    def _apply_emotion_cache(
        self, objects: list[dict[str, Any]], max_age_ms: float | None = None
    ) -> dict[str, Any] | None:
        now = time.time()
        ttl_ms = float(self.emotion_cache_ttl_ms if max_age_ms is None else max_age_ms)
        with self.emotion_cache_lock:
            cache_ts = float(self.emotion_cache_ts)
            cache_items = [dict(item) for item in self.emotion_cache_items]
        if cache_ts <= 0 or not cache_items:
            return None
        cache_age_ms = max(0.0, (now - cache_ts) * 1000.0)
        if ttl_ms > 0 and cache_age_ms > ttl_ms:
            return None

        person_indices = self._emotion_person_indices(objects)
        used_cache_ids: set[int] = set()
        items: list[dict[str, Any]] = []
        emotion_count = 0
        evaluated = 0
        iou_threshold = float(self.emotion_cache_match_iou)
        dist_threshold = float(self.emotion_cache_max_center_dist)
        if self.face_only_mode:
            iou_threshold = min(iou_threshold, 0.20)
            dist_threshold = max(dist_threshold, 0.75)
        for obj_idx in person_indices:
            obj = objects[obj_idx]
            bbox = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
            row: dict[str, Any] = {
                "object_index": int(obj_idx),
                "bbox_xyxy": bbox if bbox is not None else None,
            }
            if bbox is None:
                row["ok"] = False
                row["error"] = "invalid bbox"
                items.append(row)
                continue

            best_id = -1
            best_iou = 0.0
            best_dist_norm = 999.0
            for cid, cache in enumerate(cache_items):
                if cid in used_cache_ids:
                    continue
                cache_bbox = self._normalize_bbox_xyxy(cache.get("bbox_xyxy"))
                if cache_bbox is None:
                    continue
                iou = self._bbox_iou_xyxy(bbox, cache_bbox)
                dist_norm = self._bbox_center_dist_norm(bbox, cache_bbox)
                if iou > best_iou or (abs(iou - best_iou) < 1e-9 and dist_norm < best_dist_norm):
                    best_iou = iou
                    best_dist_norm = dist_norm
                    best_id = cid

            iou_ok = best_iou >= iou_threshold
            dist_ok = best_dist_norm <= dist_threshold
            if best_id < 0 or not (iou_ok or dist_ok):
                row["ok"] = False
                row["error"] = "cache miss"
                items.append(row)
                continue

            used_cache_ids.add(best_id)
            cached = cache_items[best_id]
            label = str(cached.get("emotion_label") or "unknown")
            confidence = float(cached.get("emotion_confidence") or 0.0)
            accepted = bool(cached.get("emotion_accepted", True))
            source = str(cached.get("emotion_source") or "emotion_cache")
            self._apply_person_emotion_attrs(obj, label, confidence, source, accepted)
            row.update(
                {
                    "ok": True,
                    "emotion_label": label,
                    "emotion_confidence": confidence,
                    "emotion_accepted": accepted,
                    "cached": True,
                    "match_iou": round(best_iou, 3),
                    "match_dist_norm": round(best_dist_norm, 3),
                }
            )
            if accepted:
                emotion_count += 1
            evaluated += 1
            items.append(row)

        return {
            "ok": True,
            "enabled": bool(self.emotion_enabled),
            "cached": True,
            "engine": self.emotion_engine or None,
            "model": self.emotion_model_name or None,
            "require_face": bool(self.emotion_require_face),
            "face_detector_requested": self._face_detector_requested_mode(),
            "face_detector": self._face_detector_active_mode()
            or self._face_detector_requested_mode(),
            "max_persons": int(self.emotion_max_persons),
            "min_confidence": float(self.emotion_min_confidence),
            "items": items,
            "emotion_count": int(emotion_count),
            "person_candidates": int(len(person_indices)),
            "person_evaluated": int(evaluated),
            "face_count": 0,
            "cache_age_ms": round(cache_age_ms, 2),
        }

    def _infer_emotion(
        self,
        frame: Any,
        objects: list[dict[str, Any]],
        allow_compute: bool = True,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        base = {
            "ok": False,
            "enabled": bool(self.emotion_enabled),
            "cached": False,
            "engine": self.emotion_engine or None,
            "model": self.emotion_model_name or None,
            "require_face": bool(self.emotion_require_face),
            "face_detector_requested": self._face_detector_requested_mode(),
            "face_detector": self._face_detector_active_mode()
            or self._face_detector_requested_mode(),
            "max_persons": int(self.emotion_max_persons),
            "min_confidence": float(self.emotion_min_confidence),
            "items": [],
            "emotion_count": 0,
            "person_candidates": 0,
            "person_evaluated": 0,
            "face_count": 0,
        }
        if not self.emotion_enabled:
            base["error"] = "emotion disabled by config"
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        person_indices = self._emotion_person_indices(objects)
        base["person_candidates"] = int(len(person_indices))
        if not person_indices:
            if not self.face_only_mode:
                self._set_emotion_cache([])
            base["ok"] = True
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        with self.emotion_cache_lock:
            last_eval_ts = float(self.emotion_last_eval_ts)
        since_eval_ms = (
            max(0.0, (time.time() - last_eval_ts) * 1000.0) if last_eval_ts > 0 else None
        )
        cached_payload = self._apply_emotion_cache(objects)
        if cached_payload is not None:
            cached_payload["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            if since_eval_ms is not None:
                cached_payload["since_eval_ms"] = round(since_eval_ms, 2)
            need_refresh = bool(allow_compute) and (
                int(cached_payload.get("person_evaluated") or 0)
                < int(cached_payload.get("person_candidates") or 0)
            )
            if (not allow_compute) or (
                since_eval_ms is not None
                and since_eval_ms < float(self.emotion_update_interval_ms)
                and not need_refresh
            ):
                return cached_payload

        if not allow_compute:
            base["error"] = "emotion cache warming"
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        if not self.emotion_infer_lock.acquire(blocking=False):
            cached_payload = self._apply_emotion_cache(
                objects, max_age_ms=max(self.emotion_cache_ttl_ms, 5000.0)
            )
            if cached_payload is not None:
                cached_payload["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                cached_payload["stale"] = True
                return cached_payload
            base["error"] = "emotion busy"
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base

        try:
            with self.emotion_cache_lock:
                last_eval_ts = float(self.emotion_last_eval_ts)
            since_eval_ms = (
                max(0.0, (time.time() - last_eval_ts) * 1000.0) if last_eval_ts > 0 else None
            )
            if (
                since_eval_ms is not None
                and since_eval_ms < float(self.emotion_update_interval_ms)
            ):
                cached_payload = self._apply_emotion_cache(objects)
                if cached_payload is not None:
                    cached_payload["latency_ms"] = round(
                        (time.perf_counter() - started) * 1000.0, 2
                    )
                    cached_payload["since_eval_ms"] = round(since_eval_ms, 2)
                    return cached_payload

            ready, ready_err = self._ensure_emotion_model()
            if not ready:
                base["error"] = ready_err or "emotion model unavailable"
                base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                return base

            items: list[dict[str, Any]] = []
            emotion_count = 0
            cache_items: list[dict[str, Any]] = []
            faces: list[dict[str, Any]] = []
            face_err = ""
            has_body_targets = any(
                not self._is_face_object(objects[obj_idx]) for obj_idx in person_indices
            )
            source_prefix = "emotion_rknn" if self.emotion_engine == "rknn" else "emotiefflib"
            if has_body_targets and self._face_detector_requested_enabled():
                faces, face_err = self._detect_faces(frame)
            base["face_count"] = int(len(faces))
            if face_err and self.emotion_require_face and has_body_targets:
                base["error"] = face_err
                base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                return base
            if face_err:
                base["face_error"] = face_err

            used_face_ids: set[int] = set()
            for obj_idx in person_indices:
                obj = objects[obj_idx]
                bbox_list = self._normalize_bbox_xyxy(obj.get("bbox_xyxy"))
                is_face_target = self._is_face_object(obj)
                row: dict[str, Any] = {
                    "object_index": int(obj_idx),
                    "bbox_xyxy": bbox_list if bbox_list is not None else None,
                    "target": "face" if is_face_target else "person",
                }
                crop = None
                source = (
                    f"{source_prefix}_face_box" if is_face_target else f"{source_prefix}_upper"
                )
                face_bbox: list[int] | None = None
                matched_landmarks: list[list[int]] | None = None
                if is_face_target and bbox_list is not None:
                    crop, face_bbox = self._crop_bbox_with_expand(
                        frame=frame,
                        bbox_xyxy=bbox_list,
                        scale=float(self.face_attr_expand),
                        min_side=20,
                    )
                elif bbox_list is not None and faces:
                    x1, y1, x2, y2 = [int(v) for v in bbox_list]
                    person_h = max(1, y2 - y1)
                    top_limit = y1 + int(round(person_h * 0.75))
                    best_face_id = -1
                    best_score = -1.0
                    for fid, face in enumerate(faces):
                        if fid in used_face_ids:
                            continue
                        fbbox = self._normalize_bbox_xyxy(face.get("bbox_xyxy"))
                        if fbbox is None:
                            continue
                        fx1, fy1, fx2, fy2 = [int(v) for v in fbbox]
                        fcx = (fx1 + fx2) * 0.5
                        fcy = (fy1 + fy2) * 0.5
                        inside = bool(x1 <= fcx <= x2 and y1 <= fcy <= y2)
                        if not inside:
                            continue
                        top_bonus = 0.8 if fcy <= top_limit else 0.0
                        iou = self._bbox_iou_xyxy(bbox_list, fbbox)
                        score = float(face.get("score", 0.0)) * 0.3 + iou + top_bonus
                        if score > best_score:
                            best_score = score
                            best_face_id = fid
                    if best_face_id >= 0:
                        used_face_ids.add(best_face_id)
                        fbbox = self._normalize_bbox_xyxy(faces[best_face_id].get("bbox_xyxy"))
                        if fbbox is not None:
                            expanded = self._expand_bbox_xyxy(
                                fbbox,
                                frame_w=int(frame.shape[1]),
                                frame_h=int(frame.shape[0]),
                                scale=float(self.emotion_face_expand),
                            )
                            face_bbox = expanded if expanded is not None else fbbox
                            fx1, fy1, fx2, fy2 = [int(v) for v in face_bbox]
                            face_crop = frame[fy1:fy2, fx1:fx2]
                            if face_crop is not None and face_crop.size > 0:
                                crop = face_crop
                                source = f"{source_prefix}_face"
                            matched_landmarks = self._normalize_face_landmarks_xy(
                                faces[best_face_id].get("landmarks_xy")
                            )
                if crop is None and bbox_list is not None and not self.emotion_require_face:
                    if is_face_target:
                        crop, face_bbox = self._crop_bbox_with_expand(
                            frame=frame,
                            bbox_xyxy=bbox_list,
                            scale=float(self.face_attr_expand),
                            min_side=20,
                        )
                        source = f"{source_prefix}_face_box"
                    else:
                        crop = self._person_face_crop(frame, bbox_list)
                if crop is None:
                    row["ok"] = False
                    row["error"] = "face not found"
                    items.append(row)
                    continue
                if face_bbox is not None:
                    row["face_bbox_xyxy"] = [int(v) for v in face_bbox]
                    attrs = obj.setdefault("attributes", {})
                    if isinstance(attrs, dict):
                        attrs["face_bbox_xyxy"] = [int(v) for v in face_bbox]
                    if isinstance(attrs, dict) and matched_landmarks is not None:
                        attrs["face_landmarks_xy"] = [
                            [int(p[0]), int(p[1])] for p in matched_landmarks
                        ]
                pred, pred_err = self._predict_emotion_crop(crop)
                if pred is None:
                    row["ok"] = False
                    row["error"] = pred_err or "emotion predict failed"
                    items.append(row)
                    continue
                row["ok"] = True
                row.update(pred)
                items.append(row)
                label = str(pred.get("emotion_label") or "unknown")
                confidence = float(pred.get("emotion_confidence") or 0.0)
                accepted = bool(pred.get("emotion_accepted", True))
                self._apply_person_emotion_attrs(obj, label, confidence, source, accepted)
                if accepted:
                    emotion_count += 1
                cache_bbox = face_bbox if face_bbox is not None else bbox_list
                if cache_bbox is not None:
                    cache_items.append(
                        {
                            "bbox_xyxy": cache_bbox,
                            "emotion_label": label,
                            "emotion_confidence": confidence,
                            "emotion_accepted": accepted,
                            "emotion_source": source,
                        }
                    )

            self._set_emotion_cache(cache_items)
            base["ok"] = True
            base["items"] = items
            base["person_evaluated"] = int(len(items))
            base["emotion_count"] = int(emotion_count)
            base["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            return base
        finally:
            self.emotion_infer_lock.release()

    def _draw_objects(self, frame: Any, objects: list[dict[str, Any]]) -> None:
        if self.cv2 is None:
            return
        cv2 = self.cv2
        h, w = frame.shape[:2]
        for obj in objects:
            xyxy = obj.get("bbox_xyxy")
            if isinstance(xyxy, list) and len(xyxy) == 4:
                x1, y1, x2, y2 = [int(v) for v in xyxy]
            else:
                xywh = obj.get("bbox_xywh")
                if not isinstance(xywh, list) or len(xywh) != 4:
                    continue
                x, y, bw, bh = [int(v) for v in xywh]
                x1, y1 = x, y
                x2, y2 = x + bw, y + bh

            x1 = max(0, min(w - 1, x1))
            y1 = max(0, min(h - 1, y1))
            x2 = max(0, min(w - 1, x2))
            y2 = max(0, min(h - 1, y2))
            if x2 <= x1 or y2 <= y1:
                continue

            obj_type = str(obj.get("type", ""))
            is_yolo = obj_type in ("yolo", "yolo_world")
            is_face = obj_type == "face"
            if is_yolo:
                color = (50, 220, 50)
            elif is_face:
                color = (60, 210, 255)
            else:
                color = (0, 190, 255)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

            if is_yolo or is_face:
                score = float(obj.get("score") or 0.0)
                cls_id = int(obj.get("class_id") or 0)
                cls_name = str(obj.get("class_name") or "").strip()
                if cls_name:
                    label = f"{cls_name} {score:.2f}"
                else:
                    label = f"cls{cls_id} {score:.2f}"
                attrs = obj.get("attributes")
                if isinstance(attrs, dict) and "wear_glasses" in attrs:
                    wg = bool(attrs.get("wear_glasses"))
                    label = f"{label} wg={'yes' if wg else 'no'}"
                if isinstance(attrs, dict) and "emotion_label" in attrs:
                    emo = str(attrs.get("emotion_label") or "").strip().lower()
                    if emo and (not bool(attrs.get("emotion_accepted", True))):
                        emo = f"{emo}?"
                    if emo:
                        label = f"{label} emo={emo}"
                if isinstance(attrs, dict):
                    identity_label = str(attrs.get("identity_label") or "").strip()
                    if bool(attrs.get("identity_match")) and identity_label:
                        label = f"{label} id={identity_label}"
                    elif identity_label:
                        label = f"{label} id={identity_label}"
                if isinstance(attrs, dict) and attrs.get("face_pose_label"):
                    face_pose = str(attrs.get("face_pose_label") or "").strip().lower()
                    if face_pose:
                        label = f"{label} face={face_pose}"
            else:
                label = str(obj.get("type") or "obj")

            font = cv2.FONT_HERSHEY_SIMPLEX
            scale = 0.5
            thickness = 1
            (txt_w, txt_h), baseline = cv2.getTextSize(label, font, scale, thickness)
            by2 = y1 if y1 > txt_h + 8 else min(h - 1, y1 + txt_h + 8)
            by1 = max(0, by2 - txt_h - baseline - 6)
            bx2 = min(w - 1, x1 + txt_w + 8)
            cv2.rectangle(frame, (x1, by1), (bx2, by2), color, -1)
            cv2.putText(
                frame,
                label,
                (x1 + 4, max(0, by2 - baseline - 3)),
                font,
                scale,
                (0, 0, 0),
                thickness,
                cv2.LINE_AA,
            )

    def _annotate_frame(
        self,
        frame: Any,
        detector: str,
        frame_ts: float = 0.0,
        wear_glasses: bool | None = None,
        emotion: bool | None = None,
        recognize: bool | None = None,
    ) -> tuple[str, int, str, dict[str, Any]]:
        mode = (detector or "none").strip().lower()
        if mode in ("yolo11", "yolo-11", "yolo_11"):
            mode = "yolo"
        if mode in ("face+world", "face_world", "face-world", "fusion"):
            mode = "face_world"
        if self.face_only_mode and mode not in ("none", "off", "face", "face_world"):
            mode = "face"
        wear_glasses_requested = bool(
            self.wear_glasses_auto if wear_glasses is None else bool(wear_glasses)
        )
        emotion_requested = bool(self.emotion_auto if emotion is None else bool(emotion))
        recognize_requested = bool(
            self.face_recognition_auto if recognize is None else bool(recognize)
        )
        if mode in ("", "none", "off"):
            return "", 0, "no detector", {"detect_ms": 0.0}
        if mode in ("face", "face_world"):
            started = time.perf_counter()
            use_world_fusion = mode == "face_world"
            meta: dict[str, Any] = {}
            if use_world_fusion:
                objects, detect_err, fusion_meta = self._detect_face_world_objects(
                    frame, frame_ts=frame_ts
                )
                meta.update(fusion_meta)
                if detect_err and not objects:
                    return detect_err, 0, "", meta
            else:
                objects, face_err = self._detect_face_objects(
                    frame,
                    frame_ts=frame_ts,
                    use_world_fusion=False,
                    world_strict=False,
                )
                meta["detect_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                if face_err and not objects:
                    return face_err, 0, "", meta
                if face_err:
                    meta["face_error"] = face_err
            if recognize_requested:
                face_rec_payload = self._recognize_faces(frame, objects, recognize=recognize)
                meta["face_recognition_ms"] = round(
                    float(face_rec_payload.get("latency_ms") or 0.0), 2
                )
                meta["face_recognition_ok"] = bool(face_rec_payload.get("ok", False))
                meta["face_recognition_ready"] = bool(face_rec_payload.get("ready", False))
                meta["face_recognition_recognized"] = int(
                    face_rec_payload.get("recognized") or 0
                )
                if not bool(face_rec_payload.get("ok", False)):
                    meta["face_recognition_error"] = face_rec_payload.get("error")
            if wear_glasses_requested:
                wear_payload = self._infer_wear_glasses(frame, objects, allow_compute=False)
                if (
                    int(wear_payload.get("person_evaluated") or 0)
                    < int(wear_payload.get("person_candidates") or 0)
                ):
                    self._schedule_wear_glasses_refresh(frame, objects)
                meta["wear_glasses_ms"] = round(
                    float(wear_payload.get("latency_ms") or 0.0), 2
                )
                meta["wear_glasses_ok"] = bool(wear_payload.get("ok", False))
                meta["wear_glasses_cached"] = bool(wear_payload.get("cached", False))
                if not bool(wear_payload.get("ok", False)):
                    meta["wear_glasses_error"] = wear_payload.get("error")
            if emotion_requested:
                emotion_payload = self._infer_emotion(frame, objects, allow_compute=False)
                if (
                    int(emotion_payload.get("person_evaluated") or 0)
                    < int(emotion_payload.get("person_candidates") or 0)
                ):
                    self._schedule_emotion_refresh(frame, objects)
                meta["emotion_ms"] = round(
                    float(emotion_payload.get("latency_ms") or 0.0), 2
                )
                meta["emotion_ok"] = bool(emotion_payload.get("ok", False))
                meta["emotion_cached"] = bool(emotion_payload.get("cached", False))
                if not bool(emotion_payload.get("ok", False)):
                    meta["emotion_error"] = emotion_payload.get("error")
            self._draw_objects(frame, objects)
            if objects:
                best = objects[0]
                best_attrs = best.get("attributes")
                best_id = (
                    str(best_attrs.get("identity_label") or "").strip()
                    if isinstance(best_attrs, dict)
                    else ""
                )
                best_match = bool(best_attrs.get("identity_match")) if isinstance(best_attrs, dict) else False
                if best_match and best_id:
                    summary = (
                        f"best face id={best_id} "
                        f"score={float(best.get('score') or 0.0):.2f}"
                    )
                else:
                    summary = f"best face score={float(best.get('score') or 0.0):.2f}"
            else:
                summary = "no face"
            return "", len(objects), summary, meta
        if mode == "rect":
            started = time.perf_counter()
            objects = self._detect_rectangles(frame)
            self._draw_objects(frame, objects)
            return (
                "",
                len(objects),
                f"rect objects={len(objects)}",
                {"detect_ms": round((time.perf_counter() - started) * 1000.0, 2)},
            )
        if mode == "yolo":
            started = time.perf_counter()
            objects, yolo_err = self._detect_yolo(frame)
            meta = {
                "detect_ms": round((time.perf_counter() - started) * 1000.0, 2),
                "suppressed_spike": bool(self.yolo_last_suppressed_spike),
            }
            if yolo_err:
                return (yolo_err, 0, "", meta)
            self._draw_objects(frame, objects)
            if objects:
                best = objects[0]
                summary = (
                    f"best yolo cls={best.get('class_id')} "
                    f"score={float(best.get('score') or 0.0):.2f}"
                )
            else:
                summary = "no target"
            return (
                "",
                len(objects),
                summary,
                meta,
            )
        if mode == "yolo_world":
            world_meta: dict[str, Any] = {}
            if self.yolo_world_async_enabled:
                async_res = self._yolo_world_async_get(max_age_ms=1000.0)
                if async_res is not None:
                    objects, world_err, world_meta = async_res
                else:
                    objects, world_err, world_meta = self._detect_yolo_world(frame, frame_ts=frame_ts)
                    world_meta["fallback_sync"] = True
            else:
                objects, world_err, world_meta = self._detect_yolo_world(frame, frame_ts=frame_ts)
            if world_err:
                return world_err, 0, "", world_meta
            if wear_glasses_requested:
                wear_payload = self._infer_wear_glasses(frame, objects, allow_compute=False)
                world_meta["wear_glasses_ms"] = round(
                    float(wear_payload.get("latency_ms") or 0.0), 2
                )
                world_meta["wear_glasses_ok"] = bool(wear_payload.get("ok", False))
                world_meta["wear_glasses_cached"] = bool(wear_payload.get("cached", False))
                if not bool(wear_payload.get("ok", False)):
                    world_meta["wear_glasses_error"] = wear_payload.get("error")
            if emotion_requested:
                emotion_payload = self._infer_emotion(frame, objects, allow_compute=False)
                world_meta["emotion_ms"] = round(
                    float(emotion_payload.get("latency_ms") or 0.0), 2
                )
                world_meta["emotion_ok"] = bool(emotion_payload.get("ok", False))
                world_meta["emotion_cached"] = bool(emotion_payload.get("cached", False))
                if not bool(emotion_payload.get("ok", False)):
                    world_meta["emotion_error"] = emotion_payload.get("error")
            head_meta = self._replace_person_boxes_with_head(
                frame, objects, allow_face_detect=bool(self.person_head_face_detect_live)
            )
            world_meta["person_head_box_replaced"] = int(head_meta.get("head_replaced", 0))
            world_meta["person_head_face_used"] = int(head_meta.get("face_used", 0))
            if head_meta.get("face_error"):
                world_meta["person_head_face_error"] = head_meta.get("face_error")
            self._draw_objects(frame, objects)
            if objects:
                best = objects[0]
                cls_name = str(best.get("class_name") or f"class_{int(best.get('class_id') or 0)}")
                summary = (
                    f"best yolo_world cls={cls_name} "
                    f"score={float(best.get('score') or 0.0):.2f}"
                )
            else:
                summary = "no target"
            return "", len(objects), summary, world_meta
        return f"unsupported detector: {mode}", 0, "", {"detect_ms": 0.0}

    def observe(
        self,
        detector: str = "face",
        wear_glasses: bool | None = None,
        emotion: bool | None = None,
        recognize: bool | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        api_meta: dict[str, Any] = {}
        mode = (detector or "face").strip().lower()
        if mode in ("yolo11", "yolo-11", "yolo_11"):
            mode = "yolo"
        if mode in ("face+world", "face_world", "face-world", "fusion"):
            mode = "face_world"
        if mode == "off":
            mode = "none"
        if self.face_only_mode and mode not in ("none", "face", "face_world"):
            mode = "face"
        frame, err, ts = self._snapshot_frame()
        capture_retries = 0
        capture_retry_wait_ms = 0.0
        if frame is None and err in ("stale frame", "frame unavailable") and VISION_OBSERVE_RETRY_MS > 0:
            # Give the capture loop a short window to reopen and publish a fresh frame
            # before failing observe requests on transient stale/unavailable snapshots.
            if err == "stale frame":
                self.request_reopen("observe:stale-frame")
            retry_started = time.perf_counter()
            retry_deadline = retry_started + (VISION_OBSERVE_RETRY_MS / 1000.0)
            interval_sec = VISION_OBSERVE_RETRY_INTERVAL_MS / 1000.0
            while frame is None and time.perf_counter() < retry_deadline:
                time.sleep(interval_sec)
                capture_retries += 1
                frame, err, ts = self._snapshot_frame()
            capture_retry_wait_ms = max(0.0, (time.perf_counter() - retry_started) * 1000.0)
        api_meta["capture_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
        if capture_retries > 0:
            api_meta["capture_retries"] = int(capture_retries)
            api_meta["capture_retry_wait_ms"] = round(capture_retry_wait_ms, 2)
        if frame is None:
            age_ms = max(0.0, (time.time() - ts) * 1000.0) if ts > 0 else None
            api_meta["observe_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
            fail_payload = {
                "ok": False,
                "timestamp": _ts_now(),
                "error": err or "frame unavailable",
                "detector": mode,
                "camera": self._camera_state(frame_age_ms=age_ms),
                "objects": [],
                "best_target": None,
                "api": api_meta,
            }
            wear_glasses_requested = bool(
                self.wear_glasses_auto if wear_glasses is None else bool(wear_glasses)
            )
            emotion_requested = bool(self.emotion_auto if emotion is None else bool(emotion))
            recognize_requested = bool(
                self.face_recognition_auto if recognize is None else bool(recognize)
            )
            if wear_glasses_requested:
                fail_payload["wear_glasses"] = {
                    "ok": False,
                    "enabled": bool(self.wear_glasses_enabled),
                    "error": err or "frame unavailable",
                }
            if emotion_requested:
                fail_payload["emotion"] = {
                    "ok": False,
                    "enabled": bool(self.emotion_enabled),
                    "error": err or "frame unavailable",
                }
            if recognize_requested:
                fail_payload["face_recognition"] = {
                    "ok": False,
                    "enabled": bool(self.face_recognition_enabled),
                    "error": err or "frame unavailable",
                }
            return fail_payload

        h, w = frame.shape[:2]
        objects: list[dict[str, Any]] = []
        wear_glasses_payload: dict[str, Any] | None = None
        emotion_payload: dict[str, Any] | None = None
        face_recognition_payload: dict[str, Any] | None = None
        wear_glasses_requested = bool(
            self.wear_glasses_auto if wear_glasses is None else bool(wear_glasses)
        )
        emotion_requested = bool(self.emotion_auto if emotion is None else bool(emotion))
        recognize_requested = bool(
            self.face_recognition_auto if recognize is None else bool(recognize)
        )
        if mode in ("face", "face_world"):
            detect_started = time.perf_counter()
            use_world_fusion = mode == "face_world"
            if use_world_fusion:
                objects, detect_err, fusion_meta = self._detect_face_world_objects(
                    frame, frame_ts=ts
                )
                api_meta.update(fusion_meta)
                if "detect_ms" not in api_meta:
                    api_meta["detect_ms"] = round(
                        (time.perf_counter() - detect_started) * 1000.0, 2
                    )
                if detect_err and not objects:
                    age_ms = max(0.0, (time.time() - ts) * 1000.0) if ts > 0 else None
                    api_meta["observe_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                    return {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": detect_err,
                        "camera": self._camera_state(frame_age_ms=age_ms),
                        "api": api_meta,
                    }
            else:
                objects, face_err = self._detect_face_objects(
                    frame,
                    frame_ts=ts,
                    use_world_fusion=False,
                    world_strict=False,
                )
                api_meta["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
                if face_err and not objects:
                    age_ms = max(0.0, (time.time() - ts) * 1000.0) if ts > 0 else None
                    api_meta["observe_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                    return {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": face_err,
                        "camera": self._camera_state(frame_age_ms=age_ms),
                        "api": api_meta,
                    }
                if face_err:
                    api_meta["face_error"] = face_err
            if recognize_requested:
                face_recognition_payload = self._recognize_faces(frame, objects, recognize=recognize)
                api_meta["face_recognition_ms"] = round(
                    float(face_recognition_payload.get("latency_ms") or 0.0), 2
                )
                api_meta["face_recognition_ready"] = bool(
                    face_recognition_payload.get("ready", False)
                )
                api_meta["face_recognition_recognized"] = int(
                    face_recognition_payload.get("recognized") or 0
                )
                if not bool(face_recognition_payload.get("ok", False)):
                    api_meta["face_recognition_error"] = face_recognition_payload.get("error")
            if wear_glasses_requested:
                wear_glasses_payload = self._infer_wear_glasses(frame, objects, allow_compute=False)
                if (
                    int(wear_glasses_payload.get("person_evaluated") or 0)
                    < int(wear_glasses_payload.get("person_candidates") or 0)
                ):
                    self._schedule_wear_glasses_refresh(frame, objects)
                api_meta["wear_glasses_ms"] = round(
                    float(wear_glasses_payload.get("latency_ms") or 0.0), 2
                )
                api_meta["wear_glasses_cached"] = bool(wear_glasses_payload.get("cached", False))
                if not bool(wear_glasses_payload.get("ok", False)):
                    api_meta["wear_glasses_error"] = wear_glasses_payload.get("error")
            if emotion_requested:
                emotion_payload = self._infer_emotion(frame, objects, allow_compute=False)
                if (
                    int(emotion_payload.get("person_evaluated") or 0)
                    < int(emotion_payload.get("person_candidates") or 0)
                ):
                    self._schedule_emotion_refresh(frame, objects)
                api_meta["emotion_ms"] = round(
                    float(emotion_payload.get("latency_ms") or 0.0), 2
                )
                api_meta["emotion_cached"] = bool(emotion_payload.get("cached", False))
                if not bool(emotion_payload.get("ok", False)):
                    api_meta["emotion_error"] = emotion_payload.get("error")
        elif mode == "rect":
            detect_started = time.perf_counter()
            objects = self._detect_rectangles(frame)
            api_meta["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
        elif mode == "yolo":
            detect_started = time.perf_counter()
            objects, yolo_err = self._detect_yolo(frame)
            api_meta["detect_ms"] = round((time.perf_counter() - detect_started) * 1000.0, 2)
            api_meta["suppressed_spike"] = bool(self.yolo_last_suppressed_spike)
            if yolo_err:
                age_ms = max(0.0, (time.time() - ts) * 1000.0) if ts > 0 else None
                api_meta["observe_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": yolo_err,
                    "camera": self._camera_state(frame_age_ms=age_ms),
                    "api": api_meta,
                }
        elif mode == "yolo_world":
            if self.yolo_world_async_enabled:
                async_res = self._yolo_world_async_get(max_age_ms=1000.0)
                if async_res is not None:
                    objects, world_err, world_meta = async_res
                else:
                    objects, world_err, world_meta = self._detect_yolo_world(frame, frame_ts=ts)
                    world_meta["fallback_sync"] = True
            else:
                objects, world_err, world_meta = self._detect_yolo_world(frame, frame_ts=ts)
            api_meta.update(world_meta)
            if world_err:
                age_ms = max(0.0, (time.time() - ts) * 1000.0) if ts > 0 else None
                api_meta["observe_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
                return {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": world_err,
                    "camera": self._camera_state(frame_age_ms=age_ms),
                    "api": api_meta,
                }
            if wear_glasses_requested:
                wear_glasses_payload = self._infer_wear_glasses(
                    frame, objects, allow_compute=False
                )
                if (
                    int(wear_glasses_payload.get("person_evaluated") or 0)
                    < int(wear_glasses_payload.get("person_candidates") or 0)
                ):
                    self._schedule_wear_glasses_refresh(frame, objects)
                api_meta["wear_glasses_ms"] = round(
                    float(wear_glasses_payload.get("latency_ms") or 0.0), 2
                )
                api_meta["wear_glasses_cached"] = bool(wear_glasses_payload.get("cached", False))
                if not bool(wear_glasses_payload.get("ok", False)):
                    api_meta["wear_glasses_error"] = wear_glasses_payload.get("error")
            if emotion_requested:
                emotion_payload = self._infer_emotion(frame, objects, allow_compute=False)
                if (
                    int(emotion_payload.get("person_evaluated") or 0)
                    < int(emotion_payload.get("person_candidates") or 0)
                ):
                    self._schedule_emotion_refresh(frame, objects)
                api_meta["emotion_ms"] = round(
                    float(emotion_payload.get("latency_ms") or 0.0), 2
                )
                api_meta["emotion_cached"] = bool(emotion_payload.get("cached", False))
                if not bool(emotion_payload.get("ok", False)):
                    api_meta["emotion_error"] = emotion_payload.get("error")
            head_meta = self._replace_person_boxes_with_head(frame, objects, allow_face_detect=True)
            api_meta["person_head_box_replaced"] = int(head_meta.get("head_replaced", 0))
            api_meta["person_head_face_used"] = int(head_meta.get("face_used", 0))
            if head_meta.get("face_error"):
                api_meta["person_head_face_error"] = head_meta.get("face_error")
        elif mode in ("none", "off"):
            objects = []
            if wear_glasses_requested:
                wear_glasses_payload = {
                    "ok": False,
                    "enabled": bool(self.wear_glasses_enabled),
                    "error": "wear_glasses requires detector=face|yolo_world",
                }
            if emotion_requested:
                emotion_payload = {
                    "ok": False,
                    "enabled": bool(self.emotion_enabled),
                    "error": "emotion requires detector=face|yolo_world",
                }
        else:
            return {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"unsupported detector: {mode}",
            }

        age_ms = max(0.0, (time.time() - ts) * 1000.0) if ts > 0 else None
        camera_state = self._camera_state(frame_age_ms=age_ms)

        best = objects[0] if objects else None
        if best is None:
            summary = "no target"
        elif best.get("type") == "face":
            best_attrs = best.get("attributes")
            best_id = (
                str(best_attrs.get("identity_label") or "").strip()
                if isinstance(best_attrs, dict)
                else ""
            )
            best_match = bool(best_attrs.get("identity_match")) if isinstance(best_attrs, dict) else False
            if best_match and best_id:
                summary = (
                    f"best face id={best_id} "
                    f"score={float(best.get('score') or 0.0):.2f} "
                    f"at ({best['cx']:.1f}, {best['cy']:.1f}), area={best['area']:.0f}"
                )
            else:
                summary = (
                    f"best face score={float(best.get('score') or 0.0):.2f} "
                    f"at ({best['cx']:.1f}, {best['cy']:.1f}), area={best['area']:.0f}"
                )
        elif best.get("type") == "yolo":
            summary = (
                f"best yolo cls={best.get('class_id')} "
                f"score={float(best.get('score') or 0.0):.2f} "
                f"at ({best['cx']:.1f}, {best['cy']:.1f}), area={best['area']:.0f}"
            )
        elif best.get("type") == "yolo_world":
            cls_name = str(best.get("class_name") or f"class_{int(best.get('class_id') or 0)}")
            summary = (
                f"best yolo_world cls={cls_name} "
                f"score={float(best.get('score') or 0.0):.2f} "
                f"at ({best['cx']:.1f}, {best['cy']:.1f}), area={best['area']:.0f}"
            )
        else:
            summary = f"best rect at ({best['cx']:.1f}, {best['cy']:.1f}), area={best['area']:.0f}"

        return {
            "ok": True,
            "timestamp": _ts_now(),
            "camera": camera_state,
            "frame": {"width": int(w), "height": int(h)},
            "objects": objects,
            "best_target": best,
            "summary": summary,
            **({"wear_glasses": wear_glasses_payload} if wear_glasses_payload is not None else {}),
            **(
                {"face_recognition": face_recognition_payload}
                if face_recognition_payload is not None
                else {}
            ),
            **({"emotion": emotion_payload} if emotion_payload is not None else {}),
            "api": {
                **api_meta,
                "observe_ms": round((time.perf_counter() - started) * 1000.0, 2),
            },
        }

    def frame_jpeg(
        self,
        detector: str = "face",
        wear_glasses: bool | None = None,
        emotion: bool | None = None,
        recognize: bool | None = None,
    ) -> tuple[bytes | None, str, dict[str, Any]]:
        started = time.perf_counter()
        mode = (detector or "face").strip().lower()
        if mode in ("yolo11", "yolo-11", "yolo_11"):
            mode = "yolo"
        if mode in ("face+world", "face_world", "face-world", "fusion"):
            mode = "face_world"
        if mode == "off":
            mode = "none"
        if self.face_only_mode and mode not in ("none", "face", "face_world"):
            mode = "face"
        if mode not in ("none", "rect", "yolo", "yolo_world", "face", "face_world"):
            return None, f"unsupported detector: {mode}", {"detector": mode, "objects": 0}

        if mode == "none":
            with self.lock:
                latest_ts = float(self.latest_frame_ts)
                cached = self.last_frame_jpeg
                cached_source_ts = self.last_jpeg_source_ts
            if (
                cached is not None
                and latest_ts > 0
                and abs(float(cached_source_ts) - latest_ts) < 1e-6
            ):
                return (
                    cached,
                    "",
                    {
                        "detector": mode,
                        "objects": 0,
                        "source_frame_ts": float(cached_source_ts),
                        "timing": {"total_ms": round((time.perf_counter() - started) * 1000.0, 2)},
                    },
                )

        frame, err, frame_ts = self._snapshot_frame(copy_frame=(mode != "none"))
        if frame is None:
            with self.lock:
                cached = self.last_frame_jpeg
                cached_source_ts = self.last_jpeg_source_ts
            if cached is not None:
                return (
                    cached,
                    "",
                    {
                        "detector": mode,
                        "objects": 0,
                        "source_frame_ts": float(cached_source_ts) if cached_source_ts > 0 else 0.0,
                        "timing": {"total_ms": round((time.perf_counter() - started) * 1000.0, 2)},
                    },
                )
            return None, err or "frame unavailable", {"detector": mode, "objects": 0}

        meta: dict[str, Any] = {
            "detector": mode,
            "objects": 0,
            "summary": "",
            "source_frame_ts": float(frame_ts) if frame_ts > 0 else 0.0,
            "timing": {"capture_ms": round((time.perf_counter() - started) * 1000.0, 2)},
        }

        if mode == "none":
            with self.lock:
                if (
                    self.last_frame_jpeg is not None
                    and frame_ts > 0
                    and abs(self.last_jpeg_source_ts - frame_ts) < 1e-6
                ):
                    return self.last_frame_jpeg, "", meta
        else:
            ann_err, obj_count, summary, ann_meta = self._annotate_frame(
                frame,
                mode,
                frame_ts=frame_ts,
                wear_glasses=wear_glasses,
                emotion=emotion,
                recognize=recognize,
            )
            if ann_err:
                return None, ann_err, {"detector": mode, "objects": 0}
            meta["objects"] = int(obj_count)
            meta["summary"] = summary
            meta["timing"].update(ann_meta)

        stream_frame = self._prepare_stream_frame(frame)
        try:
            out_h, out_w = stream_frame.shape[:2]
            meta["stream_frame"] = {"width": int(out_w), "height": int(out_h)}
        except Exception:
            pass
        enc_started = time.perf_counter()
        jpeg, enc_err = self._encode_jpeg(stream_frame)
        meta["timing"]["encode_ms"] = round((time.perf_counter() - enc_started) * 1000.0, 2)
        meta["timing"]["total_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
        if jpeg is not None:
            if mode == "none":
                with self.lock:
                    self.last_frame_jpeg = jpeg
                    self.last_jpeg_ts = time.time()
                    self.last_jpeg_source_ts = frame_ts
            return jpeg, "", meta
        with self.lock:
            cached = self.last_frame_jpeg
            cached_source_ts = self.last_jpeg_source_ts
        if cached is not None:
            meta["source_frame_ts"] = float(cached_source_ts) if cached_source_ts > 0 else 0.0
            return cached, "", meta
        return None, enc_err or "jpeg encode failed", meta
