﻿#!/usr/bin/env python3
from __future__ import annotations

import json
import http.client
import os
import re
import socket
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib import error as urlerror
from urllib import request as urlrequest
from urllib.parse import quote, urlencode, urlsplit

from ipc_http import bind_server, compose_request_path, open_connection, tcp_probe

HOST = os.environ.get("LLM_PREVIEW_HOST", "0.0.0.0")
PORT = int(os.environ.get("LLM_PREVIEW_PORT", "8091"))
UNIX_SOCKET_PATH = str(os.environ.get("LLM_UNIX_SOCKET", "")).strip()

VISION_API_BASE = os.environ.get("VISION_API_BASE", "http://127.0.0.1:8092").rstrip("/")
RKLLM_URL = os.environ.get("RKLLM_URL", "http://127.0.0.1:8080/rkllm_chat").strip()
_RKLLM_PARTS = urlsplit(RKLLM_URL)
_RKLLM_ABORT_DEFAULT = (
    f"{_RKLLM_PARTS.scheme}://{_RKLLM_PARTS.netloc}/rkllm_abort"
    if _RKLLM_PARTS.scheme and _RKLLM_PARTS.netloc
    else ""
)
RKLLM_ABORT_URL = os.environ.get("RKLLM_ABORT_URL", _RKLLM_ABORT_DEFAULT).strip()
LLM_ABORT_ON_TIMEOUT = os.environ.get("LLM_ABORT_ON_TIMEOUT", "1") not in ("0", "false", "False")
LLM_TIMEOUT_ABORT_SETTLE_SEC = max(
    0.0,
    min(15.0, float(os.environ.get("LLM_TIMEOUT_ABORT_SETTLE_SEC", "2.0"))),
)

LLM_PROXY_TIMEOUT_SEC = max(3.0, float(os.environ.get("LLM_PROXY_TIMEOUT_SEC", "30")))
LLM_DEFENSE_TIMEOUT_SEC = max(5.0, float(os.environ.get("LLM_DEFENSE_TIMEOUT_SEC", "120")))
LLM_PROXY_RETRIES = max(0, int(os.environ.get("LLM_PROXY_RETRIES", "2")))
LLM_DEFENSE_RETRIES = max(0, int(os.environ.get("LLM_DEFENSE_RETRIES", "6")))
LLM_RETRY_DELAY_SEC = max(0.05, float(os.environ.get("LLM_RETRY_DELAY_SEC", "0.35")))
LLM_AGENT_DEFAULT_TIMEOUT_SEC = max(
    1.0,
    min(60.0, float(os.environ.get("LLM_AGENT_DEFAULT_TIMEOUT_SEC", "4.5"))),
)
LLM_AGENT_BUSY_RETRIES = max(0, int(os.environ.get("LLM_AGENT_BUSY_RETRIES", "2")))
LLM_AGENT_BUSY_RETRY_DELAY_SEC = max(
    0.02, float(os.environ.get("LLM_AGENT_BUSY_RETRY_DELAY_SEC", "0.12"))
)

LLM_SINGLE_FLIGHT = os.environ.get("LLM_SINGLE_FLIGHT", "1") not in ("0", "false", "False")
LLM_QUEUE_MAX = max(1, int(os.environ.get("LLM_QUEUE_MAX", "4")))
LLM_QUEUE_WAIT_SEC = max(1.0, float(os.environ.get("LLM_QUEUE_WAIT_SEC", "45")))
LLM_VISION_TERM_MAX = max(1, min(24, int(os.environ.get("LLM_VISION_TERM_MAX", "10"))))
LLM_VISION_TERM_CACHE_TTL_SEC = max(
    0.0, float(os.environ.get("LLM_VISION_TERM_CACHE_TTL_SEC", "180"))
)
LLM_WARMUP_ENABLED = os.environ.get("LLM_WARMUP_ENABLED", "1") not in ("0", "false", "False")
LLM_WARMUP_ON_START = os.environ.get("LLM_WARMUP_ON_START", "1") not in ("0", "false", "False")
LLM_WARMUP_INTERVAL_SEC = max(0.0, float(os.environ.get("LLM_WARMUP_INTERVAL_SEC", "60")))
LLM_WARMUP_START_DELAY_SEC = max(0.0, float(os.environ.get("LLM_WARMUP_START_DELAY_SEC", "1.2")))
LLM_WARMUP_TIMEOUT_SEC = max(1.0, min(15.0, float(os.environ.get("LLM_WARMUP_TIMEOUT_SEC", "4.0"))))
LLM_WARMUP_MAX_TOKENS = max(1, min(64, int(os.environ.get("LLM_WARMUP_MAX_TOKENS", "6"))))
LLM_WARMUP_PROMPT = str(os.environ.get("LLM_WARMUP_PROMPT", "请只回复OK")).strip() or "请只回复OK"

RACE_SCORE_DIMENSIONS = [
    "图像预处理效果",
    "视觉算法性能",
    "系统鲁棒性",
    "系统稳定性",
]

_FORWARD_HEADER_KEYS = {
    "authorization",
    "accept",
    "x-request-id",
    "x-trace-id",
    "x-session-id",
    "user-agent",
}

_LLM_ROUTE_METHODS: dict[str, set[str]] = {
    "/api/llm/health": {"GET"},
    "/api/llm/queue": {"GET"},
    "/api/llm/chat": {"POST"},
    "/api/llm/agent_task": {"POST"},
    "/api/llm/vision_action": {"POST"},
    "/api/llm/defense_pack": {"POST"},
    "/api/llm/vision_label_resolve": {"POST"},
}


def _allowed_methods_for_route(route: str) -> list[str]:
    if route == "/health":
        return ["GET", "HEAD", "OPTIONS"]
    methods = _LLM_ROUTE_METHODS.get(route)
    if not methods:
        return []
    allow = set(methods)
    allow.update({"HEAD", "OPTIONS"})
    return sorted(list(allow))


def _supported_llm_routes() -> list[str]:
    return sorted(list(_LLM_ROUTE_METHODS.keys()))


def _ts_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _parse_int(value: Any, default: int, low: int, high: int) -> int:
    try:
        out = int(value)
    except (TypeError, ValueError):
        out = default
    return max(low, min(high, out))


def _extract_first_json_object(text: str) -> str:
    s = str(text or "")
    start = s.find("{")
    if start < 0:
        return ""
    depth = 0
    in_str = False
    escape = False
    for idx in range(start, len(s)):
        ch = s[idx]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return s[start : idx + 1]
    return ""


def _parse_json_object_from_text(text: str) -> tuple[dict[str, Any] | None, str]:
    raw = str(text or "").strip()
    if not raw:
        return None, "empty llm content"
    direct: dict[str, Any] | None = None
    if raw.startswith("{") and raw.endswith("}"):
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict):
                direct = obj
        except Exception:
            direct = None
    if direct is not None:
        return direct, ""
    block = _extract_first_json_object(raw)
    if not block:
        return None, "no json object found"
    try:
        obj = json.loads(block)
        if isinstance(obj, dict):
            return obj, ""
    except Exception:
        return None, "json parse failed"
    return None, "json object is not dict"


def _extract_llm_text(llm_resp: Any) -> str:
    if llm_resp is None:
        return ""
    if isinstance(llm_resp, str):
        return llm_resp.strip()
    if isinstance(llm_resp, list):
        for item in llm_resp:
            text = _extract_llm_text(item)
            if text:
                return text
        return ""
    if not isinstance(llm_resp, dict):
        return ""

    for key in ("text", "content", "response", "message", "answer", "output"):
        val = llm_resp.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    choices = llm_resp.get("choices")
    if isinstance(choices, list):
        for item in choices:
            if not isinstance(item, dict):
                continue
            msg = item.get("message")
            if isinstance(msg, dict):
                cont = msg.get("content")
                if isinstance(cont, str) and cont.strip():
                    return cont.strip()
            txt = item.get("text")
            if isinstance(txt, str) and txt.strip():
                return txt.strip()

    data = llm_resp.get("data")
    if isinstance(data, (dict, list, str)):
        return _extract_llm_text(data)

    return ""


def _extract_error_text(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload.strip()
    if isinstance(payload, dict):
        for key in ("error", "message", "detail", "raw_text"):
            val = payload.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        text = _extract_llm_text(payload)
        if text:
            return text
    if isinstance(payload, list):
        for item in payload:
            text = _extract_error_text(item)
            if text:
                return text
    return ""


def _looks_like_upstream_busy(status: int, payload: Any) -> bool:
    if int(status) not in (429, 503):
        return False
    detail = _extract_error_text(payload).lower()
    if not detail:
        return int(status) == 503
    busy_tokens = (
        "busy",
        "try again later",
        "server is busy",
        "temporarily unavailable",
        "resource busy",
        "过载",
        "繁忙",
    )
    if any(token in detail for token in busy_tokens):
        return True
    # queue/full timeout should not be treated as upstream busy retry.
    if "queue" in detail and ("full" in detail or "timeout" in detail):
        return False
    return int(status) == 503


def _summarize_vision_context(payload: dict[str, Any], max_objects: int) -> dict[str, Any]:
    objects = payload.get("objects") if isinstance(payload.get("objects"), list) else []
    picked = []
    class_counts: dict[str, int] = {}
    for item in objects[: max(1, min(20, max_objects))]:
        if not isinstance(item, dict):
            continue
        cls = str(item.get("class_name") or item.get("class_id") or "unknown")
        class_counts[cls] = class_counts.get(cls, 0) + 1
        picked.append(
            {
                "class_name": cls,
                "score": item.get("score"),
                "bbox_xywh": item.get("bbox_xywh"),
                "area": item.get("area"),
            }
        )
    return {
        "ok": bool(payload.get("ok", False)),
        "summary": str(payload.get("summary") or ""),
        "object_count": len(objects),
        "class_counts": class_counts,
        "best_target": payload.get("best_target"),
        "objects": picked,
        "camera": payload.get("camera") if isinstance(payload.get("camera"), dict) else {},
    }


def _tcp_check(url: str, timeout_sec: float = 1.0) -> tuple[bool, str]:
    return tcp_probe(url, timeout_sec=timeout_sec)


def _read_text(path: str) -> str:
    try:
        return open(path, "r", encoding="utf-8", errors="ignore").read().strip()
    except Exception:
        return ""


def _read_int(path: str) -> int | None:
    text = _read_text(path)
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        return None


_NPU_RUNTIME_LOCK = threading.Lock()
_NPU_RUNTIME_PREV_ACTIVE = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_active_time")
_NPU_RUNTIME_PREV_SUSPENDED = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_suspended_time")


def _read_npu_runtime_counters() -> tuple[int | None, int | None, str | None]:
    active = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_active_time")
    suspended = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_suspended_time")
    runtime_status = _read_text("/sys/devices/platform/fdab0000.npu/power/runtime_status") or None
    return active, suspended, runtime_status


def _read_npu_runtime() -> dict[str, Any]:
    usage_percent: float | None = None
    cores: list[float] = []
    freq_hz: int | None = None
    power_state = _read_text("/sys/kernel/debug/rknpu/power") or None
    runtime_active, runtime_suspended, runtime_status = _read_npu_runtime_counters()
    runtime_usage_percent: float | None = None

    load_text = _read_text("/sys/kernel/debug/rknpu/load")
    if load_text:
        for value in re.findall(r"Core\\d+:\\s*([0-9]+)%", load_text):
            try:
                cores.append(float(value))
            except ValueError:
                continue
        if cores:
            usage_percent = sum(cores) / len(cores)

    freq_text = _read_text("/sys/kernel/debug/rknpu/freq")
    if freq_text:
        try:
            freq_hz = int(freq_text)
        except ValueError:
            match = re.search(r"([0-9]{6,})", freq_text)
            if match:
                freq_hz = int(match.group(1))

    global _NPU_RUNTIME_PREV_ACTIVE, _NPU_RUNTIME_PREV_SUSPENDED
    with _NPU_RUNTIME_LOCK:
        prev_active = _NPU_RUNTIME_PREV_ACTIVE
        prev_suspended = _NPU_RUNTIME_PREV_SUSPENDED
        _NPU_RUNTIME_PREV_ACTIVE = runtime_active
        _NPU_RUNTIME_PREV_SUSPENDED = runtime_suspended
    if (
        runtime_active is not None
        and runtime_suspended is not None
        and prev_active is not None
        and prev_suspended is not None
    ):
        delta_active = runtime_active - prev_active
        delta_suspended = runtime_suspended - prev_suspended
        total_delta = delta_active + delta_suspended
        if delta_active >= 0 and delta_suspended >= 0 and total_delta > 0:
            runtime_usage_percent = max(0.0, min(100.0, delta_active * 100.0 / total_delta))

    devfreq_text = _read_text("/sys/class/devfreq/fdab0000.npu/load")
    if devfreq_text:
        match = re.search(r"([0-9]+)\\s*@\\s*([0-9]+)\\s*Hz", devfreq_text)
        if match:
            if freq_hz is None:
                freq_hz = int(match.group(2))
        elif usage_percent is None and runtime_usage_percent is None and not load_text:
            match = re.search(r"([0-9]+)", devfreq_text)
            if match:
                usage_percent = float(match.group(1))

    if runtime_usage_percent is not None:
        usage_percent = runtime_usage_percent
    elif usage_percent is None and runtime_status == "suspended" and power_state == "off":
        usage_percent = 0.0

    if usage_percent is not None:
        usage_percent = max(0.0, min(100.0, usage_percent))

    driver_version = "unknown"
    for path in ("/sys/kernel/debug/rknpu/version", "/proc/rknpu/version"):
        raw = _read_text(path)
        if not raw:
            continue
        match = re.search(r"v\\d+\\.\\d+\\.\\d+", raw)
        if match:
            driver_version = match.group(0)
            break
        line = raw.splitlines()[0].strip()
        if line:
            driver_version = line[:64]
            break

    return {
        "driver_version": driver_version,
        "available": bool(load_text or devfreq_text or freq_hz is not None or power_state),
        "usage_percent": usage_percent,
        "cores": cores,
        "freq_hz": freq_hz,
        "power_state": power_state,
        "runtime_status": runtime_status,
        "runtime_usage_percent": runtime_usage_percent,
        "usage_source": (
            "runtime_active_ratio"
            if runtime_usage_percent is not None
            else "debugfs_core_load"
            if cores
            else "devfreq_load"
            if devfreq_text
            else "unknown"
        ),
    }


def _new_execution_trace(route: str, payload: dict[str, Any], raw_input: str) -> dict[str, Any]:
    initiator = str(payload.get("initiator") or "user").strip().lower() or "user"
    return {
        "trace_id": f"llm-{int(time.time() * 1000):x}"[-16:],
        "route": route,
        "initiator": initiator,
        "raw_input": str(raw_input or "").strip()[:220],
        "started_at": datetime.now().isoformat(timespec="milliseconds"),
        "steps": [],
    }


def _append_trace_step(
    trace: dict[str, Any],
    name: str,
    ok: bool,
    detail: str,
    duration_ms: float | None = None,
    status: int | None = None,
) -> None:
    steps = trace.get("steps")
    if not isinstance(steps, list):
        steps = []
        trace["steps"] = steps
    row: dict[str, Any] = {
        "name": str(name or "").strip()[:48],
        "ok": bool(ok),
        "detail": str(detail or "").strip()[:220],
        "timestamp": _ts_now(),
    }
    if duration_ms is not None:
        row["duration_ms"] = round(max(0.0, float(duration_ms)), 2)
    if status is not None:
        row["status"] = int(status)
    steps.append(row)


def _finalize_execution_trace(trace: dict[str, Any], started_perf: float) -> dict[str, Any]:
    out = dict(trace)
    out["finished_at"] = datetime.now().isoformat(timespec="milliseconds")
    out["duration_ms"] = round(max(0.0, (time.perf_counter() - started_perf) * 1000.0), 2)
    return out


def _build_assistant_feedback(lines: list[str]) -> str:
    compact = [str(line).strip() for line in lines if str(line).strip()]
    return "\n".join(compact[:8])


def _coerce_enabled(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(int(value))
    text = str(value or "").strip().lower()
    if text in ("1", "true", "on", "enable", "enabled", "yes"):
        return True
    if text in ("0", "false", "off", "disable", "disabled", "no"):
        return False
    return None


def _coerce_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(int(value))
    text = str(value or "").strip().lower()
    if text in ("1", "true", "on", "yes", "enabled", "enable"):
        return True
    if text in ("0", "false", "off", "no", "disabled", "disable"):
        return False
    return bool(default)


def _normalize_term_token(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(text or "").strip().lower())


def _split_terms(text: str) -> list[str]:
    raw = str(text or "").strip()
    if not raw:
        return []
    blob = raw
    for token in ("，", "、", "；", "。", "和", "与", "以及", "或", "及", "+"):
        blob = blob.replace(token, ",")
    blob = re.sub(r"\b(and|or|plus|with)\b", ",", blob, flags=re.IGNORECASE)
    blob = re.sub(r"[,;/|\n\r\t]+", ",", blob)
    out: list[str] = []
    for item in blob.split(","):
        clean = str(item or "").strip(" .:：-_")
        if clean:
            clean = re.sub(
                r"^(只看|只关注|关注|检测|识别|查找|寻找|跟踪|仅看|只检测|看|要看)",
                "",
                clean,
            ).strip()
            clean = re.sub(
                r"^(detect|find|track|watch|focus|only|target|lookfor)\s+",
                "",
                clean,
                flags=re.IGNORECASE,
            ).strip()
        if clean:
            out.append(clean)
    return out


def _coerce_terms(value: Any) -> list[str]:
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            out.extend(_split_terms(str(item or "")))
        return out
    return _split_terms(str(value or ""))


class LLMQueueGate:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.cond = threading.Condition(self.lock)
        self.inflight = 0
        self.waiting = 0
        self.total_started = 0
        self.rejected = 0

    def snapshot_locked(self) -> dict[str, Any]:
        return {
            "single_flight": bool(LLM_SINGLE_FLIGHT),
            "queue_max": int(LLM_QUEUE_MAX),
            "queue_wait_sec": float(LLM_QUEUE_WAIT_SEC),
            "inflight": int(self.inflight),
            "waiting": int(self.waiting),
            "total_started": int(self.total_started),
            "rejected": int(self.rejected),
        }

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return self.snapshot_locked()

    def acquire(self, timeout_sec: float) -> tuple[bool, str, dict[str, Any], float]:
        if not LLM_SINGLE_FLIGHT:
            return True, "single-flight disabled", self.snapshot(), 0.0
        timeout = max(1.0, float(timeout_sec))
        wait_started = time.perf_counter()
        with self.cond:
            if self.inflight <= 0 and self.waiting <= 0:
                self.inflight = 1
                self.total_started += 1
                return True, "acquired immediately", self.snapshot_locked(), 0.0
            if self.waiting >= LLM_QUEUE_MAX:
                self.rejected += 1
                return False, "queue full", self.snapshot_locked(), 0.0

            self.waiting += 1
            deadline = time.monotonic() + timeout
            while self.inflight > 0:
                remain = deadline - time.monotonic()
                if remain <= 0:
                    self.waiting = max(0, self.waiting - 1)
                    self.rejected += 1
                    waited_ms = (time.perf_counter() - wait_started) * 1000.0
                    return False, "queue timeout", self.snapshot_locked(), waited_ms
                self.cond.wait(timeout=remain)

            self.waiting = max(0, self.waiting - 1)
            self.inflight = 1
            self.total_started += 1
            waited_ms = (time.perf_counter() - wait_started) * 1000.0
            return True, "acquired after waiting", self.snapshot_locked(), waited_ms

    def release(self) -> None:
        if not LLM_SINGLE_FLIGHT:
            return
        with self.cond:
            self.inflight = 0
            self.cond.notify(1)


QUEUE_GATE = LLMQueueGate()

_WARMUP_STATE_LOCK = threading.Lock()
_WARMUP_STATE: dict[str, Any] = {
    "enabled": bool(LLM_WARMUP_ENABLED),
    "on_start": bool(LLM_WARMUP_ON_START),
    "interval_sec": float(LLM_WARMUP_INTERVAL_SEC),
    "last_started_at": "",
    "last_finished_at": "",
    "last_ok": None,
    "last_status": 0,
    "last_detail": "never run",
    "last_latency_ms": 0.0,
    "runs": 0,
    "success": 0,
    "skipped_busy": 0,
}


def _warmup_state_snapshot() -> dict[str, Any]:
    with _WARMUP_STATE_LOCK:
        return dict(_WARMUP_STATE)


def _warmup_state_update(**kwargs: Any) -> None:
    with _WARMUP_STATE_LOCK:
        for key, value in kwargs.items():
            _WARMUP_STATE[key] = value


def _post_json_once(
    url: str,
    payload: dict[str, Any],
    *,
    timeout_sec: float,
) -> tuple[int, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    try:
        conn, _target = open_connection(url, timeout_sec=max(1.0, float(timeout_sec)))
        req_path = compose_request_path(url, "")
        if not req_path:
            req_path = "/"
        conn.request(
            "POST",
            req_path,
            body=body,
            headers={"Content-Type": "application/json", "Content-Length": str(len(body)), "Connection": "close"},
        )
        resp = conn.getresponse()
        status = int(getattr(resp, "status", 200) or 200)
        raw = resp.read()
    except Exception as exc:
        return 599, {"error": str(exc)}
    finally:
        try:
            conn.close()  # type: ignore[name-defined]
        except Exception:
            pass
    text = raw.decode("utf-8", errors="replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
    try:
        parsed = json.loads(text)
    except Exception:
        parsed = {"raw_text": text}
    return status, parsed


def _request_rkllm_abort(timeout_sec: float = 1.2) -> tuple[bool, str]:
    if not RKLLM_ABORT_URL:
        return False, "abort url not configured"
    try:
        conn, _target = open_connection(RKLLM_ABORT_URL, timeout_sec=max(0.8, float(timeout_sec)))
        req_path = compose_request_path(RKLLM_ABORT_URL, "")
        if not req_path:
            req_path = "/"
        conn.request(
            "POST",
            req_path,
            body=b"{}",
            headers={"Content-Type": "application/json", "Content-Length": "2", "Connection": "close"},
        )
        resp = conn.getresponse()
        status = int(getattr(resp, "status", 200) or 200)
        raw = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        return False, str(exc)
    finally:
        try:
            conn.close()  # type: ignore[name-defined]
        except Exception:
            pass
    try:
        payload = json.loads(raw) if raw else {}
    except Exception:
        payload = {}
    if 200 <= status < 300 and bool(payload.get("ok", True)):
        return True, "ok"
    detail = _extract_error_text(payload) or str(payload.get("message") or payload.get("detail") or f"status={status}")
    return False, detail


def _run_warmup_once(reason: str = "interval") -> None:
    if not LLM_WARMUP_ENABLED:
        return
    queue_state = QUEUE_GATE.snapshot()
    inflight = int(queue_state.get("inflight", 0) or 0)
    waiting = int(queue_state.get("waiting", 0) or 0)
    if inflight > 0 or waiting > 0:
        snap = _warmup_state_snapshot()
        _warmup_state_update(
            last_started_at=_ts_now(),
            last_finished_at=_ts_now(),
            last_ok=False,
            last_status=0,
            last_detail=f"skip({reason}): queue busy inflight={inflight}, waiting={waiting}",
            last_latency_ms=0.0,
            runs=int(snap.get("runs", 0)) + 1,
            skipped_busy=int(snap.get("skipped_busy", 0)) + 1,
        )
        return

    payload = {
        "messages": [{"role": "user", "content": LLM_WARMUP_PROMPT}],
        "stream": False,
        "enable_thinking": False,
        "temperature": 0.0,
        "top_p": 0.6,
        "top_k": 1,
        "max_tokens": int(LLM_WARMUP_MAX_TOKENS),
        "max_new_tokens": int(LLM_WARMUP_MAX_TOKENS),
        "keep_history": False,
        "clear_history": False,
    }
    started_at = _ts_now()
    started_perf = time.perf_counter()
    status, resp = _post_json_once(RKLLM_URL, payload, timeout_sec=LLM_WARMUP_TIMEOUT_SEC)
    latency_ms = (time.perf_counter() - started_perf) * 1000.0
    llm_text = _extract_llm_text(resp)
    ok = (200 <= int(status) < 300) and bool(llm_text)
    detail = "ok" if ok else (_extract_error_text(resp) or f"status={int(status)}")

    snap = _warmup_state_snapshot()
    _warmup_state_update(
        last_started_at=started_at,
        last_finished_at=_ts_now(),
        last_ok=bool(ok),
        last_status=int(status),
        last_detail=str(f"{reason}: {detail}").strip()[:220],
        last_latency_ms=round(latency_ms, 2),
        runs=int(snap.get("runs", 0)) + 1,
        success=int(snap.get("success", 0)) + (1 if ok else 0),
    )


def _warmup_worker() -> None:
    if not LLM_WARMUP_ENABLED:
        return
    if LLM_WARMUP_START_DELAY_SEC > 0:
        time.sleep(float(LLM_WARMUP_START_DELAY_SEC))
    if LLM_WARMUP_ON_START:
        _run_warmup_once("startup")
    interval = float(LLM_WARMUP_INTERVAL_SEC)
    if interval <= 0:
        return
    while True:
        time.sleep(interval)
        _run_warmup_once("interval")


class LLMPreviewHandler(BaseHTTPRequestHandler):
    vision_term_cache_lock = threading.Lock()
    vision_term_cache: dict[str, dict[str, Any]] = {}

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            return

    def _send_sse_headers(self, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,HEAD,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
        self.end_headers()

    def _write_sse_event(self, event: str, data: dict[str, Any]) -> bool:
        payload = f"event: {str(event or 'message').strip()}\n"
        payload += "data: " + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n\n"
        try:
            self.wfile.write(payload.encode("utf-8"))
            self.wfile.flush()
            return True
        except BrokenPipeError:
            return False
        except Exception:
            return False

    def _read_json_body(self) -> tuple[dict[str, Any] | None, str]:
        raw_len = self.headers.get("Content-Length", "")
        try:
            body_len = int(raw_len)
        except ValueError:
            return None, "invalid Content-Length"
        if body_len <= 0:
            return None, "empty request body"
        if body_len > 4 * 1024 * 1024:
            return None, "request body too large"
        try:
            data = self.rfile.read(body_len)
        except Exception:
            return None, "failed to read request body"
        try:
            payload = json.loads(data.decode("utf-8"))
        except Exception:
            return None, "invalid JSON body"
        if not isinstance(payload, dict):
            return None, "JSON body must be an object"
        return payload, ""

    def _request_headers_for_upstream(self, include_content_type: bool = True) -> dict[str, str]:
        out: dict[str, str] = {}
        if include_content_type:
            out["Content-Type"] = "application/json"
        for key, value in self.headers.items():
            k = key.lower().strip()
            if k in _FORWARD_HEADER_KEYS and str(value).strip():
                out[key] = str(value).strip()
        has_request_id = any(str(k).strip().lower() == "x-request-id" for k in out)
        if not has_request_id:
            out["X-Request-Id"] = f"llm-{int(time.time()*1000)}"
        return out

    def _post_json_upstream(
        self,
        url: str,
        payload: dict[str, Any],
        timeout_sec: float,
        retries: int,
    ) -> tuple[int, Any]:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        delay = LLM_RETRY_DELAY_SEC
        headers = self._request_headers_for_upstream()
        last_status = 599
        last_resp: Any = {"error": "proxy request failed"}

        for attempt in range(max(0, retries) + 1):
            req = urlrequest.Request(url, data=data, headers=headers, method="POST")
            try:
                with urlrequest.urlopen(req, timeout=max(1.0, timeout_sec)) as resp:
                    status = int(resp.getcode())
                    raw = resp.read()
                    text = raw.decode("utf-8", errors="replace") if raw else ""
                    ctype = str(resp.headers.get("Content-Type", "")).lower()
                    if "json" in ctype:
                        try:
                            parsed = json.loads(text) if text else {}
                        except Exception:
                            parsed = {"raw_text": text}
                    else:
                        parsed = {"raw_text": text}
                    return status, parsed
            except urlerror.HTTPError as exc:
                status = int(exc.code)
                raw = exc.read() if exc.fp else b""
                text = raw.decode("utf-8", errors="replace") if raw else ""
                parsed: Any
                try:
                    parsed = json.loads(text) if text else {}
                except Exception:
                    parsed = {"error": text or f"http error {status}"}
                last_status, last_resp = status, parsed
                if status >= 500 and attempt < retries:
                    time.sleep(delay)
                    continue
                return status, parsed
            except Exception as exc:
                err_text = str(exc or "")
                if LLM_ABORT_ON_TIMEOUT and ("timed out" in err_text.lower() or isinstance(exc, TimeoutError)):
                    abort_ok, abort_detail = _request_rkllm_abort(timeout_sec=1.2)
                    if abort_ok:
                        err_text = f"{err_text}; rkllm_abort=ok"
                    else:
                        err_text = f"{err_text}; rkllm_abort={abort_detail}"
                    # Keep the single-flight gate occupied briefly so upstream
                    # has time to drain after abort, reducing follow-up BUSY storms.
                    if LLM_TIMEOUT_ABORT_SETTLE_SEC > 0.0:
                        time.sleep(float(LLM_TIMEOUT_ABORT_SETTLE_SEC))
                last_status = 599
                last_resp = {"error": err_text}
                if attempt < retries:
                    time.sleep(delay)
                    continue
                return last_status, last_resp

        return last_status, last_resp

    def _call_vision_observe(self, detector: str, timeout_sec: float = 8.0) -> tuple[int, dict[str, Any]]:
        safe = quote(detector, safe="")
        req_path = compose_request_path(VISION_API_BASE, f"/api/vision/observe?detector={safe}")
        conn: http.client.HTTPConnection | None = None
        try:
            conn, _target = open_connection(VISION_API_BASE, timeout_sec=max(1.0, timeout_sec))
            conn.request(
                "GET",
                req_path,
                headers=self._request_headers_for_upstream(include_content_type=False),
            )
            resp = conn.getresponse()
            status = int(resp.getcode())
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace") if raw else ""
            try:
                payload = json.loads(text) if text else {}
            except Exception:
                payload = {"ok": False, "error": text or f"vision http error {status}"}
            if not isinstance(payload, dict):
                payload = {"ok": False, "error": "invalid vision payload"}
            return status, payload
        except Exception as exc:
            return 599, {"ok": False, "error": str(exc)}
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def _call_vision_filter_status(self, timeout_sec: float = 5.0) -> tuple[int, dict[str, Any]]:
        req_path = compose_request_path(VISION_API_BASE, "/api/vision/yolo_world/filter")
        conn: http.client.HTTPConnection | None = None
        try:
            conn, _target = open_connection(VISION_API_BASE, timeout_sec=max(1.0, timeout_sec))
            conn.request(
                "GET",
                req_path,
                headers=self._request_headers_for_upstream(include_content_type=False),
            )
            resp = conn.getresponse()
            status = int(resp.getcode())
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace") if raw else ""
            try:
                payload = json.loads(text) if text else {}
            except Exception:
                payload = {"ok": False, "error": text or f"vision filter http error {status}"}
            if not isinstance(payload, dict):
                payload = {"ok": False, "error": "invalid vision filter payload"}
            return status, payload
        except Exception as exc:
            return 599, {"ok": False, "error": str(exc)}
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def _call_vision_prompt_set(
        self,
        prompt: str,
        include_terms: list[str],
        exclude_terms: list[str],
        strict: bool,
        reason: str,
        timeout_sec: float = 5.0,
    ) -> tuple[int, dict[str, Any]]:
        params: list[tuple[str, str]] = []
        if str(prompt or "").strip():
            params.append(("prompt", str(prompt).strip()))
        for item in include_terms:
            text = str(item or "").strip()
            if text:
                params.append(("include", text))
        for item in exclude_terms:
            text = str(item or "").strip()
            if text:
                params.append(("exclude", text))
        params.append(("strict", "1" if strict else "0"))
        params.append(("reason", str(reason or "llm").strip() or "llm"))
        query = urlencode(params, doseq=True)
        req_path = compose_request_path(VISION_API_BASE, f"/api/vision/yolo_world/prompt/set?{query}")
        conn: http.client.HTTPConnection | None = None
        try:
            conn, _target = open_connection(VISION_API_BASE, timeout_sec=max(1.0, timeout_sec))
            conn.request(
                "GET",
                req_path,
                headers=self._request_headers_for_upstream(include_content_type=False),
            )
            resp = conn.getresponse()
            status = int(resp.getcode())
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace") if raw else ""
            try:
                payload = json.loads(text) if text else {}
            except Exception:
                payload = {"ok": False, "error": text or f"vision prompt http error {status}"}
            if not isinstance(payload, dict):
                payload = {"ok": False, "error": "invalid vision prompt payload"}
            return status, payload
        except Exception as exc:
            return 599, {"ok": False, "error": str(exc)}
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    @classmethod
    def _vision_term_cache_get(cls, key: str) -> dict[str, Any] | None:
        if LLM_VISION_TERM_CACHE_TTL_SEC <= 0:
            return None
        now_ts = time.time()
        with cls.vision_term_cache_lock:
            row = cls.vision_term_cache.get(key)
            if not isinstance(row, dict):
                return None
            created = float(row.get("created_at", 0.0))
            if created <= 0 or (now_ts - created) > float(LLM_VISION_TERM_CACHE_TTL_SEC):
                cls.vision_term_cache.pop(key, None)
                return None
            return dict(row)

    @classmethod
    def _vision_term_cache_set(
        cls,
        key: str,
        include_terms: list[str],
        exclude_terms: list[str],
        source: str,
    ) -> None:
        if LLM_VISION_TERM_CACHE_TTL_SEC <= 0:
            return
        with cls.vision_term_cache_lock:
            cls.vision_term_cache[key] = {
                "created_at": time.time(),
                "include_terms": [str(v) for v in include_terms[: int(LLM_VISION_TERM_MAX)]],
                "exclude_terms": [str(v) for v in exclude_terms[: int(LLM_VISION_TERM_MAX)]],
                "source": str(source or "cache"),
            }

    @staticmethod
    def _extract_terms_rule(query: str, labels: list[str]) -> tuple[list[str], list[str], str]:
        text = str(query or "").strip()
        lower = text.lower()
        if not text:
            return [], [], "empty"

        label_map: dict[str, str] = {}
        for label in labels:
            key = _normalize_term_token(label)
            if key:
                label_map[key] = label

        include: list[str] = []
        for label in labels:
            low = str(label or "").strip().lower()
            if low and low in lower and label not in include:
                include.append(label)

        alias_map = {
            "人": "person",
            "行人": "person",
            "人脸": "person",
            "手机": "cell phone",
            "电话": "cell phone",
            "车": "car",
            "汽车": "car",
            "轿车": "car",
            "卡车": "truck",
            "货车": "truck",
            "公交": "bus",
            "公交车": "bus",
            "摩托": "motorcycle",
            "自行车": "bicycle",
            "狗": "dog",
            "猫": "cat",
            "鸟": "bird",
            "杯子": "cup",
            "瓶子": "bottle",
            "桌子": "dining table",
            "椅子": "chair",
            "沙发": "couch",
            "电脑": "laptop",
            "电视": "tv",
        }
        for token, target in alias_map.items():
            if token in text and target in labels and target not in include:
                include.append(target)

        parts = _split_terms(text)
        for part in parts:
            key = _normalize_term_token(part)
            if not key:
                continue
            direct = label_map.get(key)
            if direct and direct not in include:
                include.append(direct)
                continue
            fuzzy = [lab for lab in labels if key and (key in _normalize_term_token(lab))]
            if len(fuzzy) == 1 and fuzzy[0] not in include:
                include.append(fuzzy[0])

        neg_markers = ("not ", "without ", "except ", "排除", "不要", "不看", "除了")
        exclude: list[str] = []
        if any(mark in lower for mark in neg_markers) or any(mark in text for mark in ("排除", "不要", "不看")):
            neg_parts = re.split(r"(?:排除|不要|不看|without|except|not)\s*", text, flags=re.IGNORECASE)
            if len(neg_parts) >= 2:
                tail = neg_parts[-1]
                for term in _split_terms(tail):
                    key = _normalize_term_token(term)
                    if not key:
                        continue
                    direct = label_map.get(key)
                    if direct is None:
                        for token, target in alias_map.items():
                            if token and token in term and target in labels:
                                direct = target
                                break
                    if direct and direct not in exclude:
                        exclude.append(direct)

        if exclude:
            include = [row for row in include if row not in exclude]

        include = include[: int(LLM_VISION_TERM_MAX)]
        exclude = exclude[: int(LLM_VISION_TERM_MAX)]
        return include, exclude, "rule"

    def _extract_terms_llm(
        self,
        query: str,
        labels: list[str],
        timeout_sec: float = 6.0,
    ) -> tuple[list[str], list[str], str]:
        system_prompt = (
            "You map user intent to vision labels. "
            "Output JSON only with keys include_terms (array) and exclude_terms (array). "
            "Only choose terms from available_labels; if none matched return empty arrays."
        )
        user_prompt = {
            "query": str(query or "")[:320],
            "available_labels": labels[:120],
            "max_terms": int(LLM_VISION_TERM_MAX),
        }
        llm_payload = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_prompt, ensure_ascii=False)},
            ],
            "stream": False,
        }
        status, resp, _, _ = self._llm_with_queue(
            llm_payload,
            timeout_sec=max(3.0, float(timeout_sec)),
            retries=0,
        )
        if not (200 <= status < 300):
            return [], [], f"llm_status_{status}"
        llm_text = _extract_llm_text(resp)
        parsed, _ = _parse_json_object_from_text(llm_text)
        if not isinstance(parsed, dict):
            return [], [], "llm_parse_failed"

        include_raw = parsed.get("include_terms")
        exclude_raw = parsed.get("exclude_terms")
        include_terms = _coerce_terms(include_raw) if include_raw is not None else []
        exclude_terms = _coerce_terms(exclude_raw) if exclude_raw is not None else []

        label_set = set(str(v) for v in labels)
        include = [v for v in include_terms if v in label_set][: int(LLM_VISION_TERM_MAX)]
        exclude = [v for v in exclude_terms if v in label_set][: int(LLM_VISION_TERM_MAX)]
        return include, exclude, "llm"

    def _resolve_and_apply_vision_terms(
        self,
        payload: dict[str, Any],
        query: str,
        detector: str,
        reason: str,
        apply: bool = True,
        trace: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        out: dict[str, Any] = {
            "applied": False,
            "skipped": False,
            "detector": detector,
            "source": "none",
            "include_terms": [],
            "exclude_terms": [],
            "prompt": "",
            "strict": False,
        }
        if detector != "yolo_world":
            out["skipped"] = True
            out["source"] = "detector_not_yolo_world"
            return out

        auto_mode = _coerce_bool(payload.get("auto_vision_terms", True), default=True)
        use_llm_extract = _coerce_bool(payload.get("vision_terms_with_llm", True), default=True)
        strict = _coerce_bool(payload.get("vision_terms_strict", False), default=False)
        prompt = str(payload.get("vision_prompt") or payload.get("prompt") or "").strip()
        include_terms = _coerce_terms(
            payload.get("vision_terms")
            or payload.get("include_terms")
            or payload.get("labels")
        )
        exclude_terms = _coerce_terms(
            payload.get("vision_exclude_terms")
            or payload.get("exclude_terms")
        )
        include_terms = include_terms[: int(LLM_VISION_TERM_MAX)]
        exclude_terms = exclude_terms[: int(LLM_VISION_TERM_MAX)]

        status, filter_payload = self._call_vision_filter_status(timeout_sec=4.0)
        filter_ok = bool(filter_payload.get("ok", False)) and (200 <= status < 300)
        labels = (
            [str(v) for v in filter_payload.get("available_labels", [])]
            if isinstance(filter_payload.get("available_labels"), list)
            else []
        )
        if trace is not None:
            _append_trace_step(
                trace,
                "vision.filter.status",
                filter_ok,
                f"status={status}, labels={len(labels)}",
            )
        if not filter_ok:
            out["source"] = "vision_filter_unavailable"
            out["error"] = str(filter_payload.get("error") or f"status={status}")
            return out

        if not include_terms and not prompt and auto_mode:
            q = str(query or "").strip()
            cache_key = _normalize_term_token(q)
            if cache_key:
                cached = self._vision_term_cache_get(cache_key)
            else:
                cached = None
            if isinstance(cached, dict):
                include_terms = [str(v) for v in cached.get("include_terms", [])][: int(LLM_VISION_TERM_MAX)]
                exclude_terms = [str(v) for v in cached.get("exclude_terms", [])][: int(LLM_VISION_TERM_MAX)]
                out["source"] = f"cache:{str(cached.get('source') or 'rule')}"
            else:
                include_terms, rule_exclude, src = self._extract_terms_rule(query=q, labels=labels)
                if rule_exclude and not exclude_terms:
                    exclude_terms = rule_exclude
                out["source"] = src
                if (not include_terms) and use_llm_extract and q:
                    llm_inc, llm_exc, llm_src = self._extract_terms_llm(query=q, labels=labels)
                    if llm_inc:
                        include_terms = llm_inc
                    if llm_exc and not exclude_terms:
                        exclude_terms = llm_exc
                    if llm_inc or llm_exc:
                        out["source"] = llm_src
                if cache_key and (include_terms or exclude_terms):
                    self._vision_term_cache_set(
                        cache_key,
                        include_terms=include_terms,
                        exclude_terms=exclude_terms,
                        source=out["source"],
                    )

        include_terms = include_terms[: int(LLM_VISION_TERM_MAX)]
        exclude_terms = exclude_terms[: int(LLM_VISION_TERM_MAX)]
        out["include_terms"] = list(include_terms)
        out["exclude_terms"] = list(exclude_terms)
        out["prompt"] = prompt
        out["strict"] = bool(strict)

        if not include_terms and not prompt and not exclude_terms:
            out["skipped"] = True
            if out["source"] == "none":
                out["source"] = "no_terms"
            return out

        if not apply:
            out["skipped"] = True
            out["source"] = f"preview:{out.get('source', 'rule')}"
            return out

        set_status, set_payload = self._call_vision_prompt_set(
            prompt=prompt,
            include_terms=include_terms,
            exclude_terms=exclude_terms,
            strict=bool(strict),
            reason=reason,
            timeout_sec=5.0,
        )
        set_ok = bool(set_payload.get("ok", False)) and (200 <= set_status < 300)
        out["applied"] = bool(set_ok)
        out["status"] = int(set_status)
        out["vision_payload"] = set_payload
        if trace is not None:
            _append_trace_step(
                trace,
                "vision.prompt.set",
                set_ok,
                (
                    f"status={set_status}, include={len(include_terms)}, "
                    f"exclude={len(exclude_terms)}, strict={bool(strict)}"
                ),
            )
        if not set_ok:
            out["error"] = str(set_payload.get("error") or f"status={set_status}")
        return out

    @staticmethod
    def _clamp_int(value: Any, *, default: int, min_value: int, max_value: int) -> int:
        try:
            out = int(value)
        except (TypeError, ValueError):
            out = int(default)
        return max(int(min_value), min(int(max_value), out))

    @staticmethod
    def _messages_char_count(messages: list[dict[str, Any]] | None) -> int:
        if not isinstance(messages, list):
            return 0
        total = 0
        for row in messages:
            if not isinstance(row, dict):
                continue
            total += len(str(row.get("content") or "").strip())
        return total

    @classmethod
    def _adaptive_timeout_sec(
        cls,
        *,
        task: str,
        base_timeout_sec: float,
        query: str = "",
        messages: list[dict[str, Any]] | None = None,
        object_count: int = 0,
        max_actions: int = 0,
        max_qa: int = 0,
        min_sec: float = 1.0,
        max_sec: float = 120.0,
    ) -> float:
        try:
            base = float(base_timeout_sec)
        except (TypeError, ValueError):
            base = float(min_sec)
        base = max(float(min_sec), min(float(max_sec), base))

        query_chars = len(str(query or "").strip())
        msg_chars = cls._messages_char_count(messages)
        complexity = 0
        if query_chars > 36:
            complexity += 1
        if query_chars > 120:
            complexity += 1
        if query_chars > 260:
            complexity += 1
        if msg_chars > 480:
            complexity += 1
        if msg_chars > 1200:
            complexity += 1
        if int(object_count) >= 5:
            complexity += 1
        if int(object_count) >= 12:
            complexity += 1
        if int(max_actions) >= 3:
            complexity += 1
        if int(max_qa) >= 8:
            complexity += 1
        if int(max_qa) >= 12:
            complexity += 1
        scale = max(0.0, min(1.0, float(complexity) / 10.0))

        name = str(task or "").strip().lower()
        if name == "vision_action":
            low = max(float(min_sec), min(base, 4.0))
            high = max(low, min(base, 10.0))
        elif name == "defense_pack":
            low = max(float(min_sec), min(base, 8.0))
            high = max(low, min(base, 36.0))
        else:
            low = max(float(min_sec), min(base, 3.0))
            high = max(low, base)
        timeout = low + (high - low) * scale
        return round(max(float(min_sec), min(float(max_sec), timeout)), 2)

    @classmethod
    def _adaptive_max_tokens(
        cls,
        *,
        task: str,
        query: str = "",
        messages: list[dict[str, Any]] | None = None,
        object_count: int = 0,
        max_actions: int = 0,
        max_qa: int = 0,
        min_tokens: int = 64,
        max_tokens: int = 1024,
    ) -> int:
        lo = max(16, int(min_tokens))
        hi = max(lo, int(max_tokens))
        query_chars = len(str(query or "").strip())
        msg_chars = cls._messages_char_count(messages)
        name = str(task or "").strip().lower()

        if name == "vision_action":
            budget = (
                92
                + min(56, (query_chars // 22) * 8)
                + min(24, max(0, int(max_actions) - 1) * 6)
                + min(30, max(0, int(object_count)) * 2)
                + min(24, (msg_chars // 360) * 8)
            )
            return cls._clamp_int(budget, default=112, min_value=lo, max_value=hi)

        if name == "defense_pack":
            budget = (
                360
                + min(260, (query_chars // 18) * 12)
                + min(180, (msg_chars // 300) * 14)
                + min(260, max(0, int(max_qa)) * 24)
                + min(120, max(0, int(object_count)) * 8)
            )
            return cls._clamp_int(budget, default=520, min_value=lo, max_value=hi)

        budget = 96 + min(96, (query_chars // 24) * 8) + min(40, (msg_chars // 480) * 8)
        return cls._clamp_int(budget, default=128, min_value=lo, max_value=hi)

    def _llm_with_queue(
        self,
        payload: dict[str, Any],
        timeout_sec: float,
        retries: int,
    ) -> tuple[int, Any, dict[str, Any], float]:
        wait_timeout = max(LLM_QUEUE_WAIT_SEC, float(timeout_sec) + 2.0)
        acquired, note, queue_state, waited_ms = QUEUE_GATE.acquire(wait_timeout)
        if not acquired:
            detail = f"{note}; inflight={queue_state.get('inflight', 0)}, waiting={queue_state.get('waiting', 0)}"
            return 503, {"error": detail}, queue_state, waited_ms
        try:
            status, resp = self._post_json_upstream(
                RKLLM_URL,
                payload,
                timeout_sec=timeout_sec,
                retries=retries,
            )
            return status, resp, QUEUE_GATE.snapshot(), waited_ms
        finally:
            QUEUE_GATE.release()

    def _llm_with_busy_retry(
        self,
        payload: dict[str, Any],
        timeout_sec: float,
        retries: int,
        busy_retries: int,
        busy_retry_delay_sec: float,
    ) -> tuple[int, Any, dict[str, Any], float, int]:
        total_wait_ms = 0.0
        last_status = 599
        last_resp: Any = {"error": "unknown llm error"}
        last_queue = QUEUE_GATE.snapshot()
        attempts = 0
        max_busy_retries = max(0, int(busy_retries))
        delay_sec = max(0.01, float(busy_retry_delay_sec))

        for attempt in range(max_busy_retries + 1):
            attempts += 1
            status, resp, queue_state, waited_ms = self._llm_with_queue(
                payload=payload,
                timeout_sec=timeout_sec,
                retries=retries,
            )
            total_wait_ms += float(waited_ms)
            last_status = int(status)
            last_resp = resp
            last_queue = queue_state
            if _looks_like_upstream_busy(status, resp) and attempt < max_busy_retries:
                time.sleep(delay_sec)
                continue
            return status, resp, queue_state, total_wait_ms, attempts

        return last_status, last_resp, last_queue, total_wait_ms, attempts

    def _handle_llm_chat(self, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        trace_started = time.perf_counter()
        in_messages = payload.get("messages")
        messages: list[dict[str, Any]]
        raw_input = ""

        if isinstance(in_messages, list) and in_messages:
            messages = []
            for msg in in_messages:
                if isinstance(msg, dict):
                    role = str(msg.get("role") or "user")
                    content = str(msg.get("content") or "")
                    messages.append({"role": role, "content": content})
            for msg in reversed(messages):
                if str(msg.get("role") or "").strip().lower() == "user":
                    raw_input = str(msg.get("content") or "").strip()
                    if raw_input:
                        break
        else:
            text = str(payload.get("message") or "").strip()
            if not text:
                trace = _new_execution_trace("/api/llm/chat", payload, "")
                _append_trace_step(trace, "request.parse", False, "message or messages is required")
                execution_trace = _finalize_execution_trace(trace, trace_started)
                return 400, {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "message or messages is required",
                    "assistant_feedback": "请求缺少 message/messages，无法处理。",
                    "llm_queue": QUEUE_GATE.snapshot(),
                    "execution_trace": execution_trace,
                }
            raw_input = text
            messages = [{"role": "user", "content": text}]

        trace = _new_execution_trace("/api/llm/chat", payload, raw_input or "chat request")
        attach_vision = bool(payload.get("attach_vision", True))
        detector = str(payload.get("detector") or "none").strip().lower() or "none"
        _append_trace_step(
            trace,
            "request.parse",
            True,
            f"attach_vision={attach_vision}, detector={detector}, msg_count={len(messages)}",
        )

        if bool(payload.get("stream", False)):
            _append_trace_step(trace, "request.validate", False, "stream mode is not supported")
            execution_trace = _finalize_execution_trace(trace, trace_started)
            return 400, {
                "ok": False,
                "timestamp": _ts_now(),
                "error": "stream mode is not supported by this endpoint",
                "assistant_feedback": "当前代理不支持 stream=true。",
                "llm_queue": QUEUE_GATE.snapshot(),
                "execution_trace": execution_trace,
            }

        tool_result: dict[str, Any] | None = None
        vision_terms_meta: dict[str, Any] | None = None
        if attach_vision:
            vision_terms_meta = self._resolve_and_apply_vision_terms(
                payload=payload,
                query=raw_input,
                detector=detector,
                reason="llm_chat",
                trace=trace,
            )
            tool_started = time.perf_counter()
            _, vision_payload = self._call_vision_observe(detector=detector)
            tool_result = vision_payload
            tool_ok = bool(vision_payload.get("ok", False))
            tool_detail = str(vision_payload.get("summary") or vision_payload.get("error") or "ok")
            _append_trace_step(
                trace,
                "tool.vision.observe",
                tool_ok,
                f"detector={detector}; {tool_detail}",
                duration_ms=(time.perf_counter() - tool_started) * 1000.0,
            )
            compact = _summarize_vision_context(
                vision_payload,
                max_objects=_parse_int(payload.get("max_vision_objects", 6), 6, 1, 12),
            )
            latest_user = raw_input or "请给出当前状态总结。"
            messages = messages + [
                {
                    "role": "user",
                    "content": (
                        "请基于视觉上下文回答用户问题，直接回答，不要复述 JSON。\n"
                        + f"用户问题: {latest_user}\n"
                        + "视觉上下文 JSON:\n"
                        + json.dumps(compact, ensure_ascii=False)
                    ),
                }
            ]
        else:
            _append_trace_step(trace, "tool.vision.observe", True, "skipped (attach_vision=false)")

        llm_payload: dict[str, Any] = {"messages": messages, "stream": False}
        for key in (
            "enable_thinking",
            "tools",
            "temperature",
            "top_p",
            "top_k",
            "max_tokens",
            "max_new_tokens",
            "repeat_penalty",
            "frequency_penalty",
            "presence_penalty",
            "keep_history",
            "clear_history",
            "session_id",
        ):
            if key in payload:
                llm_payload[key] = payload[key]

        fast_mode = _coerce_bool(payload.get("fast_mode"), default=False)
        try:
            raw_timeout = float(payload.get("timeout_sec"))
        except (TypeError, ValueError):
            raw_timeout = float(LLM_PROXY_TIMEOUT_SEC)
        timeout_floor = 1.0 if fast_mode else 3.0
        timeout_sec = max(timeout_floor, raw_timeout)
        retries = _parse_int(payload.get("max_retries", LLM_PROXY_RETRIES), LLM_PROXY_RETRIES, 0, 8)
        llm_started = time.perf_counter()
        status, llm_resp, queue_state, queue_waited_ms = self._llm_with_queue(
            llm_payload,
            timeout_sec=timeout_sec,
            retries=retries,
        )
        queue_err = ""
        if isinstance(llm_resp, dict):
            queue_err = str(llm_resp.get("error") or "")
        _append_trace_step(
            trace,
            "llm.queue",
            not (status == 503 and "queue" in queue_err.lower()),
            f"waited={queue_waited_ms:.2f}ms, waiting={queue_state.get('waiting', 0)}, inflight={queue_state.get('inflight', 0)}",
            duration_ms=queue_waited_ms,
        )
        ok = 200 <= status < 300
        _append_trace_step(
            trace,
            "llm.proxy",
            ok,
            f"status={status}, timeout={timeout_sec:.1f}s, retries={retries}",
            duration_ms=(time.perf_counter() - llm_started) * 1000.0,
            status=status,
        )
        llm_text = _extract_llm_text(llm_resp)

        feedback_lines = [
            f"已接收任务：{raw_input or 'chat request'}",
            (
                f"执行：读取视觉上下文(detector={detector})，结果={str(tool_result.get('summary') or tool_result.get('error') or 'ok')[:72]}。"
                if (attach_vision and isinstance(tool_result, dict))
                else "执行：本次未附加视觉上下文。"
            ),
            (f"执行：LLM 推理完成(status={status})。" if ok else f"执行：LLM 推理失败(status={status})。"),
            f"任务完成：摘要={llm_text[:96] or '（模型返回为空）'}",
        ]
        assistant_feedback = _build_assistant_feedback(feedback_lines)
        execution_trace = _finalize_execution_trace(trace, trace_started)
        response: dict[str, Any] = {
            "ok": ok,
            "timestamp": _ts_now(),
            "llm_status": status,
            "llm_url": RKLLM_URL,
            "llm_queue": queue_state,
            "queue_waited_ms": round(queue_waited_ms, 2),
            "tool_result": tool_result,
            "llm_response": llm_resp,
            "assistant_feedback": assistant_feedback,
            "execution_trace": execution_trace,
        }
        if isinstance(vision_terms_meta, dict):
            response["vision_terms"] = vision_terms_meta
        if bool(payload.get("include_llm_text", False)):
            response["llm_text"] = llm_text
        if ok:
            return 200, response
        if status == 503 and "queue" in queue_err.lower():
            return 503, response
        return 502, response

    def _handle_llm_chat_stream(self, payload: dict[str, Any]) -> None:
        trace_started = time.perf_counter()
        in_messages = payload.get("messages")
        messages: list[dict[str, Any]]
        raw_input = ""

        if isinstance(in_messages, list) and in_messages:
            messages = []
            for msg in in_messages:
                if isinstance(msg, dict):
                    role = str(msg.get("role") or "user")
                    content = str(msg.get("content") or "")
                    messages.append({"role": role, "content": content})
            for msg in reversed(messages):
                if str(msg.get("role") or "").strip().lower() == "user":
                    raw_input = str(msg.get("content") or "").strip()
                    if raw_input:
                        break
        else:
            text = str(payload.get("message") or "").strip()
            if not text:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": "message or messages is required",
                    },
                    status=400,
                )
                return
            raw_input = text
            messages = [{"role": "user", "content": text}]

        trace = _new_execution_trace("/api/llm/chat", payload, raw_input or "chat stream")
        attach_vision = bool(payload.get("attach_vision", False))
        detector = str(payload.get("detector") or "none").strip().lower() or "none"
        _append_trace_step(
            trace,
            "request.parse",
            True,
            f"stream=1, attach_vision={attach_vision}, detector={detector}, msg_count={len(messages)}",
        )

        if attach_vision:
            _append_trace_step(trace, "request.validate", False, "stream mode does not support attach_vision=true")
            execution_trace = _finalize_execution_trace(trace, trace_started)
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "stream mode does not support attach_vision=true",
                    "execution_trace": execution_trace,
                },
                status=400,
            )
            return

        llm_payload: dict[str, Any] = {"messages": messages, "stream": True}
        for key in (
            "enable_thinking",
            "tools",
            "temperature",
            "top_p",
            "top_k",
            "max_tokens",
            "max_new_tokens",
            "repeat_penalty",
            "frequency_penalty",
            "presence_penalty",
            "keep_history",
            "clear_history",
            "session_id",
        ):
            if key in payload:
                llm_payload[key] = payload[key]

        fast_mode = _coerce_bool(payload.get("fast_mode"), default=False)
        try:
            raw_timeout = float(payload.get("timeout_sec"))
        except (TypeError, ValueError):
            raw_timeout = float(LLM_PROXY_TIMEOUT_SEC)
        timeout_floor = 1.0 if fast_mode else 3.0
        timeout_sec = max(timeout_floor, raw_timeout)
        wait_timeout = max(LLM_QUEUE_WAIT_SEC, float(timeout_sec) + 2.0)

        acquired, queue_note, queue_state, queue_waited_ms = QUEUE_GATE.acquire(wait_timeout)
        if not acquired:
            _append_trace_step(
                trace,
                "llm.queue",
                False,
                f"{queue_note}; inflight={queue_state.get('inflight', 0)}, waiting={queue_state.get('waiting', 0)}",
                duration_ms=queue_waited_ms,
                status=503,
            )
            execution_trace = _finalize_execution_trace(trace, trace_started)
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"{queue_note}; inflight={queue_state.get('inflight', 0)}, waiting={queue_state.get('waiting', 0)}",
                    "llm_queue": queue_state,
                    "execution_trace": execution_trace,
                },
                status=503,
            )
            return

        conn: http.client.HTTPConnection | http.client.HTTPSConnection | None = None
        status = 0
        token_count = 0
        first_token_ms: float | None = None
        text_parts: list[str] = []
        upstream_error = ""
        stream_started = False
        stream_started_at = time.perf_counter()
        prev_choice_count = 0
        last_obj: dict[str, Any] | None = None

        try:
            parsed = urlsplit(RKLLM_URL)
            host = parsed.hostname
            if not host:
                raise RuntimeError("invalid rkllm url: missing host")
            port = int(parsed.port or (443 if parsed.scheme == "https" else 80))
            req_path = parsed.path or "/"
            if parsed.query:
                req_path = f"{req_path}?{parsed.query}"

            body = json.dumps(llm_payload, ensure_ascii=False).encode("utf-8")
            req_headers = self._request_headers_for_upstream()
            req_headers["Content-Type"] = "application/json"
            req_headers["Content-Length"] = str(len(body))
            if parsed.scheme == "https":
                conn = http.client.HTTPSConnection(host, port, timeout=max(1.0, timeout_sec))
            else:
                conn = http.client.HTTPConnection(host, port, timeout=max(1.0, timeout_sec))
            conn.request("POST", req_path, body=body, headers=req_headers)
            resp = conn.getresponse()
            status = int(getattr(resp, "status", 0) or 0)

            _append_trace_step(
                trace,
                "llm.queue",
                True,
                f"waited={queue_waited_ms:.2f}ms, waiting={queue_state.get('waiting', 0)}, inflight={queue_state.get('inflight', 0)}",
                duration_ms=queue_waited_ms,
            )

            if not (200 <= status < 300):
                raw = resp.read()
                text = raw.decode("utf-8", errors="replace") if raw else ""
                try:
                    parsed_err = json.loads(text) if text else {}
                except Exception:
                    parsed_err = {"error": text or f"status={status}"}
                upstream_error = _extract_error_text(parsed_err) or _extract_error_text(text) or f"status={status}"
                _append_trace_step(
                    trace,
                    "llm.proxy",
                    False,
                    f"status={status}, timeout={timeout_sec:.1f}s, stream=1",
                    duration_ms=(time.perf_counter() - stream_started_at) * 1000.0,
                    status=status,
                )
                execution_trace = _finalize_execution_trace(trace, trace_started)
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"upstream status={status}",
                        "upstream_error": upstream_error,
                        "llm_status": status,
                        "llm_queue": QUEUE_GATE.snapshot(),
                        "execution_trace": execution_trace,
                    },
                    status=502,
                )
                return

            self._send_sse_headers(status=200)
            stream_started = True
            if not self._write_sse_event(
                "meta",
                {
                    "ok": True,
                    "timestamp": _ts_now(),
                    "llm_status": status,
                    "queue_waited_ms": round(queue_waited_ms, 2),
                    "trace_id": trace.get("trace_id"),
                },
            ):
                return

            while True:
                line = resp.readline()
                if not line:
                    break
                text_line = line.decode("utf-8", errors="replace").strip()
                if not text_line:
                    continue
                try:
                    obj = json.loads(text_line)
                except Exception:
                    continue
                if not isinstance(obj, dict):
                    continue
                last_obj = obj
                choices = obj.get("choices")
                if not isinstance(choices, list):
                    continue
                start_idx = prev_choice_count if len(choices) >= prev_choice_count else 0
                new_choices = choices[start_idx:]
                if (not new_choices) and len(choices) == 1 and prev_choice_count == 0:
                    new_choices = choices
                for choice in new_choices:
                    if not isinstance(choice, dict):
                        continue
                    delta = choice.get("delta")
                    if not isinstance(delta, dict):
                        continue
                    chunk = str(delta.get("content") or "")
                    if not chunk:
                        continue
                    token_count += 1
                    text_parts.append(chunk)
                    if first_token_ms is None:
                        first_token_ms = (time.perf_counter() - stream_started_at) * 1000.0
                    if not self._write_sse_event(
                        "token",
                        {
                            "index": token_count,
                            "delta": chunk,
                        },
                    ):
                        return
                prev_choice_count = max(prev_choice_count, len(choices))

            if (not text_parts) and isinstance(last_obj, dict):
                fallback_text = _extract_llm_text(last_obj)
                if fallback_text:
                    text_parts.append(fallback_text)
                    token_count = 1
                    if first_token_ms is None:
                        first_token_ms = (time.perf_counter() - stream_started_at) * 1000.0
                    self._write_sse_event(
                        "token",
                        {
                            "index": token_count,
                            "delta": fallback_text,
                        },
                    )
        except Exception as exc:
            upstream_error = str(exc or "")
            status = 599
            if stream_started:
                self._write_sse_event(
                    "error",
                    {
                        "ok": False,
                        "llm_status": status,
                        "detail": upstream_error,
                    },
                )
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
            QUEUE_GATE.release()

        llm_text = "".join(text_parts)
        ok = (200 <= int(status) < 300) and bool(llm_text)
        if (not ok) and (not upstream_error):
            upstream_error = "empty llm text" if int(status) >= 200 else f"status={status}"
        _append_trace_step(
            trace,
            "llm.proxy",
            ok,
            (
                f"status={status}, timeout={timeout_sec:.1f}s, stream=1, tokens={token_count}"
                if ok
                else f"status={status}, timeout={timeout_sec:.1f}s, stream=1, error={upstream_error[:120]}"
            ),
            duration_ms=(time.perf_counter() - stream_started_at) * 1000.0,
            status=(status if status > 0 else None),
        )
        execution_trace = _finalize_execution_trace(trace, trace_started)
        done_payload = {
            "ok": ok,
            "timestamp": _ts_now(),
            "llm_status": int(status),
            "text": llm_text,
            "token_count": int(token_count),
            "first_token_ms": round(float(first_token_ms or 0.0), 2),
            "total_ms": round((time.perf_counter() - trace_started) * 1000.0, 2),
            "detail": ("ok" if ok else _extract_error_text(upstream_error) or f"status={status}"),
            "execution_trace": execution_trace,
        }
        if stream_started:
            self._write_sse_event("done", done_payload)
        self.close_connection = True

    def _handle_agent_task(self, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        trace_started = time.perf_counter()
        task = str(payload.get("task") or "agent_task").strip().lower()[:32] or "agent_task"

        in_messages = payload.get("messages")
        messages: list[dict[str, Any]]
        raw_input = ""
        if isinstance(in_messages, list) and in_messages:
            messages = []
            for msg in in_messages:
                if not isinstance(msg, dict):
                    continue
                role = str(msg.get("role") or "user").strip() or "user"
                content = str(msg.get("content") or "")
                messages.append({"role": role, "content": content})
            for msg in reversed(messages):
                if str(msg.get("role") or "").strip().lower() == "user":
                    raw_input = str(msg.get("content") or "").strip()
                    if raw_input:
                        break
        else:
            prompt = str(payload.get("message") or payload.get("prompt") or "").strip()
            if not prompt:
                trace = _new_execution_trace("/api/llm/agent_task", payload, "")
                _append_trace_step(trace, "request.parse", False, "message/prompt or messages is required")
                execution_trace = _finalize_execution_trace(trace, trace_started)
                return 400, {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": "message/prompt or messages is required",
                    "assistant_feedback": "Agent task 缺少 message/prompt。",
                    "llm_queue": QUEUE_GATE.snapshot(),
                    "execution_trace": execution_trace,
                }
            raw_input = prompt
            messages = [{"role": "user", "content": prompt}]

        trace = _new_execution_trace("/api/llm/agent_task", payload, raw_input or task)
        _append_trace_step(
            trace,
            "request.parse",
            True,
            f"task={task}, msg_count={len(messages)}",
        )

        llm_payload: dict[str, Any] = {"messages": messages, "stream": False}
        # Agent-oriented defaults: short, deterministic, no reasoning chain.
        llm_payload["enable_thinking"] = False
        llm_payload["temperature"] = 0.2
        llm_payload["top_p"] = 0.8
        llm_payload["max_tokens"] = 96
        for key in (
            "enable_thinking",
            "temperature",
            "top_p",
            "top_k",
            "max_tokens",
            "max_new_tokens",
            "repeat_penalty",
            "frequency_penalty",
            "presence_penalty",
            "keep_history",
            "clear_history",
            "session_id",
            "tools",
        ):
            if key in payload:
                llm_payload[key] = payload[key]

        fast_mode = _coerce_bool(payload.get("fast_mode"), default=True)

        try:
            raw_timeout = float(payload.get("timeout_sec", LLM_AGENT_DEFAULT_TIMEOUT_SEC))
        except (TypeError, ValueError):
            raw_timeout = float(LLM_AGENT_DEFAULT_TIMEOUT_SEC)
        timeout_floor = 1.0 if fast_mode else 2.0
        timeout_sec = max(timeout_floor, min(60.0, raw_timeout))
        retries = _parse_int(payload.get("max_retries", 0), 0, 0, 8)
        busy_retries = _parse_int(payload.get("busy_retries", LLM_AGENT_BUSY_RETRIES), LLM_AGENT_BUSY_RETRIES, 0, 8)
        try:
            busy_retry_delay = float(payload.get("busy_retry_delay_sec", LLM_AGENT_BUSY_RETRY_DELAY_SEC))
        except (TypeError, ValueError):
            busy_retry_delay = float(LLM_AGENT_BUSY_RETRY_DELAY_SEC)
        busy_retry_delay = max(0.01, min(2.0, busy_retry_delay))

        llm_started = time.perf_counter()
        status, llm_resp, queue_state, queue_waited_ms, attempts = self._llm_with_busy_retry(
            payload=llm_payload,
            timeout_sec=timeout_sec,
            retries=retries,
            busy_retries=busy_retries,
            busy_retry_delay_sec=busy_retry_delay,
        )
        queue_err = ""
        if isinstance(llm_resp, dict):
            queue_err = str(llm_resp.get("error") or "")
        _append_trace_step(
            trace,
            "llm.queue",
            not (status == 503 and "queue" in queue_err.lower()),
            (
                f"waited={queue_waited_ms:.2f}ms, waiting={queue_state.get('waiting', 0)}, "
                f"inflight={queue_state.get('inflight', 0)}, attempts={attempts}"
            ),
            duration_ms=queue_waited_ms,
        )
        llm_text = _extract_llm_text(llm_resp)
        ok = 200 <= status < 300 and bool(llm_text)
        _append_trace_step(
            trace,
            "llm.proxy",
            ok,
            (
                f"status={status}, timeout={timeout_sec:.1f}s, retries={retries}, "
                f"busy_retries={busy_retries}, attempts={attempts}"
            ),
            duration_ms=(time.perf_counter() - llm_started) * 1000.0,
            status=status,
        )
        execution_trace = _finalize_execution_trace(trace, trace_started)

        response: dict[str, Any] = {
            "ok": ok,
            "timestamp": _ts_now(),
            "task": task,
            "llm_status": status,
            "llm_url": RKLLM_URL,
            "llm_queue": queue_state,
            "queue_waited_ms": round(queue_waited_ms, 2),
            "attempts": int(attempts),
            "assistant_feedback": (
                f"Agent task={task} completed(status={status}, attempts={attempts})."
                if ok
                else f"Agent task={task} failed(status={status}, attempts={attempts})."
            ),
            "execution_trace": execution_trace,
        }
        if not ok:
            response["error"] = _extract_error_text(llm_resp) or f"status={status}"
        if bool(payload.get("include_llm_text", True)):
            response["llm_text"] = llm_text
        if bool(payload.get("include_llm_response", False)):
            response["llm_response"] = llm_resp

        if ok:
            return 200, response
        if status == 503 and "queue" in queue_err.lower():
            return 503, response
        return 502, response

    def _fallback_vision_action_plan(
        self,
        query: str,
        vision_ctx: dict[str, Any],
        max_actions: int,
    ) -> dict[str, Any]:
        actions: list[dict[str, Any]] = []
        if vision_ctx.get("object_count", 0) > 0:
            actions.append({
                "action": "锁定主要目标并持续跟踪",
                "reason": "画面中已有目标，可先稳定追踪链路",
                "priority": "high",
            })
            actions.append({
                "action": "记录当前检测摘要与置信度",
                "reason": "形成可复现实验证据",
                "priority": "medium",
            })
        else:
            actions.append({
                "action": "切换 detector 并重新采样",
                "reason": "当前无目标，先验证感知链路",
                "priority": "high",
            })
            actions.append({
                "action": "检查相机状态与光照",
                "reason": "排除输入源异常",
                "priority": "medium",
            })
        return {
            "summary": str(query or "scene action plan")[:220],
            "risk_level": "medium",
            "recommended_actions": actions[: max(1, max_actions)],
            "confidence": 0.62,
            "source": "fallback",
        }

    def _normalize_vision_action_plan(
        self,
        raw_plan: dict[str, Any],
        fallback: dict[str, Any],
        max_actions: int,
    ) -> tuple[dict[str, Any], bool]:
        source = str(raw_plan.get("source") or "llm").strip()[:24] or "llm"
        summary = str(raw_plan.get("summary") or fallback.get("summary") or "")[:220]
        risk = str(raw_plan.get("risk_level") or fallback.get("risk_level") or "medium").strip().lower()
        if risk not in ("low", "medium", "high"):
            risk = "medium"
        try:
            confidence = float(raw_plan.get("confidence"))
        except (TypeError, ValueError):
            confidence = float(fallback.get("confidence", 0.6))
        confidence = max(0.0, min(1.0, confidence))

        rows = raw_plan.get("recommended_actions")
        out: list[dict[str, Any]] = []
        if isinstance(rows, list):
            for item in rows:
                if len(out) >= max_actions:
                    break
                if isinstance(item, str):
                    text = item.strip()
                    if not text:
                        continue
                    out.append({"action": text[:120], "reason": "", "priority": "medium"})
                    continue
                if not isinstance(item, dict):
                    continue
                action = str(item.get("action") or item.get("title") or "").strip()
                reason = str(item.get("reason") or "").strip()
                priority = str(item.get("priority") or "medium").strip().lower()
                if priority not in ("low", "medium", "high"):
                    priority = "medium"
                if action:
                    out.append({"action": action[:120], "reason": reason[:160], "priority": priority})
        used_fallback = False
        if not out:
            fb = fallback.get("recommended_actions")
            if isinstance(fb, list):
                out = [item for item in fb[:max_actions] if isinstance(item, dict)]
                used_fallback = True

        return {
            "summary": summary,
            "risk_level": risk,
            "recommended_actions": out,
            "confidence": confidence,
            "source": "fallback" if used_fallback else source,
        }, used_fallback

    def _handle_vision_action(self, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        query = str(payload.get("query") or payload.get("message") or "Analyze current scene and suggest next actions.").strip()
        if not query:
            query = "Analyze current scene and suggest next actions."
        detector = str(payload.get("detector") or "yolo_world").strip().lower() or "yolo_world"
        max_objects = _parse_int(payload.get("max_objects", 8), 8, 1, 20)
        max_actions = _parse_int(payload.get("max_actions", 3), 3, 1, 5)

        trace_started = time.perf_counter()
        trace = _new_execution_trace("/api/llm/vision_action", payload, query)
        _append_trace_step(
            trace,
            "request.parse",
            True,
            f"detector={detector}, max_objects={max_objects}, max_actions={max_actions}",
        )

        vision_terms_meta = self._resolve_and_apply_vision_terms(
            payload=payload,
            query=query,
            detector=detector,
            reason="vision_action",
            trace=trace,
        )

        tool_started = time.perf_counter()
        vision_status, vision_payload = self._call_vision_observe(detector=detector)
        tool_ok = bool(vision_payload.get("ok", False))
        tool_summary = str(vision_payload.get("summary") or vision_payload.get("error") or "ok")
        _append_trace_step(
            trace,
            "tool.vision.observe",
            tool_ok,
            f"detector={detector}; {tool_summary}",
            duration_ms=(time.perf_counter() - tool_started) * 1000.0,
            status=vision_status if isinstance(vision_status, int) else None,
        )
        if not tool_ok:
            err = str(vision_payload.get("error") or "vision unavailable")
            status = 400 if "unsupported detector" in err else (503 if vision_status >= 500 else 502)
            execution_trace = _finalize_execution_trace(trace, trace_started)
            return status, {
                "ok": False,
                "timestamp": _ts_now(),
                "error": err,
                "detector": detector,
                "vision_terms": vision_terms_meta,
                "tool_result": vision_payload,
                "assistant_feedback": f"读取视觉上下文失败：{err}",
                "llm_queue": QUEUE_GATE.snapshot(),
                "execution_trace": execution_trace,
            }

        vision_ctx = _summarize_vision_context(vision_payload, max_objects=max_objects)
        fallback_plan = self._fallback_vision_action_plan(query=query, vision_ctx=vision_ctx, max_actions=max_actions)

        llm_messages = [
            {
                "role": "system",
                "content": (
                    "You are an edge-AI planner. Return JSON only.\n"
                    "Schema:\n"
                    "{\n"
                    '  "summary":"short",\n'
                    '  "risk_level":"low|medium|high",\n'
                    '  "recommended_actions":[{"action":"...","reason":"...","priority":"low|medium|high"}],\n'
                    '  "confidence": 0.0\n'
                    "}"
                ),
            },
            {
                "role": "user",
                "content": (
                    f"query: {query}\n"
                    f"detector: {detector}\n"
                    + "vision_ctx:\n"
                    + json.dumps(vision_ctx, ensure_ascii=False)
                    + f"\nmax_actions: {max_actions}"
                ),
            },
        ]
        llm_payload: dict[str, Any] = {"messages": llm_messages, "stream": False}
        for key in (
            "enable_thinking",
            "tools",
            "temperature",
            "top_p",
            "top_k",
            "max_tokens",
            "max_new_tokens",
            "repeat_penalty",
            "frequency_penalty",
            "presence_penalty",
            "keep_history",
            "clear_history",
            "session_id",
        ):
            if key in payload:
                llm_payload[key] = payload[key]

        vision_object_count = self._clamp_int(
            vision_ctx.get("object_count"),
            default=0,
            min_value=0,
            max_value=200,
        )
        if ("max_tokens" not in llm_payload) and ("max_new_tokens" not in llm_payload):
            llm_payload["max_tokens"] = self._adaptive_max_tokens(
                task="vision_action",
                query=query,
                messages=llm_messages,
                object_count=vision_object_count,
                max_actions=max_actions,
                min_tokens=96,
                max_tokens=256,
            )
        try:
            timeout_sec = max(3.0, min(60.0, float(payload.get("timeout_sec"))))
        except (TypeError, ValueError):
            timeout_sec = self._adaptive_timeout_sec(
                task="vision_action",
                base_timeout_sec=max(4.0, min(20.0, float(LLM_PROXY_TIMEOUT_SEC))),
                query=query,
                messages=llm_messages,
                object_count=vision_object_count,
                max_actions=max_actions,
                min_sec=3.0,
                max_sec=20.0,
            )
        retries = _parse_int(payload.get("max_retries", LLM_PROXY_RETRIES), LLM_PROXY_RETRIES, 0, 8)
        token_budget = self._clamp_int(
            llm_payload.get("max_tokens") or llm_payload.get("max_new_tokens"),
            default=0,
            min_value=0,
            max_value=4096,
        )
        llm_started = time.perf_counter()
        llm_status, llm_resp, queue_state, queue_waited_ms = self._llm_with_queue(
            llm_payload,
            timeout_sec=timeout_sec,
            retries=retries,
        )
        queue_err = ""
        if isinstance(llm_resp, dict):
            queue_err = str(llm_resp.get("error") or "")
        _append_trace_step(
            trace,
            "llm.queue",
            not (llm_status == 503 and "queue" in queue_err.lower()),
            f"waited={queue_waited_ms:.2f}ms, waiting={queue_state.get('waiting', 0)}, inflight={queue_state.get('inflight', 0)}",
            duration_ms=queue_waited_ms,
        )
        llm_ok = 200 <= llm_status < 300
        _append_trace_step(
            trace,
            "llm.proxy",
            llm_ok,
            f"status={llm_status}, timeout={timeout_sec:.1f}s, retries={retries}, max_tokens={token_budget}",
            duration_ms=(time.perf_counter() - llm_started) * 1000.0,
            status=llm_status,
        )
        llm_text = _extract_llm_text(llm_resp)

        parsed: dict[str, Any] | None = None
        parse_error = ""
        if llm_ok:
            parsed, parse_error = _parse_json_object_from_text(llm_text)
        else:
            parse_error = f"llm request failed with status {llm_status}"

        if parsed is None:
            action_plan = fallback_plan
            degraded = True
        else:
            action_plan, used_fallback = self._normalize_vision_action_plan(
                raw_plan=parsed,
                fallback=fallback_plan,
                max_actions=max_actions,
            )
            degraded = used_fallback
            if degraded and not parse_error:
                parse_error = "llm JSON has no actionable items; merged with fallback"

        _append_trace_step(
            trace,
            "plan.normalize",
            not degraded,
            parse_error or f"source={action_plan.get('source', 'unknown')}, degraded={degraded}",
        )

        execution_trace = _finalize_execution_trace(trace, trace_started)
        response: dict[str, Any] = {
            "ok": True,
            "timestamp": _ts_now(),
            "query": query,
            "detector": detector,
            "degraded": degraded,
            "llm_ok": llm_ok,
            "llm_status": llm_status,
            "llm_url": RKLLM_URL,
            "llm_queue": queue_state,
            "queue_waited_ms": round(queue_waited_ms, 2),
            "llm_timeout_sec": float(timeout_sec),
            "llm_max_tokens": int(token_budget),
            "vision": vision_ctx,
            "vision_terms": vision_terms_meta,
            "tool_result": vision_payload,
            "action_plan": action_plan,
            "assistant_feedback": str(action_plan.get("summary") or "action plan ready"),
            "execution_trace": execution_trace,
        }
        if parse_error:
            response["parse_error"] = parse_error
        if bool(payload.get("include_llm_text", False)) or degraded:
            response["llm_text"] = llm_text
        if bool(payload.get("include_llm_response", False)):
            response["llm_response"] = llm_resp
        return 200, response

    def _fallback_defense_pack(
        self,
        query: str,
        project_name: str,
        target_award: str,
        detector: str,
        vision_ctx: dict[str, Any],
        max_qa: int,
    ) -> dict[str, Any]:
        summary = str(vision_ctx.get("summary") or "视觉链路正常")
        score_mapping = []
        for dim in RACE_SCORE_DIMENSIONS:
            score_mapping.append(
                {
                    "dimension": dim,
                    "evidence": [f"detector={detector}", f"vision_summary={summary[:80]}"],
                    "gap": "需补齐量化压力测试数据",
                    "action": "补充稳定性、时延、吞吐测试并形成图表",
                }
            )
        qa_bank = [
            {
                "q": "你们方案的核心价值是什么？",
                "a": "核心价值是端侧闭环：感知、决策和执行在本地完成，时延低且可控。",
                "evidence": "本地 API 与执行链路可复现",
            },
            {
                "q": "系统稳定性如何证明？",
                "a": "通过持续运行监测和异常恢复机制证明稳定性，并提供 trace 证据链。",
                "evidence": "recover 机制与 execution_trace",
            },
        ]
        return {
            "project_title": project_name,
            "target_award": target_award,
            "one_sentence_value": "面向真实场景的 RK3588 端侧视觉智能体，低时延可闭环执行。",
            "opening_30s": "我们将视觉识别、LLM 决策和设备执行放在端侧，形成可解释、可验证的闭环系统。",
            "score_mapping": score_mapping,
            "innovation_points": [
                "端侧多模块闭环编排",
                "基于证据链的执行追踪",
                "视觉与策略协同的低时延链路",
            ],
            "demo_script_3min": [
                {
                    "phase": "00:00-00:40 问题定义",
                    "talk_track": "说明场景痛点与端侧部署必要性。",
                    "proof": "需求与指标约束",
                },
                {
                    "phase": "00:40-01:50 系统演示",
                    "talk_track": "展示视觉观测、LLM 规划和执行反馈。",
                    "proof": "API 实时返回与trace",
                },
                {
                    "phase": "01:50-03:00 指标映射",
                    "talk_track": "对齐评分维度逐项给出证据。",
                    "proof": "score_mapping + 压测数据",
                },
            ],
            "qa_bank": qa_bank[:max_qa],
            "next_actions_2weeks": [
                "补齐多场景稳定性压测",
                "补齐多意图并行编排能力",
                "完善外设执行白名单与审计",
            ],
            "source": "fallback",
            "query": query,
        }

    def _normalize_defense_pack(
        self,
        raw_pack: dict[str, Any],
        fallback: dict[str, Any],
        max_qa: int,
    ) -> tuple[dict[str, Any], bool]:
        used_fallback = False

        def _pick_str(key: str, default: str, limit: int) -> str:
            nonlocal used_fallback
            text = str(raw_pack.get(key) or "").strip()
            if not text:
                used_fallback = True
                text = default
            return text[:limit]

        project_title = _pick_str("project_title", str(fallback.get("project_title") or ""), 100)
        target_award = _pick_str("target_award", str(fallback.get("target_award") or ""), 40)
        one_sentence_value = _pick_str("one_sentence_value", str(fallback.get("one_sentence_value") or ""), 220)
        opening_30s = _pick_str("opening_30s", str(fallback.get("opening_30s") or ""), 320)

        score_mapping = raw_pack.get("score_mapping")
        if not isinstance(score_mapping, list) or not score_mapping:
            used_fallback = True
            score_mapping = fallback.get("score_mapping") if isinstance(fallback.get("score_mapping"), list) else []
        normalized_scores: list[dict[str, Any]] = []
        for item in score_mapping[: len(RACE_SCORE_DIMENSIONS)]:
            if not isinstance(item, dict):
                continue
            dim = str(item.get("dimension") or "").strip()[:40]
            evidence_raw = item.get("evidence")
            evidence = [str(v)[:120] for v in evidence_raw[:5]] if isinstance(evidence_raw, list) else []
            gap = str(item.get("gap") or "").strip()[:160]
            action = str(item.get("action") or "").strip()[:160]
            if not dim:
                continue
            normalized_scores.append(
                {
                    "dimension": dim,
                    "evidence": evidence,
                    "gap": gap or "待补齐该维度证据",
                    "action": action or "补齐测试与演示材料",
                }
            )
        if not normalized_scores:
            used_fallback = True
            normalized_scores = fallback.get("score_mapping") if isinstance(fallback.get("score_mapping"), list) else []

        innovation = raw_pack.get("innovation_points")
        if not isinstance(innovation, list) or not innovation:
            used_fallback = True
            innovation = fallback.get("innovation_points") if isinstance(fallback.get("innovation_points"), list) else []
        innovation_points = [str(v)[:120] for v in innovation[:6] if str(v).strip()]

        demo_script = raw_pack.get("demo_script_3min")
        if not isinstance(demo_script, list) or not demo_script:
            used_fallback = True
            demo_script = fallback.get("demo_script_3min") if isinstance(fallback.get("demo_script_3min"), list) else []
        demo_rows: list[dict[str, str]] = []
        for item in demo_script[:6]:
            if not isinstance(item, dict):
                continue
            phase = str(item.get("phase") or "").strip()[:60]
            talk_track = str(item.get("talk_track") or "").strip()[:240]
            proof = str(item.get("proof") or "").strip()[:160]
            if phase and talk_track:
                demo_rows.append({"phase": phase, "talk_track": talk_track, "proof": proof})
        if not demo_rows:
            used_fallback = True
            demo_rows = fallback.get("demo_script_3min") if isinstance(fallback.get("demo_script_3min"), list) else []

        qa_bank = raw_pack.get("qa_bank")
        if not isinstance(qa_bank, list) or not qa_bank:
            used_fallback = True
            qa_bank = fallback.get("qa_bank") if isinstance(fallback.get("qa_bank"), list) else []
        qa_rows: list[dict[str, str]] = []
        for item in qa_bank[:max_qa]:
            if not isinstance(item, dict):
                continue
            q = str(item.get("q") or item.get("question") or "").strip()[:160]
            a = str(item.get("a") or item.get("answer") or "").strip()[:280]
            evidence = str(item.get("evidence") or "").strip()[:180]
            if q and a:
                qa_rows.append({"q": q, "a": a, "evidence": evidence})
        if not qa_rows:
            used_fallback = True
            qa_rows = fallback.get("qa_bank") if isinstance(fallback.get("qa_bank"), list) else []

        next_actions = raw_pack.get("next_actions_2weeks")
        if not isinstance(next_actions, list) or not next_actions:
            used_fallback = True
            next_actions = fallback.get("next_actions_2weeks") if isinstance(fallback.get("next_actions_2weeks"), list) else []
        next_rows = [str(v)[:120] for v in next_actions[:8] if str(v).strip()]

        source = str(raw_pack.get("source") or "llm").strip()[:24] or "llm"
        if used_fallback:
            source = "mixed"

        return {
            "project_title": project_title,
            "target_award": target_award,
            "one_sentence_value": one_sentence_value,
            "opening_30s": opening_30s,
            "score_mapping": normalized_scores,
            "innovation_points": innovation_points,
            "demo_script_3min": demo_rows,
            "qa_bank": qa_rows,
            "next_actions_2weeks": next_rows,
            "source": source,
        }, used_fallback

    def _handle_defense_pack(self, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        query = str(payload.get("query") or payload.get("message") or "请基于赛题维度生成答辩稿与高频问答。").strip()
        if not query:
            query = "请基于赛题维度生成答辩稿与高频问答。"
        detector = str(payload.get("detector") or "yolo_world").strip().lower() or "yolo_world"
        project_name = str(payload.get("project_name") or payload.get("title") or "RK3588 Edge Vision Assistant").strip()
        target_award = str(payload.get("target_award") or "国赛一等奖").strip() or "国赛一等奖"

        max_objects = _parse_int(payload.get("max_objects", 8), 8, 1, 20)
        max_qa = _parse_int(payload.get("max_qa", 8), 8, 4, 15)

        trace_started = time.perf_counter()
        trace = _new_execution_trace("/api/llm/defense_pack", payload, query)
        _append_trace_step(
            trace,
            "request.parse",
            True,
            f"detector={detector}, project={project_name[:48]}, target={target_award}, max_qa={max_qa}",
        )

        vision_terms_meta = self._resolve_and_apply_vision_terms(
            payload=payload,
            query=query,
            detector=detector,
            reason="defense_pack",
            trace=trace,
        )

        tool_started = time.perf_counter()
        vision_status, vision_payload = self._call_vision_observe(detector=detector)
        tool_ok = bool(vision_payload.get("ok", False))
        tool_summary = str(vision_payload.get("summary") or vision_payload.get("error") or "ok")
        _append_trace_step(
            trace,
            "tool.vision.observe",
            tool_ok,
            f"detector={detector}; {tool_summary}",
            duration_ms=(time.perf_counter() - tool_started) * 1000.0,
            status=vision_status if isinstance(vision_status, int) else None,
        )
        if tool_ok:
            vision_ctx = _summarize_vision_context(vision_payload, max_objects=max_objects)
        else:
            vision_ctx = {
                "ok": False,
                "summary": str(vision_payload.get("error") or "vision unavailable"),
                "object_count": 0,
                "class_counts": {},
                "best_target": None,
                "objects": [],
                "camera": {},
            }

        fallback_pack = self._fallback_defense_pack(
            query=query,
            project_name=project_name,
            target_award=target_award,
            detector=detector,
            vision_ctx=vision_ctx,
            max_qa=max_qa,
        )

        llm_messages = [
            {
                "role": "system",
                "content": (
                    "你是竞赛答辩助手。仅返回 JSON，不要 markdown。\n"
                    "必须包含: project_title,target_award,one_sentence_value,opening_30s,"
                    "score_mapping,innovation_points,demo_script_3min,qa_bank,next_actions_2weeks"
                ),
            },
            {
                "role": "user",
                "content": (
                    f"query={query}\n"
                    f"project_name={project_name}\n"
                    f"target_award={target_award}\n"
                    f"detector={detector}\n"
                    + "vision_ctx="
                    + json.dumps(vision_ctx, ensure_ascii=False)
                    + f"\nmax_qa={max_qa}"
                ),
            },
        ]
        llm_payload: dict[str, Any] = {"messages": llm_messages, "stream": False}
        for key in (
            "enable_thinking",
            "tools",
            "temperature",
            "top_p",
            "top_k",
            "max_tokens",
            "max_new_tokens",
            "repeat_penalty",
            "frequency_penalty",
            "presence_penalty",
            "keep_history",
            "clear_history",
            "session_id",
        ):
            if key in payload:
                llm_payload[key] = payload[key]

        defense_object_count = self._clamp_int(
            vision_ctx.get("object_count"),
            default=0,
            min_value=0,
            max_value=200,
        )
        if ("max_tokens" not in llm_payload) and ("max_new_tokens" not in llm_payload):
            llm_payload["max_tokens"] = self._adaptive_max_tokens(
                task="defense_pack",
                query=query,
                messages=llm_messages,
                object_count=defense_object_count,
                max_qa=max_qa,
                min_tokens=360,
                max_tokens=1024,
            )
        try:
            timeout_sec = max(5.0, min(180.0, float(payload.get("timeout_sec"))))
        except (TypeError, ValueError):
            timeout_sec = self._adaptive_timeout_sec(
                task="defense_pack",
                base_timeout_sec=max(8.0, min(120.0, float(LLM_DEFENSE_TIMEOUT_SEC))),
                query=query,
                messages=llm_messages,
                object_count=defense_object_count,
                max_qa=max_qa,
                min_sec=8.0,
                max_sec=120.0,
            )
        retries = _parse_int(payload.get("max_retries", LLM_DEFENSE_RETRIES), LLM_DEFENSE_RETRIES, 0, 12)
        token_budget = self._clamp_int(
            llm_payload.get("max_tokens") or llm_payload.get("max_new_tokens"),
            default=0,
            min_value=0,
            max_value=4096,
        )
        llm_started = time.perf_counter()
        llm_status, llm_resp, queue_state, queue_waited_ms = self._llm_with_queue(
            llm_payload,
            timeout_sec=timeout_sec,
            retries=retries,
        )
        queue_err = ""
        if isinstance(llm_resp, dict):
            queue_err = str(llm_resp.get("error") or "")
        _append_trace_step(
            trace,
            "llm.queue",
            not (llm_status == 503 and "queue" in queue_err.lower()),
            f"waited={queue_waited_ms:.2f}ms, waiting={queue_state.get('waiting', 0)}, inflight={queue_state.get('inflight', 0)}",
            duration_ms=queue_waited_ms,
        )
        llm_ok = 200 <= llm_status < 300
        _append_trace_step(
            trace,
            "llm.proxy",
            llm_ok,
            f"status={llm_status}, timeout={timeout_sec:.1f}s, retries={retries}, max_tokens={token_budget}",
            duration_ms=(time.perf_counter() - llm_started) * 1000.0,
            status=llm_status,
        )
        llm_text = _extract_llm_text(llm_resp)

        parsed: dict[str, Any] | None = None
        parse_error = ""
        if llm_ok:
            parsed, parse_error = _parse_json_object_from_text(llm_text)
        else:
            parse_error = f"llm request failed with status {llm_status}"

        if parsed is None:
            defense_pack = fallback_pack
            degraded = True
        else:
            defense_pack, used_fallback = self._normalize_defense_pack(
                raw_pack=parsed,
                fallback=fallback_pack,
                max_qa=max_qa,
            )
            degraded = used_fallback
            if degraded and not parse_error:
                parse_error = "llm JSON incomplete; merged with fallback"

        _append_trace_step(
            trace,
            "pack.normalize",
            not degraded,
            parse_error or f"source={defense_pack.get('source', 'unknown')}, degraded={degraded}",
        )

        execution_trace = _finalize_execution_trace(trace, trace_started)
        response: dict[str, Any] = {
            "ok": True,
            "timestamp": _ts_now(),
            "query": query,
            "detector": detector,
            "project_name": project_name,
            "target_award": target_award,
            "degraded": degraded,
            "llm_ok": llm_ok,
            "llm_status": llm_status,
            "llm_url": RKLLM_URL,
            "llm_queue": queue_state,
            "queue_waited_ms": round(queue_waited_ms, 2),
            "llm_timeout_sec": float(timeout_sec),
            "llm_max_tokens": int(token_budget),
            "vision": vision_ctx,
            "vision_terms": vision_terms_meta,
            "tool_result": vision_payload,
            "defense_pack": defense_pack,
            "assistant_feedback": str(defense_pack.get("one_sentence_value") or "defense pack ready"),
            "execution_trace": execution_trace,
        }
        if parse_error:
            response["parse_error"] = parse_error
        if bool(payload.get("include_llm_text", False)) or degraded:
            response["llm_text"] = llm_text
        if bool(payload.get("include_llm_response", False)):
            response["llm_response"] = llm_resp
        return 200, response

    def _handle_vision_label_resolve(self, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        query = str(payload.get("query") or payload.get("message") or "").strip()
        detector = str(payload.get("detector") or "yolo_world").strip().lower() or "yolo_world"
        apply = _coerce_bool(payload.get("apply", True), default=True)

        trace_started = time.perf_counter()
        trace = _new_execution_trace("/api/llm/vision_label_resolve", payload, query)
        _append_trace_step(
            trace,
            "request.parse",
            True,
            f"detector={detector}, apply={apply}",
        )

        meta = self._resolve_and_apply_vision_terms(
            payload=payload,
            query=query,
            detector=detector,
            reason="vision_label_resolve",
            apply=apply,
            trace=trace,
        )
        ok = bool(meta.get("applied") or meta.get("skipped"))
        err = str(meta.get("error") or "").strip()
        if err:
            ok = False

        execution_trace = _finalize_execution_trace(trace, trace_started)
        response: dict[str, Any] = {
            "ok": ok,
            "timestamp": _ts_now(),
            "query": query,
            "detector": detector,
            "apply": apply,
            "vision_terms": meta,
            "assistant_feedback": (
                "视觉词汇已下发。"
                if bool(meta.get("applied"))
                else "视觉词汇已解析（未下发）。"
                if bool(meta.get("skipped"))
                else f"视觉词汇解析失败：{err or 'unknown'}"
            ),
            "execution_trace": execution_trace,
        }
        if err:
            response["error"] = err
            return 400, response
        return 200, response

    def _handle_health(self) -> tuple[int, dict[str, Any]]:
        llm_up, llm_msg = _tcp_check(RKLLM_URL, timeout_sec=1.0)
        vision_up, vision_msg = _tcp_check(VISION_API_BASE, timeout_sec=1.0)
        npu = _read_npu_runtime()
        ok = llm_up
        return (200 if ok else 503), {
            "ok": ok,
            "timestamp": _ts_now(),
            "service": "llm-preview-v2",
            "enabled": True,
            "url": RKLLM_URL,
            "listen": f"{HOST}:{PORT}",
            "rkllm_url": RKLLM_URL,
            "vision_api_base": VISION_API_BASE,
            "runtime": {
                "proxy_url": RKLLM_URL,
                "proxy_enabled": True,
                "abort_url": RKLLM_ABORT_URL or None,
                "abort_on_timeout": bool(LLM_ABORT_ON_TIMEOUT),
                "timeout_abort_settle_sec": float(LLM_TIMEOUT_ABORT_SETTLE_SEC),
                "npu_driver_version": npu.get("driver_version"),
                "npu_available": npu.get("available"),
                "npu_usage_percent": npu.get("usage_percent"),
                "npu_freq_hz": npu.get("freq_hz"),
                "npu_power_state": npu.get("power_state"),
                "npu_cores_usage": npu.get("cores"),
                "warmup": _warmup_state_snapshot(),
            },
            "health_semantics": {
                "ok_means": "rkllm dependency is reachable",
                "optional_dependencies": ["vision"],
            },
            "deps": {
                "rkllm": {"up": llm_up, "detail": llm_msg, "required": True},
                "vision": {"up": vision_up, "detail": vision_msg, "required": False},
            },
            "queue": QUEUE_GATE.snapshot(),
        }

    def do_OPTIONS(self) -> None:
        route = urlsplit(self.path).path
        allow_methods = _allowed_methods_for_route(route)
        if allow_methods:
            self.send_response(204)
            self.send_header("Allow", ",".join(allow_methods))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", ",".join(allow_methods))
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if route.startswith("/api/llm/"):
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"unsupported llm route: {route}",
                    "supported": _supported_llm_routes(),
                },
                status=404,
            )
            return
        self._send_json(
            {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"not found: {route}",
            },
            status=404,
        )

    def do_HEAD(self) -> None:
        self._dispatch(head_only=True)

    def do_GET(self) -> None:
        self._dispatch(head_only=False)

    def do_POST(self) -> None:
        self._dispatch(head_only=False)

    def do_PUT(self) -> None:
        self._dispatch(head_only=False)

    def do_PATCH(self) -> None:
        self._dispatch(head_only=False)

    def do_DELETE(self) -> None:
        self._dispatch(head_only=False)

    def do_TRACE(self) -> None:
        self._dispatch(head_only=False)

    def do_CONNECT(self) -> None:
        self._dispatch(head_only=False)

    def _dispatch(self, head_only: bool) -> None:
        route = urlsplit(self.path).path

        if route == "/health":
            if self.command in ("GET", "HEAD"):
                status, payload = self._handle_health()
                self._send_json(payload, status=status)
                return
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"method not allowed: {self.command}",
                    "route": route,
                    "allow": _allowed_methods_for_route(route),
                },
                status=405,
            )
            return

        if route.startswith("/api/llm/"):
            allow = _LLM_ROUTE_METHODS.get(route)
            if not allow:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"unsupported llm route: {route}",
                        "supported": _supported_llm_routes(),
                    },
                    status=404,
                )
                return

            effective_method = "GET" if self.command == "HEAD" else self.command
            if effective_method not in allow:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"method not allowed: {self.command}",
                        "route": route,
                        "allow": _allowed_methods_for_route(route),
                    },
                    status=405,
                )
                return

            if effective_method == "GET":
                if route == "/api/llm/health":
                    status, payload = self._handle_health()
                    payload["api"] = "/api/llm/health"
                    self._send_json(payload, status=status)
                    return
                if route == "/api/llm/queue":
                    self._send_json(
                        {
                            "ok": True,
                            "timestamp": _ts_now(),
                            "queue": QUEUE_GATE.snapshot(),
                        },
                        status=200,
                    )
                    return

            payload, err = self._read_json_body()
            if payload is None:
                self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                return

            if route == "/api/llm/chat":
                if bool(payload.get("stream", False)):
                    self._handle_llm_chat_stream(payload)
                else:
                    status, resp = self._handle_llm_chat(payload)
                    self._send_json(resp, status=status)
                return
            if route == "/api/llm/agent_task":
                status, resp = self._handle_agent_task(payload)
                self._send_json(resp, status=status)
                return
            if route == "/api/llm/vision_action":
                status, resp = self._handle_vision_action(payload)
                self._send_json(resp, status=status)
                return
            if route == "/api/llm/defense_pack":
                status, resp = self._handle_defense_pack(payload)
                self._send_json(resp, status=status)
                return
            if route == "/api/llm/vision_label_resolve":
                status, resp = self._handle_vision_label_resolve(payload)
                self._send_json(resp, status=status)
                return

            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"unsupported llm route: {route}",
                    "supported": _supported_llm_routes(),
                },
                status=404,
            )
            return

        self._send_json(
            {
                "ok": False,
                "timestamp": _ts_now(),
                "error": f"not found: {route}",
            },
            status=404,
        )

    def log_message(self, fmt: str, *args: Any) -> None:
        message = fmt % args if args else fmt
        remote = "local"
        port = 0
        if isinstance(self.client_address, tuple):
            if len(self.client_address) > 0:
                remote = str(self.client_address[0])
            if len(self.client_address) > 1:
                try:
                    port = int(self.client_address[1])
                except Exception:
                    port = 0
        print(
            f"{datetime.now().isoformat(timespec='seconds')} "
            f"llm-preview {remote}:{port} {message}"
        )


def main() -> None:
    if LLM_WARMUP_ENABLED:
        threading.Thread(target=_warmup_worker, name="llm-warmup", daemon=True).start()
    server = bind_server(HOST, PORT, LLMPreviewHandler, unix_socket_path=UNIX_SOCKET_PATH)
    print(
        "llm preview v2 listening on "
        f"{('unix://' + UNIX_SOCKET_PATH) if UNIX_SOCKET_PATH else ('http://' + HOST + ':' + str(PORT))} "
        f"(rkllm={RKLLM_URL}, vision={VISION_API_BASE}, "
        f"warmup={int(LLM_WARMUP_ENABLED)}, warmup_interval={LLM_WARMUP_INTERVAL_SEC}s)"
    )
    server.serve_forever()


if __name__ == "__main__":
    main()
