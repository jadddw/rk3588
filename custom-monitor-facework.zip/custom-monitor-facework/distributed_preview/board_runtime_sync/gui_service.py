﻿#!/usr/bin/env python3
from __future__ import annotations

import http.client
import cgi
import json
import io
import mimetypes
import os
import re
import socket
import subprocess
import threading
import time
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlencode, urlsplit

from ipc_http import bind_server, compose_request_path, open_connection, tcp_probe

HOST = os.environ.get("GUI_PREVIEW_HOST", "0.0.0.0")
PORT = int(os.environ.get("GUI_PREVIEW_PORT", "8090"))
UNIX_SOCKET_PATH = str(os.environ.get("GUI_UNIX_SOCKET", "")).strip()

ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = Path(os.environ.get("GUI_STATIC_DIR", str(ROOT / "static"))).resolve()
RUNTIME_DIR = Path(__file__).resolve().parent / "runtime"
UPLOAD_DIR = Path(os.environ.get("GUI_UPLOAD_DIR", str(RUNTIME_DIR / "uploads"))).resolve()

LLM_API_BASE = os.environ.get("GUI_LLM_API_BASE", "http://127.0.0.1:8091").rstrip("/")
AGENT_API_BASE = os.environ.get("GUI_AGENT_API_BASE", "http://127.0.0.1:8093").rstrip("/")
VISION_API_BASE = os.environ.get("GUI_VISION_API_BASE", "http://127.0.0.1:8092").rstrip("/")
HEALTH_MODE = os.environ.get("GUI_HEALTH_MODE", "self").strip().lower()
if HEALTH_MODE not in ("self", "deps"):
    HEALTH_MODE = "self"

FORWARD_TIMEOUT_SEC = max(1.0, float(os.environ.get("GUI_FORWARD_TIMEOUT_SEC", "130")))
GUI_TIMEOUT_SHORT_SEC = max(1.0, float(os.environ.get("GUI_TIMEOUT_SHORT_SEC", "8")))
GUI_TIMEOUT_MEDIUM_SEC = max(1.0, float(os.environ.get("GUI_TIMEOUT_MEDIUM_SEC", "20")))
GUI_TIMEOUT_LONG_SEC = max(1.0, float(os.environ.get("GUI_TIMEOUT_LONG_SEC", str(FORWARD_TIMEOUT_SEC))))
STREAM_CHUNK_SIZE = max(4096, int(os.environ.get("GUI_STREAM_CHUNK_SIZE", "65536")))
CAM_DIAG_CACHE_TTL_SEC = max(0.2, float(os.environ.get("GUI_CAMERA_DIAG_CACHE_TTL_SEC", "2.0")))
CAM_DIAG_WINDOW_SEC = max(20.0, float(os.environ.get("GUI_CAMERA_DIAG_WINDOW_SEC", "180")))

PAGE_ROUTES = {
    "/": "index.html",
    "/index.html": "index.html",
    "/video": "video.html",
    "/video.html": "video.html",
    "/llm": "llm.html",
    "/llm.html": "llm.html",
}

API_EXACT_MAP: dict[str, str] = {
    "/api/upload/media": "local:/api/upload/media",
}

API_PREFIX_MAP = (
    ("/api/llm/", LLM_API_BASE),
    ("/api/agent/", AGENT_API_BASE),
    ("/api/vision/", VISION_API_BASE),
)

HOP_BY_HOP = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "trailers",
    "transfer-encoding",
    "upgrade",
}
CORS_ALLOW_METHODS = "GET,POST,PUT,PATCH,DELETE,HEAD,OPTIONS"


def _ts_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _url_tcp_check(base_url: str, timeout_sec: float = 1.0) -> tuple[bool, str]:
    return tcp_probe(base_url, timeout_sec=timeout_sec)


def _read_text(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8").strip()
    except (FileNotFoundError, PermissionError, OSError):
        return ""


def _read_int(path: str) -> int | None:
    text = _read_text(path)
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        return None


def _run_cmd(cmd: list[str], timeout_sec: float = 2.0) -> tuple[int, str, str]:
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=timeout_sec)
        return int(result.returncode), result.stdout or "", result.stderr or ""
    except Exception as exc:
        return -1, "", str(exc)


def _http_get_json(base_url: str, path: str, timeout_sec: float = 2.0) -> tuple[bool, dict[str, Any] | None, str, int]:
    conn: http.client.HTTPConnection | None = None
    try:
        conn, _target = open_connection(base_url, timeout_sec=timeout_sec)
        req_path = compose_request_path(base_url, path)
        conn.request("GET", req_path, headers={"Accept": "application/json"})
        resp = conn.getresponse()
        status = int(resp.status)
        raw = resp.read()
        text = raw.decode("utf-8", errors="replace") if raw else ""
        if status < 200 or status >= 300:
            return False, None, text[:120] or f"status={status}", status
        try:
            payload = json.loads(text) if text else {}
        except Exception as exc:
            return False, None, f"invalid json: {exc}", status
        if not isinstance(payload, dict):
            return False, None, "invalid json payload", status
        return True, payload, "ok", status
    except Exception as exc:
        return False, None, str(exc), 0
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def _normalize_profile_alias(name: str) -> str:
    key = str(name or "").strip().lower()
    if key == "custom":
        return "clear60"
    return key


def _save_uploaded_media(filename: str, payload: bytes) -> Path:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = Path(filename or "upload.bin").name.replace("\\", "_").replace("/", "_")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = UPLOAD_DIR / f"{stamp}_{uuid.uuid4().hex[:8]}_{safe_name}"
    target.write_bytes(payload)
    return target


def _resolve_camera_device(camera_hint: str | None) -> dict[str, Any]:
    hint = str(camera_hint or "").strip()
    candidates: list[str] = []
    if hint:
        if hint.startswith("/dev/"):
            candidates.append(hint)
        elif hint.isdigit():
            candidates.append(f"/dev/video{hint}")

    by_id_dir = Path("/dev/v4l/by-id")
    if by_id_dir.exists():
        for item in sorted(by_id_dir.glob("*-video-index0")):
            candidates.append(str(item))
        for item in sorted(by_id_dir.glob("*-video-index1")):
            candidates.append(str(item))

    for item in sorted(Path("/dev").glob("video[0-9]*")):
        candidates.append(str(item))

    seen: set[str] = set()
    for cand in candidates:
        if cand in seen:
            continue
        seen.add(cand)
        path = Path(cand)
        if not path.exists():
            continue
        resolved = str(path.resolve())
        node = Path(resolved).name if resolved.startswith("/dev/video") else ""
        if not node.startswith("video"):
            continue
        return {
            "configured": hint or None,
            "path": cand,
            "resolved_path": resolved,
            "video_node": node,
            "exists": True,
        }

    return {
        "configured": hint or None,
        "path": hint or None,
        "resolved_path": None,
        "video_node": None,
        "exists": False,
    }


def _v4l2_capture_state(device_path: str | None) -> dict[str, Any]:
    if not device_path:
        return {"ok": False, "error": "missing device"}
    rc, out, err = _run_cmd(["v4l2-ctl", "-d", device_path, "--get-fmt-video", "--get-parm"], timeout_sec=2.0)
    text = f"{out}\n{err}".strip()
    payload: dict[str, Any] = {"ok": rc == 0, "device": device_path}
    if rc != 0:
        payload["error"] = err.strip() or out.strip() or f"v4l2-ctl rc={rc}"
        return payload
    m_size = re.search(r"Width/Height\s*:\s*(\d+)\s*/\s*(\d+)", text, re.IGNORECASE)
    m_fmt = re.search(r"Pixel Format\s*:\s*'([^']+)'", text, re.IGNORECASE)
    m_fps = re.search(r"Frames per second:\s*([0-9.]+)", text, re.IGNORECASE)
    payload["width"] = int(m_size.group(1)) if m_size else None
    payload["height"] = int(m_size.group(2)) if m_size else None
    payload["pixel_format"] = m_fmt.group(1) if m_fmt else None
    payload["fps"] = float(m_fps.group(1)) if m_fps else None
    return payload


def _transport_from_speed(speed_mbps: float | None) -> str:
    if speed_mbps is None:
        return "unknown"
    if speed_mbps >= 5000:
        return "USB 3.x SuperSpeed"
    if speed_mbps >= 480:
        return "USB 2.0 High-Speed"
    if speed_mbps >= 12:
        return "USB Full-Speed"
    return "USB Low-Speed"


def _usb_info_from_video_node(video_node: str | None) -> dict[str, Any]:
    if not video_node:
        return {"ok": False, "error": "missing video node"}
    iface_link = Path("/sys/class/video4linux") / video_node / "device"
    if not iface_link.exists():
        return {"ok": False, "error": f"sysfs not found for {video_node}"}

    try:
        iface_path = iface_link.resolve()
    except OSError as exc:
        return {"ok": False, "error": str(exc)}

    usb_dev = iface_path
    while usb_dev != usb_dev.parent:
        if (usb_dev / "idVendor").exists() and (usb_dev / "idProduct").exists():
            break
        usb_dev = usb_dev.parent

    if not (usb_dev / "idVendor").exists():
        return {"ok": False, "error": f"usb parent not found for {video_node}"}

    speed_text = _read_text(str(usb_dev / "speed"))
    speed_mbps: float | None = None
    try:
        if speed_text:
            speed_mbps = float(speed_text)
    except ValueError:
        speed_mbps = None

    busnum_text = _read_text(str(usb_dev / "busnum"))
    devpath_text = _read_text(str(usb_dev / "devpath"))
    port_id = ""
    if busnum_text.isdigit() and devpath_text:
        port_id = f"{int(busnum_text)}-{devpath_text}"

    controller = ""
    for parent in [iface_path, *iface_path.parents]:
        name = parent.name.lower()
        if "xhci" in name or "ehci" in name or "ohci" in name:
            controller = parent.name
            break

    return {
        "ok": True,
        "video_node": video_node,
        "interface_path": iface_path.name,
        "usb_device_path": usb_dev.name,
        "port_id": port_id or None,
        "busnum": int(busnum_text) if busnum_text.isdigit() else None,
        "devpath": devpath_text or None,
        "speed_mbps": speed_mbps,
        "transport": _transport_from_speed(speed_mbps),
        "vendor_id": _read_text(str(usb_dev / "idVendor")) or None,
        "product_id": _read_text(str(usb_dev / "idProduct")) or None,
        "manufacturer": _read_text(str(usb_dev / "manufacturer")) or None,
        "product": _read_text(str(usb_dev / "product")) or None,
        "serial": _read_text(str(usb_dev / "serial")) or None,
        "controller": controller or None,
    }


def _camera_dmesg_stats(usb_port_id: str | None, window_sec: float) -> dict[str, Any]:
    rc, out, err = _run_cmd(["dmesg"], timeout_sec=2.5)
    if rc != 0 and not out:
        return {"ok": False, "error": err or f"dmesg rc={rc}"}

    ts_pat = re.compile(r"^\[\s*([0-9]+(?:\.[0-9]+)?)\]\s*(.*)$")
    events: list[dict[str, Any]] = []
    for raw in out.splitlines():
        raw = raw.strip()
        if not raw:
            continue
        m = ts_pat.match(raw)
        ts_val: float | None = None
        msg = raw
        if m:
            try:
                ts_val = float(m.group(1))
            except ValueError:
                ts_val = None
            msg = m.group(2)

        kind = ""
        if "uvcvideo: Failed to resubmit video URB" in msg:
            kind = "urb_fail"
        elif "reset SuperSpeed" in msg:
            kind = "reset_superspeed"
        elif "reset high-speed" in msg:
            kind = "reset_highspeed"
        elif "USB disconnect" in msg:
            kind = "disconnect"
        elif "Found UVC" in msg:
            kind = "uvc_found"
        elif "Failed to query (GET_" in msg and "uvcvideo" in msg:
            kind = "uvc_ctrl_fail"
        else:
            continue

        if kind in ("reset_superspeed", "reset_highspeed", "disconnect") and usb_port_id:
            if f"usb {usb_port_id}" not in msg and f"{usb_port_id}:" not in msg:
                continue

        events.append({"ts": ts_val, "kind": kind, "msg": msg})

    if not events:
        return {
            "ok": True,
            "window_sec": window_sec,
            "counts_total": {},
            "counts_recent": {},
            "latest_lines": [],
            "stability": {"level": "good", "label": "无异常日志"},
        }

    max_ts = max((e["ts"] for e in events if isinstance(e["ts"], float)), default=None)
    cutoff = (max_ts - window_sec) if max_ts is not None else None

    counts_total: dict[str, int] = {}
    counts_recent: dict[str, int] = {}
    for e in events:
        k = str(e.get("kind") or "")
        counts_total[k] = counts_total.get(k, 0) + 1
        is_recent = cutoff is None or (isinstance(e.get("ts"), float) and float(e["ts"]) >= cutoff)
        if is_recent:
            counts_recent[k] = counts_recent.get(k, 0) + 1

    recent_events: list[dict[str, Any]]
    if cutoff is None:
        recent_events = events[-12:]
    else:
        tmp = [e for e in events if isinstance(e.get("ts"), float) and float(e["ts"]) >= cutoff]
        recent_events = tmp[-12:] if tmp else events[-12:]

    latest_lines: list[str] = []
    for e in recent_events:
        ts = e.get("ts")
        msg = str(e.get("msg") or "")
        if isinstance(ts, float):
            latest_lines.append(f"[{ts:8.3f}] {msg}")
        else:
            latest_lines.append(msg)

    resets_recent = (
        counts_recent.get("reset_superspeed", 0)
        + counts_recent.get("reset_highspeed", 0)
        + counts_recent.get("disconnect", 0)
    )
    urb_recent = counts_recent.get("urb_fail", 0)
    if resets_recent == 0 and urb_recent <= 1:
        stability = {"level": "good", "label": "稳定"}
    elif resets_recent <= 1 and urb_recent <= 8:
        stability = {"level": "warn", "label": "轻微抖动"}
    else:
        stability = {"level": "bad", "label": "不稳定"}

    return {
        "ok": True,
        "window_sec": window_sec,
        "kernel_time_max_sec": max_ts,
        "counts_total": counts_total,
        "counts_recent": counts_recent,
        "latest_lines": latest_lines,
        "stability": stability,
    }


CAM_DIAG_CACHE_LOCK = threading.Lock()
CAM_DIAG_CACHE: dict[str, Any] = {"ts": 0.0, "payload": None}


def _camera_diag_payload(force_refresh: bool = False) -> dict[str, Any]:
    now = time.time()
    with CAM_DIAG_CACHE_LOCK:
        cached_payload = CAM_DIAG_CACHE.get("payload")
        cached_ts = float(CAM_DIAG_CACHE.get("ts") or 0.0)
        if not force_refresh and isinstance(cached_payload, dict) and (now - cached_ts) <= CAM_DIAG_CACHE_TTL_SEC:
            return cached_payload

    profile_ok, profile, profile_msg, profile_status = _http_get_json(VISION_API_BASE, "/api/vision/profile", timeout_sec=2.0)
    request = profile.get("request") if isinstance(profile, dict) else {}
    if not isinstance(request, dict):
        request = {}
    camera_hint = request.get("camera") if isinstance(request.get("camera"), str) else None

    resolved = _resolve_camera_device(camera_hint)
    capture = _v4l2_capture_state(resolved.get("resolved_path"))
    usb = _usb_info_from_video_node(resolved.get("video_node"))
    dmesg_stats = _camera_dmesg_stats(usb.get("port_id") if isinstance(usb, dict) else None, CAM_DIAG_WINDOW_SEC)

    payload: dict[str, Any] = {
        "ok": bool(resolved.get("exists")),
        "timestamp": _ts_now(),
        "profile": {
            "ok": profile_ok,
            "status": profile_status,
            "error": None if profile_ok else profile_msg,
            "current": profile.get("current") if isinstance(profile, dict) else None,
            "camera_hint": camera_hint,
        },
        "device": resolved,
        "capture": capture,
        "usb": usb,
        "dmesg": dmesg_stats,
    }

    stability = dmesg_stats.get("stability") if isinstance(dmesg_stats, dict) else {}
    payload["stability"] = stability if isinstance(stability, dict) else {"level": "warn", "label": "未知"}

    with CAM_DIAG_CACHE_LOCK:
        CAM_DIAG_CACHE["ts"] = now
        CAM_DIAG_CACHE["payload"] = payload
    return payload


class _MetricSampler:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.prev_time = time.time()
        self.prev_cpu_total, self.prev_cpu_idle = self._read_cpu_totals()
        self.prev_net = self._read_net_counters()
        self.prev_disk = self._read_disk_counters()
        self.prev_npu_active, self.prev_npu_suspended, _ = self._read_npu_runtime_counters()

    def _read_cpu_totals(self) -> tuple[int, int]:
        with open("/proc/stat", "r", encoding="utf-8") as f:
            first = f.readline().strip()
        fields = first.split()
        values = [int(v) for v in fields[1:]]
        total = sum(values)
        idle = values[3] + (values[4] if len(values) > 4 else 0)
        return total, idle

    def _cpu_usage_percent(self) -> float:
        total, idle = self._read_cpu_totals()
        delta_total = total - self.prev_cpu_total
        delta_idle = idle - self.prev_cpu_idle
        self.prev_cpu_total = total
        self.prev_cpu_idle = idle
        if delta_total <= 0:
            return 0.0
        busy = delta_total - delta_idle
        return max(0.0, min(100.0, busy * 100.0 / delta_total))

    def _memory_info(self) -> dict[str, Any]:
        info_kb: dict[str, int] = {}
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                key, rest = line.split(":", 1)
                value = rest.strip().split()[0]
                if value.isdigit():
                    info_kb[key] = int(value)
        mem_total = info_kb.get("MemTotal", 0) * 1024
        mem_available = info_kb.get("MemAvailable", 0) * 1024
        mem_used = max(0, mem_total - mem_available)
        swap_total = info_kb.get("SwapTotal", 0) * 1024
        swap_free = info_kb.get("SwapFree", 0) * 1024
        swap_used = max(0, swap_total - swap_free)
        mem_used_pct = (mem_used * 100.0 / mem_total) if mem_total else 0.0
        swap_used_pct = (swap_used * 100.0 / swap_total) if swap_total else 0.0
        return {
            "total": mem_total,
            "used": mem_used,
            "available": mem_available,
            "used_percent": mem_used_pct,
            "swap_total": swap_total,
            "swap_used": swap_used,
            "swap_used_percent": swap_used_pct,
        }

    def _disk_usage(self) -> dict[str, Any]:
        st = os.statvfs("/")
        total = st.f_frsize * st.f_blocks
        free = st.f_frsize * st.f_bavail
        used = max(0, total - free)
        used_pct = (used * 100.0 / total) if total else 0.0
        return {"total": total, "used": used, "free": free, "used_percent": used_pct}

    def _block_devices(self) -> list[str]:
        base = Path("/sys/block")
        devices: list[str] = []
        if not base.exists():
            return devices
        for dev in sorted(p.name for p in base.iterdir() if p.is_dir()):
            if dev.startswith(("loop", "ram", "zram", "fd")):
                continue
            devices.append(dev)
        return devices

    def _read_disk_counters(self) -> dict[str, int]:
        devices = set(self._block_devices())
        read_bytes = 0
        write_bytes = 0
        with open("/proc/diskstats", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split()
                if len(parts) < 10:
                    continue
                name = parts[2]
                if name not in devices:
                    continue
                sectors_read = int(parts[5])
                sectors_written = int(parts[9])
                read_bytes += sectors_read * 512
                write_bytes += sectors_written * 512
        return {"read_bytes": read_bytes, "write_bytes": write_bytes}

    def _read_net_counters(self) -> dict[str, dict[str, Any]]:
        counters: dict[str, dict[str, Any]] = {}
        with open("/proc/net/dev", "r", encoding="utf-8") as f:
            lines = f.readlines()[2:]
        for line in lines:
            if ":" not in line:
                continue
            iface, values_blob = line.split(":", 1)
            iface = iface.strip()
            if iface == "lo":
                continue
            values = values_blob.split()
            if len(values) < 16:
                continue
            rx = int(values[0])
            tx = int(values[8])
            state = _read_text(f"/sys/class/net/{iface}/operstate") or "unknown"
            counters[iface] = {"rx_bytes": rx, "tx_bytes": tx, "state": state}
        return counters

    def _thermal(self) -> list[dict[str, Any]]:
        zones: list[dict[str, Any]] = []
        base = Path("/sys/class/thermal")
        if not base.exists():
            return zones
        for zone in sorted(base.glob("thermal_zone*")):
            raw = _read_int(str(zone / "temp"))
            if raw is None:
                continue
            celsius = raw / 1000.0 if raw > 1000 else float(raw)
            if celsius < -50 or celsius > 200:
                continue
            zones.append({"name": _read_text(str(zone / "type")) or zone.name, "temp_c": celsius})
        return zones

    def _ina_sensors(self) -> list[dict[str, Any]]:
        sensors: list[dict[str, Any]] = []
        for hwmon in sorted(Path("/sys/class/hwmon").glob("hwmon*")):
            name = _read_text(str(hwmon / "name")).lower()
            if not name.startswith("ina"):
                continue
            mv = _read_int(str(hwmon / "in1_input"))
            ma = _read_int(str(hwmon / "curr1_input"))
            uw = _read_int(str(hwmon / "power1_input"))
            sensors.append(
                {
                    "name": _read_text(str(hwmon / "name")) or hwmon.name,
                    "voltage_v": (mv / 1000.0) if mv is not None else None,
                    "current_a": (ma / 1000.0) if ma is not None else None,
                    "power_w": (uw / 1000000.0) if uw is not None else None,
                }
            )
        return sensors

    def _read_npu_runtime_counters(self) -> tuple[int | None, int | None, str | None]:
        active = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_active_time")
        suspended = _read_int("/sys/devices/platform/fdab0000.npu/power/runtime_suspended_time")
        runtime_status = _read_text("/sys/devices/platform/fdab0000.npu/power/runtime_status") or None
        return active, suspended, runtime_status

    def _npu_info(self) -> dict[str, Any]:
        usage_percent: float | None = None
        cores: list[float] = []
        freq_hz: int | None = None
        power_state = _read_text("/sys/kernel/debug/rknpu/power") or None
        runtime_active, runtime_suspended, runtime_status = self._read_npu_runtime_counters()
        runtime_usage_percent: float | None = None

        load_text = _read_text("/sys/kernel/debug/rknpu/load")
        if load_text:
            for value in re.findall(r"Core\d+:\s*([0-9]+)%", load_text):
                try:
                    cores.append(float(value))
                except ValueError:
                    continue
            if cores:
                usage_percent = sum(cores) / len(cores)

        freq_text = _read_text("/sys/kernel/debug/rknpu/freq")
        if freq_text:
            try:
                freq_hz = int(freq_text)
            except ValueError:
                match = re.search(r"([0-9]{6,})", freq_text)
                if match:
                    freq_hz = int(match.group(1))

        prev_active = self.prev_npu_active
        prev_suspended = self.prev_npu_suspended
        self.prev_npu_active = runtime_active
        self.prev_npu_suspended = runtime_suspended
        if (
            runtime_active is not None
            and runtime_suspended is not None
            and prev_active is not None
            and prev_suspended is not None
        ):
            delta_active = runtime_active - prev_active
            delta_suspended = runtime_suspended - prev_suspended
            total_delta = delta_active + delta_suspended
            if delta_active >= 0 and delta_suspended >= 0 and total_delta > 0:
                runtime_usage_percent = max(0.0, min(100.0, delta_active * 100.0 / total_delta))

        devfreq_text = _read_text("/sys/class/devfreq/fdab0000.npu/load")
        if devfreq_text:
            match = re.search(r"([0-9]+)\s*@\s*([0-9]+)\s*Hz", devfreq_text)
            if match:
                if freq_hz is None:
                    freq_hz = int(match.group(2))
            elif usage_percent is None and runtime_usage_percent is None and not load_text:
                match = re.search(r"([0-9]+)", devfreq_text)
                if match:
                    usage_percent = float(match.group(1))

        if runtime_usage_percent is not None:
            usage_percent = runtime_usage_percent
        elif usage_percent is None and runtime_status == "suspended" and power_state == "off":
            usage_percent = 0.0

        if usage_percent is not None:
            usage_percent = max(0.0, min(100.0, usage_percent))

        return {
            "available": bool(load_text or devfreq_text or freq_hz is not None or power_state),
            "usage_percent": usage_percent,
            "cores": cores,
            "freq_hz": freq_hz,
            "power_state": power_state,
            "runtime_status": runtime_status,
            "runtime_usage_percent": runtime_usage_percent,
            "usage_source": (
                "runtime_active_ratio"
                if runtime_usage_percent is not None
                else "debugfs_core_load"
                if cores
                else "devfreq_load"
                if devfreq_text
                else "unknown"
            ),
        }

    def _process_snapshot(self) -> list[dict[str, Any]]:
        result = subprocess.run(
            ["ps", "-eo", "pid,comm,%cpu,%mem", "--no-headers"],
            capture_output=True,
            text=True,
            check=False,
        )
        rows: list[dict[str, Any]] = []
        for line in result.stdout.strip().splitlines():
            parts = line.split(None, 3)
            if len(parts) != 4:
                continue
            try:
                rows.append(
                    {
                        "pid": int(parts[0]),
                        "name": parts[1],
                        "cpu_percent": float(parts[2]),
                        "mem_percent": float(parts[3]),
                    }
                )
            except ValueError:
                continue
        return rows

    def sample(self) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            dt = max(0.2, now - self.prev_time)

            cpu_percent = self._cpu_usage_percent()
            mem = self._memory_info()
            disk = self._disk_usage()
            net_now = self._read_net_counters()
            disk_now = self._read_disk_counters()
            thermal = self._thermal()
            ina = self._ina_sensors()
            npu = self._npu_info()
            process_snapshot = self._process_snapshot()
            top_cpu = sorted(process_snapshot, key=lambda row: float(row.get("cpu_percent", 0.0)), reverse=True)[:5]
            top_mem = sorted(process_snapshot, key=lambda row: float(row.get("mem_percent", 0.0)), reverse=True)[:5]

            interfaces: list[dict[str, Any]] = []
            for iface, values in sorted(net_now.items()):
                prev = self.prev_net.get(iface, values)
                rx_rate = max(0.0, (values["rx_bytes"] - prev["rx_bytes"]) / dt)
                tx_rate = max(0.0, (values["tx_bytes"] - prev["tx_bytes"]) / dt)
                interfaces.append(
                    {
                        "name": iface,
                        "state": values["state"],
                        "rx_bytes": values["rx_bytes"],
                        "tx_bytes": values["tx_bytes"],
                        "rx_rate": rx_rate,
                        "tx_rate": tx_rate,
                    }
                )

            read_rate = max(0.0, (disk_now["read_bytes"] - self.prev_disk["read_bytes"]) / dt)
            write_rate = max(0.0, (disk_now["write_bytes"] - self.prev_disk["write_bytes"]) / dt)
            max_temp = max((z["temp_c"] for z in thermal), default=None)
            total_power = sum(v["power_w"] for v in ina if v["power_w"] is not None)
            uptime_seconds = 0.0
            try:
                uptime_seconds = float(_read_text("/proc/uptime").split()[0])
            except (IndexError, ValueError):
                pass
            load1, load5, load15 = os.getloadavg()
            payload = {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "uptime_seconds": uptime_seconds,
                "cpu": {"usage_percent": cpu_percent, "load": [load1, load5, load15]},
                "memory": mem,
                "disk": {
                    **disk,
                    "read_bytes": disk_now["read_bytes"],
                    "write_bytes": disk_now["write_bytes"],
                    "read_rate": read_rate,
                    "write_rate": write_rate,
                },
                "network": interfaces,
                "thermal": thermal,
                "max_temp_c": max_temp,
                "power": {"total_w": total_power, "sensors": ina},
                "npu": npu,
                "processes": top_cpu,
                "processes_cpu": top_cpu,
                "processes_mem": top_mem,
            }
            self.prev_time = now
            self.prev_net = net_now
            self.prev_disk = disk_now
            return payload


LOCAL_METRIC_SAMPLER = _MetricSampler()


def _timeout_for_route(route_path: str) -> float:
    if route_path.startswith("/api/llm/") or route_path.startswith("/api/agent/"):
        return GUI_TIMEOUT_LONG_SEC
    if route_path.startswith("/api/vision/stream.mjpg"):
        return GUI_TIMEOUT_LONG_SEC
    if route_path.startswith("/api/vision/"):
        return GUI_TIMEOUT_MEDIUM_SEC
    return GUI_TIMEOUT_SHORT_SEC


def _http_probe_json(base_url: str, path: str, timeout_sec: float = 2.0) -> tuple[bool, str, int]:
    conn: http.client.HTTPConnection | None = None
    try:
        conn, _target = open_connection(base_url, timeout_sec=timeout_sec)
        req_path = compose_request_path(base_url, path)
        conn.request("GET", req_path, headers={"Accept": "application/json"})
        resp = conn.getresponse()
        status = int(resp.status)
        body = resp.read()
        text = body.decode("utf-8", errors="replace") if body else ""
        ok = 200 <= status < 300
        if ok:
            return True, f"status={status}", status
        detail = text[:120] if text else f"status={status}"
        return False, detail, status
    except Exception as exc:
        return False, str(exc), 0
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def _api_owner(route_path: str) -> str | None:
    if route_path in API_EXACT_MAP:
        return API_EXACT_MAP[route_path]
    for prefix, base in API_PREFIX_MAP:
        if route_path.startswith(prefix):
            return base
    return None


def _is_removed_tools_route(route_path: str) -> bool:
    return route_path == "/api/tools" or route_path.startswith("/api/tools/")


class GUIPreviewHandler(BaseHTTPRequestHandler):
    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", CORS_ALLOW_METHODS)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            return

    def _send_no_content(self) -> None:
        self.send_response(204)
        self.send_header("Allow", CORS_ALLOW_METHODS)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", CORS_ALLOW_METHODS)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _safe_static_path(self, route_path: str) -> Path | None:
        mapped = PAGE_ROUTES.get(route_path)
        if mapped is not None:
            target = (STATIC_DIR / mapped).resolve()
        else:
            clean = route_path.lstrip("/")
            if not clean:
                clean = "index.html"
            target = (STATIC_DIR / clean).resolve()
        try:
            target.relative_to(STATIC_DIR)
        except ValueError:
            return None
        if not target.exists() or not target.is_file():
            return None
        return target

    def _serve_static(self, route_path: str, head_only: bool = False) -> None:
        target = self._safe_static_path(route_path)
        if target is None:
            self._send_json({"ok": False, "timestamp": _ts_now(), "error": f"static not found: {route_path}"}, status=404)
            return

        ctype, _ = mimetypes.guess_type(str(target))
        if not ctype:
            ctype = "application/octet-stream"
        size = target.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", CORS_ALLOW_METHODS)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
        self.send_header("Content-Length", str(size))
        self.end_headers()
        if head_only:
            return
        body = target.read_bytes()
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            return

    def _read_request_body(self) -> tuple[bytes | None, str]:
        raw_len = self.headers.get("Content-Length", "")
        if not raw_len:
            return b"", ""
        try:
            body_len = int(raw_len)
        except ValueError:
            return None, "invalid Content-Length"
        if body_len < 0:
            return None, "invalid Content-Length"
        if body_len > 16 * 1024 * 1024:
            return None, "request body too large"
        if body_len == 0:
            return b"", ""
        try:
            data = self.rfile.read(body_len)
            return data, ""
        except Exception:
            return None, "failed to read request body"

    def _handle_media_upload(self, body: bytes) -> None:
        content_type = str(self.headers.get("Content-Type", "")).strip()
        if not content_type:
            self._send_json(
                {"ok": False, "timestamp": _ts_now(), "error": "missing Content-Type"},
                status=400,
            )
            return
        env = {
            "REQUEST_METHOD": "POST",
            "CONTENT_TYPE": content_type,
            "CONTENT_LENGTH": str(len(body)),
        }
        fp = io.BytesIO(body)
        try:
            form = cgi.FieldStorage(fp=fp, environ=env, keep_blank_values=True)
        except Exception as exc:
            self._send_json(
                {"ok": False, "timestamp": _ts_now(), "error": f"invalid multipart body: {exc}"},
                status=400,
            )
            return

        file_item = form["file"] if "file" in form else None
        if file_item is None or not getattr(file_item, "file", None):
            self._send_json(
                {"ok": False, "timestamp": _ts_now(), "error": "file is required"},
                status=400,
            )
            return

        query = form.getvalue("query", "")
        mode = form.getvalue("mode", "chat_manual")
        filename = getattr(file_item, "filename", "") or "upload.bin"
        payload = file_item.file.read()
        if not isinstance(payload, (bytes, bytearray)):
            payload = bytes(payload or b"")
        target = _save_uploaded_media(str(filename), bytes(payload))
        self._send_json(
            {
                "ok": True,
                "timestamp": _ts_now(),
                "summary": f"Saved {mode} attachment: {target.name}. Note: {query or 'none'}",
                "trace_id": f"trace-media-{uuid.uuid4().hex[:10]}",
                "path": str(target),
            },
            status=200,
        )

    def _normalize_forward_path(self, route_path: str) -> str:
        if route_path == "/api/vision/profile/set":
            parts = urlsplit(self.path)
            query = parse_qs(parts.query or "", keep_blank_values=True)
            name = (query.get("name", [""])[0] or "").strip()
            alias = _normalize_profile_alias(name)
            if alias != (name or "").strip().lower():
                query["name"] = [alias]
                return f"{parts.path}?{urlencode(query, doseq=True)}"
        return self.path

    def _build_forward_headers(self, body: bytes | None) -> dict[str, str]:
        out: dict[str, str] = {}
        for key, value in self.headers.items():
            lk = key.lower().strip()
            if lk in HOP_BY_HOP:
                continue
            if lk == "host":
                continue
            if lk == "content-length":
                continue
            if str(value).strip() == "":
                continue
            out[key] = str(value).strip()

        forwarded_for = self.headers.get("X-Forwarded-For", "").strip()
        client_ip = self.client_address[0] if isinstance(self.client_address, tuple) else "local"
        if forwarded_for:
            out["X-Forwarded-For"] = f"{forwarded_for}, {client_ip}"
        else:
            out["X-Forwarded-For"] = client_ip
        out["X-Forwarded-Proto"] = "http"
        out["X-Forwarded-Host"] = self.headers.get("Host", f"{HOST}:{PORT}")
        if "X-Request-Id" not in out:
            out["X-Request-Id"] = f"gui-{uuid.uuid4().hex[:12]}"

        if body is not None:
            out["Content-Length"] = str(len(body))
        return out

    def _open_upstream(self, base_url: str, timeout_sec: float) -> tuple[http.client.HTTPConnection, str, bool]:
        conn, target = open_connection(base_url, timeout_sec=timeout_sec)
        is_https = target.scheme == "https"
        return conn, (target.base_path or ""), is_https

    def _stream_upstream_response(self, upstream: http.client.HTTPResponse, head_only: bool = False) -> None:
        is_sse = False
        try:
            content_type = str(upstream.getheader("Content-Type", "")).lower()
            is_sse = "text/event-stream" in content_type
        except Exception:
            is_sse = False
        self.send_response(upstream.status, upstream.reason)

        for key, value in upstream.getheaders():
            lk = key.lower().strip()
            if lk in HOP_BY_HOP:
                continue
            if lk in (
                "server",
                "date",
                "cache-control",
                "access-control-allow-origin",
                "access-control-allow-methods",
                "access-control-allow-headers",
            ):
                continue
            self.send_header(key, value)

        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", CORS_ALLOW_METHODS)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-Id, X-Trace-Id")
        self.end_headers()

        if head_only:
            return

        try:
            if is_sse:
                # SSE must be flushed line-by-line to keep token streaming visible in GUI.
                while True:
                    chunk = upstream.readline()
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
            else:
                while True:
                    chunk = upstream.read(STREAM_CHUNK_SIZE)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
        except (socket.timeout, TimeoutError):
            # Stream timeout after headers are sent: close gracefully without sending a second response.
            self.close_connection = True
            return
        except (BrokenPipeError, ConnectionResetError):
            return

    def _forward_api(self, method: str, body: bytes | None, head_only: bool = False) -> None:
        route_path = urlsplit(self.path).path
        base = _api_owner(route_path)
        if base is None:
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"api route not owned by gui gateway: {route_path}",
                },
                status=404,
            )
            return

        conn: http.client.HTTPConnection | None = None
        upstream: http.client.HTTPResponse | None = None
        try:
            timeout_sec = _timeout_for_route(route_path)
            conn, base_path, _ = self._open_upstream(base, timeout_sec=timeout_sec)
            req_path = self._normalize_forward_path(route_path)
            if base_path and base_path != "/":
                req_path = f"{base_path.rstrip('/')}{req_path}"

            headers = self._build_forward_headers(body)
            upstream_method = "GET" if method == "HEAD" else method
            conn.request(method=upstream_method, url=req_path, body=body, headers=headers)
            upstream = conn.getresponse()
            self._stream_upstream_response(upstream, head_only=head_only)
            return
        except Exception as exc:
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"forward failed: {exc}",
                    "route": route_path,
                    "upstream": base,
                },
                status=502,
            )
            return
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except Exception:
                    pass
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def _health_payload(self, force_deps_mode: bool = False) -> tuple[int, dict[str, Any]]:
        llm_up, llm_msg, llm_status = _http_probe_json(LLM_API_BASE, "/api/llm/health", timeout_sec=2.0)
        agent_up, agent_msg, agent_status = _http_probe_json(AGENT_API_BASE, "/api/agent/health", timeout_sec=2.0)
        vision_up, vision_msg, vision_status = _http_probe_json(VISION_API_BASE, "/health", timeout_sec=2.0)
        metrics_source = "local:/api/metrics"
        try:
            sample = LOCAL_METRIC_SAMPLER.sample()
            metrics_up = isinstance(sample, dict)
            metrics_msg = "local sampler ok" if metrics_up else "local sampler invalid"
            metrics_status = 200 if metrics_up else 503
        except Exception as exc:
            metrics_up = False
            metrics_msg = str(exc)
            metrics_status = 503

        self_up = STATIC_DIR.exists() and STATIC_DIR.is_dir()
        self_detail = "static dir ready" if self_up else f"static dir invalid: {STATIC_DIR}"
        deps_ok = llm_up and agent_up and vision_up and metrics_up
        mode = "deps" if force_deps_mode else HEALTH_MODE
        ok = deps_ok if mode == "deps" else self_up

        return (200 if ok else 503), {
            "ok": ok,
            "timestamp": _ts_now(),
            "service": "gui-preview-v3",
            "listen": f"{HOST}:{PORT}",
            "static_dir": str(STATIC_DIR),
            "health_mode": mode,
            "health_semantics": {
                "self": "gui process + static directory readiness",
                "deps": "llm && agent && vision && metrics",
            },
            "routes": {
                "llm": LLM_API_BASE,
                "agent": AGENT_API_BASE,
                "vision": VISION_API_BASE,
                "metrics": metrics_source,
                "camera_diag": "local:/api/camera/diag",
                "tools": "removed:/api/tools* -> use /api/agent/command",
            },
            "self": {"up": self_up, "detail": self_detail},
            "deps_ok": deps_ok,
            "deps": {
                "llm": {"up": llm_up, "status": llm_status, "detail": llm_msg, "probe": "/api/llm/health"},
                "agent": {"up": agent_up, "status": agent_status, "detail": agent_msg, "probe": "/api/agent/health"},
                "vision": {"up": vision_up, "status": vision_status, "detail": vision_msg, "probe": "/health"},
                "metrics": {"up": metrics_up, "status": metrics_status, "detail": metrics_msg, "probe": "/api/metrics"},
            },
        }

    def do_OPTIONS(self) -> None:
        route_path = urlsplit(self.path).path
        if route_path in ("/health", "/health/deps"):
            self._send_no_content()
            return
        if _is_removed_tools_route(route_path):
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"gone: {route_path}",
                    "detail": "gui /api/tools* routes were removed; use /api/agent/command",
                },
                status=410,
            )
            return
        if route_path.startswith("/api/"):
            if route_path in ("/api/metrics", "/api/camera/diag"):
                self._send_no_content()
                return
            if _api_owner(route_path) is None:
                self._send_json(
                    {
                        "ok": False,
                        "timestamp": _ts_now(),
                        "error": f"api route not owned by gui gateway: {route_path}",
                    },
                    status=404,
                )
                return
            self._send_no_content()
            return
        if self._safe_static_path(route_path) is None:
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"static not found: {route_path}",
                },
                status=404,
            )
            return
        self._send_no_content()

    def do_HEAD(self) -> None:
        self._dispatch(head_only=True)

    def do_GET(self) -> None:
        self._dispatch(head_only=False)

    def do_POST(self) -> None:
        self._dispatch(head_only=False)

    def do_PUT(self) -> None:
        self._dispatch(head_only=False)

    def do_PATCH(self) -> None:
        self._dispatch(head_only=False)

    def do_DELETE(self) -> None:
        self._dispatch(head_only=False)

    def do_TRACE(self) -> None:
        self._dispatch(head_only=False)

    def do_CONNECT(self) -> None:
        self._dispatch(head_only=False)

    def _dispatch(self, head_only: bool) -> None:
        route_path = urlsplit(self.path).path

        if route_path == "/health":
            status, payload = self._health_payload()
            self._send_json(payload, status=status)
            return
        if route_path == "/health/deps":
            status, payload = self._health_payload(force_deps_mode=True)
            self._send_json(payload, status=status)
            return

        if _is_removed_tools_route(route_path):
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"gone: {route_path}",
                    "detail": "gui /api/tools* routes were removed; use /api/agent/command",
                },
                status=410,
            )
            return

        if route_path.startswith("/api/"):
            if route_path == "/api/metrics" and self.command in ("GET", "HEAD"):
                try:
                    payload = LOCAL_METRIC_SAMPLER.sample()
                    self._send_json(payload, status=200)
                except Exception as exc:
                    self._send_json(
                        {
                            "ok": False,
                            "timestamp": _ts_now(),
                            "error": f"local metrics failed: {exc}",
                        },
                        status=503,
                    )
                return
            if route_path == "/api/camera/diag" and self.command in ("GET", "HEAD"):
                try:
                    force = str(self.headers.get("X-Force-Refresh", "")).strip() == "1"
                    payload = _camera_diag_payload(force_refresh=force)
                    self._send_json(payload, status=200 if payload.get("ok") else 503)
                except Exception as exc:
                    self._send_json(
                        {
                            "ok": False,
                            "timestamp": _ts_now(),
                            "error": f"camera diag failed: {exc}",
                        },
                        status=503,
                    )
                return
            if self.command in ("GET", "HEAD"):
                self._forward_api(self.command, body=None, head_only=head_only)
                return
            if self.command in ("POST", "PUT", "PATCH", "DELETE"):
                body, err = self._read_request_body()
                if body is None:
                    self._send_json({"ok": False, "timestamp": _ts_now(), "error": err}, status=400)
                    return
                if route_path == "/api/upload/media" and self.command == "POST":
                    self._handle_media_upload(body)
                    return
                self._forward_api(self.command, body=body, head_only=False)
                return
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"method not allowed: {self.command}",
                },
                status=405,
            )
            return

        if self.command not in ("GET", "HEAD"):
            self._send_json(
                {
                    "ok": False,
                    "timestamp": _ts_now(),
                    "error": f"method not allowed for static route: {self.command}",
                },
                status=405,
            )
            return

        self._serve_static(route_path, head_only=head_only)

    def log_message(self, fmt: str, *args: Any) -> None:
        message = fmt % args if args else fmt
        remote = "local"
        port = 0
        if isinstance(self.client_address, tuple):
            if len(self.client_address) > 0:
                remote = str(self.client_address[0])
            if len(self.client_address) > 1:
                try:
                    port = int(self.client_address[1])
                except Exception:
                    port = 0
        print(
            f"{datetime.now().isoformat(timespec='seconds')} "
            f"gui-preview {remote}:{port} {message}"
        )


def main() -> None:
    server = bind_server(HOST, PORT, GUIPreviewHandler, unix_socket_path=UNIX_SOCKET_PATH)
    print(
        "gui preview v3 listening on "
        f"{('unix://' + UNIX_SOCKET_PATH) if UNIX_SOCKET_PATH else ('http://' + HOST + ':' + str(PORT))} "
        f"(llm={LLM_API_BASE}, agent={AGENT_API_BASE}, vision={VISION_API_BASE})"
    )
    server.serve_forever()


if __name__ == "__main__":
    main()
