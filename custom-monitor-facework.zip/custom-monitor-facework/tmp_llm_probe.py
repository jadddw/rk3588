
import json, urllib.request
cases = [
    {"name":"short64","message":"Please briefly say hello.","max_tokens":64,"timeout_sec":12},
    {"name":"longask64","message":"Explain in detail the architecture, modules, data flow, deployment path, and current limitations of this project in Chinese, and expand as much as possible.","max_tokens":64,"timeout_sec":12},
    {"name":"longask128","message":"Explain in detail the architecture, modules, data flow, deployment path, and current limitations of this project in Chinese, and expand as much as possible.","max_tokens":128,"timeout_sec":12},
    {"name":"longprompt128","message":"You are a project assistant. Answer in Chinese and be detailed. Cover architecture, modules, data flow, deployment, current version boundaries, and demo path. Keep it coherent and expanded. Project knowledge: access control with face recognition and smart lock; multimodal perception with pool vision plus temperature, pH, turbidity, water level; abnormal object localization; XY gantry cleanup; app and LLM interaction; full closed loop smart aquaculture. Now explain the full project in detail.","max_tokens":128,"timeout_sec":12},
]
url='http://127.0.0.1:8091/api/llm/chat'
for case in cases:
    payload={"message":case["message"],"tools":[],"attach_vision":False,"max_retries":0,"timeout_sec":case["timeout_sec"],"max_tokens":case["max_tokens"]}
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'})
    print('===', case['name'], '===')
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            body = r.read().decode('utf-8','replace')
            print(body[:1500])
    except Exception as e:
        print('ERR', repr(e))
