
    let currentAttendanceSettings = null;

    function escapeHtml(value) {
      return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
    }

    function formatTime(value) {
      const text = String(value || "").trim();
      if (!text) return "未打卡";
      return text.replace("T", " ");
    }

    function formatMinutes(minutes) {
      const value = Number(minutes || 0);
      if (!Number.isFinite(value) || value <= 0) return "-";
      if (value % 60 === 0) {
        const hours = value / 60;
        if (hours % 24 === 0) {
          const days = hours / 24;
          return `${days} 天`;
        }
        return `${hours} 小时`;
      }
      return `${value} 分钟`;
    }

    function renderSettings(settings) {
      const clean = settings && typeof settings === "object" ? settings : {};
      currentAttendanceSettings = clean;
      const minutes = Number(clean.attendance_recheck_interval_minutes || 1440);
      const input = document.getElementById("intervalMinutesInput");
      input.value = String(Number.isFinite(minutes) && minutes > 0 ? minutes : 1440);
      const note = document.getElementById("configNote");
      note.textContent = `当前有效期：${formatMinutes(minutes)}。超过这个时间后，账号会自动变成“需要重新打卡”。`;
    }

    function buildPlaceholder(name) {
      const text = String(name || "?").trim();
      return escapeHtml(text.slice(0, 1) || "?");
    }

    function renderAccounts(accounts) {
      const grid = document.getElementById("grid");
      const emptyState = document.getElementById("emptyState");
      if (!Array.isArray(accounts) || accounts.length === 0) {
        grid.hidden = true;
        grid.innerHTML = "";
        emptyState.hidden = false;
        return;
      }

      emptyState.hidden = true;
      grid.hidden = false;
      const cards = accounts.map((item) => {
        const checked = item?.checked_in_valid === true || item?.checked_in_today === true;
        const displayName = escapeHtml(item?.display_name || item?.username || "未命名");
        const username = escapeHtml(item?.username || "-");
        const badgeClass = checked ? "good" : "bad";
        const badgeText = checked ? "已打卡" : "未打卡";
        const nextDue = item?.attendance_next_due_at ? formatTime(item.attendance_next_due_at) : "待下次打卡后生成";
        const intervalText = formatMinutes(item?.attendance_recheck_interval_minutes);
        const portrait = item?.portrait_url
          ? `<img src="${escapeHtml(item.portrait_url)}" alt="${displayName}" loading="lazy" onerror="this.remove(); this.parentNode.querySelector('.portrait-placeholder').hidden = false;">`
          : "";
        const placeholderHidden = item?.portrait_url ? " hidden" : "";
        const note = item?.portrait_url ? "已绑定人脸照片" : "未上传人脸照片";
        return `
          <article class="face-card ${checked ? "checked" : "unchecked"}">
            <div class="portrait">
              ${portrait}
              <div class="portrait-placeholder"${placeholderHidden}>${buildPlaceholder(displayName)}</div>
              <div class="badge ${badgeClass}">${badgeText}</div>
            </div>
            <div class="face-info">
              <div class="face-name">${displayName}</div>
              <div class="face-row">账号：${username}</div>
              <div class="face-row">状态：${note}</div>
              <div class="face-row">最近打卡：${escapeHtml(formatTime(item?.last_check_in_at))}</div>
              <div class="face-row">有效期：${escapeHtml(intervalText)}</div>
              <div class="face-row">下次重打卡：${escapeHtml(nextDue)}</div>
            </div>
          </article>
        `;
      });

      cards.push(`
        <a class="add-card" href="/add_person.html">
          <div class="add-plus">+</div>
          <h2>添加人员</h2>
          <p>新建一个账号，并给这个账号绑定唯一的人脸照片。</p>
        </a>
      `);

      grid.innerHTML = cards.join("");
    }

    function setStatus(message, isError) {
      const bar = document.getElementById("statusBar");
      bar.textContent = message;
      bar.className = isError ? "status-bar error" : "status-bar";
    }

    async function loadAccounts() {
      const refreshBtn = document.getElementById("refreshBtn");
      refreshBtn.disabled = true;
      try {
        const resp = await fetch("/api/vision/accounts", { cache: "no-store" });
        const payload = await resp.json();
        if (!resp.ok || payload?.ok === false) {
          throw new Error(String(payload?.error || `HTTP ${resp.status}`));
        }

        const accounts = Array.isArray(payload?.accounts) ? payload.accounts : [];
        renderSettings(payload?.settings);
        document.getElementById("countTotal").textContent = String(payload?.count ?? accounts.length ?? 0);
        document.getElementById("countChecked").textContent = String(payload?.checked_in_valid_count ?? payload?.checked_in_today ?? 0);
        document.getElementById("countUnchecked").textContent = String(payload?.needs_recheck_count ?? payload?.unchecked_today ?? 0);
        renderAccounts(accounts);

        const storePath = payload?.account_store_path ? ` 账号库：${payload.account_store_path}` : "";
        const galleryState = payload?.face_gallery_error ? ` 人脸库：${payload.face_gallery_error}` : "";
        const intervalText = payload?.settings?.attendance_recheck_interval_minutes
          ? ` 当前重打卡间隔：${formatMinutes(payload.settings.attendance_recheck_interval_minutes)}`
          : "";
        setStatus(`已加载 ${accounts.length} 个账号。${intervalText}${storePath}${galleryState}`.trim(), false);
      } catch (error) {
        document.getElementById("countTotal").textContent = "-";
        document.getElementById("countChecked").textContent = "-";
        document.getElementById("countUnchecked").textContent = "-";
        renderAccounts([]);
        setStatus(`加载失败：${String(error)}`, true);
      } finally {
        refreshBtn.disabled = false;
      }
    }

    async function saveAttendanceInterval() {
      const btn = document.getElementById("saveIntervalBtn");
      const input = document.getElementById("intervalMinutesInput");
      const value = Number(String(input.value || "").trim());
      if (!Number.isFinite(value) || value < 1 || value > 10080) {
        setStatus("保存失败：请输入 1 到 10080 之间的整数分钟数。", true);
        return;
      }
      btn.disabled = true;
      try {
        const resp = await fetch("/api/vision/accounts/settings", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            attendance_recheck_interval_minutes: Math.round(value),
          }),
        });
        const payload = await resp.json();
        if (!resp.ok || payload?.ok === false) {
          throw new Error(String(payload?.error || `HTTP ${resp.status}`));
        }
        renderSettings(payload?.settings);
        const accounts = Array.isArray(payload?.accounts) ? payload.accounts : [];
        document.getElementById("countTotal").textContent = String(payload?.count ?? accounts.length ?? 0);
        document.getElementById("countChecked").textContent = String(payload?.checked_in_valid_count ?? payload?.checked_in_today ?? 0);
        document.getElementById("countUnchecked").textContent = String(payload?.needs_recheck_count ?? payload?.unchecked_today ?? 0);
        renderAccounts(accounts);
        setStatus(`已保存新的重打卡间隔：${formatMinutes(payload?.settings?.attendance_recheck_interval_minutes || value)}。`, false);
      } catch (error) {
        setStatus(`保存打卡间隔失败：${String(error)}`, true);
      } finally {
        btn.disabled = false;
      }
    }

    document.getElementById("refreshBtn").addEventListener("click", loadAccounts);
    document.getElementById("saveIntervalBtn").addEventListener("click", saveAttendanceInterval);
    loadAccounts();
    window.setInterval(loadAccounts, 10000);
  