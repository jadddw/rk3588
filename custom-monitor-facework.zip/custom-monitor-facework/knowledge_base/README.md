# 智渔灵枢知识库

本目录用于沉淀“智渔灵枢-基于RK3588的生物安全门禁与多模态融合智慧养殖监测系统”的专属知识内容，后续将作为 LLM 聊天助手的人设依据、知识检索来源和现场讲解语料。

知识结构分为两层。

## 第一层：介绍层

面向评委老师、体验者、第一次接触系统的人。
重点回答三个问题：

- 这套系统是什么
- 这套系统能解决什么问题
- 这套系统为什么有价值

当前文件：

- `00_intro_layer/01_system_positioning.md`
- `00_intro_layer/02_core_capabilities.md`
- `00_intro_layer/03_closed_loop_workflow.md`
- `00_intro_layer/04_project_highlights.md`
- `00_intro_layer/05_demo_experience_path.md`

## 第二层：操作和实现原理层

面向答辩追问、深入讲解、系统说明、现场排障和后续 LLM 专项增强。
重点回答四个问题：

- 每个模块怎么工作
- 为什么这样设计
- 当前版本已经做到什么程度
- 现场提问时应该如何准确解释

当前文件：

- `01_operation_and_principle_layer/01_access_control_principle.md`
- `01_operation_and_principle_layer/02_multimodal_perception.md`
- `01_operation_and_principle_layer/03_abnormal_detection_and_localization.md`
- `01_operation_and_principle_layer/04_executor_and_cleanup.md`
- `01_operation_and_principle_layer/05_llm_and_platform.md`
- `01_operation_and_principle_layer/06_current_version_boundaries.md`
- `01_operation_and_principle_layer/07_defense_and_experience_qa.md`

## 使用建议

后续把知识库接入 LLM 时，建议遵循下面的回答顺序：

1. 先判断用户是在问“介绍层”还是“原理层”
2. 若是评委、体验者、展示场景，优先使用介绍层内容
3. 若是技术追问、实现追问、系统解释，优先使用原理层内容
4. 回答时保持项目身份统一，不要把助手回答成通用 AI，而是回答成“智渔灵枢专属讲解与交互助手”

## 项目身份锚点

知识库和后续系统提示词都应长期保持以下统一口径：

- 项目名称：智渔灵枢-基于RK3588的生物安全门禁与多模态融合智慧养殖监测系统
- 项目定位：面向小型智慧养殖场景的边缘人工智能闭环系统
- 核心链路：门禁防闭、环境感知、视觉识别、智能交互、自动处置
- 回答风格：先讲场景价值，再讲系统逻辑，最后讲实现原理与当前边界
